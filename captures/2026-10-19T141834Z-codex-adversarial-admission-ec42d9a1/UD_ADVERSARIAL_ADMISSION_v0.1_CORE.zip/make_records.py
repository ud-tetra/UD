"""Three exactly encoded unit-ball patterns; hashes precede all new fitting."""
import argparse,json
from pathlib import Path
import numpy as np
from bindings import P,sha,freeze
from sketch import sketch

def patterns(name,selection):
 k=np.arange(8191);a=np.arange(37)
 if name=='stationary_port0':return np.zeros((37,8191),np.int64),np.broadcast_to(1-2*(a[:,None]%2),(37,8191)).copy()
 if name=='seeded_onehot':
  rng=np.random.default_rng(219091);return rng.integers(0,62,size=(37,8191),dtype=np.int64),rng.integers(0,2,size=(37,8191),dtype=np.int64)*2-1
 if name=='directed_random_time':
  rng=np.random.default_rng(219090);time=rng.integers(0,2,size=8191,dtype=np.int64)*2-1
  return np.broadcast_to(np.array(selection['channels'],np.int64)[:,None],(37,8191)).copy(),np.array(selection['signs'],np.int64)[:,None]*time[None,:]
 raise ValueError(name)
def select():
 f=freeze();src=P.parent/f['selection_source'];assert sha(src)==f['selection_source_sha256']
 with np.load(src,allow_pickle=False) as z:v=z['right_transpose'][208]
 scores=(sketch().astype(float)@v).reshape(62,37);channels=np.argmax(abs(scores),axis=0);signs=np.where(scores[channels,np.arange(37)]>=0,1,-1)
 row={'channels':channels.tolist(),'signs':signs.tolist(),'source_sha256':sha(src),'rule':'Heuristic maximum absolute binary64 rowdot perprep from knownrightfactor208; frozen table is recipe, no optimalityclaim','tie_rule':'numpyargmax firstchannel'}
 assert not (P/'SELECTION.json').exists();(P/'SELECTION.json').write_text(json.dumps(row,indent=2));(P/'SELECTION_FREEZE.json').write_text(json.dumps({'status':'TABLE_FROZEN_BEFORE_GENERATION','sha256':sha(P/'SELECTION.json'),'protocol_sha256':sha(P/'PROTOCOL_FREEZE.json')},indent=2));return row

def generate(dest,replay=False):
 f=freeze();selection=json.loads((P/'SELECTION.json').read_text());assert sha(P/'SELECTION.json')==json.loads((P/'SELECTION_FREEZE.json').read_text())['sha256']
 base=P.parent/f['baseline'];assert sha(base)==f['baseline_sha256'];Y=np.memmap(base,dtype='<i8',mode='r',shape=(37,8191,62));dest=Path(dest);dest.mkdir(exist_ok=False,parents=True);rows=[]
 for name in f['cases']:
  channels,signs=patterns(name,selection);assert channels.shape==signs.shape==(37,8191) and np.all(abs(signs)==1) and np.all((channels>=0)&(channels<62))
  raw=dest/(name+'.i64le')
  with raw.open('xb') as s:s.truncate(150321232)
  Z=np.memmap(raw,dtype='<i8',mode='r+',shape=Y.shape);Z[:]=Y;tt=np.arange(8191)
  for a in range(37):Z[a,tt,channels[a]]+=signs[a]
  Z.flush();count=0;peak=0
  for k in range(0,8191,256):
   d=Z[:,k:k+256]-Y[:,k:k+256];expected=np.zeros_like(d);ts=np.arange(k,min(k+256,8191))
   for a in range(37):expected[a,np.arange(len(ts)),channels[a,ts]]=signs[a,ts]
   assert np.array_equal(d,expected) and np.all(np.sum(d*d,axis=-1)==1);count+=d.size;peak=max(peak,int(np.sum(d*d,axis=-1).max()))
  row={'case':name,'record_sha256':sha(raw),'bytes':raw.stat().st_size,'readings_checked':count,'vector_integer_squared_error_max':peak,'noise_budget':[1,1<<48],'scalar_quantum':[1,1<<48],'baseline_sha256':sha(base),'new_apparatus_data':False};assert count==18790154;rows.append(row);del Z;print(json.dumps(row),flush=True)
 assert sha(base)==f['baseline_sha256']
 if replay:
  assert rows==json.loads((P/'DATA_FREEZE.json').read_text())['records'];(dest/'RAW_REGENERATION_RECEIPT.json').write_text(json.dumps({'status':'PASS_ALL_THREE_RAW_HASHES_AND_DIFFERENCES','records':rows,'physical_promotion':0},indent=2))
 else:
  assert not (P/'DATA_FREEZE.json').exists();(P/'DATA_FREEZE.json').write_text(json.dumps({'status':'ALL_RAW_HASHES_FROZEN_BEFORE_FITTING','protocol_sha256':sha(P/'PROTOCOL_FREEZE.json'),'selection_freeze_sha256':sha(P/'SELECTION_FREEZE.json'),'records':rows,'physical_promotion':0},indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--regenerate',type=Path);p.add_argument('--select',action='store_true');a=p.parse_args()
 if a.select:select()
 else:generate(a.regenerate or P/'records',a.regenerate is not None)

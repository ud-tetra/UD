"""Lossless exact numerator reconstruction from pinned parent and frozen deltas."""
import json,hashlib,argparse
import numpy as np
from bindings import P,freeze,sha

def materialize(rawdir=None):
 f=freeze();anchor=[]
 for s in f['integer_anchor']:
  q=P.parent/s['path'];assert sha(q)==s['sha256']
  with np.load(q,allow_pickle=False) as z:anchor.append(z['numerator'])
 receipt=json.loads((P/'RAW_PROJECTION_REPLAY.json').read_text());data=json.loads((P/'DATA_FREEZE.json').read_text());count=0
 for case in receipt['cases']:
  folder=P/'results'/case['case'];pieces=[]
  for c in case['chunks']:
   q=P/c['delta_path'];assert sha(q)==c['delta_sha256']
   with np.load(q,allow_pickle=False) as z:delta=z['delta'];assert delta.dtype==np.int16 and delta.shape==tuple(c['integer_shape'])
   assert np.max(np.abs(delta.astype(np.int64)))<=1040
   n=anchor[c['chunk']].astype(np.int64)+delta.astype(np.int64);assert max(abs(int(n.min())),abs(int(n.max())))<2**53
   assert hashlib.sha256(n.astype('<i8').tobytes()).hexdigest()==c['integer_bytes_sha256']
   target=folder/'results'/f'INTEGER_{c["chunk"]}.npz'
   if target.exists():
    with np.load(target,allow_pickle=False) as z:assert np.array_equal(z['numerator'],n)
   else:np.savez_compressed(target,numerator=n)
   pieces.append(n);count+=n.size
  if rawdir is not None:
   from sketch import sketch
   row=next(x for x in data['records'] if x['case']==case['case']);raw=rawdir/(case['case']+'.i64le');assert sha(raw)==row['record_sha256'];Y=np.memmap(raw,dtype='<i8',mode='r',shape=(37,8191,62));X=np.array(Y.transpose(1,2,0).reshape(8191,2294),np.int64);A=sketch();mx=max(abs(int(X.min())),abs(int(X.max())));assert mx*int(np.abs(A).sum(axis=0).max())<2**63;assert np.array_equal(X@A,np.vstack(pieces))
 r={'status':'PASS_LOSSLESS_NUMERATOR_RECONSTRUCTION','integer_entries':count,'complete_raw_reprojection':rawdir is not None,'cases':3,'empty_original_retained_but_not_used_as_numeric_witness':True,'physical_promotion':0};print(json.dumps(r),flush=True);return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--raw-records',type=__import__('pathlib').Path);a=p.parse_args();materialize(a.raw_records)

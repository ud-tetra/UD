"""Constructor packaging source; no data/estimator/gate modification."""
from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
P=Path(__file__).resolve().parent;repo=P.parent/'ud-repo';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ID=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H%M%SZ')+'-codex-adversarial-admission-ec42d9a1';out=repo/'captures'/ID;out.mkdir(exist_ok=False)
raw=[]
for row in json.loads((P/'DATA_FREEZE.json').read_text())['records']:raw.append({'path':'records/'+row['case']+'.i64le','size_bytes':row['bytes'],'sha256':row['record_sha256'],'recovery':'Frozen make_records.py plus pinned encodedstressbaseline'})
nums=[]
for p in sorted(P.glob('results/*/results/INTEGER_*.npz')):nums.append({'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'original_container_sha256':sha(p),'recovery':'Lossless parentN+checkedint16delta; canonicalarraySHA in RAW_PROJECTION_REPLAY.json; compressedZIPbyteidentity not required'})
(P/'OMISSIONS.json').write_text(json.dumps({'raw_records':raw,'generated_numerator_containers':nums,'no_actual_factor_or_emission_omitted':True,'physical_promotion':0},indent=2));omitted={P/x['path'] for x in raw+nums};arrays=[p for p in sorted(P.rglob('*.npz')) if p not in omitted and '__pycache__' not in p.parts];groups=[];g=[];size=0
for p in arrays:
 assert p.stat().st_size<9000000
 if g and size+p.stat().st_size>9000000:groups.append(g);g=[];size=0
 g.append(p);size+=p.stat().st_size
if g:groups.append(g)
entries=[];archives=[]
for k,g in enumerate(groups,1):
 a=out/f'WITNESS_{k:02d}.zip'
 with zipfile.ZipFile(a,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in g:z.write(p,p.relative_to(P).as_posix());entries.append({'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'archive':a.name,'role':'retained_empty_original_not_numeric' if p.stat().st_size==0 else 'numeric_witness'})
 assert a.stat().st_size<12000000;archives.append({'path':a.name,'size_bytes':a.stat().st_size,'sha256':sha(a)})
(P/'ARRAY_INDEX.json').write_text(json.dumps({'files':entries,'archives':archives,'physical_promotion':0},indent=2));files=[p for p in sorted(P.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p not in arrays and p not in omitted and p.name!='PACKAGE_MANIFEST.json']
(P/'PACKAGE_MANIFEST.json').write_text(json.dumps({'files':[{'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in files],'physical_promotion':0},indent=2));files.append(P/'PACKAGE_MANIFEST.json');core=out/'UD_ADVERSARIAL_ADMISSION_v0.1_CORE.zip'
with zipfile.ZipFile(core,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.relative_to(P).as_posix())
for n in ['README.md','THEOREMS.md','PROTOCOL_FREEZE.json','DATA_FREEZE.json','PROVENANCE.json','CLAIM_LEDGER.json','RESULT_SUMMARY.json','GATE_RESULTS.json','EXACT_SHIFT_EXCEEDANCE.json','DERIVED_ARTIFACT_REPAIRS.json','ARRAY_INDEX.json','PACKAGE_MANIFEST.json','OMISSIONS.json']:shutil.copyfile(P/n,out/n)
(out/'BUILD_RECEIPT.json').write_text(json.dumps({'archives':len(archives)+1,'retained_NPZ_files':len(arrays),'empty_original_count':sum(p.stat().st_size==0 for p in arrays),'payload_bytes':sum(p.stat().st_size for p in out.glob('*.zip')),'physical_promotion':0},indent=2))
f={'capture_id':ID,'physical_promotion':0,'status':'FROZEN_ADVERSARIAL_TWO_PASS_ONE_IN_BALL_GATE_HOLD','supersedes':[],'extends':['2026-10-19T134625Z-codex-uniform-output-73b6e18a'],'verification_scope':'Threefreshknownsourceencodedunitballcontrols; fullSVDorder209all; twoadmitted andone4.147204xstrictshiftgateHOLD. No phasefailure/allalgorithmno-go/externalreviewclaim. Oneemptyderivedarchive retainedandnewreplacementboundtoraw.','files':[{'path':p.relative_to(repo).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'status':'Same-team development; externalreviewpending','provenance':'Frozencontrolrecipes andunchangedPR210policy; actualreturnedfactors/exactrawreplay; sourcedcandidateidentification'} for p in sorted(out.iterdir()) if p.is_file()]};(out/'MANIFEST.json').write_text(json.dumps(f,indent=2))
(repo/'events'/f'{ID}.json').write_text(json.dumps({'capture_id':ID,'event':'adversarial_encoded_ball_admission_campaign','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'physical_promotion':0,'summary':'Threefreshunitballrecordslearn209; twoPASS, directedHOLDonlyshiftgate ratio4.147204; exactraw/fullfactorwitnessesretained. Strictpolicy notuniformlyadmittingobservedfamily; notphasefailure. Emptyderivedoriginalpreserved/rederivedlineage. Threeexternalreviewercandidatesidentified, nonecontacted, receiptpending.'},indent=2));(P.parent/'ADVERSARIAL_CAPTURE_PATH.txt').write_text(str(out));print(json.dumps({'capture':str(out),**json.loads((out/'BUILD_RECEIPT.json').read_text())}))

"""Exact rational shift-gate pass/violation; not inferred from a rounded upper alone."""
import sys,json
import numpy as np
from bindings import P,freeze
from flint import arb,fmpq,ctx
ctx.prec=512
sys.path.insert(0,str(P.parent/'record-contract-work'))
from numeric_math import encode,diffnorm
from proof_math import fm,up,down
from fractions import Fraction as F
rows=[]
for name in freeze()['cases']:
 d=P/'results'/name/'results/integer_projection';U=np.vstack([np.load(d/f'FACTOR_{k}.npz')['left'] for k in range(3)])[:,:209]
 with np.load(d/'PHASE_META.npz') as z:T=z['shift']
 un,bu=encode(U);tn,bt=encode(T);norm,pair=diffnorm(fm(un[2:]),bu,fm(un[:-2])*fm(tn),bu+bt);sq=F(*pair);gate2=F(1,1<<68);ratio=(arb(fmpq(sq.numerator,sq.denominator))*(1<<68)).sqrt()
 rows.append({'case':name,'exact_shift_residual_squared':[str(sq.numerator),str(sq.denominator)],'gate_squared':[1,1<<68],'strictly_violates_shift_gate':sq>gate2,'ratio_to_gate_lower':down(ratio),'ratio_to_gate_upper':up(ratio),'readable_ratio':float(ratio.mid()),'new_phase_failure_claimed':False})
assert [x['strictly_violates_shift_gate'] for x in rows]==[False,False,True]
(P/'EXACT_SHIFT_EXCEEDANCE.json').write_text(json.dumps({'status':'VALIDATED_COUNTEREXAMPLE_TO_UNQUALIFIED_UNIVERSAL_ADMISSION_FOR_THIS_RUN_PIPELINE','rows':rows,'not_a_solver_phase_failure_or_all_algorithm_no_go':True,'physical_promotion':0},indent=2));print(json.dumps(rows),flush=True)

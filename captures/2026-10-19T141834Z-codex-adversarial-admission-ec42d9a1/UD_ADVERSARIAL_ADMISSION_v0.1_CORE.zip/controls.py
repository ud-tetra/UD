"""Two isolated numeric/custody controls; originals always remain unchanged."""
import tempfile,shutil,subprocess,json,sys,os
from pathlib import Path
import numpy as np
from bindings import P,sha
before={p.relative_to(P).as_posix():sha(p) for p in P.rglob('*.npz')};rows=[]
with tempfile.TemporaryDirectory(prefix='adversarial-zero-inverse-',dir=P.parent) as td:
 (Path(td)/'record-contract-work').symlink_to(P.parent/'record-contract-work',target_is_directory=True);(Path(td)/'rounding-replay-work').symlink_to(P.parent/'rounding-replay-work',target_is_directory=True)
 q=Path(td)/'fixture';shutil.copytree(P,q,ignore=shutil.ignore_patterns('__pycache__','records','INTEGER_*.npz'));target=q/'results/stationary_port0/results/integer_projection/PHASE_META.npz'
 with np.load(target) as z:d={k:z[k] for k in z.files}
 d['inverse']=np.zeros_like(d['inverse']);np.savez_compressed(target,**d);(q/'GATE_RESULTS.json').unlink();r=subprocess.run([sys.executable,'gates.py'],cwd=q,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'});assert r.returncode==0
 out=json.loads((q/'GATE_RESULTS.json').read_text());x=out['rows'][0];assert x['status']=='HOLD_OUTPUT_GATES' and 'inverse_residual' in x['failed_gates'];rows.append({'control':'zero_proposed_inverse','status':'HOLD_INVERSE_GATE','source_case':'stationary_port0','numeric_gate_evaluated':True})
with tempfile.TemporaryDirectory(prefix='adversarial-delta-tamper-',dir=P.parent) as td:
 (Path(td)/'record-contract-work').symlink_to(P.parent/'record-contract-work',target_is_directory=True);(Path(td)/'rounding-replay-work').symlink_to(P.parent/'rounding-replay-work',target_is_directory=True)
 q=Path(td)/'fixture';shutil.copytree(P,q,ignore=shutil.ignore_patterns('__pycache__','records','INTEGER_*.npz'));target=q/'results/stationary_port0/SKETCH_DELTA_0.npz'
 with np.load(target) as z:d=z['delta'].copy()
 d[0,0]+=1;np.savez_compressed(target,delta=d);r=subprocess.run([sys.executable,'materialize.py'],cwd=q,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'});assert r.returncode!=0 and b'AssertionError' in r.stdout;rows.append({'control':'one_projected_delta_entry_changed','status':'REJECTED_DELTA_HASH','original_provenance_index_unchanged':True})
assert before=={p.relative_to(P).as_posix():sha(p) for p in P.rglob('*.npz')};result={'status':'PASS_TWO_EXPECTED_REFUSALS','controls':rows,'all_original_arrays_unchanged':True,'physical_promotion':0};(P/'CONTROLS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)

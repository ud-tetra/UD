"""Fresh rawrecipe replay and complete projection binding; recover only empty derivedfile."""
import json,io,hashlib
from pathlib import Path
import numpy as np
from bindings import P,sha,freeze
from sketch import sketch
f=freeze();data=json.loads((P/'DATA_FREEZE.json').read_text());folder=P.parent/'adversarial-regenerated-records';A=sketch();anchors=[]
for s in f['integer_anchor']:
 q=P.parent/s['path'];assert sha(q)==s['sha256']
 with np.load(q) as z:anchors.append(z['numerator'])
anchor=np.vstack(anchors);bound=2*np.abs(A).reshape(62,37,321).max(axis=0).sum(axis=0);ranges=[(0,2731),(2731,5462),(5462,8191)];rows=[];repairs=[]
for row in data['records']:
 raw=folder/(row['case']+'.i64le');assert sha(raw)==row['record_sha256'];Y=np.memmap(raw,dtype='<i8',mode='r',shape=(37,8191,62));X=np.array(Y.transpose(1,2,0).reshape(8191,2294),np.int64);mx=max(abs(int(X.min())),abs(int(X.max())));assert mx*int(np.abs(A).sum(axis=0).max())<2**63;N=X@A;delta=N-anchor;assert np.all(np.abs(delta)<=bound[None,:]) and max(abs(int(N.min())),abs(int(N.max())))<2**53;case=P/'results'/row['case'];chunks=[]
 for k,(a,b) in enumerate(ranges):
  with np.load(case/'results'/f'INTEGER_{k}.npz') as z:assert np.array_equal(N[a:b],z['numerator'])
  q=case/f'SKETCH_DELTA_{k}.npz';used=q
  if q.stat().st_size==0:
   used=case/f'SKETCH_DELTA_{k}_RECOVERED.npz';assert not used.exists();buf=io.BytesIO();np.savez_compressed(buf,delta=delta[a:b].astype(np.int16));blob=buf.getvalue()
   with used.open('xb') as stream:stream.write(blob)
   assert sha(used)==hashlib.sha256(blob).hexdigest();repairs.append({'original':q.relative_to(P).as_posix(),'original_bytes':0,'original_sha256':sha(q),'replacement':used.relative_to(P).as_posix(),'replacement_sha256':sha(used),'raw_record_sha256':sha(raw),'original_exact_numerator_chunk_sha256':sha(case/'results'/f'INTEGER_{k}.npz'),'cause':'UNKNOWN_EMPTY_DERIVED_ARCHIVE','method':'FreshrawN minus pinnedcyclicN, alloriginalN entries andpercolumnboundschecked; no estimator/gate retune'})
  with np.load(used) as z:d=z['delta'];assert d.dtype==np.int16 and np.array_equal(d.astype(np.int64),delta[a:b])
  reconstructed=anchors[k]+d.astype(np.int64);assert np.array_equal(reconstructed,N[a:b]);digest=hashlib.sha256(N[a:b].astype('<i8').tobytes()).hexdigest()
  with np.load(case/'results/integer_projection'/f'FACTOR_{k}.npz') as z:assert str(z['projection_sha256'])==hashlib.sha256((reconstructed.astype(float)/2.**55).astype('<f8').tobytes()).hexdigest()
  chunks.append({'chunk':k,'integer_shape':list(N[a:b].shape),'integer_bytes_sha256':digest,'delta_path':used.relative_to(P).as_posix(),'delta_sha256':sha(used)})
 rows.append({'case':row['case'],'raw_sha256':sha(raw),'integer_entries_reprojected':int(N.size),'all_original_numerator_chunks_equal':True,'chunks':chunks});print(json.dumps({'case':row['case'],'status':'PASS_FULL_RAW_TO_PROJECTED_DELTA_LINEAGE'}),flush=True)
(P/'RAW_PROJECTION_REPLAY.json').write_text(json.dumps({'status':'PASS_ALL_THREE_COMPLETE_REPROJECTIONS','cases':rows,'total_integer_entries':3*8191*321,'raw_recipe_regeneration_receipt_sha256':sha(folder/'RAW_REGENERATION_RECEIPT.json'),'physical_promotion':0},indent=2));(P/'DERIVED_ARTIFACT_REPAIRS.json').write_text(json.dumps({'repairs':repairs,'empty_originals_retained':True,'no_numerical_code_gate_or_result_change':True,'physical_promotion':0},indent=2))

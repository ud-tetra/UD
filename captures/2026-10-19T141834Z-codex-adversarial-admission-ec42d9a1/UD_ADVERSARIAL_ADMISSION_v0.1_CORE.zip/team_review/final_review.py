"""Read-only same-team campaign lineage/gate review; no new cases or solver runs."""
from pathlib import Path
from fractions import Fraction
from datetime import datetime,timezone
import hashlib,json
import numpy as np
P=Path(__file__).resolve().parent;W=P.parent/'adversarial-admission-work';H=P.parent/'record-contract-work'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((W/'PROTOCOL_FREEZE.json').read_text());supp=json.loads((W/'SUPPLEMENT_FREEZE.json').read_text())
sources={}
for group,base in [('code_sha256',W),('inputs_sha256',W/'inputs'),('helper_sha256',H)]:
 for n,h in f[group].items():assert sha(base/n)==h;sources[str(base/n)]=h
for n,h in supp['code_sha256'].items():assert sha(W/n)==h;sources[str(W/n)]=h
data=json.loads((W/'DATA_FREEZE.json').read_text());assert data['protocol_sha256']==sha(W/'PROTOCOL_FREEZE.json')
selection=json.loads((W/'SELECTION_FREEZE.json').read_text());assert selection['protocol_sha256']==sha(W/'PROTOCOL_FREEZE.json') and selection['sha256']==sha(W/'SELECTION.json')
assert data['selection_freeze_sha256']==sha(W/'SELECTION_FREEZE.json')
policy=json.loads((W/'inputs/PARENT_GATE_FREEZE.json').read_text())['gates'];assert policy==json.loads((P.parent/'uniform-output-work/FREEZE.json').read_text())['gates']
gates=json.loads((W/'GATE_RESULTS.json').read_text());exceed=json.loads((W/'EXACT_SHIFT_EXCEEDANCE.json').read_text());raw=json.loads((W/'RAW_PROJECTION_REPLAY.json').read_text());repair=json.loads((W/'DERIVED_ARTIFACT_REPAIRS.json').read_text())
regen=P.parent/'adversarial-regenerated-records';regreceipt=json.loads((regen/'RAW_REGENERATION_RECEIPT.json').read_text());assert regreceipt['records']==data['records'];assert sha(regen/'RAW_REGENERATION_RECEIPT.json')==raw['raw_recipe_regeneration_receipt_sha256']
assert [r['case'] for r in gates['rows']]==f['cases']==[r['case'] for r in raw['cases']]
anchors=[]
for s in f['integer_anchor']:
 path=P.parent/s['path'];assert sha(path)==s['sha256'];sources[str(path)]=s['sha256']
 with np.load(path,allow_pickle=False) as z:anchors.append(z['numerator'])
rows=[]
for d,g,e,rr in zip(data['records'],gates['rows'],exceed['rows'],raw['cases']):
 name=d['case'];assert name==g['case']==e['case']==rr['case'];assert d['vector_integer_squared_error_max']==1 and d['readings_checked']==18790154
 assert sha(W/'records'/(name+'.i64le'))==d['record_sha256']==sha(regen/(name+'.i64le'))==g['record_sha256']==rr['raw_sha256']
 exact=Fraction(*map(int,e['exact_shift_residual_squared']));gate2=Fraction(*e['gate_squared']);assert gate2==Fraction(*policy['raw_shift_residual'])**2
 violation=exact>gate2;assert violation==e['strictly_violates_shift_gate']==('raw_shift_residual' in g['failed_gates'])
 assert len(g['checks'])==8 and set(g['checks'])==set(policy)
 for metric,passed in g['checks'].items():
  if passed:assert Fraction(*g['metrics'][metric])<=Fraction(*policy[metric])
 assert g['learned_order']==209 and not g['phase_failure_claimed']
 chunks=[]
 for k,c in enumerate(rr['chunks']):
  deltafile=W/c['delta_path'];assert sha(deltafile)==c['delta_sha256']
  with np.load(deltafile,allow_pickle=False) as z:delta=z['delta']
  assert delta.dtype==np.int16 and np.max(np.abs(delta.astype(np.int64)))<=1040
  reconstructed=anchors[k].astype(np.int64)+delta.astype(np.int64)
  numfile=W/'results'/name/'results'/f'INTEGER_{k}.npz'
  with np.load(numfile,allow_pickle=False) as z:assert np.array_equal(z['numerator'],reconstructed)
  assert hashlib.sha256(reconstructed.astype('<i8').tobytes()).hexdigest()==c['integer_bytes_sha256']
  factor=W/'results'/name/'results/integer_projection'/f'FACTOR_{k}.npz'
  with np.load(factor,allow_pickle=False) as z:assert str(z['projection_sha256'])==hashlib.sha256((reconstructed.astype(float)/2.**55).astype('<f8').tobytes()).hexdigest()
  chunks.append({'chunk':k,'delta_file':c['delta_path'],'delta_sha256':sha(deltafile),'integer_chunk_sha256':sha(numfile),'factor_sha256':sha(factor)})
 rows.append({'case':name,'status':g['status'],'all_eight_gate_checks_retained':True,'failed_gates':g['failed_gates'],'exact_shift_gate_violation':violation,'raw_hash':d['record_sha256'],'projection_chunks':chunks})
assert len(repair['repairs'])==1
rep=repair['repairs'][0];assert (W/rep['original']).stat().st_size==0 and sha(W/rep['original'])==rep['original_sha256'];assert sha(W/rep['replacement'])==rep['replacement_sha256']
assert [r['status'] for r in rows]==['ADMITTED_UNIFORM_OUTPUT_CONTRACT','ADMITTED_UNIFORM_OUTPUT_CONTRACT','HOLD_OUTPUT_GATES']
assert [r['exact_shift_gate_violation'] for r in rows]==[False,False,True]
assert all(sha(Path(p))==h for p,h in sources.items())
reports=['PROTOCOL_FREEZE.json','SELECTION_FREEZE.json','SELECTION.json','DATA_FREEZE.json','SUPPLEMENT_FREEZE.json','GATE_RESULTS.json','EXACT_SHIFT_EXCEEDANCE.json','RAW_PROJECTION_REPLAY.json','DERIVED_ARTIFACT_REPAIRS.json','RUN_EXECUTIONS.json']
result={'status':'PASS_SAME_TEAM_CAMPAIGN_AND_COUNTEREXAMPLE_REVIEW','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),'review_code_sha256':sha(__file__),'scope':'Read-only code/theorem review, exact rational gate checks, actual source hashes and cached integerprojection lineage reconstruction; no new cases/fitting/SVD/full rawprojection execution','source_hashes_before_and_after_equal':sources,'helper_runtime_binding_note':'Frozen bindings.freeze checks code/input hashes; this separate review checks every listed helper before/after review. A composed replay should check helpers around gateexecution.','report_hashes':{n:sha(W/n) for n in reports},'cases':rows,'repair_scope':'One empty deriveddelta archive retained; replacement re-derived from regeneratedrawN/pinnedparentN and checked against all saved integerN/projection hashes. This is not restoration of known preexisting ZIPbytes.','counterexample_scope':'Directed eligible record strictly violates unchanged rawshift admission gate for this executed integerprojection/SVD/lagtwo pipeline. Refutes unqualified all-record admission for this pipeline, not conditional implication, true-phase accuracy, solver convergence or all algorithms.','material_issues':[],'dependencies':['Complete fullfactor exact certificate replay remains a separate replay operation.','Full raw generation/projection arithmetic verified by bound supplemental receipts reviewed here, not rerun by this review.'],'new_estimator_runs':0,'new_SVD_runs':0,'independent_external_review':'PENDING','physical_promotion':0,'lane':'development — no registry entry'}
(P/'FINAL_REVIEW_RECEIPT.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:result[k] for k in ['status','material_issues']}))

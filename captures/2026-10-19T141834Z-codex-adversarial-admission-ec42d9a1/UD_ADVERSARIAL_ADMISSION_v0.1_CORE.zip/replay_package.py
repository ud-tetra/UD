"""Offline complete replay, with optional fresh noise-record regeneration; no newSVD."""
import argparse,json,tempfile,shutil,subprocess,os,sys
from pathlib import Path
from bindings import P,sha

def check():
 for index in ['PACKAGE_MANIFEST.json','ARRAY_INDEX.json']:
  for row in json.loads((P/index).read_text())['files']:
   p=Path(row['path']);assert not p.is_absolute() and '..' not in p.parts;q=P/p
   assert q.is_file() and q.stat().st_size==row['size_bytes'] and sha(q)==row['sha256'],row['path']
def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--raw',action='store_true');p.add_argument('--baseline',type=Path);a=p.parse_args();check();out=a.out.absolute();assert not out.exists();out.mkdir(parents=True);logs=[];receipt={'status':'RUNNING','external_review':'PENDING','physical_promotion':0,'new_SVD_or_estimator_runs':0,'mode':'raw_and_saved_factors' if a.raw else 'saved_factors_only','logs':logs}
 def go(cwd,args,tag):
  log=out/(tag+'.log');r=subprocess.run([sys.executable,*args],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'});log.write_bytes(r.stdout);logs.append({'tag':tag,'argv':args,'exit_code':r.returncode,'log_sha256':sha(log)});assert r.returncode==0,tag
 try:
  from offline_intake import intake
  for key in ['rounding','contract']:intake(a.repo.resolve(),key,out)
  work=out/'adversarial-admission-work';shutil.copytree(P,work,ignore=shutil.ignore_patterns('__pycache__','records','INTEGER_*.npz'))
  f=json.loads((work/'PROTOCOL_FREEZE.json').read_text());helper=out/'record-contract-work'
  for n,h in f['helper_sha256'].items():assert sha(helper/n)==h
  if a.raw:
   assert a.baseline is not None and sha(a.baseline)==f['baseline_sha256'];base=out/f['baseline'];base.parent.mkdir(parents=True);os.link(a.baseline.resolve(),base)
   go(work,['make_records.py','--regenerate',str(out/'adversarial-regenerated-records')],'raw-regeneration')
  go(work,['materialize.py',*(['--raw-records',str(out/'adversarial-regenerated-records')] if a.raw else [])],'materialize')
  # Every captured fullfactor certificate is recomputed; no new numerical SVD called.
  code='import full_svd; from bindings import P,freeze\nfor n in freeze()["cases"]:\n full_svd.P=P/"results"/n\n full_svd.certify("integer_projection")\n'
  go(work,['-c',code],'full-SVD-replay');go(work,['gates.py','--replay'],'all-output-gates');go(work,['exceedance.py'],'strict-shift-exceedance')
  assert json.loads((work/'EXACT_SHIFT_EXCEEDANCE.json').read_text())==json.loads((P/'EXACT_SHIFT_EXCEEDANCE.json').read_text())
  for n,h in f['helper_sha256'].items():assert sha(helper/n)==h
  receipt.update(status='PASS_COMPLETE_CAMPAIGN_REPLAY',cases=3,admitted=2,HOLD=1,helper_hashes_before_after_verified=True,reviewer_identity=None)
 except Exception as e:receipt.update(status='FAIL',error=type(e).__name__+': '+str(e));raise
 finally:(out/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()

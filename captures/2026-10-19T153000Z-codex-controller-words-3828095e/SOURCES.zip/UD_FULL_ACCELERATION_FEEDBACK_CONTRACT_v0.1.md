# Full acceleration-feedback sampling and inverse-mass contract

**25 September 2026 · Development — no registry entry.** Internal claim: conditional sampled full-acceleration and inverse-mass feedback contract. Correspondence: **FORMAL_CORRESPONDENCE**. Physical promotion: **0**. Independent review: **not performed**. No apparatus, physical measurements or numerical SI calibration.

## Outcome and scope

This step completes a conditional error path from sampled position and velocity, through the active emulator's acceleration law and inverse-mass force conversion, into the v109 damping certificate. It treats the full acceleration evaluation separately from damping estimation. The two error fractions have different sensitivities and must not be substituted for one another.

The new plant law uses sampled values for both the acceleration and the inverse-mass conversion. It does not assume access to an exact current mass matrix inside the controller. A force-supremum inequality closes before the inherited comparison theorem is invoked. The proof remains a sufficient engineering contract, not a demonstration that an apparatus can meet it or that the embedded target model describes a natural carrier.

The design and expected qualitative outcomes were frozen before the new numerical budget and symbolic checks. This records constructor execution order, not independent preregistration. All old source files and results remain unchanged.

## 1. Implemented plant and sampling assumptions

Let $Q,v$ be the nine canonical generalized positions and their velocities. Write $M(Q)$ for the v106 positive mass matrix, $N_f(Q)=M(Q)^{-1}$ for its inverse, and $\alpha(Q,v)$ for the ideal acceleration law. The constant-mass active platform follows

$$Q''=\alpha(\widehat Q,\widehat v)+N_f(\widehat Q)\widehat f_d+e_C+e_P+N_f(Q)f_{\rm ext},$$

where $\widehat f_d=-\widehat D\widehat v_d$ is the v109 sampled damping force. The last term represents an **external canonical force channel** in the mathematical plant model, not an additional instruction requiring exact current-state computation. An acceleration disturbance may enter $e_P$ instead; never count it twice.

For each arm, $\widehat Q$ and $\widehat v$ estimate the same historical state at a common stamp $t_\alpha\in[0,s]$, with age at most $h$ and component errors at most $e_Q,e_V$. The damping stamps retain their separate v109 age and error conditions. Schedules are causal, initialized at zero and locally finite, with no unknown prehistory or infinitely many updates in finite time. Estimates are held between updates. Bounded error signals satisfy the inherited local regularity needed for the piecewise ordinary dynamics.

The component bounds $e_C,e_P$ cover, respectively, the complete acceleration-command arithmetic error and plant acceleration error. In particular, $e_C$ covers evaluating and adding both command terms, including the inverse mass times damping force. This is an input assumption about a numerical implementation; the exact replay does not establish a floating-point error certificate.

The controller uses the **same fixed Hamiltonian parameters as the modeled arm**, inside the inherited parameter box. Their allowed mismatch from the ideal comparison remains covered by the old theorem. A further mismatch between the controller's coefficients and its modeled target is not silently covered: it requires a separate evaluation bound or inclusion in a justified command-error allowance. The current result does not cover arbitrary asynchronous position/velocity pairs, unspecified filters or general actuator transfer functions.

## 2. Exact acceleration and force identities

Retain the ambient vector field $F(x;\theta)$, constant position map $L_Q$ and momentum-force injection $C=T_P$. Since $L_QC=0$,

$$v=L_QF(x),\qquad g(x)=L_QDF(x)F(x).$$

The canonical reconstruction is

$$X(Q,v,a_0)=T_QQ+C\bigl(M(Q)v+A(Q)\bigr)+a_0u,$$

and $\alpha(Q,v)=g(X(Q,v,a_0))$. The replay checks $g$ against the canonical flow derivative. The predecessor's Legendre and Euler–Lagrange identities then supply the same acceleration law. The derivative of $g$ along the uniform column $u$ is zero, so the arbitrary conserved leaf value affects neither evaluation nor the bound. The proof uses the true leaf only to compare reconstructed states; no exact measurement of that leaf is required by the controller.

The actual canonical force is exactly

$$f=\widehat f_d+M(Q)\bigl[\alpha(\widehat Q,\widehat v)-\alpha(Q,v)+e_C+e_P\bigr]+\bigl[M(Q)N_f(\widehat Q)-I\bigr]\widehat f_d+f_{\rm ext}.$$

The conversion defect has the identity

$$M(Q)N_f(\widehat Q)-I=M(Q)\bigl[N_f(\widehat Q)-N_f(Q)\bigr].$$

It must be bounded even when the acceleration law is evaluated without arithmetic error. Its zero-error limit is zero, and its position dependence vanishes at $\gamma=0$.

## 3. Reconstruction and polynomial derivative bounds

The inherited trajectory tube has radius one **about its launch**. Its componentwise absolute bounds are the recorded vector $m_a$; these are not all one. Use that actual vector when bounding $F$ and $Dg$. Let $G_1$ be an induced infinity-norm majorant of $Dg$ on $|x_i|\le(m_a)_i$, and $G_2$ the corresponding bound on $|x_i|\le(m_a)_i+1$. Coefficient interval bounds use the complete inherited parameter box and exact rational arithmetic.

For controller reconstruction, use the position radius $q_* = \max_i(|L_Q|m_a)_i+1$ and velocity radius $w+1$. Require $e_Q,e_V\le1$. The v106 global bound is

$$\|M\|_\infty\le\beta=\max\{1/2,4/\mu_{\min}\}.$$

Write $b_c(Q)=2\gamma Q_6u_c(Q)$ for the controller's velocity shift before inversion, so $A=-N^{-1}b_c$ in its two-dimensional block. Define polynomial majorants on the declared position box:

$$B_N\ge\sum_j\|\partial_jN_f\|_\infty,\quad B_b\ge\|b_c\|_\infty,\quad B_{db}\ge\sum_j\|\partial_jb_c\|_\infty.$$

Inverse differentiation gives $\partial_jM=-M(\partial_jN_f)M$. With $c=\|C\|_\infty$ and $q=\|T_Q\|_\infty$, sufficient reconstruction constants are

$$r_Q=q+c\left[\beta^2B_N(w+1+B_b)+\beta B_{db}\right],\qquad r_V=c\beta.$$

The sampled reconstruction error relative to its **same-stamp** true state satisfies

$$\Delta_x=r_Qe_Q+r_Ve_V.$$

Require $\Delta_x\le1$. The interpolating reconstruction segment then lies in the outer absolute box, giving acceleration-estimation error at that stamp at most $G_2\Delta_x$. This enlargement is a proof domain, not permission to let the actual trajectory leave its inherited tube.

## 4. Force enclosure before residual admission

Let $b$ be the held v108 additional-force allowance. Retain a chosen v109 damping fixture with errors $e_{D,d},e_{v,d}$ and actuator allocation $e_{A,d}$. Define

$$F_d=(\kappa+e_{D,d})(w+e_{v,d}),\qquad V_* = \max_i(V_a)_i.$$

Reserve $b/4$ for external canonical force. Until a possible tube exit, let $F_*$ denote the supremum of the applied canonical force norm over the causal history. The ambient speed is bounded by $V_*+cF_*$. Integration along the actual state history therefore yields

$$E_\alpha\le G_2\Delta_x+G_1(V_*+cF_*)h.$$

The sampled inverse-mass error contributes at most

$$E_M=\beta B_N(e_Q+wh)F_d.$$

Consequently $F_*\le K_0+K_1F_*$, where

$$K_0=F_d+\beta\left[e_C+e_P+G_2\Delta_x+G_1V_*h\right]+E_M+b/4,\qquad K_1=\beta G_1ch.$$

Require $K_1\le1/2$, obtaining

$$\overline F=\frac{K_0}{1-K_1}.$$

The history supremum is finite on each compact interval before exit: the state is bounded there, the mass inverse is smooth, errors are bounded, and hold updates are locally finite. Thus the inequality can be solved before asserting residual admission. There is no assumed v109 force cap in this step.

Use $\overline F$ in the old ordinary trajectory enclosure,

$$E_a^{\rm raw}=\epsilon\left(R_a\mathbf1+TR_aP_a\mathbf1\right)+TR_a|C|\mathbf1\,\overline F.$$

Every component must be at most $1/8$. Together with the ideal radius $3/4$, this closes the first-exit argument strictly inside the radius-one launch tube. Here $\epsilon$ is the old joint acquisition allowance, distinct from either new sampling fraction.

## 5. Admission into the damping and comparison certificate

The complete full-controller contribution, excluding the separately allocated plant error, is

$$E_{\rm full}=\beta\left[e_C+G_2\Delta_x+G_1(V_*+c\overline F)h\right]+E_M.$$

Require both

$$E_{\rm full}\le b/4,\qquad \beta e_P\le e_{A,d}.$$

Then $E_{\rm full}+\|f_{\rm ext}\|_\infty\le b/2$ fits v109's other-force reserve, and the plant error fits its actuator channel. The replay recomputes the actual velocity-acceleration bound, sampled-damping residual and full paired comparison error. It also verifies that the resulting raw force and state enclosures are no larger than those admitted by v109.

Both observable signs therefore retain the original reserved observation window **under all stated assumptions**. Preparation, parameter, scientific-readout and readout-timing requirements are unchanged. The controller and readout instruments must satisfy both sets of requirements if shared.

## 6. Frozen allocation and results

For each v109 operator class, retain its damping fraction and all old caps. Introduce a different full-controller fraction $\zeta$:

$$e_Q=\zeta,\quad e_V=w\zeta,\quad e_C=e_P=\zeta,\quad h=T\zeta.$$

The unit coefficients for position and acceleration errors are declared native engineering normalization choices. They are not derived UD constants, numerical SI scales or relative errors with respect to instantaneous quantities. Search the first dyadic $\zeta=2^{-k}$, $k\ge4$, satisfying every condition above; record the preceding dyadic's failure reasons.

| Domain | Full-controller $\zeta$, bounded-slew damping | Full-controller $\zeta$, constant damping | Maximum native controller age, both classes |
|---|---:|---:|---:|
| 1 | $2^{-174}$ | $2^{-174}$ | $2^{-189}$ |
| 2 | $2^{-165}$ | $2^{-165}$ | $2^{-180}$ |
| 3 | $2^{-180}$ | $2^{-180}$ | $2^{-197}$ |

**173 new grouped checks pass.** Every predecessor is rerun with byte-identical output. The previous larger dyadic fails the on-arm full-controller reserve in all six fixtures. The damping-only fraction fails full-controller admission in every case. Result SHA-256: `c6541df0f3d61e17c5d4148f21434200e01b2bf51cbbed249733055f1c204522`.


These are conservative sufficient allowances, not necessary hardware precision, optimal sampling limits or impossibility theorems. Errors in the full acceleration law are not multiplied by the small damping coefficient. The larger damping-only fraction therefore cannot certify the full command.

## 7. Failure modes retained

| Rejected route | Failure | Mitigation and reconsideration condition |
|---|---|---|
| Reuse the damping-only fraction for the complete controller | Direct acceleration errors lack the damping suppression; the replay evaluates and rejects this substitution | Use the full residual budget; revisit with a separately proved sharper bound |
| Treat sampled inverse-mass conversion as exact | $M(Q)N_f(\widehat Q)-I$ is generally nonzero | Include $E_M$ or prove an exact special case |
| Solve the force inequality without a gain condition | At gain one, $F\le K_0+F$ gives no upper bound for positive $K_0$ | Establish gain below one or supply another independent enclosure |
| Apply the same-stamp reconstruction proof to arbitrary asynchronous sensor pairs | Those values need not represent one historical state | Synchronize/time-align with a proved error bound, or derive a two-stamp extension |
| Treat bounded command arithmetic as already verified floating-point behavior | The exact replay uses rational/symbolic arithmetic | Derive a finite-word implementation receipt over the admitted input domain |

The v109 bounded-matrix/staleness and delayed-damping power obstructions remain active. The target Hamiltonian is virtual platform energy accounting; its conservation or controlled dissipation does not identify actual actuator supply or stored physical energy.

## 8. Append-only clarification of predecessor wording

**Found during construction of this extension:** v109's narrative used “unit state box” without saying it is centered on the launch. Literal interpretation as $|x_i|\le1$ is incorrect for the prescribed launches. The replay already used the inherited coordinate bounds $m_a$, including components larger than one; no numerical majorant, result, input or frozen artifact is changed here.

The replacement reading is “radius-one launch-centered tube, bounded absolutely by the recorded coordinate vector.” The present proof explicitly uses $m_a$ and $m_a+\mathbf1$. This is a scope/wording correction with its own receipt, not a silent repair or mathematical promotion.

## 9. Units and next bridge task

| Error quantity | Factor multiplying its native bound |
|---|---|
| Generalized position | $\ell_*$ |
| Generalized velocity | $\ell_*/\tau_*$ |
| Complete acceleration command and plant acceleration | $\ell_*/\tau_*^2$ |
| Sample age | $\tau_*$ |
| Canonical force | $E_*/\ell_*$ |

No numerical scales or component models are selected. Next, derive a **controller coefficient-mismatch and finite-word evaluation certificate**: separate errors in the implemented model from the old target/reference mismatch, bound the complete evaluated command including its inverse-mass term, and test it against the remaining allowance. This should precede component claims. Sharper sufficient bounds are a separate possible refinement; failure of the current conservative allowance is not a physical impossibility result.

Origin: user-directed UD development. Constructor: Codex. Independent reviewers: none. Prior source: v109, commit `3a10a1110c85bb6670ad087993d133f03e53a221`. Frozen design SHA-256: `9747ddd5cc54c6724366b0480e4f1a5c317d45f70bc71357efbb365fc1ca7f18`. Dependencies: complete v109 sampled-feedback tree, including its earlier exact source laws and governance records. New changes are bridge refinement, frontier extension and scope clarification. The coefficient ledger remains unchanged. Registry promotion, natural-carrier identity and empirical validation remain open.

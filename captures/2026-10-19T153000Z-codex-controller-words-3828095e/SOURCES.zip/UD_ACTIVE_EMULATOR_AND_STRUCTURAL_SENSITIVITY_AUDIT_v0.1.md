# Active-emulator admissibility and structural sensitivity audit

**25 September 2026 · Development — no registry entry.** Internal claim: conditional active-emulator map and structural sensitivity audit. Correspondence: **FORMAL_CORRESPONDENCE**. Physical promotion: **0**. Independent review: **not performed**. No apparatus, physical measurements or numerical SI scales are supplied.

## Outcome and scope

A declared nine-axis, constant-mass plant can reproduce the v104 generalized mechanical target under exact acceleration feedback. The transformation from plant acceleration error to canonical force error is explicit, allowing the v105 comparison certificate to admit bounded command and plant errors.

This is an **active emulator model**, not a manufactured implementation or an independently established natural carrier. Its controller incorporates the UD candidate equations. Accurate tracking would test implementation fidelity; it would not independently establish those equations as laws of nature. Its power supply and mechanical kinetic energy also need not realize the target's internal energy partition.

The sensitivity audit finds a structural reason for caution about precision: an arbitrarily weak damping force applied to only one arm produces a first-order bulk contrast at launch, whereas the ideal comparison begins at eighth order. The reserved observation window and disturbance bounds are load-bearing. This does not show that all current sufficient bounds are optimal.

The design was frozen before this symbolic audit and the new acceleration-budget calculation. The algebraic route had been reasoned about beforehand. No measurement results or numerical physical targets selected the construction. This is an internal ordering record, not independent preregistration.

## 1. Exact target acceleration

Use the inherited nine canonical positions $Q$ and momenta $P$, a fixed uniform leaf label $a_0$, and native velocity $V=Q'$. The regular target Lagrangian is

$$\mathcal L(Q,V)=\tfrac12V^TM(Q)V+A(Q)^TV-V_{\rm eff}(Q)-a_0^2,$$

where

$$M=\operatorname{diag}(I_7/2,N^{-1}),\qquad A=(0_7,a),\qquad P=MV+A.$$

The quantities $N,a,V_{\rm eff}$ are exactly those established in v104. Parameters are fixed; $\mu,\nu>0$ and the inherited comparison domains impose the remaining restrictions. Define

$$\Gamma_i=\sum_{j,k}\left(\partial_kM_{ij}-\tfrac12\partial_iM_{jk}\right)V_jV_k,\qquad \mathcal B_{ij}=\partial_iA_j-\partial_jA_i.$$

Here $\mathcal B$ is an antisymmetric curvature matrix, not the bulk energy observable $B$. The Euler–Lagrange equation gives the target acceleration

$$\alpha(Q,V)=M^{-1}\left[-\Gamma+\mathcal B V-\nabla V_{\rm eff}\right].$$

The replay checks each of the nine transformed momentum equations exactly, as well as $V^T\mathcal BV=0$ and the Christoffel kinetic-power identity. Thus the acceleration law includes coordinate-dependent inertia and the velocity-dependent coupling; a plain spring model is not substituted for them.

## 2. Declared plant and control law

Choose a normalized unit-mass plant with nine translational generalized axes:

$$Q''=u+e_{\rm plant}.$$

Ideal feedback commands $u=\alpha(Q,V)$. Represent implementation error by

$$u=\alpha(Q,V)+e_{\rm command}.$$

The canonical reconstruction then gives exactly

$$Q'=\partial_Ph,\qquad P'=-\partial_Qh+f,\qquad f=M(e_{\rm command}+e_{\rm plant}).$$

Consequently this plant fits the v105 canonical-force subclass whenever its residuals satisfy the required regularity and bounds. Controller means and the uniform leaf label remain preserved by the reconstructed momentum force.

This model declares nine independent inertial axes, signed position/velocity sensing, a controller evaluating $\alpha$, and force actuation. It supplies their interface equations, not a parts list. No bandwidth, stroke, sensor resolution, sampling rate or supply rating has been assumed feasible.

The error terms must include all applicable effects after transformation: sensor error, state-estimation error, latency, numerical evaluation, sample-and-hold behavior, actuator calibration, unmodeled inertia, friction and saturation. A command error at the estimated state must be bounded relative to $\alpha$ at the actual state. Merely measuring an actuator's nominal force accuracy does not establish the required total error. A sampled-data implementation needs a separate argument establishing a bounded residual between updates; the current equations do not silently supply that argument.

## 3. Global mass bound and inherited error admission

For the two controller coordinates, the established inverse mass is

$$N^{-1}=\frac G\mu-\frac{2\gamma^2Gu_cu_c^TG}{\mu(\mu+2\gamma^2u_c^TGu_c)},\qquad G=\begin{pmatrix}2&1\\1&2\end{pmatrix}.$$

The subtracted term is positive semidefinite, and $N^{-1}$ is positive definite. Thus its diagonal entries are at most $2/\mu$. Its positive-semidefinite two-by-two minor implies $|(N^{-1})_{12}|\le\sqrt{(N^{-1})_{11}(N^{-1})_{22}}\le2/\mu$. Therefore

$$\|M\|_\infty\le\max(1/2,4/\mu).$$

This is a conservative global bound; no selected coordinate value or small-controller approximation is required. For each extended v103 parameter domain set $\mu_{\min}=(14/16)\mu_{\rm center}$ and $\beta=\max(1/2,4/\mu_{\min})$.

Keep the v105 canonical-force allowance $\zeta$. Choose the first dyadic $\xi=2^{-k}$ with

$$\xi\le\frac\zeta{2\beta}.$$

If both $\|e_{\rm command}\|_\infty\le\xi$ and $\|e_{\rm plant}\|_\infty\le\xi$ throughout the admitted box and interval, then $\|f\|_\infty\le2\beta\xi\le\zeta$. All prior launch, parameter, timing, readout and residual inequalities remain in force. These two half-allocations may be reallocated only through the general combined inequality, not by adding independent maxima.

| Domain | Mass bound $\beta$ | Canonical force cap $\zeta$ | Each acceleration-error cap $\xi$ | Limiting v105 constraints (ambient / force) |
|---|---:|---:|---:|---|
| 1 | $32/7$ | $2^{-131}$ | $2^{-135}$ | sign_S / sign_B |
| 2 | $16/7$ | $2^{-128}$ | $2^{-131}$ | sign_S / sign_B |
| 3 | $64/21$ | $2^{-149}$ | $2^{-152}$ | sign_S / sign_B |

**66 new grouped checks pass.** The complete predecessor chain reruns 112 + 82 + 134 + 97 + 119 + 66 + 73 + 56 + 46 grouped checks. New result SHA-256: `bc19edff19d964d433884eccddfd9a72cce39ac5d623db78934ffb22365ee6af`.

The v104 unit map makes the plant mass $m_*=E_*\tau_*^2/\ell_*^2$, the physical acceleration error $\ell_*\xi/\tau_*^2$, and the physical actuation-force error $E_*\xi/\ell_*$. The mass choice is an engineering normalization, not a newly derived UD mass. The actual numerical scales and component tolerances remain unfilled.

## 4. Target energy is not platform supply energy

The target energy balance under the residual map is

$$h'=V^TM(e_{\rm command}+e_{\rm plant}).$$

The normalized plant kinetic energy is $K_{\rm plant}=V^TV/2$, with

$$K'_{\rm plant}=V^Tu+V^Te_{\rm plant}.$$

Even under ideal feedback, $h'=0$ does not require $V^Tu=0$. The controller may inject and recover energy while following a target trajectory whose virtual Hamiltonian is constant.

An exact diagnostic sets all four target parameters to one, $Q_0=V_0=1$, and the other positions and velocities to zero. The replay obtains ideal plant supply power $-20/3$ while the target energy derivative is zero. This point tests the global model distinction; it is not claimed to lie in the three certified launch fixtures.

Accordingly, evaluating $E_*h$ from measured state is a calibrated **virtual target-energy observable** for this active proposal. It is not by itself a measurement of total apparatus energy, battery work, actuator losses or component storage. A physical energy-realization claim would require an explicit storage/work map including controller and supply. The v104–v105 formal dictionaries remain valid within their stated scopes; the present candidate does not fill their physical storage fields merely by tracking trajectories.

## 5. Exact launch sensitivity and an early-time obstruction

At the inherited launch, vertex 0 has amplitude one, edges 01 and 02 have amplitudes $a,b$, and all other amplitudes and controller coordinates vanish. Let $T_P$ inject the nine canonical forces into the original carrier and $L_Q$ extract canonical position velocities. Exact evaluation gives

$$T_P^T\nabla B\big|_0=(-1,-1,-1,0,0,0,0,0,0)^T=Q'(0),$$

$$T_P^T\nabla S\big|_0=0,\qquad |Q'(0)|^2=3.$$

The ideal on/off bulk slopes agree at launch. Apply isotropic damping $f_{\rm on}=-\kappa Q'_{\rm on}$ only to the on arm, keep the off arm unforced, and take any $\kappa>0$. Then

$$\delta B'(0)=-3\kappa<0,\qquad h'_{\rm on}(0)=-3\kappa.$$

The two arms have equal initial bulk values. Continuity therefore gives $\delta B(s)<0$ for sufficiently small positive $s$. This establishes that **no nonzero allowance for arbitrary asymmetric damping can preserve the positive bulk contrast on every $0<s\le T$**. The damping can be arbitrarily weak and passive. Its coefficient is an engineering perturbation, not a revised theory coefficient.

This does not contradict v105, which guarantees signs only in its reserved observation window after the disturbance and acquisition budgets are met. Nor does it establish failure for equal damping shared by both arms. The source observable has a zero direct force sensitivity at launch, but that single null does not by itself establish a sharper uniform source-error bound.

## 6. Why small margins persist

The ideal bulk contrast starts with $(2\lambda/7)s^8$. The force direction above introduces a term $-3\kappa s$. A local two-parameter expansion about zero time and zero damping therefore compares an eighth-order signal with a first-order disturbance. On shrinking observation windows $s=cT$, a perturbative worst-case damping allowance must be of order $T^7$ or smaller to remain comparable to the ideal signal in this direction.

This is an asymptotic sensitivity statement, not a global optimality proof for the dyadic constants. The absolute-value majorants, broad state boxes and unused cancellations can still make current bounds much more conservative than necessary. In particular, disturbances shared by both arms should be distinguished from their differences before assigning independent worst-case errors to each arm.

The exact limiter audit recomputes every v105 sign, tube and protocol cap, retaining ties. Its result table identifies which constraints actually set each residual allowance; the full rational ratios are in the result JSON. No endpoint is enlarged and no improved bound is claimed in this audit.

## 7. Candidate admission and next task

The active model is mathematically admitted only after a proposed implementation supplies: the normalized plant equations and scale calibration; complete position/velocity-to-canonical reconstruction; residual bounds over the full domain and interval; the combined acquisition inequalities; and a separate physical supply/storage ledger. A failure to establish these conditions leaves the candidate unadmitted. Exceeding a sufficient bound makes the current certificate inconclusive, not the entire UD theory falsified.

The next mathematical task is a **paired disturbance model**: retain disturbances shared by both arms, bound their differences separately, and determine which early-time errors cancel. Any stronger comparison bound must be derived on that declared class and must retain the asymmetric-damping counterexample. Component bandwidth and sensor choices should follow an independently justified implementation/error model. Non-constructor review remains necessary before claim promotion.

## Verification and provenance

The replay authenticates the frozen design and the complete v105 predecessor package; checks the Euler–Lagrange/canonical transformation, plant residual and power identities, mass bound ingredients, launch sensitivities and rational budgets; and reproduces the predecessor result bytes. The verification receipt records a clean archive replay and deliberate nested-dependency tamper rejection. These are constructor checks only.

Origin: user-directed UD development. Constructor: Codex. Independent reviewers: none. Change types: bridge refinement and scope clarification. Prior source: v105, commit `758da7a5fad467e31afb91575cec5b52c1dc7b6c`. Frozen design SHA-256: `8272ebdbf3441654aec6f8359f8447e1679483faefead2bd9c172d6bdf98b1f6`. Historical governance and coefficient-ledger attachment hashes remain unchanged. All predecessor mathematical inputs are retained under `dependencies/implementation-defect-v0.1/`.

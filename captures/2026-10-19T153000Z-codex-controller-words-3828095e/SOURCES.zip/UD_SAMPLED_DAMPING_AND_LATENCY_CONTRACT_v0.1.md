# Sampled damping, sensing and latency contract

**25 September 2026 · Development — no registry entry.** Internal claim: conditional sampled damping and latency residual contract. Correspondence: **FORMAL_CORRESPONDENCE**. Physical promotion: **0**. Independent review: **not performed**. No apparatus, physical measurements or numerical SI scales.

## Outcome and scope

This extension translates velocity-estimation error, damping-matrix calibration, sample age and actuator-force error into the additional canonical residual admitted by v108. A direct raw-force bound closes the trajectory enclosure before the sampled feedback is treated as a small residual. The original observation windows, preparation and readout constraints remain unchanged.

Two alternative regularity classes are evaluated: a common damping operator with a declared bound on its rate of change, and a constant common operator. Boundedness alone is insufficient for a small matrix-staleness error. Positive damping applied to stale velocity can also inject instantaneous power, so the implemented sampled law is not assumed exactly passive.

This is a certificate for the **sampled damping layer**. Sampling the v106 emulator's full acceleration-feedback law $\alpha(Q,v)$ requires its own evaluation-error bound. Such errors may occupy a reserved residual channel only after that separate bound is supplied; this result does not silently certify the entire digital emulator.

The design was frozen before the numerical budget and symbolic audit. The force decomposition and noncircular raw-force enclosure were derived first. This is internal execution order, not independent preregistration or experimental validation.

## 1. Causal sample histories and estimates

Keep the common target damping operator $D(s)$ from v108, with $D=D^T\succeq0$ and $\|D\|_\infty\le\kappa$. The target Hamiltonian parameters remain fixed. Introduce prescribed causal, locally finite sample-and-hold schedules, with matrix and velocity stamps

$$0\le t_{D,a}(s),t_{v,a}(s)\le s,\qquad s-t_{D,a}\le h_D,\qquad s-t_{v,a}\le h_v.$$

Initial samples are taken at zero; no unspecified prelaunch history is used. Locally finite updates exclude infinitely many sample events in finite time. The dynamics between updates are ordinary equations with the inherited local regularity and bounded error signals.

The applied estimates are

$$\widehat D_a=D(t_{D,a})+E_{D,a},\qquad \widehat v_a=v_a(t_{v,a})+e_{v,a},$$

with operator norm error $\|E_{D,a}\|_\infty\le e_D$ and componentwise velocity error $|e_{v,a,j}|\le e_v$. The implemented canonical force is

$$f_a=-\widehat D_a\widehat v_a+e_{A,a}+u_{{\rm other},a}.$$

Each actuator-force error component is bounded by $e_A$. Let $b$ denote the v108 **additional-force** allowance, equal to half its retained unequal-force cap. Reserve $b/2$ for $u_{\rm other}$.

Sample age may include sensing, computation, transport, holding and a pure actuator delay when the resulting applied force can be represented by these stamps. A general actuator transfer function, saturation or startup transient is not automatically represented: it must fit the explicit force-error channel or receive a separate model. Input ages are distinct from the earlier observable-readout time offsets.

## 2. Required operator regularity

Assume, where the operator varies,

$$\|D(s)-D(t)\|_\infty\le L_D|s-t|.$$

This Lipschitz bound is an engineering assumption requiring evidence for an implementation. It does not follow from positive semidefiniteness or bounded magnitude. In the constant-operator class, $L_D=0$, but matrix-calibration error $e_D$ remains permitted.

For a precise rejected route, a bounded PSD step from $0$ to $\kappa I$ has a stale mismatch of $\kappa$ whenever two stamps straddle the jump, however short their positive separation. There is therefore no uniform mismatch bound tending to zero with delay from boundedness alone. This step is outside the finite-slew class certified here.

## 3. Independent raw-force and acceleration enclosure

Use the inherited global canonical velocity majorant $w$. Until a possible state-box exit, every historical sampled velocity is bounded by $w$, since its stamp lies between zero and the present. Consequently

$$F_{\rm raw}=(\kappa+e_D)(w+e_v)+e_A+b/2$$

bounds every applied force component, without assuming that the sampled residual is small.

Let $c=|T_P|\mathbf1_9$ and retain the predecessor state/parameter majorants, resolvents and joint acquisition allowance $\epsilon$. The ordinary per-arm error enclosure is

$$E_a^{\rm raw}=\epsilon\left(R_a\mathbf1_{21}+TR_aP_a\mathbf1_4\right)+TR_acF_{\rm raw}.$$

Require every component to be at most $1/8$. Combined with the ideal radius $3/4$, this closes the causal-history first-exit argument strictly inside the unit state box. This step does not invoke sampled-residual admission or assume passivity of the delayed law.

For fixed Hamiltonian parameters, canonical velocity is $v=L_QF(x;\theta)$ and $L_QT_P=0$. Thus, almost everywhere,

$$|v'_a|\le |L_Q|H_a\left(V_a+cF_{\rm raw}\right),$$

where $V_a$ is the ambient speed majorant. Define $A$ as the largest component of this bound across both arms. No derivative of the damping matrix is needed for this acceleration enclosure. Integrating it over the velocity sample age gives

$$\|\widehat v_a-v_a(s)\|_\infty\le e_v+Ah_v.$$

The matrix-staleness bound is $\|\widehat D_a-D(s)\|_\infty\le e_D+L_Dh_D$. Also, the historical-sample bound still gives $\|\widehat v_a\|_\infty\le w+e_v$.

## 4. Complete sampled-feedback residual

Relative to the current shared damping law, the exact force difference is

$$D(s)v(s)-\widehat D\widehat v=D(s)(v(s)-\widehat v)+(D(s)-\widehat D)\widehat v.$$

Therefore the complete additional canonical residual is bounded by

$$U_{\rm sample}=\kappa(e_v+Ah_v)+(e_D+L_Dh_D)(w+e_v)+e_A+b/2.$$

When $U_{\rm sample}\le b$, v108 applies. Its shared/differential decomposition, velocity-gap estimate and complete comparison certificate then retain both reported signs in the reserved observation window. The proof order is raw force, state enclosure, acceleration/sample errors, residual admission, and only then the inherited comparison theorem.

The sampled implementation may supply power through its error term:

$$h'=-v^TD(s)v+v^Tu_{\rm sample}.$$

On the certified box, the absolute contribution of residual work to target power is bounded by $\sum_j(w_a)_j\,U_{\rm sample}$; integration over $[0,T]$ adds the factor $T$. This is a target-energy error bound, not a physical platform supply measurement.

A simple force-law diagnostic shows why exact passivity is unavailable: take a scalar velocity ramp with current value $Ah/2$ and stale value $-Ah/2$. Positive damping $\kappa$ applied to the stale value supplies current power $\kappa A^2h^2/4>0$, while the velocity difference still obeys the acceleration-age bound $Ah$. This is a diagnostic history, not a claim to have constructed a new full UD trajectory. The certificate accounts for this work as a bounded error instead of assuming it vanishes.

## 5. Frozen joint engineering fractions

Hold the v108 damping cap $\kappa$, interval $T$ and additional-force budget $b$ fixed. Define a new joint engineering fraction $\xi$ by

$$e_v=w\xi,\qquad e_D=\kappa\xi,\qquad e_A=b\xi,\qquad h_v=h_D=T\xi.$$

The two alternative operator classes are:

- **Bounded slew:** $L_D\le\kappa/T$.
- **Constant operator:** $L_D=0$, while retaining the same allowed calibration error $e_D$.

The rate cap is a declared engineering regularity assumption, not a newly derived UD coefficient. Search the first dyadic $\xi=2^{-k}$, $k\ge4$, satisfying the raw-state tube and $U_{\rm sample}\le b$. Half of $b$ remains explicitly reserved for other forces. Failed conditions for the preceding larger dyadic are recorded.

| Domain | Bounded-slew joint $\xi$ | Constant-operator joint $\xi$ | Bounded-slew maximum native age | Constant-operator maximum native age |
|---|---:|---:|---:|---:|
| 1 | $2^{-11}$ | $2^{-10}$ | $2^{-26}$ | $2^{-25}$ |
| 2 | $2^{-12}$ | $2^{-11}$ | $2^{-27}$ | $2^{-26}$ |
| 3 | $2^{-11}$ | $2^{-11}$ | $2^{-28}$ | $2^{-28}$ |

**117 new grouped checks pass.** The full predecessor chain reruns 81 + 85 + 66 + 112 + 82 + 134 + 97 + 119 + 66 + 73 + 56 + 46 grouped checks. Result SHA-256: `c2ca3baa818b44892c58337e08d24d69d8a305d978f0cec11bfeb7f0d8fbf465`.

These fractions scale **different quantities by their declared bounds**. In particular, $e_v/w=\xi$ is not relative error with respect to the instantaneous velocity, which may be zero. Neither column is a sample frequency, an overall state-estimation precision, or a physical hardware specification. The constant and bounded-slew columns are alternative classes, not additive budgets.

The v104 preparation and energy-readout requirements remain unchanged. If one instrument supports both feedback and scientific readout, it must satisfy both contracts, with shared systematic errors accounted for. The comparatively larger feedback fraction is possible partly because its error is multiplied by the very small held damping coefficient. It does not resolve the severe full-state preparation, force-actuation or physical-calibration requirements.

## 6. Unit mapping and implementation boundary

| Quantity | Physical factor multiplying its native bound |
|---|---|
| Velocity-estimation error | $\ell_*/\tau_*$ |
| Matrix/velocity sample age | $\tau_*$ |
| Damping-matrix calibration error | $E_*\tau_*/\ell_*^2$ |
| Canonical force residual | $E_*/\ell_*$ |
| Damping-operator rate of change | $E_*/\ell_*^2$ |

The last factor maps native operator slew to kg/s². These mappings do not select numerical scales or component bandwidth. The active constant-mass plant of v106 still requires its declared conversion from plant errors to canonical forces; its physical supply energy remains distinct from the virtual target Hamiltonian.

The present $e_A$ is an already bounded **canonical force-output error**. It does not derive that error from a motor, amplifier or sampled evaluation of $\alpha(Q,v)$. Likewise, the velocity estimate is supplied with a bound; a sensor/filter design must establish that bound. The reserved other-force channel is a capacity in the certificate, not evidence that a particular unmodeled effect fits it.

Delayed or unequal time stamps in the two arms are allowed here only insofar as both satisfy the stated age/error envelopes relative to the same common target operator. A bounded matrix without finite slew, unknown prehistory, future-dated samples, unbounded actuator transients or an unspecified delay-feedback model do not satisfy this contract.

## 7. Verification and next task

The next task is a **sampled full-acceleration feedback contract** for the v106 emulator: bound how position and velocity estimation, sample age and computation change $\alpha(Q,v)$; convert that error through the coordinate-dependent mass matrix; and combine it with the damping budget. This will identify the remaining control requirements before any component selection or experimental claim.

The replay authenticates the design and complete v108 dependency tree, reproduces every predecessor result byte-for-byte, verifies the force decomposition and diagnostic failure modes, and checks the exact raw-force, acceleration, residual and inherited comparison inequalities. A clean extracted replay and nested-dependency tamper rejection are recorded separately. These are constructor checks; no non-constructor review or promotion is implied.

Origin: user-directed UD development. Constructor: Codex. Independent reviewers: none. Change types: bridge refinement and frontier extension. Prior source: v108, commit `eec5e6db874f861f0dbebaefbb575a9ef752338c`. Frozen design SHA-256: `33d15e677d71dd98a2836f2b8a3c2b0ae6d8e2ca29ef24e7178a5cd19a391b33`. Full predecessor inputs remain under `dependencies/shared-damping-v0.1/`. The historical coefficient-ledger and CRL-governance attachment hashes remain unchanged. Physical realization, practical precision and natural-carrier identification remain open.

"""Exact structural and interval certificates for a conditional UD calibration.

python certify_calibration.py
No apparatus data. No private attachment is copied into the deliverable.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import lcm, factorial
import json, hashlib, platform, importlib.metadata
import numpy as np
from scipy.sparse import csr_matrix
import sympy as sp
from flint import arb, ctx

ROOT=Path(__file__).resolve().parent
ctx.prec=256
def a(x):
    x=Q(x)
    return arb(x.numerator)/x.denominator
def pair(x):
    x=Q(x)
    return [x.numerator,x.denominator]
def enc(x):
    return {'arb_enclosure':str(x),'display_only':float(x.mid())}
def write(name,x):
    (ROOT/name).write_text(json.dumps(x,indent=2)+'\n')
def read(name):
    return json.loads((ROOT/'sources'/name).read_text())

z=np.load(ROOT/'sources/operators.npz')
A=csr_matrix((z['A_data'].astype(np.int64),z['A_indices'],z['A_indptr']),shape=(2640,2640))
obs=set(z['obs'].tolist())
assert (A+A.T).nnz==0
cuts=[0,120,840,2040,2640]
grade=np.repeat(np.arange(4),np.diff(cuts))
rows=[]
for i in range(2640):
    rows.append([(int(A.indices[k]),int(A.data[k]),int(min(grade[i],grade[A.indices[k]])))
                 for k in range(A.indptr[i],A.indptr[i+1])])
v,e,f,t=33,486,1680,2040
P=[v,e,t]; S=[1,-1,1]; p=[0]*2640;p[e]=p[f]=1
assert {v,e,f,t} <= obs
s=read('COMPLEX_AND_ACTION.json')['simplices']
assert s[0][v]==[33] and s[1][e-120]==[33,34]
assert s[2][f-840]==[33,34,41] and s[3][t-2040]==[0,33,34,41]
def multiply(nums,x):
    return [sum(value*nums[k]*x[j] for j,value,k in row) for row in rows]
channel_action=[multiply([int(k==i) for k in range(3)],p) for i in range(3)]
jet=[[S[j]*channel_action[k][P[j]] for k in range(3)] for j in range(3)]
assert jet==[[1,0,0],[0,1,0],[0,0,1]]
for i in range(3):
    for j in range(3):
        if i!=j:
            assert not any(multiply([int(k==i) for k in range(3)],channel_action[j]))
# Exact metric no-go witness u0 = all-ones on C0. The source full operator
# is nonzero, but both A u0 and u0^T A are exactly zero.
u0=[int(i<120) for i in range(2640)]
assert not any(multiply([1,1,1],u0))
assert sum(x*x for x in u0)==120

g,alpha,w1,w2,w3=sp.symbols('g alpha w1 w2 w3',positive=True)
pars=sp.Matrix([g,alpha,w1,w2,w3])
bare=sp.Matrix([g,g*alpha*w1,g*alpha*w2,g*alpha*w3]).jacobian(pars)
anchored=sp.Matrix([g,alpha,g*alpha*w1,g*alpha*w2,g*alpha*w3]).jacobian(pars)
null=sp.Matrix([0,alpha,-w1,-w2,-w3])
assert bare.rank()==4 and bare*null==sp.zeros(4,1)
det=sp.factor(anchored.det());assert det==g**3*alpha**3

h=Q(1,256);lo=Q(15,16);hi=Q(17,16)
L=16*arb(6).sqrt()*a(hi**2*h)
assert L < a(Q(7,40))
assert Q(1)-Q(7,40)==Q(33,40)
assert (1+Q(7,40))/(1-Q(7,40))==Q(47,33)
nu0=nu=xi=Q(1,10**12)
epsg=hi*xi+nu0
epsalpha=Q(1,10**11);jittercal=Q(1,10**14);solver=Q(1,10**11)
B=(a(nu)+arb(2).sqrt()*a(epsg)+a(hi*xi))/a(lo*h*lo)
B+=4*arb(2).sqrt()*a(hi/lo*(epsalpha+jittercal/h))
rate_error=(B+a(solver))/a(Q(33,40))
assert rate_error < a(Q(2,10**9))
gain_residual=a(epsg/lo)
assert gain_residual < a(Q(1,100000))
# A priori contraction count from diameter of the rate box. This is a
# distance-to-fixed-point bound, rather than an unverified stopping rule.
n=0
diameter=arb(3).sqrt()/8
while not (a(Q(7,40))**n*diameter < a(Q(1,10**11))):n+=1

# Finite evaluations on actual 2640-coordinate carrier. Integer moments and
# exact rational Taylor sums; analytic skew-generator remainder bounds certify
# errors. These are synthetic checks, not empirical calibration measurements.
def exact_forward(w,alph,degree=20):
    dw=lcm(*(x.denominator for x in w))
    nums=[int(x*dw) for x in w]
    c=h*alph/dw
    x=p[:]; coeff=Q(1); sums=[Q(p[j]) for j in P]
    for order in range(1,degree+1):
        x=multiply(nums,x); coeff*=c/order
        for k,j in enumerate(P):sums[k]+=coeff*x[j]
    zmax=a(4*max(w)*alph*h)
    rem=arb(2).sqrt()*zmax**(degree+1)/factorial(degree+1)
    # Integral remainder: skewness gives ||exp(s X)||=1 for real s.
    assert rem < a(Q(1,10**50))
    values=[a(S[k]*(sums[k]-p[j])/(h*alph)) for k,j in enumerate(P)]
    return values,rem/a(h*alph)

tests=[]
for ww,aa in [([Q(1)]*3,Q(1)),([lo,hi,lo],hi),([hi,lo,hi],lo)]:
    val,rem=exact_forward(ww,aa)
    tests.append({'rates':[pair(x) for x in ww],'alpha':pair(aa),
                  'phi_Taylor_enclosures':[enc(x) for x in val],
                  'additional_coordinate_error_upper':enc(rem)})

# Noiseless nominal inversion with exact rational evaluations plus rational
# rounding. The theorem certifies arbitrary allowed data; this example checks
# that implementing projected fixed-point iteration does not substitute w=phi.
target=[Q(1)]*3;alpha0=Q(1)
q,qrem=exact_forward(target,alpha0)
current=[Q(31,32),Q(33,32),Q(31,32)]
steps=[]
for iteration in range(1,17):
    phi,_=exact_forward(current,alpha0)
    # The synthetic numerical iterate is illustrative. Its final residual is
    # enclosed rigorously below with rational inputs and exact Taylor sums.
    current=[min(hi,max(lo,Q(round(float(current[k])+float(q[k].mid())-float(phi[k].mid()),14)))) for k in range(3)]
    if iteration in (1,4,8,16):steps.append({'iteration':iteration,'rates':[pair(x) for x in current]})
phi,rem=exact_forward(current,alpha0)
residual2=arb(0)
for k in range(3):
    # q is itself an enclosure of an exact rational Taylor sum. Add both
    # Taylor remainders when bounding difference from the exact forward map.
    d=abs(phi[k]-q[k])+qrem+rem
    residual2+=d*d
residual=residual2.sqrt()
assert residual < a(solver)
actual_error=sum((x-Q(1))**2 for x in current)
assert a(actual_error).sqrt()<a(Q(1,10**10))

protocols=[]
for item in read('SCHEDULE_CERTIFICATES.json')['protocols']:
    M=item['samples'];T=Q(M-1,2)
    drift=T*epsalpha/lo
    # Candidate post-calibration clock-jitter ceiling, separately required.
    sample_jitter=Q(1,10**6)
    assert drift+sample_jitter < Q(3,10**6)
    protocols.append({'samples':M,'clock_scale_error_drift_upper':pair(drift),
                      'separately_required_sample_jitter_upper':pair(sample_jitter),
                      'total_timing_error_upper':pair(drift+sample_jitter),
                      'passes_parent_tau_ceiling':[3,10**6]})

hashes=[{'path':'sources/'+x.name,'size_bytes':x.stat().st_size,
         'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted((ROOT/'sources').iterdir()) if x.is_file()]
write('CALIBRATION_CERTIFICATE.json',{
 'status':'DERIVED_CONDITIONAL_CONSTRUCTOR_VERIFIED','physical_promotion':0,'independent_review':'pending',
 'model':'H=I; common positive gain g; positive three rates; constant affine clock scale alpha; known coordinate preparation',
 'flag':{'vertex':v,'edge':e,'face':f,'tetrahedron':t,'preparation_coordinates':[e,f],'preparation_coefficients':[1,1],'readout_coordinates':[e,v,e,t]},
 'exact_jet_sign_matrix':jet,'unanchored_jet_rank':4,'clock_anchored_jet_rank':5,
 'anchored_jet_determinant':str(det),'bare_null_direction':['0','alpha','-w1','-w2','-w3'],
 'finite_protocol':{'sample_times':[pair(Q(0)),pair(h)],'parameter_box':[pair(lo),pair(hi)],
   'normalized_rate_Jacobian_error_bound':enc(L),'declared_error_upper':[7,40],
   'normalized_rate_lower_Lipschitz':[33,40],'normalized_rate_upper_Lipschitz':[47,40],
   'normalized_rate_condition_upper':[47,33],'finite_full_parameter_rank':5,
   'raw_feature_determinant_magnitude_lower_formula':'(g h alpha)^3 (33/40)^3',
   'projected_iteration_contraction_upper':[7,40],'a_priori_steps_for_1e-11_fixed_point_distance':n},
 'candidate_measurement_contract':{
   'initial_scalar_noise_upper':pair(nu0),'later_three_vector_noise_upper':pair(nu),
   'preparation_vector_error_upper':pair(xi),'gain_estimate_error_upper':pair(epsg),
   'clock_scale_estimate_error_upper':pair(epsalpha),'calibration_interval_jitter_upper':pair(jittercal),
   'certified_projected_residual_upper':pair(solver),'data_feature_error_upper':enc(B),
   'rate_estimation_error_upper_enclosed':enc(rate_error),'declared_rate_error_upper':[2,10**9],
   'acceptance_max_rate_estimate_deviation':[1,10**9],
   'accepted_true_max_rate_deviation':[3,10**9],
   'gain_normalized_readout_operator_error_upper':enc(gain_residual),
   'clock_protocols':protocols},
 'synthetic_actual_carrier_checks':tests,
 'synthetic_round_trip':{'status':'PASS','iteration_checkpoints':steps,'final_projected_residual_upper':enc(residual),'not_empirical':True},
 'metric_no_go':{'witness':'H=I+eta*u0*u0^T/120, u0=1 on all vertices and 0 elsewhere',
                  'exact_A_u0_zero':True,'u0_norm_squared':120,'consequence':'H^-1 A = A for every eta>-1; metric error is dynamically invisible'},
 'open':['Arbitrary relative readout/crosstalk is not calibrated by these four scalars',
         'Dense metric cannot be identified or bounded by this protocol',
         'Known preparation and independent clock reference are apparatus assumptions',
         'Gain/rates/clock must remain stable between calibration and acquisition',
         'No physical time map or apparatus qualification is derived'],
 'sources':hashes})
write('VALIDATION.json',{'status':'PASS','actual_carrier_integer_flag_check':True,
 'exact_unanchored_rank':4,'exact_anchored_jet_rank':5,
 'finite_full_parameter_rank_proved':5,'finite_parameter_box_uniform_inequality':True,
 'integer_metric_counterexample':True,'finite_actual_carrier_points_checked':len(tests),
 'synthetic_projected_inverse_checked':True,'interval_precision_bits':ctx.prec,
 'runtime':{'python':platform.python_version(),**{x:importlib.metadata.version(x) for x in ['numpy','scipy','sympy','python-flint']}},
 'scope':'Constructor algebra, exact integer moments and interval inequalities; finite-rank theorem analytical; no apparatus data or independent review'})
print(json.dumps({'status':'PASS','finite_rank':5,'uniform_rate_condition_bound':[47,33],
                  'rate_error_upper_display':float(rate_error.mid()),'iteration_bound':n},indent=2))

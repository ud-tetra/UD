# UD held-out sampled validation

Read `UD_HELD_OUT_VALIDATION_v0.1.md` for the corrected thresholds, fault
controls and limits. All supplied observations are synthetic controls.

Reproduce:

```bash
python certify_heldout.py
python -m unittest -v test_validation.py
python validate_heldout.py
```

Freeze a prediction for the actual fitted effective ratios before examining
validation data:

```bash
python validation_engine.py predict --ratios 1 1 1 1 1 1 --out prediction.json
python validation_engine.py assess prediction.json observations.json --out assessment.json
```

The six unit ratios above are an example, not an empirical fit. Replace them
with the six frozen D1,U1,D2,U2,D3,U3 values as exact fractions or decimal
strings. The prediction command uses the frozen incidence matrix and probes.

The observation JSON must have `kind` equal to `APPARATUS_DATA` or
`SYNTHETIC_CONTROL`, the matching `model_lock_sha256`, the exact `times` array
from prediction.json, and an `outputs` array of shape25x62x3. Numeric entries
must be rational pairs, integers or decimal strings. Binary64 numeric literals
are rejected. Include a `receipts` map with the keys in
`validation_engine.REQUIRED_RECEIPTS`; values identify external evidence.
The module checks presence, not the truth of those receipts.

Data without receipts remain `INCOMPLETE_RECEIPTS`, even if every residual is
small. A consistency decision never certifies an unrestricted model or a
failure mechanism. No apparatus observations are included in this package.
Physical promotion is zero; constructor checks are not independent review.

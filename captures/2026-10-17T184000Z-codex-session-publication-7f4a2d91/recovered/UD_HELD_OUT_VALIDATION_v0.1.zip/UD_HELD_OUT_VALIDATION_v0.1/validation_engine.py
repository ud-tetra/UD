"""Frozen-incidence predictions and exact sampled residual gates.

CLI: python validation_engine.py predict --ratios 1 1 1 1 1 1 --out prediction.json
     python validation_engine.py assess prediction.json observations.json --out assessment.json

Observations must be collected independently. Synthetic controls are not evidence
of experimental model validity. No ordinary binary64 tolerance decisions are used.
"""
from pathlib import Path
from fractions import Fraction as F
from math import lcm
import argparse,hashlib,json
import numpy as np
from flint import arb,ctx

ROOT=Path(__file__).resolve().parent
def a(x):
 x=F(x);return arb(x.numerator)/x.denominator
def pair(x):
 x=F(x);return [x.numerator,x.denominator]
def parse(x):
 if isinstance(x,str):return F(x)
 if type(x) is int:return F(x)
 if isinstance(x,list) and len(x)==2 and all(type(y) is int for y in x):return F(*x)
 raise ValueError('Numbers must be rational pairs, integers or decimal/rational strings; no floats')
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def load(name):return json.loads((ROOT/name).read_text())
def round_dyadic(x,bits=80):
 y=x*2**bits
 return F((2*y.numerator+y.denominator)//(2*y.denominator),2**bits)
def source():
 z=np.load(ROOT/'sources/OPERATORS.npz');S=np.load(ROOT/'HELD_OUT_PREPARATIONS.npz')['numerator']
 if hashlib.sha256(S.astype(np.int8).tobytes()).hexdigest()!=load('DESIGN.json')['numerator_sha256']:
  raise ValueError('Frozen probe hash mismatch')
 grades=np.repeat(np.arange(4),[120,720,1200,600])
 return z,S,grades
def model_lock(ratios):
 q=[parse(x) for x in ratios]
 if len(q)!=6 or not all(F(15,16)<=x<=F(17,16) for x in q):raise ValueError('Six ratios must be in frozenbox')
 lock={'ratios':[pair(x) for x in q],
  'operator_sha256':hashlib.sha256((ROOT/'sources/OPERATORS.npz').read_bytes()).hexdigest(),
  'design_sha256':hashlib.sha256((ROOT/'DESIGN.json').read_bytes()).hexdigest(),
  'certificate_sha256':hashlib.sha256((ROOT/'HELD_OUT_CERTIFICATE.json').read_bytes()).hexdigest(),
  'engine_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  'meaning':'fixed effective logger-time ratios; must be frozen before validation data'}
 return q,lock

def predict_values(ratios,extra_entries=None,read_indices=None):
 """Arb-evaluated Taylor model, rounded to rational dyadics.

 extra_entries is for explicitly labelled alternative controls only. Caller
 must prove total generator norm<=17/4 for the uniform remainder bound.
 """
 ctx.prec=256
 q,_=model_lock(ratios);z,S,grades=source()
 if 4*max(q)+sum(abs(F(v)) for _,_,v in (extra_entries or []))>F(17,4):
  raise ValueError('No17/4 generator norm certificate for this alternative')
 indices=list(map(int,z['obs'])) if read_indices is None else list(read_indices)
 if len(indices)!=len(set(indices)):raise ValueError('Repeated observation coordinates')
 entries=[]
 for i in range(2640):
  for k in range(int(z['A_indptr'][i]),int(z['A_indptr'][i+1])):
   j=int(z['A_indices'][k]);low=min(int(grades[i]),int(grades[j]))
   direction=2*low+int(grades[i]>grades[j])
   entries.append((i,j,int(z['A_data'][k])*q[direction]))
 for i,j,v in extra_entries or []:entries.append((i,j,F(v)))
 den=lcm(*(v.denominator for _,_,v in entries))
 rows=[[] for _ in range(2640)]
 for i,j,v in entries:rows[i].append((j,int(v*den)))
 cur=[list(map(int,S[:,k])) for k in range(3)]
 degree=80;powers=[]
 for n in range(degree+1):
  powers.append([[cur[k][i] for k in range(3)] for i in indices])
  if n<degree:cur=[[sum(v*x[j] for j,v in row) for row in rows] for x in cur]
 times=[parse(x) for x in load('DESIGN.json')['times']]
 omega=F(17,4);b=arb(495).sqrt()/13
 zz=a(omega*max(times))
 from math import factorial
 tail=b*zz.exp()*zz**(degree+1)/factorial(degree+1)
 assert tail<a(F(1,2**100))
 assert arb(len(indices)*3).sqrt()*a(F(1,2**79))+tail<a(F(1,2**70))
 out=[]
 for t in times:
  vals=[[arb(0) for _ in range(3)] for _ in indices]
  coeff=a(F(1,52));step=a(t/den)
  for n,block in enumerate(powers):
   for i,row in enumerate(block):
    for k,value in enumerate(row):vals[i][k]+=value*coeff
   coeff*=step/(n+1)
  snapshot=[]
  for row in vals:
   vrow=[]
   for v in row:
    centre=F(str(v.mid().fmpq()))
    rounded=round_dyadic(centre)
    assert abs(v-a(rounded))<a(F(1,2**79))
    vrow.append(rounded)
   snapshot.append(vrow)
  out.append(snapshot)
 return out

def make_prediction(ratios):
 q,lock=model_lock(ratios)
 values=predict_values([pair(x) for x in q])
 result={'kind':'MODEL_PREDICTION','model_lock':lock,'model_lock_sha256':digest(lock),
  'times':load('DESIGN.json')['times'],'shape':[25,62,3],
  'prediction_numerical_error_F':[1,2**70],
  'outputs':[[[pair(x) for x in row] for row in snap] for snap in values]}
 result['prediction_sha256']=digest(result)
 return result

REQUIRED_RECEIPTS=['calibration_ratio_bound','ratio_domain','modeled_gain_62_uncertainty_bound',
 'combined_preparation_bound','sample_noise_bound','time_error_bound','stable_family',
 'fit_frozen_before_validation','validation_excluded_from_fit']
def decode_outputs(raw):
 if not isinstance(raw,list) or len(raw)!=25:raise ValueError('Expected25 snapshots')
 out=[]
 for snap in raw:
  if not isinstance(snap,list) or len(snap)!=62:raise ValueError('Expected62 outputs')
  block=[]
  for row in snap:
   if not isinstance(row,list) or len(row)!=3:raise ValueError('Expected3 preparation columns')
   block.append([parse(x) for x in row])
  out.append(block)
 return out
def assess(prediction,observations):
 pred=dict(prediction);stored=pred.pop('prediction_sha256',None)
 if stored!=digest(pred):raise ValueError('Prediction hash mismatch')
 _,lock=model_lock(pred['model_lock']['ratios'])
 if lock!=pred['model_lock'] or digest(lock)!=pred['model_lock_sha256']:raise ValueError('Source/model lock mismatch')
 if observations.get('model_lock_sha256')!=pred['model_lock_sha256']:raise ValueError('Observation model lock mismatch')
 times=load('DESIGN.json')['times']
 if pred.get('times')!=times or observations.get('times')!=times:raise ValueError('Time grid mismatch')
 if observations.get('kind') not in ['SYNTHETIC_CONTROL','APPARATUS_DATA']:raise ValueError('Declare observation kind')
 P=decode_outputs(pred['outputs']);Y=decode_outputs(observations['outputs'])
 cert=load('HELD_OUT_CERTIFICATE.json');thresholds=[parse(x['acceptance_ceiling']) for x in cert['sample_thresholds']]
 squares=[sum((p-y)**2 for prow,yrow in zip(ps,ys) for p,y in zip(prow,yrow)) for ps,ys in zip(P,Y)]
 flags=[i for i,(sq,th) in enumerate(zip(squares,thresholds)) if sq>=th**2]
 weights=[parse(x) for x in cert['sampled_energy']['weights']]
 energy=sum(w*sq for w,sq in zip(weights,squares));energy_gate=parse(cert['sampled_energy']['acceptance_ceiling'])
 receipts=observations.get('receipts',{})
 missing=[key for key in REQUIRED_RECEIPTS if not isinstance(receipts.get(key),str) or not receipts[key].strip()]
 return {'status':'COMPLETE_INPUTS' if not missing else 'INCOMPLETE_RECEIPTS',
  'sampled_decision':'REJECT_JOINT_CONTRACT' if flags or energy>=energy_gate else 'CONSISTENT_AT_SAMPLED_POINTS',
  'declared_observation_kind':observations['kind'],'physical_promotion':0,
  'missing_receipts':missing,'receipt_contents_independently_verified':False,
  'rejected_sample_indices':flags,'residual_Frobenius_squared':[pair(x) for x in squares],
  'sampled_energy':pair(energy),'sampled_energy_gate':pair(energy_gate),
  'early_gate_passed':not any(i<=12 for i in flags),
  'model_lock_sha256':pred['model_lock_sha256'],
  'interpretation':'Consistency at these samples only. Does not identify an unrestricted generator, certify asymptotic stability or diagnose a failure cause.',
  'empirical_model_validity_claimed':False}

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 sub=parser.add_subparsers(dest='command',required=True)
 p=sub.add_parser('predict');p.add_argument('--ratios',nargs=6,required=True);p.add_argument('--out',required=True)
 p=sub.add_parser('assess');p.add_argument('prediction');p.add_argument('observations');p.add_argument('--out',required=True)
 args=parser.parse_args()
 if args.command=='predict':result=make_prediction(args.ratios)
 else:result=assess(json.loads(Path(args.prediction).read_text()),json.loads(Path(args.observations).read_text()))
 Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'output':args.out,'kind':result.get('kind'),'decision':result.get('sampled_decision'),'status':result.get('status')}))

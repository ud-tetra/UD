"""Exact gate controls using separately declared synthetic alternative models.

Run python -m unittest -v test_validation.py. No apparatus data are generated.
"""
import copy,json,unittest
from fractions import Fraction as F
from pathlib import Path
from validation_engine import (ROOT,assess,decode_outputs,load,make_prediction,
 model_lock,pair,predict_values,REQUIRED_RECEIPTS)

def wrap(pred,values,label):
 return {'kind':'SYNTHETIC_CONTROL','control':label,
  'model_lock_sha256':pred['model_lock_sha256'],'times':pred['times'],
  'outputs':[[[pair(x) for x in row] for row in snap] for snap in values],
  'receipts':{k:'synthetic control assumption; not an apparatus receipt' for k in REQUIRED_RECEIPTS}}

class ValidationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.pred=make_prediction(['1']*6);cls.nominal=decode_outputs(cls.pred['outputs'])
  q=[pair(F(1)+F(1,2**45))]+[[1,1]]*5
  cls.allowed=predict_values(q)
  obs=load('DESIGN.json')['readout_coordinates'];assert obs[0] not in [1,133,486,878,1680,2040]
  more=predict_values(['1']*6,read_indices=obs+[0])
  cls.cross=[]
  for snap in more:
   block=[row[:] for row in snap[:62]]
   for k in range(3):block[0][k]+=F(1,2**30)*snap[62][k]
   cls.cross.append(block)
  cls.dynamic=predict_values(['1']*6,extra_entries=[(obs[0],0,F(1,2**20)),(0,obs[0],-F(1,2**20))])
  cls.results={}
 def test_nominal_consistent(self):
  result=assess(self.pred,wrap(self.pred,self.nominal,'exact fitted nominal control'))
  self.assertEqual(result['sampled_decision'],'CONSISTENT_AT_SAMPLED_POINTS')
  self.results['nominal']=result['sampled_decision']
 def test_allowed_ratio_uncertainty(self):
  result=assess(self.pred,wrap(self.pred,self.allowed,'trueD1 differs from fittedD1 by2^-45'))
  self.assertEqual(result['sampled_decision'],'CONSISTENT_AT_SAMPLED_POINTS')
  sq=[F(*x) for x in result['residual_Frobenius_squared']]
  self.assertGreater(sq[12],(F(1,2**49)+F(1,2**69))**2)
  # The fitted unit ratios can actually arise within the prior raw calibration
  # noise budget: cancel the six finite raw response changes, rather than
  # merely placing the parameter pair inside a conservative error envelope.
  poly=load('sources/PARENT_FINITE_MAP.json')['integer_coefficients']
  def phi(q):
   values=[]
   for r,grade in enumerate([0,1,1,2,2,3]):
    value=F(0)
    for k in range(3):
     direction=grade-k
     if direction not in [0,1]:continue
     from math import factorial
     for m,c in enumerate(poly[r][k]):
      value+=c*q[2*k+direction]*(q[2*k]*q[2*k+1])**m*F(1,32)**(2*m)/factorial(2*m+1)
    values.append(value)
   return values
  nominal=phi([F(1)]*6)
  true=phi([F(1)+F(1,2**45)]+[F(1)]*5)
  raw_noise_L1=sum(abs(x-y) for x,y in zip(nominal,true))/32+F(1,2**174)
  self.assertLess(raw_noise_L1,F(1,2**49))
  self.results['allowed_ratio_uncertainty']={'corrected_gate':result['sampled_decision'],
   'user_2^-49_gate_at12over32':'REJECTED despite allowed calibration uncertainty',
   'residual_F_squared_at12over32':pair(sq[12]),
   'fitted_unit_ratios_realizable_by_raw_calibration_noise_below2^-49':True,
   'raw_calibration_noise_L1_upper_including_Taylor_tails':pair(raw_noise_L1)}
 def test_cross_talk_rejected(self):
  result=assess(self.pred,wrap(self.pred,self.cross,'alternate readoutC=R+2^-30 row0 e0T'))
  self.assertIn(0,result['rejected_sample_indices'])
  self.results['cross_talk']={'decision':result['sampled_decision'],
   'residual_F_squared_at0':result['residual_Frobenius_squared'][0]}
 def test_dynamic_alternative_rejected(self):
  result=assess(self.pred,wrap(self.pred,self.dynamic,'alternate generatorA+2^-20(erp e0T-e0 erpT)'))
  self.assertEqual(result['sampled_decision'],'REJECT_JOINT_CONTRACT')
  self.assertIn(1,result['rejected_sample_indices'])
  self.results['dynamic_alternative']={'decision':result['sampled_decision'],
   'residual_F_squared_at1over32':result['residual_Frobenius_squared'][1],
   'scope':'Positive control of response gate; no claim it passes the twelve calibration values'}
 def test_missing_receipts_stays_incomplete(self):
  data=wrap(self.pred,self.nominal,'missing receipts');data['receipts']={}
  self.assertEqual(assess(self.pred,data)['status'],'INCOMPLETE_RECEIPTS')
 def test_lock_mismatch_rejected(self):
  data=wrap(self.pred,self.nominal,'wrong lock');data['model_lock_sha256']='wrong'
  with self.assertRaises(ValueError):assess(self.pred,data)
 def test_bad_shape_rejected(self):
  data=wrap(self.pred,self.nominal,'truncated timeline');data['outputs'].pop()
  with self.assertRaises(ValueError):assess(self.pred,data)
 def test_prediction_tamper_rejected(self):
  pred=copy.deepcopy(self.pred);pred['outputs'][0][0][0]=[0,1]
  with self.assertRaises(ValueError):assess(pred,wrap(self.pred,self.nominal,'tamper'))
 def test_float_decision_inputs_rejected(self):
  data=wrap(self.pred,self.nominal,'float');data['outputs'][0][0][0]=0.1
  with self.assertRaises(ValueError):assess(self.pred,data)
 def test_synthetic_control_not_empirical(self):
  result=assess(self.pred,wrap(self.pred,self.nominal,'nominal'))
  self.assertFalse(result['empirical_model_validity_claimed'])
 @classmethod
 def tearDownClass(cls):
  out={'status':'CONTROLS_COMPUTED; test outcome recorded separately by validation runner','physical_promotion':0,'independent_review':'pending',
   'kind':'SYNTHETIC_CONTROLS_ONLY','tests':cls.results,
   'generator_controls':'Separate frozenA or specified alternative-generator evolution; not predicted_y+noise',
   'apparatus_execution':False}
  (ROOT/'SYNTHETIC_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':unittest.main()

"""Source-bound, uncertainty-aware sampled held-out validation design."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
import numpy as np
from flint import arb,ctx,nmod_mat

root=Path(__file__).resolve().parent;ctx.prec=256
def a(x):
 x=F(x);return arb(x.numerator)/x.denominator
def pair(x):
 x=F(x);return [x.numerator,x.denominator]
def enc(x):return {'arb_enclosure':str(x),'display_only':float(x.mid())}
def write(name,x):(root/name).write_text(json.dumps(x,indent=2)+'\n')
domain='UD-600cell-six-ratio-heldout-v0.1-2026-10-17'
bits=np.unpackbits(np.frombuffer(hashlib.shake_256(domain.encode()).digest((2640*3+7)//8),dtype=np.uint8),bitorder='little')[:2640*3]
S=(2*bits.astype(np.int16)-1).reshape(2640,3)
parent=np.load(root/'sources/PARENT_37_PREPARATIONS.npz')['numerator'].astype(np.int64)
assert parent.shape==(2640,37)
cal=np.zeros((2640,3),dtype=np.int64)
cal[[1,133,486,878,1680,2040],0]=52
cal[[1,1680],1]=52;cal[[133,2040],2]=52
joint=np.concatenate([parent,cal,S],axis=1)
Gram=joint.T@joint
rank=nmod_mat(Gram.tolist(),1009).rank();assert rank==43
assert np.diag(S.T@S).tolist()==[2640]*3
np.savez_compressed(root/'HELD_OUT_PREPARATIONS.npz',numerator=S.astype(np.int8),denominator=np.array(52))
z=np.load(root/'sources/OPERATORS.npz');obs=z['obs'].tolist();assert len(obs)==62
assert obs[0] not in [1,133,486,878,1680,2040]
design={'physical_promotion':0,'status':'CANDIDATE_DESIGN_CONSTRUCTOR_VERIFIED',
 'domain':domain,'algorithm':'SHAKE256, little-bit order, row-major2640x3;0->-1,1->+1; divide52',
 'labels':['x38','x39','x40'],'label_scope':'Labels only; does not establish randomized independence or preparation realization',
 'preparation_squared_norm_each':[165,169],'combined_Frobenius_norm_squared':[495,169],
 'numerator_sha256':hashlib.sha256(S.astype(np.int8).tobytes()).hexdigest(),
 'joint_37_plus_three_calibration_plus_three_validation_Gram_rank_mod1009':rank,
 'readout_coordinates':obs,'times':[pair(F(j,32)) for j in range(25)],
 'steps':24,'snapshots_including_zero':25,'scalar_readings':4650,
 'early_gate_interval':[0,[3,8]],'final_time':[3,4],
 'heldout_policy':'Freeze actual fitted ratios, probes, time grid, source hashes and decision thresholds before examining validation outputs; do not refit on these outputs',
 'scope':'Sampled prediction consistency; no full generator identification or asymptotic stability assertion'}
write('DESIGN.json',design)

delta=F(1,2**40);generator_error=4*delta
omega=F(17,4);g=(a(F(17,15))**3).sqrt();b=arb(495).sqrt()/13
rho=F(1,2**47);xi=nu=F(1,2**49);jitter=F(1,2**55);pred=F(1,2**70)
intercept=g*((1+a(rho))*a(xi)+a(rho)*b+(1+a(rho))*b*a(omega*jitter))+a(nu)+a(pred)
slope=b*g*g*a(generator_error)
tau0=F(11,2**49);tau1=F(5,2**39)
assert intercept<a(tau0) and slope<a(tau1)
times=[F(j,32) for j in range(25)];thresholds=[tau0+tau1*t for t in times]
weights=[F(1,64)]+[F(1,32)]*23+[F(1,64)]
energy=sum(w*t*t for w,t in zip(weights,thresholds))
T=a(F(3,4));null_integral=intercept**2*T+intercept*slope*T**2+slope**2*T**3/3
cut=F(1,2**30)
cross_signal=a(cut)*arb(3).sqrt()/52
cross_uncertainty=a((1+cut)*xi+nu+pred)
assert cross_signal-cross_uncertainty>a(tau0)
sigma_static=arb(3).sqrt()/52
passing_scalar_fault=(a(tau0)+intercept)/(sigma_static-g*(a(xi)+b*a(omega*jitter)))
assert passing_scalar_fault<a(F(1,2**39))
bound=[{'time':pair(t),'null_response_bound':enc(intercept+slope*a(t)),
        'acceptance_ceiling':pair(th)} for t,th in zip(times,thresholds)]
write('HELD_OUT_CERTIFICATE.json',{
 'status':'DERIVED_CONDITIONAL_CONSTRUCTOR_VERIFIED','physical_promotion':0,'independent_review':'pending','lane':'development; no registry entry',
 'true_and_fitted_ratio_box':[[15,16],[17,16]],'six_vector_calibration_error_ceiling':pair(delta),
 'effective_generator_error_upper':pair(generator_error),'propagator_norm_uniform_all_signed_times':enc(g),
 'propagator_bound_proof':'H grades are cumulative productsD/U; maxH/minH <=(17/15)^3; K is H-skew, hence normU(t)<=sqrt(maxH/minH)',
 'null_response_bound_formula':'B(t)=a0+a1*t; a0=g*((1+rho)*xi+rho*b+(1+rho)*b*omega*j)+nu+eps_pred; a1=b*g^2*(4*delta)',
 'b_preparation_Frobenius':enc(b),'null_intercept':enc(intercept),'null_slope':enc(slope),
 'exact_acceptance_envelope':{'intercept':pair(tau0),'slope':pair(tau1),'formula':'tau(t)=11/2^49 + (5/2^39)*t'},
 'instrument_receipts_required':{
  'gain_normalized_62_output_readout_operator_error':pair(rho),
  'combined_three_run_preparation_Frobenius_error':pair(xi),
  'combined_62_by3_output_noise_Frobenius_at_each_sample':pair(nu),
  'each_run_logger_time_error':pair(jitter),'prediction_Frobenius_numerical_error':pair(pred),
  'new_readout_receipt':'All62 gain corrections need uncertainty receipts. Under the diagonal readout null these bound the modeled readout operator; only2 ports share the previous calibration. Passing probes do not certify arbitrary cross-talk bounds.',
  'offset_handling':'noise receipt includes blank/offset correction; no blank run counted in4650',
  'family_stability':'fixed linear grade-scalar positive generator and bounded readout over all runs'},
 'sample_thresholds':bound,'sampled_energy':{'definition':'trapezoidal grid sum weights_j * ||residual_j||_F^2',
  'weights':[pair(w) for w in weights],'acceptance_ceiling':pair(energy),
  'diagnostic_only':'Redundant when every node gate passes; not a continuous integral measurement'},
 'continuous_energy_envelope_if_same_receipts_hold_all_times':enc(null_integral),
 'continuous_envelope_scope':'Not inferred from finite samples. Includes noise terms, so requires their bounds at every intermediate time as well.',
 'continuous_interpolation_no_go':{'residual':'2^-20 * sin(32*pi*t) * a unit output/preparation matrix',
  'zero_on_all_grid_nodes':True,'integral_squared_Frobenius_on_0_to_3_over4':[3,2**43],
  'comparison':'exceeds2^-55 despite exact sampled agreement; independent regularity bounds required'},
 'static_cross_talk_control':{'readout_fault':'2^-30 * first_output_row * input_coordinate0^T',
  'unused_by_six_ratio_calibration_output':obs[0],
  'unchanged_twelve_calibration_readings':True,'validation_time0_signal_Frobenius':enc(cross_signal),
  'measurement_and_prediction_uncertainty_bound':enc(cross_uncertainty),
  'restricted_one_coefficient_static_observation_singular_value':enc(sigma_static),
  'passing_restricted_scalar_fault_upper':enc(passing_scalar_fault),
  'passing_restricted_scalar_fault_declared_upper':[1,2**39],
  'certified_time0_rejection':True,'scope':'Constructed alternative, not an inferred cause for arbitrary failures'},
 'no_go':{'three_validation_cyclic_span_upper_nominal':315,
  'arbitrary_readout_blind_directions_per_row_lower_nominal':2325,
  'three_calibration_plus_three_validation_cyclic_span_upper':630,
  'combined_six_preparation_readout_blind_directions_per_row_lower':2010,
  'original62_nominal_dynamic_kernel':747,
  'scope':'Cyclic dimensions use frozen nominal degree105; do not claim the same minimal polynomial for generic unequal directed rates',
  'finite_horizon':'3/4 is a short finite run; cannot certify asymptotic behavior or the long acquisition horizon',
  'failure_cause':'A breach rejects the joint fitted-family and metrology contract; does not identify resonance/bulk leakage'},
 'policy':{'fitting_on_validation_data':False,'empirical_pass_claimed':False,'independent_validation_data_supplied':False}})
write('AUDIT.json',{'physical_promotion':0,'supplied_script_executed':False,'items':[
 {'claim':'six-ratio accuracy is exact arithmetic accuracy','finding':'NO: exact arithmetic proof bounds nonzero parameter estimation error'},
 {'claim':'12 calibration scalars are12 temporal steps','finding':'NO: six initial gain readings plus six readings at one positive interval'},
 {'claim':'minimal extraction window','finding':'NOT PROVED: sufficiency was certified; global minimality was not'},
 {'claim':'20iterations converge beneath raw noise floor','finding':'TYPE ERROR: normalized ratio defect and raw observation noise have different scaling'},
 {'claim':'auxiliary ports isolate bulk from shell','finding':'NO: port selection is readout access, not an invariant dynamical split'},
 {'claim':'seed822d407','finding':'SYNTAX ERROR: invalid decimal literal; hexadecimal conversion would not validate provenance'},
 {'claim':'random dense skew matrix isA_fit','finding':'UNSUPPORTED: replaces frozen14880-entry incidence operator and ignores fitted grade metric'},
 {'claim':'random denseR is original62 observer','finding':'FALSE: originalR is the frozen coordinate selector of operator norm1'},
 {'claim':'normalized sign preparations need sqrt rescaling','finding':'UNNECESSARY: exact2640/52^2=165/169 already'},
 {'claim':'true_y=predicted_y+noise validates model','finding':'CIRCULAR: residual is exactly the injected noise, up to rounding'},
 {'claim':'Gaussian sigma bounds noise floor','finding':'FALSE: Gaussian noise is unbounded; vector norm scales with matrix dimensions'},
 {'claim':'Euler step is exponential and norm preserving','finding':'FALSE: ||(I+hA)x||^2=||x||^2+h^2||Ax||^2 for real skewA'},
 {'claim':'script implementsFrobenius2^-49 gate','finding':'FALSE: computes spectral norm and compares peak to2^-39'},
 {'claim':'24 iterations cover24/32','finding':'FALSE in suppliedrange(24): last reported state is23/32; needs25 snapshots for24 intervals'},
 {'claim':'time jitter2^-55 is residual energy threshold','finding':'UNSUPPORTED: distinct typed quantities; no transfer law'},
 {'claim':'Riemann sum certifiescontinuous integral','finding':'NO without quadrature/regularity bound'},
 {'claim':'short finite run provesasymptotic stability','finding':'NO'},
 {'claim':'one channel failure provesunmodeled bulk phases','finding':'NO: multiple model/metrology discrepancies can cause it'}]})
print(json.dumps({'status':'PASS','new_probes':3,'joint_rank_mod1009':rank,'sample_count':25,
 'threshold_at0':float(a(thresholds[0])),'threshold_at12over32':float(a(thresholds[12])),
 'threshold_at24over32':float(a(thresholds[-1])),'sampled_energy_gate':float(a(energy))}))

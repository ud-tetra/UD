"""Isolated replay of the design, uniform bounds, gate tests and source hashes."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
import numpy as np
root=Path(__file__).resolve().parent
prov=json.loads((root/'PROVENANCE.json').read_text())
for item in prov['sources']:
 b=(root/item['path']).read_bytes()
 assert len(b)==item['size_bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
with tempfile.TemporaryDirectory(prefix='ud-heldout-replay-') as tmp:
 p=Path(tmp);shutil.copytree(root/'sources',p/'sources')
 for name in ['certify_heldout.py','validation_engine.py','test_validation.py']:
  shutil.copy2(root/name,p/name)
 c=subprocess.run([sys.executable,'certify_heldout.py'],cwd=p,capture_output=True,text=True)
 assert c.returncode==0,c.stderr
 r=subprocess.run([sys.executable,'-m','unittest','-v','test_validation.py'],cwd=p,capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 assert 'Ran 10 tests' in r.stderr and r.stderr.rstrip().endswith('OK'),r.stderr
 for name in ['DESIGN.json','HELD_OUT_CERTIFICATE.json','AUDIT.json','SYNTHETIC_CONTROLS.json']:
  assert json.loads((root/name).read_text())==json.loads((p/name).read_text()),name
 x=np.load(root/'HELD_OUT_PREPARATIONS.npz');y=np.load(p/'HELD_OUT_PREPARATIONS.npz')
 for key in x.files:assert np.array_equal(x[key],y[key])
out={'status':'PASS','physical_promotion':0,'independent_review':'pending',
 'isolated_replay':'design, uniform certificate, audit, synthetic controls and preparation arrays identical',
 'exact_gate_tests':10,'rational_probes':3,'joint_initial_preparation_rank':43,
 'sampled_scalar_readings':4650,'synthetic_controls_only':True,
 'key_result':'Allowed calibration uncertainty can fail the proposed2^-49 residual gate while passing the corrected envelope',
 'detected_positive_controls':['static cross-talk on uncalibrated output','explicit extra skew generator term'],
 'not_established':['Apparatus passage','Arbitrary generator/readout bounds','Continuous integral from samples','Asymptotic stability','Independent review']}
(root/'VALIDATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

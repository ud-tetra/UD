from pathlib import Path
import json,tempfile,shutil,subprocess,sys,os
D=Path(__file__).resolve().parent
scripts=['modal_dimensions.py','stage_ranks.py','frequency_certificate.py','spatial_certificate.py','schedule_certificates.py','summarize.py','validate.py']
with tempfile.TemporaryDirectory() as td:
 t=Path(td);shutil.copytree(D/'sources',t/'sources')
 for f in ['operators.npz','moments.json.gz','SELECTION.json','RANK_CERTIFICATE.json','ANNIHILATOR_CERTIFICATE.json']+scripts:shutil.copy2(D/f,t/f)
 env=dict(os.environ);env['OPENBLAS_NUM_THREADS']='2'
 for f in scripts:subprocess.run([sys.executable,str(t/f)],check=True,env=env)
 same=['MODAL_DIMENSIONS.json','STAGE_RANKS.json','FREQUENCY_CERTIFICATE.json','SCHEDULE_CERTIFICATES.json','RESULTS.json','VALIDATION.json','FINAL_PORT_WITNESS.json']
 for f in same:assert (t/f).read_bytes()==(D/f).read_bytes(),f
 a=json.loads((t/'CONDITIONING_CERTIFICATE.json').read_text());b=json.loads((D/'CONDITIONING_CERTIFICATE.json').read_text())
 for k in ['spatial_alpha_squared_rational_lower','normalized_sampling_sigma_min_squared_lower','normalized_sampling_sigma_max_squared_upper','condition_number_upper_integer','sampled_observation_rank','sampled_kernel_dimension']:assert a[k]==b[k],k
(D/'CLEAN_REPLAY.json').write_text(json.dumps({'status':'PASS','scope':'clean trace, rational-stage, frequency, interval-conditioning, schedule, summary and validation replay from preserved integer moments; full field rank and integer moment generation executed separately','byte_identical_outputs':same,'rational_conditioning_bounds_identical':True},indent=2)+'\n');print('CLEAN CERTIFICATE REPLAY PASS')

import json,math
from pathlib import Path
import sympy as s
from flint import arb,ctx
D=Path(__file__).resolve().parent
ctx.prec=256
x=s.Symbol('x');q=s.Poly.from_list(json.loads((D/'sources/modular_results.json').read_text())['qL_coefficients'],x)
def rat(z):return arb(str(z.p))/int(z.q)
roots=[];factors=[]
for ff,e in s.factor_list(q)[1]:
 for (a,b),mult in s.polys.polytools.intervals(ff,eps=s.Rational(1,2**190)):
  mid=(a+b)/2;rad=(b-a)/2;mu=arb(rat(mid),rat(rad));assert mu.lower()>=0
  roots.append({'factor':str(ff.as_expr()),'a':[int(a.p),int(a.q)],'b':[int(b.p),int(b.q)],'omega':mu.sqrt()})
roots.sort(key=lambda r:float(r['omega']))
assert len(roots)==53 and roots[0]['omega']==0
frequencies=[-r['omega'] for r in roots[:0:-1]]+[r['omega'] for r in roots]
assert len(frequencies)==105
C=[];mingap=None
for i,w in enumerate(frequencies):
 c=arb(0)
 for j,v in enumerate(frequencies):
  if i==j:continue
  gap=abs(w-v);lo=gap.lower();assert lo>0
  if mingap is None or lo<mingap:mingap=lo
  den=abs((gap/4).sin());assert den.lower()>0
  c+=1/den
 C.append(c)
Cmax=max(c.upper() for c in C);M=1
while arb(M)<4*Cmax:M*=2
eps=Cmax/M;assert eps<arb(1)/4
out={'mu_root_intervals':[{k:v for k,v in r.items() if k!='omega'} for r in roots],'frequency_count':105,'step':[1,2],'samples':M,'last_time':[(M-1),2],'temporal_row_sum_bound':str(Cmax),'temporal_epsilon_upper':str(eps.upper()),'temporal_epsilon_rational_bound':[1,4],'frequency_gap_lower':str(mingap),'precision_bits':256,'proof':'Geometric-series off-diagonal Gram entries <=1/(M abs(sin((omega_i-omega_j)/4))); Gershgorin gives spectrum within [1-epsilon,1+epsilon].','status':'CERTIFIED_ARB_WITH_EXACT_STURM_ROOT_INTERVALS'}
(D/'FREQUENCY_CERTIFICATE.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k!='mu_root_intervals'})

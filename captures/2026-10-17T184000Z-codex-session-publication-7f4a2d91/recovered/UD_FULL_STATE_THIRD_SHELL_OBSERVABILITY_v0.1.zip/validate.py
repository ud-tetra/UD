from pathlib import Path
import json,gzip,math
import numpy as np,scipy.sparse as sp
from flint import arb,ctx,fmpz_mat
D=Path(__file__).resolve().parent;ctx.prec=256;checks={}
def ck(n,b):assert b,n;checks[n]=True
z=np.load(D/'operators.npz');A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(2640,2640));obs=z['obs'];st=json.loads((D/'STAGE_RANKS.json').read_text());rk=json.loads((D/'RANK_CERTIFICATE.json').read_text());mo=json.loads((D/'MODAL_DIMENSIONS.json').read_text());cert=json.loads((D/'CONDITIONING_CERTIFICATE.json').read_text());freq=json.loads((D/'FREQUENCY_CERTIFICATE.json').read_text());src=json.loads((D/'sources/COMPLEX_AND_ACTION.json').read_text());sel=json.loads((D/'SELECTION.json').read_text())
ck('A_skew',(A+A.T).nnz==0);ck('baseline_readout_included',set(map(int,np.load(D/'sources/selected_operators.npz')['obs'])) <= set(map(int,obs[:186])))
ck('coordinate_observer',len(obs)==189 and len(set(obs))==189);ck('all_third_centres_screened',len(sel['third_shell_cases'])==118 and sel['selected_third']['vertex']==66)
ck('exact_stages',st['ranks']==[2626,2634,2638,2640] and st['kernel_dimensions']==[14,6,2,0]);ck('full_rank_two_primes',[(r['prime'],r['rank']) for r in rk['checks']]==[(1009,2640),(1013,2640)])
ck('modal_dimensions_independent',mo['simplex_orbit_counts']==[1]*4 and mo['symmetry_actions']==240 and sum(c['ambient_dimension'] for c in mo['components'])==2640)
ck('temporal_bound',freq['samples']==8192 and arb(freq['temporal_epsilon_upper'])<arb(1)/4);ck('all_modal_spatial_bounds',len(cert['components'])==53 and all(arb(c['spatial_squared_singular_lower'])>arb(1)/65536 for c in cert['components']))
ck('modal_ranks_sum',sum(c['rank_per_signed_frequency']*(1 if i==0 else 2) for i,c in enumerate(cert['components']))==2640);ck('condition_bound',296**2*3>262144 and cert['condition_number_upper_integer']==296)
ck('full_band_below_four',freq['mu_root_intervals'][-1]['b'][0]<16*freq['mu_root_intervals'][-1]['b'][1])
with gzip.open(D/'moments.json.gz','rt') as f:mom=json.load(f)
ck('zeroth_G_moment',mom['G'][0]==np.eye(189,dtype=int).tolist());ck('zeroth_J_moment',mom['J'][0]==A[obs][:,obs].toarray().tolist());ck('annihilator_record',json.loads((D/'ANNIHILATOR_CERTIFICATE.json').read_text())['status']=='PASS')
off=[0,120,840,2040,2640];ck('ports_match_simplex_data',all(tuple(src['simplices'][p['degree']][p['coordinate']-off[p['degree']]])==tuple(p['simplex']) for p in sel['additional_ports']))
# Explicit two-dimensional ambiguity removed by the final vertex port.
L=(-A@A).tocsr();before=obs[:-1];assert obs[-1]==4
rows=[(L[:120,:120]-14*sp.eye(120,dtype=np.int64)).toarray()]
for coord in before:
 if coord<120:rows.append(np.eye(120,dtype=np.int64)[[coord]])
 elif coord<840:rows.append(A[[coord],:120].toarray())
K,null=fmpz_mat(np.vstack(rows).tolist()).nullspace();ck('last_port_graph_nullity',null==1)
v=[int(K[i,0]) for i in range(120)];g=math.gcd(*v);x=np.array([a//g for a in v]+[0]*2520,dtype=object)
def mul(v):return np.array([sum(int(a)*v[j] for j,a in zip(A.indices[A.indptr[i]:A.indptr[i+1]],A.data[A.indptr[i]:A.indptr[i+1]])) for i in range(2640)],dtype=object)
y=mul(x);ck('last_port_witness',not np.any(x[before]) and not np.any(y[before]) and np.array_equal(mul(y),-14*x) and x[4]!=0)
enc=lambda a:[[i,int(v)] for i,v in enumerate(a) if v]
(D/'FINAL_PORT_WITNESS.json').write_text(json.dumps({'frequency_squared':14,'x':enc(x),'Ax':enc(y),'identity':'A²x=-14x; all first 188 readouts vanish on x and Ax for every time; vertex coordinate 4 observes x and its history observes the oscillator pair','last_port_initial_value':int(x[4])},indent=2)+'\n')
(D/'VALIDATION.json').write_text(json.dumps({'status':'PASS','checks':checks,'check_count':len(checks)},indent=2)+'\n');print('VALIDATION PASS',len(checks))

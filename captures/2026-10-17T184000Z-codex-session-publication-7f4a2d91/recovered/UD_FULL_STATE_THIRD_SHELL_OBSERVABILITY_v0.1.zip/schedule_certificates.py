from pathlib import Path
import json,math
from fractions import Fraction
from flint import arb,ctx
D=Path(__file__).resolve().parent;ctx.prec=256;freq=json.loads((D/'FREQUENCY_CERTIFICATE.json').read_text());C=arb(freq['temporal_row_sum_bound']);rows=[]
for M,eps in [(2048,Fraction(7,8)),(4096,Fraction(1,2)),(8192,Fraction(1,4))]:
 assert C/M < arb(eps.numerator)/eps.denominator
 low=(1-eps)/65536;k=math.isqrt(low.denominator//low.numerator)
 while k*k*low.numerator<low.denominator:k+=1
 rows.append({'samples':M,'step':[1,2],'last_time':[M-1,2],'scalar_samples':189*M,'temporal_epsilon_upper':[eps.numerator,eps.denominator],'sigma_min_squared_lower':[low.numerator,low.denominator],'sigma_max_squared_upper':[1,1],'condition_number_upper_integer':k,'inverse_noise_amplification_upper_integer':k,'rank':2640,'kernel':0})
assert [r['condition_number_upper_integer'] for r in rows]==[725,363,296]
(D/'SCHEDULE_CERTIFICATES.json').write_text(json.dumps({'status':'CERTIFIED','spatial_alpha_squared_lower':[1,65536],'protocols':rows,'proof':'The reciprocal-sine sum C is independent of sample count. For each M, C/M is strictly below the declared rational epsilon. Temporal frame and common spatial bounds yield sigma_min² >= (1-epsilon)/65536. Norm preservation gives sigma_max<=1.'},indent=2)+'\n');print('THREE SCHEDULE CERTIFICATES PASS')

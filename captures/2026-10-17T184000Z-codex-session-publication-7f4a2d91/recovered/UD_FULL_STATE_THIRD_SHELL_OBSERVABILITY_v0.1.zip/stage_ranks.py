import json,gzip,math
from pathlib import Path
import numpy as np,sympy as s
from flint import fmpz_mat,nmod_mat
D=Path(__file__).resolve().parent
with gzip.open(D/'moments.json.gz','rt') as f:mom=json.load(f)
G=[np.array(v,dtype=object) for v in mom['G']];J=[np.array(v,dtype=object) for v in mom['J']];ns=mom['sensor_count'];assert ns==189
modal=json.loads((D/'MODAL_DIMENSIONS.json').read_text());prior={c['factor']:c['augmented_rank'] for c in json.loads((D/'sources/RESULTS.json').read_text())['spectral_components']};x=s.Symbol('x');q=s.Poly.from_list(json.loads((D/'sources/modular_results.json').read_text())['qL_coefficients'],x)
rows=[]
for c in modal['components']:
 dim=c['ambient_dimension'];d=c['degree']
 if prior[c['factor']]==dim:ranks=[dim]*4;method='baseline exact full component rank plus observation inclusion'
 else:
  Q=s.Poly.from_list(list(reversed(c['projector_coefficients_ascending'])),x);gs=[];js=[]
  for power in range(2*d):
   pol=(Q*s.Poly(x**power,x)).rem(q);coeff=[int(pol.nth(k)) for k in range(53)]
   gs.append(sum((a*M for a,M in zip(coeff,G) if a),np.zeros((ns,ns),dtype=object)))
   js.append(sum((a*M for a,M in zip(coeff,J) if a),np.zeros((ns,ns),dtype=object)))
  blocks=[]
  for a in range(d):
   row0=[];row1=[]
   for b in range(d):row0.extend([gs[a+b],-js[a+b]]);row1.extend([js[a+b],gs[a+b+1]])
   blocks.extend([row0,row1])
  B=np.block(blocks);assert np.array_equal(B,B.T)
  ranks=[]
  for n in [186,187,188,189]:
   take=[j*ns+i for j in range(2*d) for i in range(n)];M=B[np.ix_(take,take)].copy()
   for row in M:
    g=math.gcd(*map(int,row))
    if g>1:row//=g
   r=fmpz_mat(M.tolist()).rank();assert nmod_mat([[int(a)%1009 for a in row] for row in M],1009).rank()==r;ranks.append(r)
  method='exact rational rank of PSD history Gram via integer CRT projector moments'
 rows.append({'factor':c['factor'],'ambient_dimension':dim,'ranks':ranks,'method':method});print(c['factor'],ranks,flush=True)
totals=[sum(c['ranks'][i] for c in rows) for i in range(4)];assert totals==[2626,2634,2638,2640]
(D/'STAGE_RANKS.json').write_text(json.dumps({'status':'EXACT','stages':['third shell plus baseline tetrahedral port','plus face port','plus edge port','plus vertex port'],'sensor_counts':[186,187,188,189],'ranks':totals,'kernel_dimensions':[2640-r for r in totals],'components':rows,'proof':'For each real Laplacian CRT projector P, the history rows R L^j P and R A L^j P have PSD Gram blocks [[G_(j+k),-J_(j+k)],[J_(j+k),G_(j+k+1)]]. A positive common denominator gives an integer matrix of exactly the same rank. Sum over the mutually orthogonal factors. Components fully observed in the baseline stay full under added coordinates.'},indent=2)+'\n');print('EXACT STAGE RANKS PASS',totals)

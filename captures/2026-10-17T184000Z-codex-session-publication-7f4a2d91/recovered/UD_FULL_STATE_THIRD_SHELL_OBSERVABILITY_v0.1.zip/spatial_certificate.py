import json,gzip,time,math
from pathlib import Path
import numpy as np
import sympy as s
from flint import arb,arb_mat,acb,acb_mat,ctx
D=Path(__file__).resolve().parent;ctx.prec=256
freq=json.loads((D/'FREQUENCY_CERTIFICATE.json').read_text());ranks=json.loads((D/'MODAL_DIMENSIONS.json').read_text());assert ranks['complete']
with gzip.open(D/'moments.json.gz','rt') as f:mom=json.load(f)
n=mom['sensor_count'];G=[arb_mat(v) for v in mom['G']];J=[arb_mat(v) for v in mom['J']];del mom
co=json.loads((D/'sources/modular_results.json').read_text())['qL_coefficients'];dco=[a*(len(co)-1-i) for i,a in enumerate(co[:-1])]
rankmap={r['factor']:r for r in ranks['components']}
def rat(pair):return arb(str(pair[0]))/pair[1]
def rootball(r):
 a,b=rat(r['a']),rat(r['b']);return arb((a+b)/2,(b-a)/2)
res=[];alpha=None
for ri,r in enumerate(freq['mu_root_intervals']):
 start=time.time();mu=rootball(r);cc=[arb(1)]
 for b in co[1:-1]:cc.append(arb(b)+mu*cc[-1])
 derivative=arb(0)
 for c in dco:derivative=derivative*mu+c
 assert derivative.abs_lower()>0
 gg=arb_mat(n,n);jj=arb_mat(n,n)
 for k,c in enumerate(cc):gg+=G[52-k]*c;jj+=J[52-k]*c
 gg=gg*(1/derivative);jj=jj*(1/derivative)
 zero=ri==0
 if zero:
  H=acb_mat([[acb(gg[i,j]) for j in range(n)] for i in range(n)]);rank=rankmap[r['factor']]['ambient_dimension']
 else:
  omega=mu.sqrt();H=acb_mat([[acb(gg[i,j]/2,-jj[i,j]/(2*omega)) for j in range(n)] for i in range(n)])
  rr=rankmap[r['factor']];assert rr['ambient_dimension']%(2*rr['degree'])==0;rank=rr['ambient_dimension']//(2*rr['degree'])
 mid=np.array([[complex(float(H[i,j].real.mid()),float(H[i,j].imag.mid())) for j in range(n)] for i in range(n)])
 vals,U=np.linalg.eigh((mid+mid.conj().T)/2)
 UU=acb_mat([[acb(float(U[i,j].real),float(U[i,j].imag)) for j in range(n)] for i in range(n)]);adj=UU.conjugate().transpose();B=adj*H*UU;gram=adj*UU
 eta=max(sum((abs(gram[i,j]-(1 if i==j else 0)) for j in range(n)),arb(0)).upper() for i in range(n))
 epsilon=max(sum((abs(B[i,j]-(float(vals[i]) if i==j else 0)) for j in range(n)),arb(0)).upper() for i in range(n))
 assert eta<1
 lower=(arb(float(vals[n-rank]))-epsilon)/(1+eta)
 assert lower.lower()>0, (ri,r['factor'],lower)
 if alpha is None or lower.lower()<alpha:alpha=lower.lower()
 res.append({'factor':r['factor'],'mu_interval':{'a':r['a'],'b':r['b']},'rank_per_signed_frequency':rank,'spatial_squared_singular_lower':str(lower.lower()),'diagonalization_residual_upper':str(epsilon),'unitarity_defect_upper':str(eta),'numerical_min_positive_eigenvalue':float(vals[n-rank])})
 print(ri,r['factor'],'rank',rank,'lower',float(lower.lower()),'sec',time.time()-start,flush=True)
 (D/'SPATIAL_CERTIFICATE_PARTIAL.json').write_text(json.dumps({'components':res},indent=2)+'\n')
Bden=1
while arb(1)/Bden>=alpha:Bden*=2
# Exact integer bounds from alpha²>=1/Bden and temporal spectrum [3/4,5/4].
def ceil_sqrt_ratio(a,b):
 k=math.isqrt(a//b)
 while k*k*b<a:k+=1
 return k
amp=ceil_sqrt_ratio(4*Bden,3);cond=amp
out={'status':'CERTIFIED_INTERVAL_ARITHMETIC','precision_bits':256,'components':res,'spatial_alpha_squared_lower':str(alpha),'spatial_alpha_squared_rational_lower':[1,Bden],'normalized_sampling_sigma_min_squared_lower':[3,4*Bden],'normalized_sampling_sigma_max_squared_upper':[1,1],'condition_number_upper_integer':cond,'inverse_noise_amplification_upper_integer':amp,'samples':freq['samples'],'step':freq['step'],'sensor_count':n,'sampled_observation_rank':2640,'sampled_kernel_dimension':0,'proof':'Exact modal ranks specify zero eigenvalue multiplicities. Arb encloses compressed normal-operator spectral projectors. Approximate unitary congruence plus certified residual/Gram defects bounds each positive eigenvalue. Temporal Vandermonde Gershgorin bounds combine with these spatial lower bounds.'}
(D/'CONDITIONING_CERTIFICATE.json').write_text(json.dumps(out,indent=2)+'\n');print('FINAL',Bden,amp,cond,flush=True)

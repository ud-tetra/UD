import json,gzip,math
from pathlib import Path
import sympy as s
D=Path(__file__).resolve().parent;src=json.loads((D/'sources/COMPLEX_AND_ACTION.json').read_text());V=[tuple(tuple(p) for p in v) for v in src['vertices']];lookup={v:i for i,v in enumerate(V)};S=[[tuple(t) for t in ss] for ss in src['simplices']];idx=[{t:i for i,t in enumerate(ss)} for ss in S]
def pm(x,y):a,b=x;c,d=y;return a*c+b*d,a*d+b*c+b*d
def qm(v,w):
 signs=[[(0,0,1),(1,1,-1),(2,2,-1),(3,3,-1)],[(0,1,1),(1,0,1),(2,3,1),(3,2,-1)],[(0,2,1),(2,0,1),(3,1,1),(1,3,-1)],[(0,3,1),(3,0,1),(1,2,1),(2,1,-1)]];out=[]
 for terms in signs:
  a=b=0
  for i,j,sg in terms:c,d=pm(v[i],w[j]);a+=sg*c;b+=sg*d
  assert a%2==0 and b%2==0;out.append((a//2,b//2))
 return tuple(out)
parent=[list(range(len(ss))) for ss in S]
def find(pa,a):
 while pa[a]!=a:pa[a]=pa[pa[a]];a=pa[a]
 return a
actions=0
for u in V:
 for right in [False,True]:
  vp=[lookup[qm(v,u) if right else qm(u,v)] for v in V];assert len(set(vp))==120
  for k,ss in enumerate(S):
   pa=parent[k]
   for i,t in enumerate(ss):
    j=idx[k][tuple(sorted(vp[v] for v in t))];a=find(pa,i);b=find(pa,j);pa[a]=b
  actions+=1
orbits=[len({find(pa,i) for i in range(len(pa))}) for pa in parent];assert orbits==[1,1,1,1]
print('signed-natural symmetry: 240 left/right vertex maps preserve all simplices; transitive each grade',flush=True)
import numpy as np
z=np.load(D/'operators.npz');obs=z['obs'];off=[0,120,840,2040,2640];which=[next(i for i,v in enumerate(obs) if off[k]<=v<off[k+1]) for k in range(4)]
with gzip.open(D/'moments.json.gz','rt') as f:mom=json.load(f)
traces=[sum((off[k+1]-off[k])*G[which[k]][which[k]] for k in range(4)) for G in mom['G']]
x=s.Symbol('x');q=s.Poly.from_list(json.loads((D/'sources/modular_results.json').read_text())['qL_coefficients'],x).set_domain(s.QQ);rows=[]
for ff,e in s.factor_list(q)[1]:
 h=q.exquo(ff);inv=s.invert(h,ff);proj=(h*inv).rem(q);assert (proj*proj-proj).rem(q).is_zero
 den=s.ilcm(*[c.q for c in proj.all_coeffs()]);Q=s.Poly(proj*den,x);coef=[int(Q.nth(k)) for k in range(53)];num=sum(a*t for a,t in zip(coef,traces));assert num%den==0;dim=int(num//den)
 rows.append({'factor':str(ff.as_expr()),'degree':ff.degree(),'ambient_dimension':dim,'projector_denominator':int(den),'projector_coefficients_ascending':coef})
assert sum(r['ambient_dimension'] for r in rows)==2640
prior={r['factor']:r['ambient_dimension'] for r in json.loads((D/'sources/BASE_SPECTRAL_DIMENSIONS.json').read_text())['components']};assert all(prior[r['factor']]==r['ambient_dimension'] for r in rows)
(D/'MODAL_DIMENSIONS.json').write_text(json.dumps({'status':'EXACT_INDEPENDENT_TRACE_CERTIFICATE','complete':True,'ambient_dimension':2640,'symmetry_actions':actions,'simplex_orbit_counts':orbits,'trace_powers_L':traces,'components':rows,'proof':'Exact left/right quaternion automorphisms act transitively on simplices in each grade. Thus traces of L^k equal grade counts times any representative diagonal entry, available in observed moments. Rational CRT projectors have trace equal to their ambient dimension; q(L)=0 follows independently from full observability and the exact observer annihilator.'},indent=2)+'\n');print('MODAL TRACE DIMENSIONS PASS',flush=True)

from pathlib import Path
import json,time
import numpy as np,scipy.sparse as sp
from flint import nmod_mat
D=Path(__file__).resolve().parent;z=np.load(D/'operators.npz');N=2640
A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(N,N));R=np.eye(N,dtype=np.int64)[z['obs']];result=[]
for p in [1009,1013]:
 rows=[];cur=R;hit=None
 for k in range(64):
  rows.append(cur.copy());cur=(A.T@cur.T).T%p
  if k+1 in [32,64]:
   O=np.concatenate(rows);rank=nmod_mat(O.tolist(),p).rank();print(p,k+1,rank,flush=True)
   if rank==2640:hit=k+1;break
 if hit is None:raise AssertionError('extend depth explicitly')
 result.append({'prime':p,'derivative_orders':[0,hit-1],'rank':2640})
(D/'RANK_CERTIFICATE.json').write_text(json.dumps({'status':'EXACT_FULL_RANK_OVER_Q_R_AND_C','sensor_count':R.shape[0],'dimension':2640,'checks':result,'proof':'Each modular full rank certifies a nonzero integer minor. Rational rank is at least 2640 and at most the 2640 columns, hence exactly 2640.','full_state_kernel_dimension':0},indent=2)+'\n')

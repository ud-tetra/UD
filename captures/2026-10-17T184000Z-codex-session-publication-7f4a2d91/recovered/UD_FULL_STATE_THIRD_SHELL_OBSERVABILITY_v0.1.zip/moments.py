import json,gzip
from pathlib import Path
import numpy as np,scipy.sparse as sp
D=Path(__file__).resolve().parent;z=np.load(D/'operators.npz');obs=z['obs'];N=2640
A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(N,N));L=(-A@A).tocsr();R=np.eye(N,dtype=np.int64)[obs].astype(object)
co=json.loads((D/'sources/modular_results.json').read_text())['qL_coefficients']
def mul(M,S):
 out=np.zeros((M.shape[0],S.shape[1]),dtype=object);c=S.tocoo()
 for i,j,a in zip(c.row,c.col,c.data):out[:,j]+=int(a)*M[:,i]
 return out
# Stream moments and the annihilator rather than retaining all full Krylov matrices.
G=[];J=[];cur=R;ann=np.zeros(R.shape,dtype=object)
for k in range(54):
 ann+=int(co[53-k])*cur
 if k<=52:G.append(cur[:,obs].tolist());J.append(mul(cur,A)[:,obs].tolist())
 if k<53:cur=mul(cur,L)
 if k%10==0:print('power',k,flush=True)
assert not np.any(ann)
with gzip.open(D/'moments.json.gz','wt') as f:json.dump({'G':G,'J':J,'sensor_count':len(obs)},f,separators=(',',':'))
(D/'ANNIHILATOR_CERTIFICATE.json').write_text(json.dumps({'status':'PASS','integer_identity':'R q(-A²)=0','polynomial_degree':53,'observer_rows':len(obs),'precision':'arbitrary-precision integer arithmetic','full_carrier_consequence':'combined with full observation rank and commutation, q(-A²)=0 on all states'},indent=2)+'\n');print('MOMENT AND ANNIHILATOR PASS',flush=True)

import json,time
from pathlib import Path
import numpy as np,scipy.sparse as sp
from flint import nmod_mat
D=Path(__file__).resolve().parent;p=1009;N=2640
z=np.load(D/'sources/selected_operators.npz');A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(N,N));obs=z['obs'];R=np.eye(N,dtype=np.int64)[obs]
src=json.loads((D/'sources/COMPLEX_AND_ACTION.json').read_text());S=[[tuple(t) for t in ds] for ds in src['simplices']];off=np.cumsum([0]+list(map(len,S)));idx=[{t:i for i,t in enumerate(ss)} for ss in S]
def shell(v):return sorted(int(off[k])+idx[k][tuple(a for a in t if a!=v)] for k in range(3) for t in S[k+1] if v in t)
def nullspace(M):
 rr,r=nmod_mat(M.tolist(),p).rref();n=M.shape[1];piv=[next(j for j in range(n) if rr[i,j]) for i in range(r)];free=sorted(set(range(n))-set(piv));K=np.zeros((n,len(free)),dtype=np.int64)
 K[free]=np.eye(len(free),dtype=np.int64);K[piv]=np.array([[-int(rr[i,j])%p for j in free] for i in range(r)]) if free else np.empty((r,0),dtype=np.int64)
 return K,r
rows=[];cur=R
for j in range(105):rows.append(cur);cur=(A.T@cur.T).T%p
O=np.concatenate(rows);K,r=nullspace(O);assert r==2498 and K.shape==(2640,142);del rows,O
print('baseline kernel',K.shape,flush=True)
# All candidate coordinate histories restricted to the baseline hidden space.
H=np.empty((N,105,142),dtype=np.uint16);cur=K
for k in range(105):H[:,k,:]=cur;cur=(A@cur)%p
print('all hidden-coordinate histories',flush=True)
cases=[]
for v in range(120):
 if v in [0,45]:continue
 sh=shell(v);M=H[sh].reshape(-1,142).astype(np.int64);gain=nmod_mat(M.tolist(),p).rank();union=sorted(set(map(int,obs))|set(sh));cases.append({'vertex':v,'rank_mod':2498+gain,'hidden_mod':142-gain,'sensor_count':len(union),'shell':sh,'union':union})
 if v%20==0:print('third vertex',v,'rank',2498+gain,flush=True)
best=max(cases,key=lambda c:(c['rank_mod'],-c['sensor_count'],-c['vertex']));print('selected third',best['vertex'],best['rank_mod'],best['sensor_count'],flush=True)
# Remaining kernel coordinates inside the 142-dimensional baseline kernel.
C,r3=nullspace(H[best['shell']].reshape(-1,142).astype(np.int64));assert r3==best['rank_mod']-2498
ports=[];current=C
while current.shape[1]:
 bestgain=-1;bestcoord=None;bestM=None
 for coord in range(N):
  if coord in best['union'] or coord in ports:continue
  M=H[coord].astype(np.int64)@current%p;gain=nmod_mat(M.tolist(),p).rank()
  if gain>bestgain:bestgain=gain;bestcoord=coord;bestM=M
 assert bestgain>0
 olddim=current.shape[1];Cnew,rg=nullspace(bestM);current=current@Cnew%p;ports.append(bestcoord)
 print('port',bestcoord,'gain',bestgain,'remaining',current.shape[1],flush=True)
final_obs=best['union']+ports
portinfo=[]
for coord in ports:
 degree=next(k for k in range(4) if off[k]<=coord<off[k+1]);portinfo.append({'coordinate':coord,'degree':degree,'simplex':S[degree][coord-int(off[degree])]})
result={'status':'EXACT_FINITE_FIELD_SCREEN','prime':p,'baseline_rank':2498,'third_shell_cases':cases,'selected_third':best,'additional_ports':portinfo,'final_sensor_count':len(final_obs),'final_rank_mod':2640,'selection_rule':'all 118 remaining vertex centres, highest rank then fewer sensors then lowest index; greedy extra coordinate ports maximizing restricted history rank, ties lowest coordinate; no global minimum claimed'}
(D/'SELECTION.json').write_text(json.dumps(result,indent=2)+'\n');np.savez_compressed(D/'operators.npz',A_data=A.data,A_indices=A.indices,A_indptr=A.indptr,obs=np.array(final_obs),third_shell_obs=np.array(best['union']))

"""Isolated full replay; historical captures are not mutated."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
root=Path(__file__).resolve().parent
prov=json.loads((root/'PROVENANCE.json').read_text())
for source in prov['sources']:
    p=root/source['path']
    assert p.stat().st_size==source['size_bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==source['sha256']
with tempfile.TemporaryDirectory(prefix='ud-hankel-replay-') as temp:
    p=Path(temp)
    shutil.copytree(root/'sources',p/'sources')
    shutil.copy2(root/'MULTIPLICITY_TABLE.json',p/'MULTIPLICITY_TABLE.json')
    for script in ['compute_mod13_rank.py','certify_hankel_structure.py']:
        shutil.copy2(root/script,p/script)
        run=subprocess.run([sys.executable,script],cwd=p,capture_output=True,text=True)
        assert run.returncode==0,run.stderr
    for name in ['MOD13_OBSERVABILITY.json','HANKEL_STRUCTURE_CERTIFICATE.json']:
        old=json.loads((root/name).read_text());new=json.loads((p/name).read_text())
        old.pop('elapsed_rank_seconds',None);new.pop('elapsed_rank_seconds',None)
        assert old==new
    import numpy as np
    old=np.load(root/'MOD13_KERNEL.npz');new=np.load(p/'MOD13_KERNEL.npz')
    assert old.files==new.files
    for k in old.files:assert np.array_equal(old[k],new[k])
result={'status':'PASS','scope':'isolated exact rank, recurrence, kernel and structural replay; frozen source hashes verified',
        'real_observation_rank_inherited':1893,'computed_mod13_rank':1877,'mod13_kernel_basis_columns':763,
        'one_trajectory_Hankel_rank_upper':105,'generic_real_preparation_minimum':37,
        'physical_promotion':0,'independent_review':'pending'}
(root/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

"""Exact block observability rank at characteristic13; no SVD or field lifting."""
from pathlib import Path
import json,time
import numpy as np
from scipy.sparse import csr_matrix
from flint import nmod_mat
root=Path(__file__).resolve().parent
z=np.load(root/'sources/OPERATORS.npz')
A=csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(2640,2640),dtype=np.int64)
obs=z['obs'];B=np.eye(2640,dtype=np.int64)[obs];blocks=[]
for k in range(105):
    blocks.append(B.astype(np.uint8))
    B=np.asarray(A.T@B.T).T%13
O=np.vstack(blocks)
print('Constructed O105 mod13 '+str(O.shape),flush=True)
t=time.monotonic();mat=nmod_mat(O.tolist(),13)
rank=mat.rank()
reduced,rank2=mat.rref()
assert rank==rank2
pivots=[];start=0
for i in range(rank):
    pivot=next(j for j in range(start,2640) if reduced[i,j])
    pivots.append(pivot);start=pivot+1
free=[j for j in range(2640) if j not in set(pivots)]
N=np.zeros((2640,len(free)),dtype=np.int64)
N[free,np.arange(len(free))]=1
for i,pivot in enumerate(pivots):
    N[pivot,:]=[-int(reduced[i,j])%13 for j in free]
assert np.array_equal(N[free,:],np.eye(len(free),dtype=np.int64))
NM=nmod_mat(N.tolist(),13)
product=mat*NM
assert product==nmod_mat(6510,len(free),13)
np.savez_compressed(root/'MOD13_KERNEL.npz',basis=N.astype(np.uint8),free_columns=np.array(free),pivot_columns=np.array(pivots))
# Check the observer's degree105 recurrence after reduction as well.
coeff=json.loads((root/'sources/ANNIHILATOR_COEFFICIENTS.json').read_text())['qL_coefficients_descending']
pcoeff=[0]*106
for j,c in enumerate(coeff[:-1]):
    power=52-j;pcoeff[2*power+1]=int(c)*(-1)**power
assert pcoeff[105]==1
res=np.zeros_like(B)
for j,c in enumerate(pcoeff):
    if c%13:res=(res+(c%13)*(B if j==105 else blocks[j].astype(np.int64)))%13
assert not np.any(res)
result={'status':'EXACT','prime':13,'rows':6510,'columns':2640,'rank':rank,'kernel_dimension':2640-rank,
        'rank_over_F13_12':rank,'extension_argument':'All entries lie in F13, so scalar extension preserves rank',
        'rank_rechecked_by_rref':rank2,'kernel_basis_columns':len(free),
        'kernel_basis_independence':'free-coordinate submatrix is identity',
        'exact_O_times_kernel_is_zero':True,'observer_degree105_recurrence_mod13_verified':True,
        'elapsed_rank_seconds':time.monotonic()-t,'physical_promotion':0,'independent_review':'pending'}
(root/'MOD13_OBSERVABILITY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)

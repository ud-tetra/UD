"""Small exact witnesses and source-bound excitation multiplicity calculation."""
from pathlib import Path
import json
import sympy as s
root=Path(__file__).resolve().parent
J=s.Matrix([[0,-1],[1,0]])
A=s.diag(J,J,J);x=s.Matrix([1,0,1,0,1,0]);R=s.eye(6)
O=R.col_join(R*A)
K=s.Matrix.hstack(*[A**j*x for j in range(7)])
H=O*K
assert O.rank()==6 and K.rank()==2 and H.rank()==2
X=s.Matrix.hstack(s.eye(6)[:,0],s.eye(6)[:,2],s.eye(6)[:,4])
Km=s.Matrix.hstack(X,A*X)
assert (O*Km).rank()==6
rows=json.loads((root/'MULTIPLICITY_TABLE.json').read_text())
assert sum(z['complex_eigenvalue_count'] for z in rows)==105
assert sum(z['real_observable_dimension'] for z in rows)==1893
max_mult=max(z['observable_multiplicity_per_eigenvalue'] for z in rows)
assert max_mult==37
result={'status':'EXACT_DERIVED_FROM_FROZEN_REAL_MODEL','physical_promotion':0,'independent_review':'pending',
 'one_trajectory_factorization':'H_(L,M)(x)=O_L [x,A x,...,A^(M-1)x]',
 'one_trajectory_rank_upper':105,'assumption':'Frozen real degree105 minimal polynomial, or verified reduced recurrence for mod13 observations',
 'minimal_number_preparations_for_generic_real_full_observable_excitation':37,
 'preparation_minimality_scope':'Unrestricted real preparations, semisimple observable quotient, sufficiently long derivative horizon; no particular37 preparations constructed or conditioned',
 'max_multiplicity_factor':'L-4','real_observable_dimension_at_factor':74,
 'safe_generic_real_dimensions':{'L':105,'M':105,'p':37,'rows':6510,'columns':3885,'derivative_samples_per_preparation':209},
 'guaranteed_identity_preparation_dimensions':{'L':105,'M':1,'p':2640,'rows':6510,'columns':2640,'real_rank':1893},
 'counterexample':{'state_dimension':6,'observation_rank':6,'H_rows':12,'H_columns':7,'one_state_H_rank':2,'three_preparations_H_rank':6},
 'column_count_only_necessary':True,'finite_field_prep_threshold37_not_asserted':True,
 'ordinary_exponential_warning':'In characteristic13, factorial denominators from13 onward are noninvertible; exp(sA) needs a separately defined construction',
 'ordinary_SVD_warning':'Use exact finite-field elimination for field rank; real singular-value conditioning does not follow'}
(root/'HANKEL_STRUCTURE_CERTIFICATE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'single_trajectory_cap':105,'generic_real_preparations_minimum':37,'toy_ranks':[6,2,6]}))

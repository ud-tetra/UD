# UD Hankel excitation audit

Read `UD_HANKEL_EXCITATION_AUDIT_v0.1.md` for the corrected mathematical interpretation and dimensions. The key results are the 105 one-trajectory temporal rank cap, the characteristic13 observation rank 1877, and the real-model generic preparation threshold 37.

Run `python validate_hankel.py` to replay the exact calculations in an isolated directory without rewriting the frozen inputs. The replay verifies the complete 763-column modular kernel, the observer recurrence and modal multiplicity calculation. The included modular kernel uses field coefficients 0 through 12; its columns are not real unobservable states.

The preparation threshold 37 is an unrestricted generic real-model result, not a chosen, conditioned experimental protocol. Physical promotion is zero, and independent review is pending. No gauge group or physical clock is derived.

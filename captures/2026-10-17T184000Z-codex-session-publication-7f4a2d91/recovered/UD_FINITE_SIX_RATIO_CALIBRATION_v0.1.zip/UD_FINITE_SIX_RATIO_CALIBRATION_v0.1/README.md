# Finite six-ratio calibration certificate

Read `UD_FINITE_SIX_RATIO_CALIBRATION_v0.1.md` for the protocol, proof and scope.
Run `python certify_six_ratios.py` then `python validate_six_ratios.py` using
the pinned dependencies. The second command replays construction in a fresh
temporary directory and checks certificate equality and frozen source hashes.

No apparatus data are included. All precision values are sufficient candidate
protocol requirements. Constructor verification does not constitute independent
review. Physical promotion remains zero.

"""Isolated deterministic replay; constructor verification only."""
from pathlib import Path
import hashlib, json, shutil, subprocess, sys, tempfile
from fractions import Fraction as F

root = Path(__file__).resolve().parent
prov = json.loads((root/'PROVENANCE.json').read_text())
for item in prov['sources']:
    b=(root/item['path']).read_bytes()
    assert len(b)==item['size_bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
with tempfile.TemporaryDirectory(prefix='ud-six-ratios-replay-') as tmp:
    p=Path(tmp)
    shutil.copytree(root/'sources',p/'sources')
    shutil.copy2(root/'certify_six_ratios.py',p/'certify_six_ratios.py')
    r=subprocess.run([sys.executable,'certify_six_ratios.py'],cwd=p,capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    for name in ['FINITE_MAP_POLYNOMIAL.json','SIX_RATIO_CALIBRATION_CERTIFICATE.json']:
        assert json.loads((root/name).read_text())==json.loads((p/name).read_text()),name
d=json.loads((root/'SIX_RATIO_CALIBRATION_CERTIFICATE.json').read_text())
assert d['finite_protocol']['raw_scalar_readings']==12
assert d['finite_protocol']['additional_ports_over_original_62']==[1,133,878,2040]
assert d['uniform_finite_inverse']['iterations']==20
assert F(*d['candidate_precision_contract']['stronger_verified_ratio_vector_error_ceiling']) < F(1,2**39)
assert len(d['synthetic_round_trips'])==4
out={'status':'PASS','physical_promotion':0,'independent_review':'pending',
 'isolated_replay':'all polynomial and calibration certificate fields identical',
 'full_carrier_rational_forward_points':4,'synthetic_inverse_cases':4,
 'noisy_out_of_image_boundary_case':'PASS',
 'uniform_Jacobian_and_error_inequalities':'256-bit Arb interval comparisons',
 'conditional_ratio_vector_error_below':[1,2**40],
 'requested_each_ratio_gate':[1,2**39],
 'apparatus_execution':False,'constructor_only':True}
(root/'VALIDATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

"""Finite six-ratio calibration: exact incidence powers and Arb error certificate.

No apparatus data are used. All output bounds are conditional protocol bounds.
"""
from pathlib import Path
from fractions import Fraction as F
from math import factorial, lcm
import json
import numpy as np
from scipy.sparse import csr_matrix
from flint import arb, ctx

ROOT = Path(__file__).resolve().parent
ctx.prec = 256
def pair(x):
    x = F(x)
    return [x.numerator, x.denominator]
def a(x):
    x = F(x)
    return arb(x.numerator) / x.denominator
def enc(x):
    return {'arb_enclosure': str(x), 'display_only': float(x.mid())}
def write(name, x):
    (ROOT / name).write_text(json.dumps(x, indent=2) + '\n')
def read(name):
    return json.loads((ROOT / 'sources' / name).read_text())

z = np.load(ROOT / 'sources/CALIBRATION_OPERATORS.npz')
A = csr_matrix((z['A_data'].astype(np.int64), z['A_indices'], z['A_indptr']), shape=(2640, 2640))
shell = np.load(ROOT / 'sources/SHELL_OPERATORS.npz')
Ashell = csr_matrix((shell['A_data'].astype(np.int64), shell['A_indices'], shell['A_indptr']), shape=A.shape)
assert (A - Ashell).nnz == 0 and (A + A.T).nnz == 0 and A.nnz == 14880
grades = np.repeat(np.arange(4), [120, 720, 1200, 600])
coo = A.tocoo()
assert np.all(np.abs(grades[coo.row] - grades[coo.col]) == 1)
lowgrades = np.minimum(grades[coo.row], grades[coo.col])
channels = []
directions = []
for k in range(3):
    mask = lowgrades == k
    channels.append(csr_matrix((coo.data[mask], (coo.row[mask], coo.col[mask])), shape=A.shape))
    for direction in range(2):
        mask = (lowgrades == k) & (grades[coo.row] == k + direction)
        directions.append(csr_matrix((coo.data[mask], (coo.row[mask], coo.col[mask])), shape=A.shape))
assert (sum(channels) - A).nnz == 0
products = 0
for i in range(3):
    for j in range(3):
        if i != j:
            # Both products establish orthogonal initial and final spaces.
            for left, right in [(channels[i], channels[j]), (channels[i].T, channels[j])]:
                p = left @ right
                p.eliminate_zeros()
                assert p.nnz == 0
                products += 1
for i in range(6):
    for j in range(6):
        if i // 2 != j // 2:
            p = directions[i] @ directions[j]
            p.eliminate_zeros()
            assert p.nnz == 0

ports = [1, 133, 486, 878, 1680, 2040]
records = [(1, 1, 1), (0, 133, -1), (0, 486, -1),
           (1, 878, 1), (1, 1680, -1), (0, 2040, 1)]
preps = [[0]*2640 for _ in range(2)]
for i in [1, 1680]: preps[0][i] = 1
for i in [133, 2040]: preps[1][i] = 1
gainprep = [int(i in ports) for i in range(2640)]
assert sum(x*x for x in gainprep) == 6
assert all(i in z['obs'] for i in ports)
jet = [[sign * int((T @ np.array(preps[run], dtype=np.int64))[i]) for T in directions]
       for run, i, sign in records]
assert jet == np.eye(6, dtype=int).tolist()
for run, i, _ in records:
    assert preps[run][i] == 0
    assert all(grades[j] % 2 != grades[i] % 2 for j, x in enumerate(preps[run]) if x)
complex_ = read('COMPLEX_AND_ACTION.json')['simplices']
offsets = [0, 120, 840, 2040]
port_simplices = [{'coordinate': i, 'grade': int(grades[i]),
                  'simplex': complex_[int(grades[i])][i-offsets[int(grades[i])]],
                  'in_original_62_shell': bool(i in shell['obs'])} for i in ports]

lo, hi, h = F(15, 16), F(17, 16), F(1, 32)
omega = 4 * hi
L = 8 * arb(6).sqrt() * (a(omega * h).cosh() - 1)
assert L < a(F(1, 5))

# Exact scalar polynomials for the finite map. Cross-channel annihilation
# gives K_k^(2m+1) = (D_k U_k)^m times the appropriate directed scalar.
# Coefficients retain every odd term through degree31 of exp(h K).
degree = 32
def exact_rows(T):
    return [[(int(T.indices[j]),int(T.data[j])) for j in range(T.indptr[i],T.indptr[i+1])]
            for i in range(T.shape[0])]
def exact_mv(rows, x):
    return [sum(value*x[j] for j,value in row) for row in rows]
coefficients = [[[0]*16 for _ in range(3)] for _ in range(6)]
for k, Ak in enumerate(channels):
    rows = exact_rows(Ak)
    for run, prep in enumerate(preps):
        x = prep[:]
        for n in range(1, degree+1):
            x = exact_mv(rows, x)
            if n % 2:
                for r, (which, i, sign) in enumerate(records):
                    if which == run:
                        coefficients[r][k][n//2] = int(sign * x[i])
            else:
                assert all(x[i] == 0 for which, i, _ in records if which == run)
tail = 2 * a(omega*h).exp() * a(omega*h)**33 / factorial(33) / a(h)
assert tail < a(F(1, 2**170))
def phi(q):
    out = []
    for r, (_, i, _) in enumerate(records):
        value = F(0)
        for k in range(3):
            direction = int(grades[i]) - k
            if direction not in [0, 1]:
                assert not any(coefficients[r][k])
                continue
            product = q[2*k] * q[2*k+1]
            for m, coeff in enumerate(coefficients[r][k]):
                if coeff:
                    value += coeff * q[2*k+direction] * product**m * h**(2*m) / factorial(2*m+1)
        out.append(value)
    return out

def direct_full_carrier(q):
    den = lcm(*(x.denominator for x in q))
    nums = [int(x*den) for x in q]
    T = sum(n*D for n, D in zip(nums, directions))
    rows = exact_rows(T)
    out = [F(0)]*6
    for run, prep in enumerate(preps):
        x = prep[:]
        scale = F(1)
        for n in range(1, degree+1):
            x = exact_mv(rows, x)
            scale *= h / (den*n)
            if n % 2:
                for r, (which, i, sign) in enumerate(records):
                    if which == run:
                        out[r] += sign * scale * int(x[i]) / h
            else:
                assert all(x[i] == 0 for which, i, _ in records if which == run)
    return out

fit = read('PARENT_FITTED_CERTIFICATE.json')['fitted_centre']['directed_ratios']
fit = [F(*v) for v in fit]
candidate = [fit[j] for k in range(3) for j in [k, k+3]]
points = [[F(1)]*6, [lo, hi]*3, [hi, lo]*3, candidate]
for q in points:
    assert all(lo <= v <= hi for v in q)
    assert phi(q) == direct_full_carrier(q)

# Deterministic candidate precision contract. The gain errors below are
# per-port infinity norms; dynamic errors are combined two-run/six-value norms.
xiG = nuG = xi = nu = F(1, 2**49)
jitter = F(1, 2**55)
epsg = hi*xiG + nuG
solver = F(1, 2**44)
data_round = step_error = F(1, 2**60)
E = a(omega*(h+jitter)).exp()
Braw = E*a(nu + 2*epsg + hi*xi + 2*hi*omega*jitter) / a(h*lo)
B = Braw + a(data_round)
ratio_error = (B + a(solver))*5/4
target, stronger = F(1, 2**39), F(1, 2**40)
assert ratio_error < a(stronger) < a(target)
diameter = arb(6).sqrt()/8
iterations = 20
defect_bound = a(F(6, 5))*(a(F(1, 5))**iterations*diameter + a(step_error)*5/4)
assert defect_bound < a(solver)
# Rounding each coordinate to the nearest2^-64 costs <=sqrt(6)*2^-65.
quantization = arb(6).sqrt()*a(F(1, 2**65))
assert tail + quantization < a(step_error)

def round_dyadic(x):
    scaled = x * 2**64
    nearest = (2*scaled.numerator + scaled.denominator)//(2*scaled.denominator)
    return F(nearest, 2**64)
def project(x): return min(hi, max(lo, x))
def invert(data):
    current = [F(1)]*6
    for _ in range(iterations):
        values = phi(current)
        current = [project(round_dyadic(x+y-v)) for x, y, v in zip(current, data, values)]
    return current

synthetic = []
for label, truth in [('unit', points[0]), ('alternating_boundary', points[1]), ('fitted_centre', candidate)]:
    data = phi(truth)
    estimate = invert(data)
    values = phi(estimate)
    # L1 is a conservative Euclidean bound; tail is a vector bound.
    defect = sum(a(abs(x-project(x+y-v))) for x,y,v in zip(estimate,data,values)) + tail
    error = sum(abs(x-y) for x, y in zip(estimate, truth))
    assert defect < a(solver) and a(error) < a(stronger)
    synthetic.append({'case': label, 'true_ratios': [pair(x) for x in truth],
                      'estimated_ratios': [pair(x) for x in estimate],
                      'projected_fixed_point_defect_bound': enc(defect),
                      'actual_error_L1_upper': pair(error), 'apparatus_data': False})
# Synthetic raw gain and response values exercise division by imperfect gains.
truth = candidate
values = phi(truth)
gains = [F(1)+F((-1)**k,32) for k in range(6)]
gain_data = [g*(1+xiG)+nuG for g in gains]
gain_estimates = [project(g) for g in gain_data]
raw_dynamic = [g*h*v+((-1)**k)*nu/4 for k,(g,v) in enumerate(zip(gains,values))]
data = [y/(h*g) for y,g in zip(raw_dynamic,gain_estimates)]
estimate = invert(data)
estimated_values = phi(estimate)
defect = sum(a(abs(x-project(x+y-v))) for x,y,v in zip(estimate,data,estimated_values)) + tail
error = sum(abs(x-y) for x,y in zip(estimate,truth))
data_error = sum(a(abs(x-y)) for x,y in zip(data,values)) + tail
assert data_error < B and defect < a(solver) and a(error) < a(stronger)
synthetic.append({'case':'imperfect_gain_and_raw_noise',
 'true_ratios':[pair(x) for x in truth], 'estimated_ratios':[pair(x) for x in estimate],
 'gain_raw_readings':[pair(x) for x in gain_data],
 'signed_dynamic_raw_readings':[pair(x) for x in raw_dynamic],
 'projected_fixed_point_defect_bound':enc(defect),
 'normalized_data_error_L1_upper':enc(data_error), 'actual_error_L1_upper':pair(error),
 'preparation_and_timing_dynamic_errors_in_this_example':0,'apparatus_data':False})
# An outward noisy boundary datum need not be in the model image. Projection
# still gives the guarantee; a raw forward-residual stopping rule need not.
truth = [lo]*6
values = phi(truth)
data = [v-F(1, 2**43) for v in values]
assert arb(6).sqrt()*a(F(1,2**43)) + tail < B
assert tail < a(F(1,2**43))
assert all(project(x+y-v) == x for x,y,v in zip(truth,data,values))
raw_residual_lower = arb(6).sqrt()*a(F(1,2**43)) - tail
assert raw_residual_lower > a(solver)

# Propagate the protocol into the parent gate, using its declared2^-39 cap.
ell = a(target/(lo-target))
metric = (6*ell).exp()-1
rate = a(F(1025,1024))*((1+a(F(1,2**38)))*(7*ell).exp()-1)
assert metric < a(F(1,2**35)) and rate < a(F(1,2**35))

write('FINITE_MAP_POLYNOMIAL.json', {
 'degree': degree, 'h': pair(h), 'coefficients_shape': [6,3,16],
 'integer_coefficients': coefficients,
 'evaluation': 'sum_k,m c[r,k,m] q[2k+direction(output)] (q[2k]q[2k+1])^m h^(2m)/(2m+1)!',
 'vector_remainder_bound': enc(tail), 'declared_remainder_ceiling': [1,2**170]})
write('SIX_RATIO_CALIBRATION_CERTIFICATE.json', {
 'status': 'DERIVED_CONDITIONAL_CONSTRUCTOR_VERIFIED', 'physical_promotion': 0,
 'lane': 'development; no registry entry', 'independent_review': 'pending',
 'candidate_family': 'constant logger-time K formed by scaling each lower-grade row of channelA_k byD_k and each upper-grade row byU_k in frozen A orientation; diagonal positive gains; no offsets/cross-talk',
 'ratio_order': ['D1','U1','D2','U2','D3','U3'],
 'effective_ratios': 'D_k=alpha w_k/h_(k-1), U_k=alpha w_k/h_k',
 'ratio_and_gain_box': [pair(lo),pair(hi)],
 'clock_anchor_required_for_effective_ratios': False,
 'absolute_metric_scale_identified': False,
 'finite_protocol': {'logger_interval':pair(h), 'preparation_count':3,
   'gain_preparation_unit_coordinates':ports,'gain_preparation_squared_norm':6,
   'dynamic_A_unit_coordinates':[1,1680], 'dynamic_B_unit_coordinates':[133,2040],
   'dynamic_preparation_squared_norm_each':2,
   'raw_scalar_readings':12, 'raw_breakdown':[6,3,3], 'finite_positive_time_samples_per_dynamic_run':1,
   'ports':port_simplices, 'additional_ports_over_original_62':[i for i in ports if i not in shell['obs']],
   'feature_records':[{'ratio':name,'preparation':['A','B'][run],'output':i,'sign':sgn}
                      for name,(run,i,sgn) in zip(['D1','U1','D2','U2','D3','U3'],records)],
   'gain_estimator':'project each initial gain reading onto [15/16,17/16]',
   'normalized_feature':'signed dynamic reading / (h * estimated_port_gain)',
   'readout_coordinates_zero_based':True},
 'uniform_finite_inverse':{'exact_jet':jet,'generator_norm_upper':pair(omega),
   'Jacobian_error_bound':enc(L),'declared_Jacobian_error_ceiling':[1,5],
   'lower_Lipschitz':[4,5],'upper_Lipschitz':[6,5],'condition_upper':[3,2],
   'projected_iteration':'q_next=projection_box(q+z-Phi(q))',
   'iterations':iterations,'initial_point':[1]*6,'Euclidean_step_error_ceiling':pair(step_error),
   'dyadic_coordinate_rounding_denominator':2**64,
   'projected_fixed_point_defect_bound':enc(defect_bound),
   'accepted_defect_ceiling':pair(solver),
   'forward_evaluation':'exact rational Taylor polynomial of degree32 plus uniform interval remainder',
   'boundary_caution':'stop on projected fixed-point defect; raw forward residual can remain nonzero for out-of-image data'},
 'candidate_precision_contract':{
   'gain_preparation_observed_coefficient_infinity_error':pair(xiG),
   'gain_initial_reading_infinity_noise':pair(nuG),
   'dynamic_combined_two_preparation_state_error_2norm':pair(xi),
   'dynamic_six_scalar_raw_noise_2norm':pair(nu),
   'sufficient_each_dynamic_scalar_noise':pair(nu/4),
   'per_run_logger_interval_total_error':pair(jitter),
   'individual_gain_estimation_error_bound':pair(epsg),
   'normalized_data_computation_error_2norm':pair(data_round),
   'data_feature_error_formula':'exp(omega*(h+j))*(nu+2*epsilon_g+u*xi+2*u*omega*j)/(h*l) + data_round',
   'data_feature_error_bound':enc(B),
   'ratio_vector_error_bound_formula':'(5/4)*(B+projected_fixed_point_defect)',
   'ratio_vector_error_bound':enc(ratio_error),
   'stronger_verified_ratio_vector_error_ceiling':pair(stronger),
   'requested_each_ratio_absolute_error_gate':pair(target),
   'stochastic_averaging_assumed':False},
 'parent_shape_gate':{'estimated_relative_rate_shape_ceiling':[1,2**38],
   'separate_common_scale_gate':[1,1024], 'metric_shape_error_bound':enc(metric),
   'native_rate_shape_error_bound':enc(rate), 'residual_shape_ceiling':[1,2**35],
   'requires_actual_estimates_to_pass':True},
 'synthetic_round_trips':synthetic,
 'out_of_image_boundary_witness':{'noise_each_normalized_feature':[-1,2**43],
   'projected_defect_of_exact_boundary_point':0,'raw_residual_lower_bound':enc(raw_residual_lower),
   'raw_residual_exceeds_solver_defect_ceiling':True},
 'scope_limits':['No apparatus execution or independent review',
   'The twelve scalars do not validate diagonal readout, grade-scalar metric, or absence of extra dynamics',
   'Gain preparation errors are bounded at the actual initial readout event',
   'Parameters and gains are constant across runs; no arbitrary drift',
   'Four auxiliary ports require separate calibration access; original62 alone does not supply this protocol',
   'No bound on extra skewJ or the entire acquisition readout operator follows from six gains',
   'Logger-time accuracy is not a derivation of physical seconds',
   'Protocol precisions are design controls under ledgerO03, not theory constants'],
 'exact_checks':{'sparse_generator_entries':A.nnz,'orthogonal_channel_products_zero':products,
   'all_cross_channel_directed_products_zero':True,'full_carrier_rational_forward_checks':len(points),
   'odd_parity_and_jet':True}})
print(json.dumps({'status':'PASS','Jacobian_error_display':float(L),'ratio_error_display':float(ratio_error),
 'requested_gate':pair(target),'stronger_verified_gate':pair(stronger),'readings':12,
 'auxiliary_ports':[i for i in ports if i not in shell['obs']], 'iterations':iterations}))

import itertools as it,json
import sympy as s
from pathlib import Path
P=13
checks={}
def check(k,b):
 assert b,k
 checks[k]=True
def complex_(tets):
 S=[sorted(set(q for t in tets for q in it.combinations(t,k+1))) for k in range(4)]
 B=[]
 for k in range(1,4):
  b=s.zeros(len(S[k-1]),len(S[k]))
  for j,t in enumerate(S[k]):
   for r in range(k+1): b[S[k-1].index(t[:r]+t[r+1:]),j]=(-1)**r
  B.append(b)
 return S,B
def rankmod(a):
 a=[list(map(lambda x:int(x)%P,row)) for row in a.tolist()];r=0
 for c in range(len(a[0]) if a else 0):
  q=next((i for i in range(r,len(a)) if a[i][c]),None)
  if q is None:continue
  a[r],a[q]=a[q],a[r];z=pow(a[r][c],-1,P);a[r]=[(v*z)%P for v in a[r]]
  for i in range(len(a)):
   if i!=r:
    z=a[i][c];a[i]=[(v-z*w)%P for v,w in zip(a[i],a[r])]
  r+=1
 return r
minus,bm=complex_([(0,1,2,3),(0,1,2,4)])
plus,bp=complex_([(0,1,3,4),(0,2,3,4),(1,2,3,4)])
for label,S,B,f in [('minus',minus,bm,[5,9,7,2]),('plus',plus,bp,[5,10,9,3])]:
 check(label+'_f',list(map(len,S))==f)
 check(label+'_chain',B[0]*B[1]==s.zeros(5,len(S[2])) and B[1]*B[2]==s.zeros(len(S[1]),len(S[3])))
 check(label+'_ranks',[rankmod(b) for b in B]==[4,f[1]-4,f[3]])
 check(label+'_flat_dimension',len(S[1])-rankmod(B[1])==4)
boundary=lambda S:[f for f in S[2] if sum(set(f)<=set(t) for t in S[3])==1]
check('common_boundary',boundary(minus)==boundary(plus) and len(boundary(minus))==6)
check('boundary_dimension',5+9+6==20)
# Every scalar potential modulo a common constant: 13^4 representatives.
for vals in it.product(range(P),repeat=4):
 x=s.Matrix([[0,*vals]])
 # use simple direct edge evaluation for speed
 e={edge:((0,*vals)[edge[1]]-(0,*vals)[edge[0]])%P for edge in plus[1]}
 for f in plus[2]:assert (e[f[1:]]-e[(f[0],f[2])]+e[f[:2]])%P==0
check('all_28561_scalar_flat_extensions',True)
check('q8_i_square',(s.diag(5,8)**2)%P==12*s.eye(2))
I=s.eye(2);i=s.diag(5,8);j=s.Matrix([[0,1],[12,0]]);k=(i*j)%P
G=[m%P for m in [I,-I,i,-i,j,-j,k,-k]]
check('q8_eight_distinct',len({tuple(m) for m in G})==8)
check('q8_relations',all((m*m)%P==12*I for m in [i,j,k]) and (i*j*k)%P==12*I and (j*i)%P==(-k)%P)
check('q8_all64_products',all(any((a*b)%P==c for c in G) for a in G for b in G))
check('q8_determinants',all(int(m.det())%P==1 for m in G))
check('q8_symplectic',all((m.T*j*m)%P==j for m in G))
check('q8_not_dot_isometry',(i.T*i)%P!=I)
check('no_embedding_order',(13*(13**2-1))%120!=0)
check('field_residues',sorted({x*x%P for x in range(1,P)})==[1,3,4,9,10,12])
check('no_primitive13th_root',all(pow(x,13,P)!=1 for x in range(2,P)))
u=s.Matrix([[1,1],[0,1]])
check('order13_unipotent',u**13%P==I and all(u**r%P!=I for r in range(1,13)))
check('c10_factorization',s.expand((s.Symbol('t')-1)*(s.Symbol('t')+1)*(s.Symbol('t')**4-s.Symbol('t')**3+s.Symbol('t')**2-s.Symbol('t')+1)*(s.Symbol('t')**4+s.Symbol('t')**3+s.Symbol('t')**2+s.Symbol('t')+1))==s.Symbol('t')**10-1)
t=s.Symbol('t')
check('c10_quartics_irreducible',s.Poly(t**4+t**3+t**2+t+1,t,modulus=13).is_irreducible and s.Poly(t**4-t**3+t**2-t+1,t,modulus=13).is_irreducible)
edge_values=s.zeros(1,10)
edge_values[0,plus[1].index((3,4))]=1
defects=(edge_values*bp[1])%P
check('counterexample_new_edge',sum(v!=0 for v in defects)==3 and all(defects[0,plus[2].index(f)]==1 for f in [(0,3,4),(1,3,4),(2,3,4)]))
# Exhaust all SL2(F5) matrices: group size and central involution.
sl5=[(a,b,c,d) for a,b,c,d in it.product(range(5),repeat=4) if (a*d-b*c)%5==1]
check('sl2_5_order',len(sl5)==120)
def mul(a,b,q=5):return ((a[0]*b[0]+a[1]*b[2])%q,(a[0]*b[1]+a[1]*b[3])%q,(a[2]*b[0]+a[3]*b[2])%q,(a[2]*b[1]+a[3]*b[3])%q)
def inv(a):return (a[3],-a[1]%5,-a[2]%5,a[0])
comm={mul(mul(mul(a,b),inv(a)),inv(b)) for a in sl5 for b in sl5}
H={(1,0,0,1)};todo=list(H)
while todo:
 a=todo.pop()
 for b in comm:
  c=mul(a,b)
  if c not in H:H.add(c);todo.append(c)
check('sl2_5_perfect',len(H)==120)
# Character branching using class sizes 1,1,2,2,2.
qchars=[[1,1,1,1,1],[1,1,1,-1,-1],[1,1,-1,1,-1],[1,1,-1,-1,1],[2,-2,0,0,0]]
rows=[('1',1,1,1),('2',2,-2,0),('2prime',2,-2,0),('3',3,3,-1),('3prime',3,3,-1),('4even',4,4,0),('4odd',4,-4,0),('5',5,5,1),('6',6,-6,0)]
branch={}
for name,d,z,t in rows:
 chi=[d,z,t,t,t];m=[sum(w*a*b for w,a,b in zip([1,1,2,2,2],chi,c))//8 for c in qchars]
 check('branch_'+name,sum(a*c[0] for a,c in zip(m,qchars))==d)
 branch[name]=m
out={'status':'PASS','checks':checks,'check_count':len(checks),'pachner_f_vectors':{'minus':list(map(len,minus)),'plus':list(map(len,plus)),'boundary':[5,9,6]},'q8_matrices':[[[int(v) for v in row] for row in m.tolist()] for m in G],'branching_columns':['trivial','chi1','chi2','chi3','sigma2'],'branching':branch,'scope':'exact local incidence, finite arithmetic and character restriction; no full 600-cell observability calculation'}
Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','check_count':len(checks),'scalar_extensions':13**4}))

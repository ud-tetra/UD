"""Isolated exact replay and source hash verification."""
from pathlib import Path
import json,hashlib,shutil,subprocess,tempfile,sys
root=Path(__file__).resolve().parent
expected=json.loads((root/'DEGREE12_CERTIFICATE.json').read_text())
prov=json.loads((root/'PROVENANCE.json').read_text())
for source in prov['sources']:
    p=root/source['path']
    assert p.stat().st_size==source['size_bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==source['sha256']
with tempfile.TemporaryDirectory(prefix='ud-degree12-') as temp:
    p=Path(temp)
    shutil.copy2(root/'certify_degree12.py',p/'certify_degree12.py')
    shutil.copytree(root/'sources',p/'sources')
    run=subprocess.run([sys.executable,'certify_degree12.py'],cwd=p,capture_output=True,text=True)
    assert run.returncode==0,run.stderr
    replay=json.loads((p/'DEGREE12_CERTIFICATE.json').read_text())
    assert replay==expected
result={'status':'PASS','isolated_exact_replay':'all certificate fields match',
        'source_hashes_verified':len(prov['sources']),'group_algebra_products_verified':100,
        'actual_snapshot_counterexamples':2,'physical_promotion':0,'independent_review':'pending',
        'not_verified':['Mod13 observation-history ranks','Real finite-sample conditioning transfer','Physical interpretation','A corrected Pachner transport']}
(root/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

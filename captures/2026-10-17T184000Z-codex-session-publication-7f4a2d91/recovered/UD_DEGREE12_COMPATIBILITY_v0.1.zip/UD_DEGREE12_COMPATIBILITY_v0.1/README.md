# UD degree twelve compatibility certificate

Read `UD_DEGREE12_COMPATIBILITY_v0.1.md` for the findings and `DEGREE12_CERTIFICATE.json` for exact coefficients and witnesses. The source matrices and signed C10 action are frozen inputs from this session's earlier computations.

Install the pinned dependencies if needed, then run `python validate_degree12.py`. The validator verifies source hashes and reconstructs the full certificate in an isolated directory. It checks exact field arithmetic, all one hundred projector products, the actual signed cycle decomposition and integer commutators, and two concrete snapshot-intertwiner counterexamples.

The output does not certify a physical metric, update clock, gauge bridge, modular observability rank or real conditioning transfer. Physical promotion is zero; independent review is pending. No earlier artifacts are replaced.

"""Exact finite-field and frozen-action compatibility certificate.

No physical identification or positive-norm transfer is asserted.
"""
from pathlib import Path
import json
import math
import sympy as sp
import numpy as np
from scipy.sparse import csr_matrix

P=13
zero=(0,)*12
one=(1,)+(0,)*11

def scalar(a): return (a%P,)+(0,)*11
def add(a,b): return tuple((x+y)%P for x,y in zip(a,b))
def neg(a): return tuple(-x%P for x in a)
def sub(a,b): return add(a,neg(b))
def scale(a,n): return tuple(x*n%P for x in a)

# Basis beta^r gamma^s, 0<=r<3, 0<=s<4; beta^3=2,
# gamma^4=gamma^3-gamma^2+gamma-1.
def mul(a,b):
    t=[[0]*7 for _ in range(5)]
    for i,u in enumerate(a):
        if not u: continue
        r,s=divmod(i,4)
        for j,v in enumerate(b):
            if v:
                rr,ss=divmod(j,4)
                t[r+rr][s+ss]+=u*v
    for r in range(5):
        for s in range(6,3,-1):
            z=t[r][s]
            t[r][s-1]+=z; t[r][s-2]-=z
            t[r][s-3]+=z; t[r][s-4]-=z
    for r in range(4,2,-1):
        for s in range(4):t[r-3][s]+=2*t[r][s]
    return tuple(t[r][s]%P for r in range(3) for s in range(4))

def power(a,n):
    assert n>=0
    z=one
    while n:
        if n&1:z=mul(z,a)
        a=mul(a,a); n//=2
    return z

def basis(j):return tuple(int(i==j) for i in range(12))
beta=basis(4);gamma=basis(1)
assert power(beta,3)==scalar(2)
assert add(sub(add(sub(power(gamma,4),power(gamma,3)),power(gamma,2)),gamma),one)==zero
assert {pow(a,3,P) for a in range(P)}=={0,1,5,8,12}
assert all((a**3-2)%P for a in range(P))
assert [pow(13,d,10) for d in range(1,5)]==[3,9,7,1]
assert power(gamma,10)==one and all(power(gamma,d)!=one for d in [1,2,5])

# Irreducible degrees3 and4 are coprime, so the quotient tensor
# product is a field. Frobenius on the explicit basis checks all subfields.
def rank_mod(a):
    a=[[int(v)%P for v in row] for row in a]
    r=0
    for j in range(len(a[0])):
        z=next((i for i in range(r,len(a)) if a[i][j]),None)
        if z is None:continue
        a[r],a[z]=a[z],a[r]
        inv=pow(a[r][j],-1,P);a[r]=[v*inv%P for v in a[r]]
        for i in range(len(a)):
            if i!=r:
                z=a[i][j];a[i]=[(v-z*w)%P for v,w in zip(a[i],a[r])]
        r+=1
        if r==len(a):break
    return r

field_size=13**12
fixed_dims={}
for d in [1,2,3,4,6,12]:
    columns=[sub(power(basis(j),13**d),basis(j)) for j in range(12)]
    fixed_dims[d]=12-rank_mod(list(zip(*columns)))
    assert fixed_dims[d]==d
for j in range(12):assert power(basis(j),field_size)==basis(j)

# An explicit single-polynomial presentation using theta=beta+gamma.
theta=add(beta,gamma)
orbit=[power(theta,13**j) for j in range(12)]
assert len(set(orbit))==12 and power(theta,13**12)==theta
cols=[mul(theta,basis(j)) for j in range(12)]
M=sp.Matrix(list(zip(*cols)));y=sp.Symbol('y')
Hcoeff=[int(c)%P for c in M.charpoly(y).all_coeffs()]
value=zero
for c in Hcoeff:value=add(mul(value,theta),scalar(c))
assert value==zero
Hexpr=sum(c*y**(12-j) for j,c in enumerate(Hcoeff))

assert power(beta,36)==one and power(beta,18)!=one and power(beta,12)!=one
assert power(beta,183)==scalar(2)
u=add(beta,power(beta,2));eta=power(u,12)
assert power(eta,183)==one and power(eta,61)!=one and power(eta,3)!=one

# Exact group-algebra projectors in F_(13^12)[C10].
def ga_mul(a,b):
    out=[zero]*10
    for j in range(10):
        for k in range(10):out[(j+k)%10]=add(out[(j+k)%10],mul(a[j],b[k]))
    return out

inv10=pow(10,-1,P)
projectors=[[scale(power(gamma,(-m*j)%10),inv10) for j in range(10)] for m in range(10)]
assert [tuple(sum(projectors[m][j][k] for m in range(10))%P for k in range(12)) for j in range(10)]==[one]+[zero]*9
for m in range(10):
    for n in range(10):
        assert ga_mul(projectors[m],projectors[n])==(projectors[m] if m==n else [zero]*10)
    transpose=[projectors[m][-j%10] for j in range(10)]
    assert transpose==projectors[-m%10]
    hermitian=[power(projectors[m][-j%10],13**6) for j in range(10)]
    assert hermitian==projectors[m]
assert power(gamma,13**6)==power(gamma,9)
assert power(beta,13**6)==beta

root=Path(__file__).resolve().parent
action=json.loads((root/'sources/SIGNED_C10_ACTION.json').read_text())
perm=action['permutation'];signs=action['signs'];n=len(perm)
assert sorted(perm)==list(range(n)) and all(s in [-1,1] for s in signs)
unseen=set(range(n));cycles=[]
while unseen:
    j=min(unseen);cur=j;cyc=[];sgn=1
    while cur not in cyc:
        cyc.append(cur);unseen.remove(cur);sgn*=signs[cur];cur=perm[cur]
    assert cur==j and len(cyc)==10 and sgn==1
    cycles.append(cyc)
assert len(cycles)==264
G=csr_matrix((signs,(perm,np.arange(n))),shape=(n,n),dtype=np.int64)
witnesses={}
for name,f in [('single_link','SINGLE_LINK_OPERATORS.npz'),('full_observer','FULL_OBSERVER_OPERATORS.npz')]:
    z=np.load(root/'sources'/f)
    A=csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(n,n),dtype=np.int64)
    AG=A@G-G@A;AG.eliminate_zeros();assert AG.nnz==0
    GG=G.T@G-csr_matrix(np.eye(n,dtype=np.int64));GG.eliminate_zeros();assert GG.nnz==0
    obs=set(int(v) for v in z['obs'])
    j=next(j for j in range(n) if j not in obs and perm[j] in obs)
    witnesses[name]={'channels':len(obs),'unobserved_coordinate':j,'observed_image_coordinate':perm[j],'sign':signs[j],
                     'identity_failure':'R e_j=0 but R G e_j is nonzero; no G_out with R G=G_out R'}

# A nonzero isotropic vector refutes positive-definite norm transfer.
assert (5*5+1)%13==0
# Frobenius order12 is different from multiplicative or transition order.
N=sp.zeros(3);N[0,1]=1;T=sp.eye(3)+N
assert T**13%P==sp.eye(3) and T**12%P!=sp.eye(3)

result={
 'status':'EXACT_CONSTRUCTOR_VERIFIED','physical_promotion':0,'independent_review':'pending',
 'basis':'beta^r gamma^s; index=4r+s; coefficients in F13',
 'quotient':'F13[b,g]/(b^3-2,g^4-g^3+g^2-g+1)',
 'field_size':field_size,'dimension_over_F13':12,
 'irreducibility_proof':'Cubic has no root; Phi10 irreducible by ord_10(13)=4; coprime degrees3,4 make tensor product a field',
 'single_generator':'theta=beta+gamma','H_coefficients_descending':Hcoeff,'H_polynomial':str(Hexpr),
 'H_irreducibility_proof':'theta has twelve distinct Frobenius conjugates, so minimal degree is12',
 'frobenius_order':12,'fixed_subfield_dimensions':fixed_dims,
 'cube_root_beta':{'multiplicative_order':36,'norm_to_F13':2},
 'norm_one_element':{'definition':'(beta+beta^2)^12','coefficients':list(eta),'multiplicative_order':183},
 'projector_checks':{'products':100,'sum_identity':True,'transpose':'P_m^T=P_(-m)','Hermitian':'P_m^dagger=P_m with dagger=(Frob^6 entrywise) followed by transpose','rank_each':264,'signed_cycles':264,'cycle_length':10,'real_positive_norm_claim':False},
 'source_action_checks':{'integer_AG_equals_GA':True,'integer_G_transpose_G_equals_I':True,'observation_intertwiner_counterexamples':witnesses},
 'period_counterexample':{'matrix':'I3+E12','order':13,'twelfth_power_is_identity':False},
 'not_derived':['Pachner period12','positive real norm from finite Hermitian form','1146 index plane','gauge groups or spacetime dimension','unchanged modular observation ranks or real conditioning']}
(root/'DEGREE12_CERTIFICATE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'H':str(Hexpr),'fixed_dimensions':fixed_dims,'projector_rank':264,'intertwiner_witnesses':witnesses}))

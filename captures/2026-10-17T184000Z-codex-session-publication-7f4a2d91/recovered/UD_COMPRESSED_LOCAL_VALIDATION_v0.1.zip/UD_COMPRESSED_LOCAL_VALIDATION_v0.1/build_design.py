"""Deterministic local stencils and parity-separated DSATUR preparation code."""
from pathlib import Path
from math import isqrt
import json,hashlib
import numpy as np
from scipy.sparse import csr_matrix
ROOT=Path(__file__).resolve().parent

def build():
    z=np.load(ROOT/'sources/operators.npz')
    A=csr_matrix((z['A_data'].astype(np.int64),z['A_indices'],z['A_indptr']),shape=(2640,2640))
    obs=z['obs'].tolist();grade=np.repeat(np.arange(4),[120,720,1200,600])
    adj=[set(map(int,A.indices[A.indptr[i]:A.indptr[i+1]])) for i in range(2640)]
    partners={r:{u for j in adj[r] for u in adj[j] if grade[u]==grade[r] and u!=r} for r in obs}
    # Explicit named extension includes the previously demonstrated two-vertex
    # metric fault. It is not implied by the radius-two Hasse rule.
    partners[4].add(0)
    JK={};JC={}
    for r in obs:
        JK[r]=set().union(*(adj[u] for u in partners[r]|{r}))
        JC[r]=JK[r]|partners[r]|{r}
    graph=[set() for _ in range(2640)]
    for support in JC.values():
        for i in support:graph[i].update(support-{i})
    color=[-1]*2640;offset=0
    for parity in [0,1]:
        pending={i for i in range(2640) if grade[i]%2==parity and graph[i]}
        saturation={i:{color[j] for j in graph[i] if color[j]>=0} for i in pending}
        while pending:
            i=max(pending,key=lambda i:(len(saturation[i]),len(graph[i]),-i))
            c=offset
            while c in saturation[i]:c+=1
            color[i]=c;pending.remove(i)
            for j in graph[i]&pending:saturation[j].add(c)
        offset=max(color)+1
    m=offset;sizes=[color.count(c) for c in range(m)]
    scales=[isqrt(n)+(isqrt(n)**2<n) for n in sizes]
    assert all(n>0 and n<=q*q for n,q in zip(sizes,scales))
    for r in obs:
        assert len({color[j] for j in JC[r]})==len(JC[r])
        assert all(color[j]>=0 for j in JC[r])
        assert all(grade[j]%2 !=grade[r]%2 for j in JK[r])
    for c in range(m):assert len({int(grade[i]%2) for i,x in enumerate(color) if x==c})==1
    pairs=sorted({tuple(sorted((r,u))) for r in obs for u in partners[r]})
    gram=A@A.T
    minimum=100;witness=None
    for u,v in pairs:
        assert grade[u]==grade[v]
        # Equal same-grade row norms allow an exact 2x2 Gram eigenvalue.
        assert gram[u,u]==gram[v,v]
        value=int(gram[u,u])-abs(int(gram[u,v]))
        if value<minimum:minimum=value;witness=[u,v]
    assert minimum>=3
    d={'status':'EXACT_CONSTRUCTOR_VERIFIED','metric_pairs':pairs,
       'metric_pair_rule':'Same grade, Hasse distance two, at least one observed endpoint; additionally pair(0,4); defects form a matching',
       'observed_coordinates':obs,'readout_stencils':{str(r):sorted(JC[r]) for r in obs},
       'generator_row_stencils':{str(r):sorted(JK[r]) for r in obs},
       'colors':color,'color_count':m,'class_sizes':sizes,'preparation_denominators':scales,
       'preparation_rule':'p_c has coefficient1/q_c on coordinates of color c, zero elsewhere',
       'prepared_coordinate_count':sum(x>=0 for x in color),'unprepared_coordinate_count':sum(x<0 for x in color),
       'maximum_class_size':max(sizes),'maximum_denominator':max(scales),
       'sum_preparation_denominator_squared':sum(q*q for q in scales),
       'maximum_dynamic_row_weight_squared':max(sum(scales[color[j]]**2 for j in JK[r]) for r in obs),
       'readout_parameter_count':sum(map(len,JC.values())),
       'generator_observed_row_parameter_count':sum(map(len,JK.values())),
       'maximum_readout_stencil':max(map(len,JC.values())),
       'maximum_generator_stencil':max(map(len,JK.values())),
       'metric_pair_row_Gram_min_eigenvalue':minimum,'metric_pair_Gram_witness':witness,
       'static_unrestricted_readout_nullity_per_row':2640-m,
       'three_time_unrestricted_readout_nullity_per_row_lower':max(0,2640-3*m),
       'physical_promotion':0}
    (ROOT/'PROBE_DESIGN.json').write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps({k:d[k] for k in ['color_count','prepared_coordinate_count','maximum_class_size','maximum_denominator','sum_preparation_denominator_squared','maximum_dynamic_row_weight_squared','metric_pair_row_Gram_min_eigenvalue','readout_parameter_count']},indent=2))
    return d,A,grade
if __name__=='__main__':build()

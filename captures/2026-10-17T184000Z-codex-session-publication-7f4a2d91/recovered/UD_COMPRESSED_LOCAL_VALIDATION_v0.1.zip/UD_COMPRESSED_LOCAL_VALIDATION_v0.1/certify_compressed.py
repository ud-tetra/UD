"""Certify local-code validation thresholds; no apparatus data.

python certify_compressed.py
"""
from pathlib import Path
from fractions import Fraction as Q
from math import factorial
import hashlib,json,platform,importlib.metadata
import numpy as np
from flint import arb,ctx
from build_design import build

ROOT=Path(__file__).resolve().parent;ctx.prec=256
def a(x):
    x=Q(x);return arb(x.numerator)/x.denominator
def pair(x):x=Q(x);return [x.numerator,x.denominator]
def enc(x):return {'arb_enclosure':str(x),'display_only':float(x.mid())}
def write(name,x):(ROOT/name).write_text(json.dumps(x,indent=2)+'\n')
d,A,grade=build();obs=d['observed_coordinates'];color=d['colors'];qs=d['preparation_denominators'];m=d['color_count']
JC={int(r):s for r,s in d['readout_stencils'].items()};JK={int(r):s for r,s in d['generator_row_stencils'].items()}
ecol=Q(1,10**13);h=Q(1,1024);Omega=5
eta=Q(3,10**9);bfit=Q(2,10**9);deltaH=Q(5,10**10);deltaw=Q(4,10**10)
clock=Q(1,10**12)/Q(15,16)
gamma=Q(33,16*10**13)/Q(15,16)
eps=4*deltaw/(1-eta)+4*(1+bfit)*deltaH/(1-eta)**2+4*(1+eta)/(1-eta)*clock
assert (1+clock)*4*(1+eta)/(1-eta-Q(1,16))<5
acode=arb(d['sum_preparation_denominator_squared']).sqrt()
arow=arb(d['maximum_dynamic_row_weight_squared']).sqrt()
tauC=acode*a(ecol)
unused_static_threshold=arb(m).sqrt()*a(ecol)
TC=arb(189).sqrt()*a(gamma)+tauC
Epass=TC+tauC
assert Epass<a(Q(13,10**12))
z=a(Omega*h)
Bh=((2*z).sinh()-8*z.sinh()+6*z)/(6*a(h))
Fh_bound=a(Q(5,3)*Omega)*(2*z).exp()
noise=a(Q(8,3)*ecol/h)
tauK=arow*(Bh+Epass*Fh_bound+noise)
TD=a(eps)+tauK
cmetric=arb(3).sqrt()*a((1-clock)*(1-eta)/(1+eta)**2)
Spass=(a(2*eps)+2*tauK)/cmetric
assert Spass<a(Q(23,10**9))
assert Bh>0

# Uniform actual-observer consequence within the selected local family.
Sstar=Q(23,10**9);Estar=Q(13,10**12);acqjitter=Q(1,10**6)
Ga=a((1+eta+Sstar)/(1-eta-Sstar)).sqrt()
Gf=a((1+bfit)/(1-bfit)).sqrt()
epsTotal=eps+(1+clock)*4*(1+eta)*Sstar/((1-eta)*(1-eta-Sstar))
protocols=[]
parents=json.loads((ROOT/'sources/SCHEDULE_CERTIFICATES.json').read_text())
for p in parents['protocols']:
    M=p['samples'];trms=a(Q((M-1)*(2*M-1),24)).sqrt()
    sf=a(Q(*p['sigma_min_squared_lower'])).sqrt()*a(Q(97,100))
    beta=a(Estar)*Ga+Ga*Gf*a(epsTotal)*trms+(1+a(Estar))*Ga*a(5*acqjitter)
    sactual=sf-beta;condition=(Gf+beta)/sactual
    upper={2048:783,4096:391,8192:328}[M]
    assert sactual>0 and condition<upper
    protocols.append({'samples':M,'extra_acquisition_jitter_ceiling':pair(acqjitter),
        'finite_map_error_upper':enc(beta),'actual_sigma_min_lower':enc(sactual),
        'actual_condition_enclosed_upper':enc(condition),'declared_condition_upper':upper,
        'rank':2640,'kernel_dimension':0})

# Exact sparse local readout injection/decoding. Every coefficient has its
# own data coordinate (row,color), with nonzero amplitude1/q_color.
keys=set()
for r,stencil in JC.items():
    for j in stencil:
        key=(r,color[j]);assert key not in keys;keys.add(key)
        assert Q(1,qs[color[j]])>=Q(1,5)
assert len(keys)==16175
static_r=4;static_j=0;assert static_j in JC[static_r]
static_epsilon=Q(1,10**9);c0=color[static_j]
encoded=static_epsilon/qs[c0]
assert encoded*qs[c0]==static_epsilon
assert a(static_epsilon)>TC+tauC

# A two-column readout outside the local family can alias exactly at t0.
blind=None
for r,stencil in JC.items():
    for j in stencil:
        group=[k for k,c in enumerate(color) if c==color[j] and k!=j]
        if group:
            k=group[0];assert k not in stencil
            blind=(r,j,k,color[j]);break
    if blind:break
assert blind
r,j,k,c=blind
assert Q(1,qs[c])-Q(1,qs[c])==0

# Actual-carrier metric fault (0,4), using its coded edge120 preparation.
assert (0,4) in d['metric_pairs'] and 120 in JK[4]
rho=Q(1,10**6);den=10**12-1
assert abs(rho)<Q(1,16)
rows=[]
for i in range(2640):
    accumulated={};terms=[(i,den)]
    if i==0:terms=[(0,10**12),(4,-10**6)]
    if i==4:terms=[(4,10**12),(0,-10**6)]
    for source,coef in terms:
        for pos in range(A.indptr[source],A.indptr[source+1]):
            col=int(A.indices[pos]);accumulated[col]=accumulated.get(col,0)+coef*int(A.data[pos])
    rows.append(list(accumulated.items()))
def multiply(x):return [sum(value*x[j] for j,value in row) for row in rows]
cc=color[120];scale=qs[cc];input_indices=[j for j,c in enumerate(color) if c==cc]
p=[int(i in set(input_indices)) for i in range(2640)]
assert grade[120]%2!=grade[4]%2
assert sum(int(A[4,j]) for j in input_indices)==0
assert sum(dict(rows[4]).get(j,0) for j in input_indices)==-10**6
def forward(t,N=24):
    x=p[:];coefficient=Q(1);total=Q(p[4])
    for n in range(1,N+1):
        x=multiply(x);coefficient*=t/den/n;total+=coefficient*x[4]
    zz=a(4*t/(1-rho));pnorm=a(Q(len(input_indices),scale**2)).sqrt()
    rem=pnorm*zz.exp()*zz**(N+1)/factorial(N+1)
    return a(total/scale),rem
y1,e1=forward(h);y2,e2=forward(2*h)
metric_coefficient=a(scale)*(8*y1-y2)/(6*a(h))
metric_error=a(scale)*(8*e1+e2)/(6*a(h))
signal=abs(metric_coefficient)-metric_error
assert signal>a(Q(9,10**7))
# All instrument error in the selected coefficient is <=q_color*noise.
assert signal-a(scale)*noise>TD

raw_scalars=2*(m+1)*3*189
old=2043740160
assert raw_scalars==295974 and old>6900*raw_scalars
source_hashes=[{'path':'sources/'+f.name,'size_bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted((ROOT/'sources').iterdir()) if f.is_file()]
write('COMPRESSED_CERTIFICATE.json',{
 'status':'DERIVED_CONDITIONAL_CONSTRUCTOR_VERIFIED','physical_promotion':0,'independent_review':'pending',
 'candidate_fault_family':{'metric':'H=H0+S; same-grade off-diagonal defects on listed pairs; active pairs form a matching; at least one endpoint observed; ||S||<=1/16',
 'background':'H0 grade scalar, w and constant clock within declared background uncertainty of frozen fit',
 'readout':'gain-normalized C-R has support only in the listed local row stencils',
 'stability':'constant linear plant through validation and later acquisition',
 'excluded':['Cross-grade metrics','Nonmatching interacting metric defects','Metric diagonal heterogeneity outside H0','Readout outside listed stencils','Nonlinearity or unbounded temporal drift']},
 'code':{'preparations':m,'controlled_coordinates':d['prepared_coordinate_count'],
   'readout_coefficient_rank':len(keys),'restricted_readout_sigma_min':[1,5],
   'restricted_readout_condition_upper':5,'preparation_norm_upper':1,
   'metric_pairs':len(d['metric_pairs']),'metric_pair_row_Gram_min_eigenvalue':3,
   'times':[[0,1],pair(h),pair(2*h)],'epochs':2,'blank_extra':True,
   'scalar_outputs':raw_scalars,'previous_full_basis_scalar_outputs':old,
   'reduction_factor_exact':pair(Q(old,raw_scalars))},
 'instrument_contract':{'per_code_normalized_blank_corrected_vector_error':pair(ecol),
   'static_Frobenius_error':enc(tauC),'static_residual_threshold':enc(TC),
   'unused_static_cells':189*m-len(keys),'unused_static_Frobenius_threshold':enc(unused_static_threshold),
   'passing_readout_operator_error':enc(Epass),'declared_readout_error_ceiling':pair(Estar)},
 'dynamic_estimator':{'formula':'[8Y(h)-Y(2h)-7Y(0)]/(6h), opposite-parity outputs; subtract R Khat P before local decoding',
   'h':pair(h),'generator_norm_ceiling':Omega,'odd_remainder_bound':enc(Bh),
   'readout_contamination_factor':enc(Fh_bound),'noise_factor_times_ecol':enc(noise),
   'maximum_row_decode_factor':enc(arow),'row_error_bound':enc(tauK),
   'null_effective_generator_uncertainty':pair(eps),'maximum_row_residual_threshold':enc(TD),
   'metric_visibility_lower_factor':enc(cmetric),'passing_metric_S_operator_bound':enc(Spass),
   'declared_metric_S_upper':pair(Sstar)},
 'conditional_actual_observer_protocols':protocols,
 'synthetic_local_cross_talk':{'row':static_r,'input':static_j,'epsilon':pair(static_epsilon),
   'color':c0,'encoded_scalar':pair(encoded),'exactly_recovered':True,'not_empirical':True},
 'synthetic_local_metric':{'pair':[0,4],'rho':pair(rho),'coded_input_color':cc,
   'decoded_coefficient_signal_lower':enc(signal),'rejected_with_error_budget':True,'not_empirical':True},
 'blind_spots':{'static_unrestricted_nullity_per_row':2640-m,
   'three_time_unrestricted_nullity_per_row_lower':2640-3*m,
   'static_two_entry_alias':{'row':r,'positive_input':j,'negative_input':k,'same_color':c,'outside_local_family':True},
   'not_a_full_basis_observer_validation':True,'metric_harmonic_and_sampling_alias_no_go_outside_family_remain':True},
 'sources':source_hashes})
write('VALIDATION.json',{'status':'PASS','code_stencil_injectivity_exact':True,
 'all_16175_local_readout_coefficients_injective':True,'all_metric_pair_Gram_bounds_exact':True,
 'uniform_interval_static_dynamic_and_observer_bounds':True,
 'local_cross_talk_and_metric_fault_checks':'PASS','static_outside_family_alias_exact':True,
 'physical_measurements_used':False,'interval_precision_bits':ctx.prec,
 'runtime':{'python':platform.python_version(),**{x:importlib.metadata.version(x) for x in ['numpy','scipy','python-flint']}}})
print(json.dumps({'status':'PASS','scalar_outputs':raw_scalars,
   'static_pass_readout_error':float(Epass.mid()),'dynamic_threshold':float(TD.mid()),
   'metric_pass_error':float(Spass.mid()),'actual_condition_upper':[783,391,328]},indent=2))

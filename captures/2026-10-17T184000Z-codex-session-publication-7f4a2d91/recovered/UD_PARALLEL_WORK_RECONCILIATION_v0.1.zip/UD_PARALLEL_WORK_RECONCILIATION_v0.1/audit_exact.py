"""Controlled exact checks of constants in the supplied conversation.

Does not import or execute attached code. Run from this directory.
"""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
import hashlib
import json
import math
import ast
import os
os.environ.setdefault('SYMPY_GROUND_TYPES', 'python')
import sympy as sp

P = 13
x = sp.Symbol('x')
checks = []

def record(name, verdict, evidence, **details):
    checks.append(dict(id=name, verdict=verdict, evidence=evidence, **details))

def rows(m):
    return [[int(v) % P for v in row] for row in m.tolist()]

def rank_mod(m):
    a = rows(m)
    r = 0
    for j in range(m.cols):
        pivot = next((i for i in range(r, m.rows) if a[i][j]), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        inv = pow(a[r][j], -1, P)
        a[r] = [v * inv % P for v in a[r]]
        for i in range(m.rows):
            if i != r:
                z = a[i][j]
                a[i] = [(v-z*w) % P for v, w in zip(a[i], a[r])]
        r += 1
        if r == m.rows:
            break
    return r

f = sp.Poly(x**3-x-2, x, modulus=P)
factorization = sp.factor_list(f.as_expr(), modulus=P)
assert all(int(c)%P==0 for c in sp.Poly((x-6)*(x+3)**2-f.as_expr(),x).all_coeffs())
nil = sp.Poly((x-6)*(x+3),x,modulus=P)
assert not nil.rem(f).is_zero and (nil*nil).rem(f).is_zero
record('FIELD_CUBIC', 'REFUTED', '(x^3-x-2)=(x-6)(x+3)^2 over F13; a nonzero nilpotent exists',
       factorization=str(factorization), nonzero_square_zero_element=str(nil.as_expr()))
assert math.gcd(13,13**6) != 1
record('FIELD_NOT_INTEGER_MODULUS', 'REFUTED', 'Z/(13^6) has characteristic 13^6 and nonunit 13; F_(13^6) has characteristic 13',
       integer_modulus=13**6, nonzero_nilpotent=13, nilpotency_exponent=6)

I = sp.eye(2)
qi = sp.Matrix([[5,0],[0,8]])
qj = sp.Matrix([[0,1],[12,0]])
qk = qi*qj % P
bad_minus_k = sp.Matrix([[0,8],[0,8]])
good_minus_k = -qk % P
assert all((q*q+I) % P == sp.zeros(2) for q in [qi,qj,qk])
assert (qi*qj*qk+I)%P == sp.zeros(2)
q8 = [I,-I,qi,-qi,qj,-qj,qk,-qk]
keys = {tuple(v%P for v in q) for q in q8}
assert len(keys)==8 and all(tuple(v%P for v in a*b) in keys for a in q8 for b in q8)
assert bad_minus_k.det()%P == 0
record('Q8', 'REPAIR', 'Quaternion generators work; the final negative-k matrix is singular',
       corrected_negative_k=rows(good_minus_k), bad_negative_k_det_mod13=0, products_checked=64)

K = sp.Matrix([[5,1],[1,5],[0,0]])
Omega = (4*sp.eye(3)).row_join(K).col_join(K.T.row_join(9*sp.eye(2)))
assert rank_mod(K*K.T) == 2
assert (K*K.T)%P != 2*sp.eye(3)
assert Omega.det()%P == 0
record('RECTANGULAR_ISOMETRY', 'REFUTED', 'rank(K K^T)<=2, while rank(2 I3)=3', KKt=rows(K*K.T))
record('SPIN_TRANSPORT', 'REFUTED', 'Omega is singular over F13 and every field extension',
       determinant_integer=int(Omega.det()), determinant_mod13=0, rank_mod13=rank_mod(Omega), Omega=rows(Omega))

def orbits(mult):
    unseen=set(range(10)); out=[]
    while unseen:
        j=min(unseen); orbit=[]; v=j
        while v not in orbit:
            orbit.append(v); unseen.remove(v); v=v*mult%10
        out.append(orbit)
    return out

order=next(d for d in range(1,10) if pow(13,d,10)==1)
assert order == 4 and (13**6-1)%10 != 0 and (13**12-1)%10 == 0
record('C10_SPLITTING', 'EXACT', 'ord_10(13)=4; sextic field leaves four conjugate pairs plus two fixed characters',
       minimal_splitting_degree=4, common_extension_degree_with_sextic=12,
       base_orbits=orbits(13), sextic_orbits=orbits(pow(13,6,10)),
       base_factor_degrees=sorted([sp.degree(g,x) for g,e in sp.factor_list(x**10-1,modulus=P)[1] for _ in range(e)]))

# Genuine F_(13^3) repair with x^3=2. Degree-three polynomial is
# irreducible precisely when it has no base-field root.
assert not any((a**3-2)%P==0 for a in range(P))
one=(1,0,0)
def mul(a,b):
    t=[0]*5
    for i in range(3):
        for j in range(3): t[i+j]=(t[i+j]+a[i]*b[j])%P
    for i in range(4,2,-1): t[i-3]=(t[i-3]+2*t[i])%P
    return tuple(t[:3])
def power(a,n):
    z=one
    while n:
        if n&1: z=mul(z,a)
        a=mul(a,a); n//=2
    return z
prime_divisors=[2,3,61]
generator=None
for a in range(P):
    for b in range(P):
        for c in range(P):
            z=(a,b,c)
            if z!=(0,0,0) and all(power(z,2196//r)!=one for r in prime_divisors):
                generator=z; break
        if generator: break
    if generator: break
assert generator is not None and power(generator,2196)==one
beta=power(generator,12)
assert power(beta,183)==one and power(beta,61)!=one and power(beta,3)!=one
assert power(beta,1+13+169)==one
record('NORM_ONE_183', 'EXACT_CONDITIONAL_REPAIR', 'The norm-one subgroup really has order 183 in a genuine cubic field',
       irreducible_polynomial='x^3-2', primitive_generator=list(generator),
       element_order_183=list(beta), frobenius_orbit=[list(power(beta,j)) for j in [1,13,169]])

n=2640; r=1893; history_rows=62*105
assert history_rows-r==4617 and n-r==747
record('HANKEL_INDEX', 'REFUTED', 'For H=O O^T, dim ker H=dim ker H^T; Fredholm index=0',
       history_rows=history_rows, observation_rank=r, kernel_O=n-r, cokernel_O=history_rows-r,
       rectangular_index_O=n-history_rows, square_index_H=0, rank_minus_nullity_O=r-(n-r))

def faces(top):
    return [{tuple(f) for t in top for f in combinations(t,k+1)} for k in range(len(top[0]))]
def delta(old,new):
    return [len(b)-len(a) for a,b in zip(faces(old),faces(new))]
d4=delta([(0,1,2,3,4)],[tuple(sorted((5,)+tuple(f))) for f in combinations(range(5),4)])
d3=delta([(0,1,2,3)],[tuple(sorted((4,)+tuple(f))) for f in combinations(range(4),3)])
d23=delta([(0,1,2,3),(0,1,2,4)],[(0,1,3,4),(0,2,3,4),(1,2,3,4)])
assert d4==[1,5,10,10,4] and sum(d4)==30
assert d3==[1,4,6,3] and sum(d3)==14
assert d23==[0,1,2,1] and sum(d23)==4
record('PACHNER_DIMENSIONS', 'REFUTED', 'The unaugmented full-chain increase is 30 for 4D 1->5, not 15',
       four_dimensional_1_to_5=d4, three_dimensional_1_to_4=d3, three_dimensional_2_to_3=d23)

N=sp.Matrix([[0,1],[0,0]])
T=sp.eye(2)+2*N
assert N*N==sp.zeros(2) and T.T*T%P != sp.eye(2)
record('NILPOTENT_NOT_ORTHOGONAL', 'REFUTED', 'N^2=0 alone does not imply (I+2N)^T(I+2N)=I',
       N=rows(N), transpose_gram=rows(T.T*T))
record('ONE_HISTORY_SVD', 'REFUTED', 'A 6510-by-1 data column has rank at most 1; a 1-by-1 skew generator is zero',
       nonzero_column_rank=1, skew_trace_projection='trace(S J)=0 for symmetric S and real skew J')
record('ONE_GENERATOR_LIE_ALGEBRA', 'NO_GO', 'Commutators of A with itself vanish; additional specified generators are required',
       dimension_of_generated_real_Lie_algebra_at_most=1)
assert Fraction(1,1)/(1+Fraction(3,5)) == Fraction(5,8)
record('MIXING_FRACTION', 'REFUTED', 'The printed monograph formula gives 5/8, not 3/8',
       actual_fraction='5/8', requested_fraction='3/8', code_starting_fraction='1/3')
record('CENTRAL_PARITY', 'REFUTED', 'det(-I5)=-1=12 in characteristic 13; -I5 is not in SL5',
       determinant_mod13=(-1)**5%13, centre_order_SL5_F13six=math.gcd(5,13**6-1))
assert (5*5+1)%13 == 0
record('FINITE_FORM_NOT_REAL_NORM', 'NO_GO', '(5,1) is nonzero but has c^T c=0 over F13',
       isotropic_vector=[5,1], real_squared_length=26)
assert pow(13,6,5)==4
record('SUBFIELD_TRACE', 'EXACT_WITH_INFORMATION_LOSS', 'Trace transitivity is valid, but a nonzero F13-linear map F_(13^6)->F13 has kernel dimension five',
       trace_of_one=6, rank_over_F13=1, nullity_over_F13=5,
       field_intersection_degree=math.gcd(2,3), compositum_degree=math.lcm(2,3))
assert 2184%120!=0
record('BINARY_ICOSAHEDRAL', 'REFUTED', '120 does not divide |SL2(F13)|=2184', quotient=str(Fraction(2184,120)))
record('NO_C13_BRANCHING', 'NO_GO', 'Any group homomorphism from order-120 group 2I to order-13 group C13 is trivial; D13 of order 26 is not a subgroup of 2I',
       gcd_orders=math.gcd(120,13), D13_order=26, D13_divides_120=(120%26==0))
U=sp.eye(3); U[0,1]=1
assert U.det()==1 and U**13%P==sp.eye(3)
assert all(U**j%P!=sp.eye(3) for j in range(1,13))
record('UNIVERSAL_RECURRENCE', 'REFUTED', 'I+E12 in SL3 has order 13 over all the proposed extension fields; neither stated period is a universal period',
       unipotent_order=13, claimed_periods_mod13=[2196%13,114924%13])

source=Path('../upload/Pasted text(4).txt')
if source.exists():
    data=source.read_bytes(); lines=data.decode().splitlines()
    first=next(i for i,t in enumerate(lines) if t.startswith('class CombinatorialTopologicalAutomaton:'))
    last=next(i for i in range(first,len(lines)) if lines[i]=='Use code with caution.')
    literal='\n'.join(lines[first:last])
    try:
        ast.parse(literal); syntax={'parses':True}
    except SyntaxError as e:
        syntax={'parses':False,'source_line':first+e.lineno,'message':e.msg,'text':e.text.strip()}
    assert not syntax['parses']
    record('LITERAL_PAYLOAD_SYNTAX', 'REFUTED_AS_SUPPLIED', 'Static parse only; no attached code executed. Export damage may explain missing for-loop iterables', **syntax)
    source_meta={'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data),'lines':len(lines)}
else:
    source_meta={'note':'Original private attachment not distributed; arithmetic checks remain reproducible'}

result={'status':'PASS_CONSTRUCTOR_AUDIT','physical_promotion':0,'independent_review':'pending',
        'scope':'Exact checks and counterexamples, not a full formalization or physical validation',
        'source':source_meta,'check_count':len(checks),'checks':checks}
Path('EXACT_AUDIT.json').write_text(json.dumps(result,indent=2,default=int)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'transport_rank':rank_mod(Omega),'beta':beta}))

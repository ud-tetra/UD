"""Replay controlled arithmetic in isolation and verify inherited source hashes."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
frozen = json.loads((root/'EXACT_AUDIT.json').read_text())
provenance = json.loads((root/'PROVENANCE.json').read_text())
assert frozen['source']['sha256'] == provenance['source_attachment']['sha256']
for item in provenance['sources']:
    assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest() == item['sha256']

with tempfile.TemporaryDirectory(prefix='ud-parallel-audit-') as temp:
    p = Path(temp)
    shutil.copy2(root/'audit_exact.py',p/'audit_exact.py')
    run = subprocess.run([sys.executable,'audit_exact.py'],cwd=p,capture_output=True,text=True)
    assert run.returncode==0,run.stderr
    replay=json.loads((p/'EXACT_AUDIT.json').read_text())
    expected=[c for c in frozen['checks'] if c['id']!='LITERAL_PAYLOAD_SYNTAX']
    assert replay['checks']==expected

single=json.loads((root/'sources/PARENT_SINGLE_SHELL_RESULTS.json').read_text())
full=json.loads((root/'sources/PARENT_FULL_STATE_RESULTS.json').read_text())
compressed=json.loads((root/'sources/PARENT_COMPRESSED_CERTIFICATE.json').read_text())
assert (single['dynamic_observation_rank'],single['dynamic_unobservable_dimension'])==(1893,747)
assert (full['history_rank'],full['history_kernel_dimension'])==(2640,0)
assert compressed['code']['preparations']==260
assert compressed['code']['scalar_outputs']==295974
assert [p['declared_condition_upper'] for p in compressed['conditional_actual_observer_protocols']]==[783,391,328]
assert all(p['kernel_dimension']==0 for p in compressed['conditional_actual_observer_protocols'])
report=(root/'UD_PARALLEL_WORK_RECONCILIATION_v0.1.md').read_text()
assert all(t in report for t in ['Physical promotion remains **0**','independent review pending','F_(13^12)','30','6510-by-1'])
clean={'status':'PASS','isolated_replay_items':len(expected),
       'source_static_parse':'Original source was parsed statically in construction; private attachment omitted from replay distribution',
       'attached_code_executed':False,'physical_promotion':0,'independent_review':'pending'}
validation={'status':'PASS','frozen_audit_items':len(frozen['checks']),
            'arithmetic_and_counterexample_replay_items':len(expected),
            'parent_source_hashes_verified':len(provenance['sources']),
            'prior_rank_conditioning_certificates_rerun':False,
            'physical_promotion':0,'independent_review':'pending'}
(root/'CLEAN_REPLAY.json').write_text(json.dumps(clean,indent=2)+'\n')
(root/'VALIDATION.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps(validation))

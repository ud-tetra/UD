import json,time,sys,math
from pathlib import Path
import numpy as np
import scipy.sparse as sp
import sympy as s
from flint import fmpz_mat,nmod_mat
D=Path(__file__).resolve().parent
z=np.load(D/'operators.npz');N=2640;A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(N,N));L=(-A@A).tocsr();obs=z['obs']
x=s.Symbol('x');q=s.Poly.from_list(json.loads((D/'modular_results.json').read_text())['qL_coefficients'],x)
# Multiply integer object row matrices by a sparse matrix, vectorized across rows.
def mul(M,S):
 out=np.zeros((M.shape[0],S.shape[1]),dtype=object)
 co=S.tocoo()
 for i,j,a in zip(co.row,co.col,co.data):out[:,j]+=int(a)*M[:,i]
 return out
red=json.loads((D/'sources/REDUCED_GENERATORS.json').read_text())
off=np.cumsum([0,120,720,1200,600]);tvar=s.Symbol('t');phi=s.Poly(tvar**4-tvar**3+tvar**2-tvar+1,tvar);sectorQ={}
for m in [0,1,2,5]:
 entries=[[] for _ in range(4)];col=0
 for k,orbits in enumerate(red['signed_orbits']):
  for orbit in orbits:
   for pos,(ind,sign) in enumerate(zip(orbit['indices'],orbit['signs'])):
    pp=s.rem(s.Poly(tvar**((-m*pos)%10),tvar),phi)
    for l in range(4):
     a=int(pp.nth(l))*sign
     if a:entries[l].append((int(off[k])+ind,col,a))
   col+=1
 sectorQ[m]=[sp.coo_matrix(([a for i,j,a in ent],([i for i,j,a in ent],[j for i,j,a in ent])),shape=(2640,264)).tocsr() for ent in entries]
mult=[]
for l in range(4):
 M=np.zeros((4,4),dtype=np.int64)
 for j in range(4):
  pp=s.rem(s.Poly(tvar**(l+j),tvar),phi)
  for i in range(4):M[i,j]=int(pp.nth(i))
 mult.append(M)
print('start exact integer Krylov with rational C10 components',flush=True)
R=np.eye(N,dtype=np.int64)[obs].astype(object)
P=[R];cur=R
for k in range(1,q.degree()+3):
 cur=mul(cur,L);P.append(cur)
 if k%10==0:print('power',k,flush=True)
# Independent full integer annihilator check on observer rows; full operator check later.
ann=sum((int(a)*P[q.degree()-i] for i,a in enumerate(q.all_coeffs())),np.zeros(R.shape,dtype=object))
assert not np.any(ann);print('observer annihilator PASS',flush=True)
res=[]
for ff,e in s.factor_list(q)[1]:
 h=q.exquo(ff);co=list(map(int,h.all_coeffs()));base=sum((a*P[h.degree()-i] for i,a in enumerate(co)),np.zeros(R.shape,dtype=object))
 rows=[];t=base
 for j in range(ff.degree()):
  rows.extend([t,mul(t,A)])
  t=mul(t,L)
 M=np.concatenate(rows)
 # Normalize each nonzero row by its integer content to ease exact rank work.
 for row in M:
  g=0
  for v in row:g=math.gcd(g,int(v))
  if g>1:row//=g
 start=time.time();mm=fmpz_mat(M.tolist());rank=mm.rank()
 low=nmod_mat([[int(v)%1009 for v in row] for row in M],1009).rank()
 assert low==rank
 print(str(ff.as_expr()),rank,'sec',time.time()-start,flush=True)
 sector_ranks={}
 for m,Q in sectorQ.items():
  C=[mul(M,Qi) for Qi in Q]
  if m in [0,5]:
   assert not any(np.any(c) for c in C[1:]);rr=fmpz_mat(C[0].tolist()).rank()
  else:
   block=np.zeros((4*M.shape[0],4*264),dtype=object)
   for l in range(4):
    for ii in range(4):
     for jj in range(4):
      if mult[l][ii,jj]:block[ii*M.shape[0]:(ii+1)*M.shape[0],jj*264:(jj+1)*264]+=int(mult[l][ii,jj])*C[l]
   block=block[np.any(block!=0,axis=1)]
   rr4=fmpz_mat(block.tolist()).rank();assert rr4%4==0;rr=rr4//4
  sector_ranks[str(m)]=rr
 print('  exact complex sectors',sector_ranks,flush=True)
 res.append({'factor':str(ff.as_expr()),'degree':ff.degree(),'rank_Q':rank,'rank_mod1009':low,'complex_sector_ranks':sector_ranks})
 (D/'exact_complex_sector_results.json').write_text(json.dumps({'components':res,'total_rank':sum(r['rank_Q'] for r in res),'complete':len(res)==len(s.factor_list(q)[1]),'observer_annihilator_exact':True},indent=2)+'\n')

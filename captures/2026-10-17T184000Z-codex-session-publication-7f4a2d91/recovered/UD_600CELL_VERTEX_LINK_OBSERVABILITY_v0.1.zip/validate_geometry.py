import json,itertools
from pathlib import Path
import numpy as np
import scipy.sparse as sp
from flint import fmpz_mat
D=Path(__file__).resolve().parent
src=json.loads((D/'sources/COMPLEX_AND_ACTION.json').read_text());red=json.loads((D/'sources/REDUCED_GENERATORS.json').read_text());S=[[tuple(t) for t in ds] for ds in src['simplices']];V=src['vertices'];checks={}
def ck(n,b):assert b,n;checks[n]=True
def prod(x,y):a,b=x;c,d=y;return a*c+b*d,a*d+b*c+b*d
def dot(v,w):p=[prod(x,y) for x,y in zip(v,w)];return tuple(map(sum,zip(*p)))
ck('all_120_unit_vertices',len(V)==120 and len({str(v) for v in V})==120 and all(dot(v,v)==(4,0) for v in V))
edges=[(a,b) for a,b in itertools.combinations(range(120),2) if dot(V[a],V[b])==(0,2)]
ck('exact_golden_adjacency',edges==S[1]);nbr=[set() for v in V]
for a,b in edges:nbr[a].add(b);nbr[b].add(a)
tri=sorted({tuple(sorted((a,b,c))) for a,b in edges for c in nbr[a]&nbr[b]})
tet=sorted({tuple(sorted((*t,d))) for t in tri for d in set.intersection(*(nbr[a] for a in t))})
ck('all_clique_triangles',tri==S[2]);ck('all_clique_tetrahedra',tet==S[3])
ck('edge_valence_five',all(sum(set(e)<=set(t) for t in tet)==5 for e in edges))
ck('vertex_valence_twenty',all(sum(v in t for t in tet)==20 for v in range(120)))
vp=src['vertex_permutation'];off=np.cumsum([0]+list(map(len,S)));N=2640;r=[];c=[];vals=[]
for k,ss in enumerate(S):
 idx={t:i for i,t in enumerate(ss)}
 for i,t in enumerate(ss):
  image=[vp[v] for v in t];sign=(-1)**sum(image[a]>image[b] for a in range(len(t)) for b in range(a+1,len(t)));dest=idx[tuple(sorted(image))]
  ckval=src['signed_simplex_permutations'][k][i]
  assert ckval=={'destination':dest,'sign':sign}
  r.append(int(off[k])+dest);c.append(int(off[k])+i);vals.append(sign)
 for orb in red['signed_orbits'][k]:
  inds=orb['indices'];signs=orb['signs'];assert len(inds)==10 and signs[0]==1
  for j in range(10):
   a=src['signed_simplex_permutations'][k][inds[j]];assert a['destination']==inds[(j+1)%10] and signs[j]*a['sign']==signs[(j+1)%10]
T=sp.csr_matrix((vals,(r,c)),shape=(N,N));z=np.load(D/'operators.npz');A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(N,N))
ck('signed_action_reconstructed',True);ck('A_skew',(A+A.T).nnz==0);ck('A_T_commute',(A@T-T@A).nnz==0)
rr=json.loads((D/'modular_results.json').read_text());L=[[tuple(t) for t in ss] for ss in rr['link_simplices']]
bl=[]
for k in [1,2]:
 idx={t:i for i,t in enumerate(L[k-1])};M=np.zeros((len(L[k-1]),len(L[k])),dtype=int)
 for j,t in enumerate(L[k]):
  for n in range(k+1):M[idx[t[:n]+t[n+1:]],j]=(-1)**n
 bl.append(M)
ck('link_boundary_squared_zero',not np.any(bl[0]@bl[1]));ck('link_S2_homology_ranks',[fmpz_mat(m.tolist()).rank() for m in bl]==[11,19])
ck('link_edge_incidence_two',all(sum(set(e)<=set(t) for t in L[2])==2 for e in L[1]))
ck('snapshot_sector_orbit_counts',[sum(bool(set(orb['indices'])&{S[k].index(t) for t in L[k]}) for orb in red['signed_orbits'][k]) for k in range(3)]==[6,25,20])
res=json.loads((D/'RESULTS.json').read_text());ck('exact_component_rank_sum',sum(c['rank_Q'] for c in res['components'])==1893);ck('dark_dimension_sum',sum(c['unobservable_dimension'] for c in res['components'])==747)
ck('modular_full_rank_corroboration',all(v['global_observation_rank']==1893 for v in rr['modular'].values()))
for r in res['complex_sector_results']:
 ck('modular_sector_'+str(r['m']),all(v['sectors'][r['m']]['dynamic_rank']==r['dynamic_rank_C'] for v in rr['modular'].values() if 'sectors' in v))
(D/'VALIDATION.json').write_text(json.dumps({'status':'PASS','checks':checks,'check_count':len(checks)},indent=2)+'\n');print('PASS',len(checks),'check families')

from pathlib import Path
import tempfile,shutil,subprocess,sys,json
D=Path(__file__).resolve().parent
scripts=['compute_sectors.py','exact_complex_rank.py','summarize.py','validate_geometry.py','build_witnesses.py']
outputs=['modular_results.json','exact_complex_sector_results.json','RESULTS.json','VALIDATION.json','HIDDEN_WITNESSES.json']
with tempfile.TemporaryDirectory() as td:
 t=Path(td)
 shutil.copytree(D/'sources',t/'sources')
 for script in scripts:shutil.copy2(D/script,t/script)
 for script in scripts:
  subprocess.run([sys.executable,str(t/script)],check=True)
 for f in outputs:assert (t/f).read_bytes()==(D/f).read_bytes(),f
(D/'CLEAN_REPLAY.json').write_text(json.dumps({'status':'PASS','json_outputs_byte_identical':outputs,'scripts':scripts},indent=2)+'\n')
print('CLEAN REPLAY PASS',flush=True)

import json,sympy as s
from pathlib import Path
D=Path(__file__).resolve().parent;x=s.Symbol('x');spec=json.loads((D/'sources/EXACT_SPECTRA.json').read_text())
# Exact characteristic multiplicities from all ten source sectors.
count={'x':2}
for rec in spec['m_0_through_5']:
 mult=1 if rec['m'] in [0,5] else 2
 for ff in rec['factors_over_Qsqrt5']:
  expr=s.sympify(ff['polynomial'])
  if expr==x:continue
  # A singular value contributes twice to the full Laplacian.
  exponent=2*mult*ff['multiplicity']
  if expr.has(s.sqrt(5)):
   norm=s.Poly(s.expand(expr*expr.xreplace({s.sqrt(5):-s.sqrt(5)})),x)
   # Collect both conjugate source factors: each contributes half the rational norm exponent.
   for f,e in s.factor_list(norm)[1]:
    key=str(f.as_expr());count[key]=count.get(key,0)+s.Rational(exponent*e,2)
  else:
   for f,e in s.factor_list(s.Poly(expr,x))[1]:
    key=str(f.as_expr());count[key]=count.get(key,0)+exponent*e
r=json.loads((D/'exact_complex_sector_results.json').read_text())
rows=[]
for c in r['components']:
 ambient=int(count[c['factor']])*c['degree']
 rows.append({**c,'ambient_dimension':ambient,'unobservable_dimension':ambient-c['rank_Q']})
assert sum(c['ambient_dimension'] for c in rows)==2640
sums={m:sum(c['complex_sector_ranks'][m] for c in rows) for m in ['0','1','2','5']}
sector=[{'m':m,'dimension_C':264,'snapshot_rank_C':51,'dynamic_rank_C':sums[str(0 if m==0 else 5 if m==5 else 1 if m%2 else 2)],'dynamic_nullity_C':264-sums[str(0 if m==0 else 5 if m==5 else 1 if m%2 else 2)]} for m in range(10)]
out={'status':'EXACT_CONSTRUCTOR_VERIFIED','model':'unit simplex metric, A(1,1,1), ideal continuous-time observation, unaugmented real chains','full_dimension':2640,'shell_f_vector':[12,30,20],'snapshot_rank':62,'snapshot_nullity':2578,'dynamic_observation_rank':sum(c['rank_Q'] for c in rows),'dynamic_unobservable_dimension':sum(c['unobservable_dimension'] for c in rows),'complex_sector_results':sector,'components':rows,'individually_dark_sector_dimension':sum(c['dynamic_nullity_C'] for c in sector),'cross_sector_additional_dark_dimension':sum(c['unobservable_dimension'] for c in rows)-sum(c['dynamic_nullity_C'] for c in sector),'stationary_dark_dimension':1,'oscillatory_dark_dimension':746,'sources_full_spectra_replayed':False,'nonconstructor_review':False,'physical_promotion':0}
(D/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['components','complex_sector_results']},indent=2))

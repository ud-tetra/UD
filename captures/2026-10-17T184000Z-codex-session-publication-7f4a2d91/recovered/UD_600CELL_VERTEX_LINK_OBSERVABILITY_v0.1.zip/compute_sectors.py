import json,itertools,time
from pathlib import Path
import numpy as np
import scipy.sparse as sp
import sympy as sy
from flint import nmod_mat
D=Path(__file__).resolve().parent
src=json.loads((D/'sources/COMPLEX_AND_ACTION.json').read_text());red=json.loads((D/'sources/REDUCED_GENERATORS.json').read_text())
S=[[tuple(s) for s in degree] for degree in src['simplices']]
print('sizes',list(map(len,S)),flush=True)
off=np.cumsum([0]+list(map(len,S)));N=int(off[-1]);B=[]
for k in range(1,4):
 idx={s:i for i,s in enumerate(S[k-1])};r=[];c=[];v=[]
 for j,t in enumerate(S[k]):
  for z in range(k+1):r.append(idx[t[:z]+t[z+1:]]);c.append(j);v.append((-1)**z)
 B.append(sp.csr_matrix((v,(r,c)),shape=(len(S[k-1]),len(S[k])),dtype=np.int64))
assert (B[0]@B[1]).nnz==0 and (B[1]@B[2]).nnz==0
A=sp.bmat([[None,-B[0],None,None],[B[0].T,None,-B[1],None],[None,B[1].T,None,-B[2]],[None,None,B[2].T,None]],format='csr')
# Vertex zero is (-1,0,0,0), source exact coordinate convention.
v=0
link=[sorted({tuple(x for x in t if x!=v) for t in S[k+1] if v in t}) for k in range(3)]
obs=[int(off[k])+S[k].index(t) for k in range(3) for t in link[k]]
assert list(map(len,link))==[12,30,20]
R=np.eye(N,dtype=np.int64)[obs]
print('shell',v,list(map(len,link)),flush=True)
# Derive rational annihilator of -A^2 from preserved exact spectral factors.
x=sy.Symbol('x');spec=json.loads((D/'sources/EXACT_SPECTRA.json').read_text())
q=sy.Poly(x,x)
for r in spec['m_0_through_5']:
 for f in r['factors_over_Qsqrt5']:
  expr=sy.sympify(f['polynomial']);expr=sy.expand(expr*expr.xreplace({sy.sqrt(5):-sy.sqrt(5)})) if expr.has(sy.sqrt(5)) else expr
  ff=sy.Poly(expr,x);q=sy.lcm(q,ff).sqf_part()
print('qL degree',q.degree(), 'qA degree',2*q.degree()-1,flush=True)
# A has semisimple zero, so minimal annihilator h(z)=q(-z^2)/z.
DEPTH=2*q.degree()-1
out={'shell_vertex':v,'shell_vertex_coordinates':src['vertices'][v],'link_simplices':link,'observed_indices':obs,'snapshot_rank':len(obs),'snapshot_nullity':N-len(obs),'qL_coefficients':[int(a) for a in q.all_coeffs()],'annihilator_A_degree':DEPTH,'source_dimensions':list(map(len,S)),'modular':{}}
np.savez_compressed(D/'operators.npz',A_data=A.data,A_indices=A.indices,A_indptr=A.indptr,obs=np.array(obs))
for p in [2011,3011]:
 rows=[];cur=R.copy()
 for t in range(DEPTH):
  rows.append(cur.copy());cur=(A.T@cur.T).T%p
 O=np.concatenate(rows);start=time.time();rank=nmod_mat(O.tolist(),p).rank()
 print('global',p,rank,'time',time.time()-start,flush=True)
 out['modular'][str(p)]={'global_observation_rank':rank}
 del O,rows
 # Sector lower bounds using a split prime only.
 if (p-1)%10==0:
  primitive=next(a for a in range(2,p) if pow(a,10,p)==1 and pow(a,5,p)!=1 and pow(a,2,p)!=1)
  sect=[]
  for m in range(10):
   # Unnormalized signed orbit Fourier basis, inverse ten irrelevant to rank.
   Q=np.zeros((N,264),dtype=np.int64);col=0
   for k,orbits in enumerate(red['signed_orbits']):
    for orbit in orbits:
     for l,(ind,sign) in enumerate(zip(orbit['indices'],orbit['signs'])):
      Q[int(off[k])+ind,col]=sign*pow(primitive,(-m*l)%10,p)%p
     col+=1
   C=R@Q%p
   # Find A_m via representative coordinates, whose Fourier coefficient is one.
   reps=[int(off[k])+r for k in range(4) for r in red['orbit_representatives'][k]]
   am=(A@Q)[reps]%p
   assert np.array_equal((A@Q)%p,Q@am%p)
   cur=C;rows=[]
   for t in range(DEPTH):rows.append(cur);cur=cur@am%p
   sr=nmod_mat(C.tolist(),p).rank();dr=nmod_mat(np.concatenate(rows).tolist(),p).rank()
   print('sector',p,m,sr,dr,flush=True);sect.append({'m':m,'snapshot_rank':sr,'dynamic_rank':dr})
  out['modular'][str(p)]['sectors']=sect
 (D/'modular_results.json').write_text(json.dumps(out,indent=2)+'\n')

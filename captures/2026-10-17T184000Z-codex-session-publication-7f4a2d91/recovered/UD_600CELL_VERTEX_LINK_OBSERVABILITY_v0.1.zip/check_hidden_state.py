"""Exact membership in the ideal dynamical unobservable subspace.

Call check_sparse([[global_coordinate, integer_value], ...]).
No numerical tolerance or finite-field inference is used.
"""
import json
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parent
def check_sparse(pairs):
 z=np.load(D/'operators.npz');indices=z['A_indices'];data=z['A_data'];indptr=z['A_indptr'];observed=z['obs'];x=[0]*2640
 for i,v in pairs:
  if not isinstance(i,int) or not 0<=i<2640 or not isinstance(v,int):raise ValueError('integer coordinate/value pairs required')
  x[i]+=v
 for k in range(105):
  residual=[[int(i),x[int(i)]] for i in observed if x[int(i)]]
  if residual:return {'unobservable':False,'first_visible_derivative_order':k,'nonzero_output_entries':residual}
  x=[sum(int(v)*x[int(j)] for j,v in zip(indices[indptr[i]:indptr[i+1]],data[indptr[i]:indptr[i+1]])) for i in range(2640)]
 return {'unobservable':True,'derivatives_checked':[0,104]}
if __name__=='__main__':
 w=json.loads((D/'HIDDEN_WITNESSES.json').read_text());center=check_sparse([[0,1]]);assert center['first_visible_derivative_order']==2
 assert len(center['nonzero_output_entries'])==12 and all(v==1 for i,v in center['nonzero_output_entries'])
 examples={'central_vertex_snapshot_hidden_but_dynamic_visible':center,'stationary_hidden_cycle':check_sparse(w['stationary_fundamental_C3_cycle']),'sqrt14_hidden_oscillator':check_sparse(w['sqrt14_oscillator']['x'])}
 assert examples['stationary_hidden_cycle']['unobservable'] and examples['sqrt14_hidden_oscillator']['unobservable']
 (D/'MEMBERSHIP_EXAMPLES.json').write_text(json.dumps(examples,indent=2)+'\n');print('exact membership examples PASS')

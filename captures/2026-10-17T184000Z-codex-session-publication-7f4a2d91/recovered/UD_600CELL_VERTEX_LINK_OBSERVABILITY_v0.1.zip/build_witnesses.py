import json,math
from pathlib import Path
import numpy as np
import scipy.sparse as sp
from flint import fmpz_mat
D=Path(__file__).resolve().parent;z=np.load(D/'operators.npz');A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(2640,2640));obs=z['obs'];L=(-A@A).tocsr()
# The 120-dimensional graph channel permits a small exact hidden-mode witness.
rows=np.vstack([(L[:120,:120]-14*sp.eye(120,dtype=np.int64)).toarray(),np.eye(120,dtype=np.int64)[obs[obs<120]]])
K,nullity=fmpz_mat(rows.tolist()).nullspace();assert nullity>0
v=[int(K[i,0]) for i in range(120)];g=math.gcd(*v);v=[a//g for a in v];x=np.array(v+[0]*2520,dtype=object)
def mult(a):
 out=np.zeros(2640,dtype=object)
 for i in range(2640):out[i]=sum(int(c)*a[j] for j,c in zip(A.indices[A.indptr[i]:A.indptr[i+1]],A.data[A.indptr[i]:A.indptr[i+1]]))
 return out
y=mult(x);assert not np.any(x[obs]) and not np.any(y[obs]);assert np.array_equal(mult(y),-14*x)
src=json.loads((D/'sources/COMPLEX_AND_ACTION.json').read_text());tets=[tuple(t) for t in src['simplices'][3]];faces={}
for j,t in enumerate(tets):
 for k in range(4):faces.setdefault(t[:k]+t[k+1:],[]).append((j,(-1)**k))
neighbors=[[] for t in tets]
for pair in faces.values():
 assert len(pair)==2;(a,sa),(b,sb)=pair;neighbors[a].append((b,-sa*sb));neighbors[b].append((a,-sa*sb))
cells=[0]*600;cells[0]=1;todo=[0]
while todo:
 a=todo.pop()
 for b,sg in neighbors[a]:
  if cells[b]:assert cells[b]==sg*cells[a]
  else:cells[b]=sg*cells[a];todo.append(b)
h=np.array([0]*2040+cells,dtype=object);assert all(cells) and not np.any(mult(h)) and not np.any(h[obs])
encode=lambda v:[[i,int(a)] for i,a in enumerate(v) if a]
out={'stationary_fundamental_C3_cycle':encode(h),'sqrt14_oscillator':{'x':encode(x),'Ax':encode(y),'relation':'A x=y, A y=-14 x, R x=R y=0','evolution':'exp(tA)x=cos(sqrt(14)t)x+sin(sqrt(14)t)/sqrt(14)y','graph_eigenspace_vanishing_on_link_dimension':nullity},'checks':'exact arbitrary precision integers'}
pairs=[]
for col in range(nullity):
 vv=[int(K[i,col]) for i in range(120)];gg=math.gcd(*vv);vv=[a//gg for a in vv];xx=np.array(vv+[0]*2520,dtype=object);yy=mult(xx)
 assert not np.any(xx[obs]) and not np.any(yy[obs]) and np.array_equal(mult(yy),-14*xx)
 pairs.append({'x':encode(xx),'Ax':encode(yy)})
out['sqrt14_oscillator']['all_24_basis_pairs']=pairs
(D/'HIDDEN_WITNESSES.json').write_text(json.dumps(out,indent=2)+'\n');print('hidden harmonic and sqrt14 oscillator PASS; graph nullity',nullity,'support',sum(x!=0),sum(y!=0))

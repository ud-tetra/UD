"""Reproduce the conditional grade-metric / individual-gain certificates.

Run python certify_grade_calibration.py. No apparatus data are used.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import lcm, factorial
import hashlib,json,platform,importlib.metadata
import numpy as np
from scipy.sparse import csr_matrix
import sympy as sp
from flint import arb,ctx

ROOT=Path(__file__).resolve().parent;ctx.prec=256
def a(x):
    x=Q(x);return arb(x.numerator)/x.denominator
def pair(x):
    x=Q(x);return [x.numerator,x.denominator]
def enc(x):return {'arb_enclosure':str(x),'display_only':float(x.mid())}
def write(name,x):(ROOT/name).write_text(json.dumps(x,indent=2)+'\n')
def read(name):return json.loads((ROOT/'sources'/name).read_text())
z=np.load(ROOT/'sources/operators.npz')
A=csr_matrix((z['A_data'].astype(np.int64),z['A_indices'],z['A_indptr']),shape=(2640,2640))
obs=z['obs'].tolist();assert len(obs)==len(set(obs))==189
assert (A+A.T).nnz==0
grade=np.repeat(np.arange(4),[120,720,1200,600])
rows=[]
channel_ids=[]
for i in range(2640):
    row=[]
    for k in range(A.indptr[i],A.indptr[i+1]):
        j=int(A.indices[k]);low=int(min(grade[i],grade[j]))
        assert abs(int(grade[i])-int(grade[j]))==1
        direction=2*low+int(grade[i]>grade[j]) # d1,u1,d2,u2,d3,u3
        row.append((j,int(A.data[k]),direction))
        channel_ids.append(low)
    rows.append(row)
channel_ids=np.array(channel_ids)
channels=[]
for k in range(3):
    channel=csr_matrix((A.data*(channel_ids==k),A.indices,A.indptr),shape=A.shape)
    channel.eliminate_zeros();channels.append(channel)
assert (sum(channels)-A).nnz==0
for i in range(3):
    for j in range(3):
        if i!=j:
            product=channels[i]@channels[j];product.eliminate_zeros()
            assert product.nnz==0
def multiply(nums,x):return [sum(value*nums[k]*x[j] for j,value,k in row) for row in rows]

prepA=[0]*2640;prepB=[0]*2640
for i in [1,1680]:prepA[i]=1
for i in [133,2040]:prepB[i]=1
preps=[prepA,prepB]
gainprep=[int(i in set(obs)) for i in range(2640)]
assert [gainprep[i] for i in obs]==[1]*189
# Each record is (preparation, output, orientation correction).
features=[(1,1,1),(0,133,-1),(0,486,-1),(1,878,1),(1,1680,-1),(0,2040,1)]
assert all(i in obs for _,i,_ in features)
assert {1,133,486,878,1680,2040}<=set(obs)
simplex=read('COMPLEX_AND_ACTION.json')['simplices']
expected={1:(0,[1]),133:(1,[1,11]),486:(1,[33,34]),878:(2,[1,11,87]),1680:(2,[33,34,41]),2040:(3,[0,33,34,41])}
offset=[0,120,840,2040]
for coordinate,(k,vertices) in expected.items():assert simplex[k][coordinate-offset[k]]==vertices
jet=[]
for run,i,sign in features:
    assert preps[run][i]==0
    assert all(grade[j]%2 != grade[i]%2 for j,x in enumerate(preps[run]) if x)
    jet.append([sign*multiply([int(k==r) for k in range(6)],preps[run])[i] for r in range(6)])
assert jet==np.eye(6,dtype=int).tolist()

# Logs of six logger-time slopes: log alpha + log wk - log htarget.
# Columns: alpha,h0,h1,h2,h3,w1,w2,w3.
M=sp.zeros(8,8)
for k in range(3):
    for direction in range(2):
        r=2*k+direction;M[r,0]=1;M[r,1+k+direction]=-1;M[r,5+k]=1
M[6,0]=1;M[7,1]=1
assert M[:6,:].rank()==6 and M[:7,:].rank()==7 and M.rank()==8
assert M.det()==-1
clock_null=sp.Matrix([1,0,0,0,0,-1,-1,-1])
metric_null=sp.Matrix([0,1,1,1,1,1,1,1])
assert M[:6,:]*clock_null==sp.zeros(6,1)
assert M[:6,:]*metric_null==sp.zeros(6,1)
N=sp.zeros(7,7);N[0,0]=1
for k in range(3):
    for direction in range(2):N[1+2*k+direction,k+direction]=-1;N[1+2*k+direction,4+k]=1
inverse=N.inv();assert N.det()==-1 and sum(x*x for x in inverse)==28

def recover(q,h0=Q(1)):
    hs=[h0];ws=[]
    for k in range(3):
        ws.append(hs[-1]*q[2*k]);hs.append(hs[-1]*q[2*k]/q[2*k+1])
    return hs,ws

lo=Q(15,16);hi=Q(17,16);h=Q(1,32);omega=4*hi
zmax=4*h*hi**2
L=8*arb(6).sqrt()*(a(zmax).cosh()-1)
assert L<a(Q(1,5))
assert (1+Q(1,5))/(1-Q(1,5))==Q(3,2)
# Candidate deterministic calibration precision contract.
nuG=xiG=nu=xi=Q(1,10**13)
epsg=hi*xiG+nuG
epsalpha=Q(1,10**12);jcal=Q(1,10**15)
solve=Q(1,10**12);logh0=Q(1,10**11)
E=a(omega*(hi*h+jcal)).exp()
B=(E*a((nu+2*epsg+hi*xi)/lo)+2*a(omega)*E*a(h*epsalpha+jcal))/a(h*lo)
eq=(B+a(solve))/a(Q(4,5));elog=eq/a(lo)
hmax=hi*(hi/lo)**3;wmax=hi**2*(hi/lo)**2
metric_error=a(hmax)*((a(logh0)+6*elog).exp()-1)
rate_error=a(wmax)*((a(logh0)+5*elog).exp()-1)
assert metric_error<a(Q(5,10**10))
assert rate_error<a(Q(4,10**10))
assert a(epsg/lo)<a(Q(1,100000))
assert Q(2,10**9)+Q(5,10**10)<Q(3,10**9)
assert Q(2,10**9)+Q(4,10**10)<Q(3,10**9)
n=0;diameter=arb(6).sqrt()/8
while not ((1+a(Q(1,5)))*a(Q(1,5))**n*diameter<a(solve)):n+=1

# Exact rational finite forward map on the full source carrier.
def exact_forward(q,alpha,degree=32):
    den=lcm(*(x.denominator for x in q));nums=[int(x*den) for x in q]
    scale=h*alpha/den
    sums=[Q(0)]*6
    for run,prep in enumerate(preps):
        x=prep[:];coefficient=Q(1)
        for order in range(1,degree+1):
            x=multiply(nums,x);coefficient*=scale/order
            if order%2:
                for k,(which,i,sign) in enumerate(features):
                    if which==run:sums[k]+=sign*coefficient*x[i]/(h*alpha)
            else:
                assert all(x[i]==0 for which,i,_ in features if which==run)
    zz=a(4*max(q)*alpha*h)
    # Combined input norm is 2. General exponential Taylor remainder.
    remainder=2*zz.exp()*zz**(degree+1)/factorial(degree+1)/a(h*alpha)
    assert remainder<a(Q(1,10**50))
    return [a(x) for x in sums],remainder

checks=[]
for q,alpha in [([Q(1)]*6,Q(1)),([lo,hi]*3,hi),([hi,lo]*3,lo)]:
    hs,ws=recover(q)
    for k in range(3):
        assert ws[k]/hs[k]==q[2*k] and ws[k]/hs[k+1]==q[2*k+1]
    vals,rem=exact_forward(q,alpha)
    checks.append({'ratios':[pair(x) for x in q],'alpha':pair(alpha),
                   'metric_weights':[pair(x) for x in hs],'rates':[pair(x) for x in ws],
                   'exact_rational_Taylor_Arb_enclosures':[enc(x) for x in vals],
                   'additional_feature_vector_error_upper':enc(rem)})

# Synthetic inverse, with a certified residual after illustrative floating
# updates. No empirical measurement or fit to an external numerical target.
target=[Q(1)]*6;data,datarem=exact_forward(target,Q(1))
current=[Q(31,32),Q(33,32)]*3;checkpoints=[]
for iteration in range(1,19):
    phi,_=exact_forward(current,Q(1))
    current=[min(hi,max(lo,Q(str(round(float(current[k])+float(data[k].mid())-float(phi[k].mid()),14))))) for k in range(6)]
    if iteration in [1,4,8,18]:checkpoints.append({'iteration':iteration,'ratios':[pair(x) for x in current]})
phi,rem=exact_forward(current,Q(1))
# A scalar sum of absolute interval differences bounds the Euclidean norm.
# It remains defined when an interval sum of squares straddles exact zero.
residual=sum(abs(x-y) for x,y in zip(phi,data))+rem+datarem
assert residual<a(solve)
assert max(abs(x-1) for x in current)<Q(1,10**10)

profiles=[]
for proto in read('SCHEDULE_CERTIFICATES.json')['protocols']:
    count=proto['samples'];drift=Q(count-1,2)*epsalpha/lo;jitter=Q(1,10**6)
    assert drift+jitter<Q(3,10**6)
    profiles.append({'samples':count,'clock_drift_upper':pair(drift),
                     'separate_acquisition_jitter_ceiling':pair(jitter),
                     'total_time_error_upper':pair(drift+jitter),
                     'accepted_parent_condition_upper':{2048:748,4096:375,8192:306}[count]})
sources=[{'path':'sources/'+x.name,'size_bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted((ROOT/'sources').iterdir()) if x.is_file()]
write('GRADE_CALIBRATION_CERTIFICATE.json',{
 'status':'DERIVED_CONDITIONAL_CONSTRUCTOR_VERIFIED','lane':'development — no registry entry',
 'physical_promotion':0,'independent_review':'pending',
 'candidate_model':'H=diag(h0 I120,h1 I720,h2 I1200,h3 I600); K=H^-1 A_w; C=diag(g_j) R; constant affine clock alpha',
 'parameter_count':197,'gains':189,'grade_metric_weights':4,'rates':3,'clock_scales':1,
 'directed_ratios':['d1=w1/h0','u1=w1/h1','d2=w2/h1','u2=w2/h2','d3=w3/h2','u3=w3/h3'],
 'preparations':{'gain':'unit coefficient on all 189 observed coordinates; zero elsewhere',
                 'A_coordinates':[1,1680],'B_coordinates':[133,2040],'dynamic_coefficients':[1,1]},
 'feature_records':[{'ratio':name,'preparation':['A','B'][run],'output':i,'sign':sign} for name,(run,i,sign) in zip(['d1','u1','d2','u2','d3','u3'],features)],
 'exact_directed_jet_matrix':jet,'unanchored_log_slope_rank':6,
 'anchored_log_slope_rank':8,'anchored_log_slope_determinant':-1,
 'metric_log_reconstruction_matrix':[list(map(int,inverse.row(i))) for i in range(7)],
 'metric_log_reconstruction_Frobenius_squared':28,
 'total_ranks':{'no_scale_anchors':195,'clock_anchor_only':196,'clock_and_metric_scale_anchors':197},
 'finite_protocol':{'logger_step':pair(h),'ratio_gain_clock_box':[pair(lo),pair(hi)],
   'h0_and_h0hat_box':[pair(lo),pair(hi)],'directed_ratio_Jacobian_error_bound':enc(L),
   'declared_Jacobian_error_upper':[1,5],'lower_Lipschitz':[4,5],'upper_Lipschitz':[6,5],
   'normalized_ratio_condition_upper':[3,2],'finite_full_parameter_rank':197,
   'raw_sensor_scalar_count':195,'independent_scale_reference_count':2,
   'projected_iteration_contraction_upper':[1,5],
   'a_priori_iterations_for_residual_below_1e-12':n},
 'candidate_precision_contract':{'gain_preparation_infinity_error':pair(xiG),
   'gain_initial_noise_infinity_error':pair(nuG),'dynamic_combined_preparation_error':pair(xi),
   'dynamic_six_scalar_noise_vector_error':pair(nu),'individual_gain_estimation_error':pair(epsg),
   'clock_scale_error':pair(epsalpha),'calibration_interval_jitter':pair(jcal),
   'log_h0_reference_error':pair(logh0),'certified_solver_residual':pair(solve),
   'data_feature_error_bound':enc(B),'ratio_estimation_error_bound':enc(eq),
   'metric_weight_error_bound':enc(metric_error),'rate_error_bound':enc(rate_error),
   'metric_weight_error_declared_upper':[5,10**10],'rate_error_declared_upper':[4,10**10],
   'acceptance_metric_and_rate_estimate_deviation':[2,10**9],
   'accepted_true_metric_and_rate_ceiling':[3,10**9],
   'gain_normalized_readout_error_bound':pair(epsg/lo),'acquisition_profiles':profiles},
 'synthetic_finite_forward_checks':checks,'synthetic_round_trip':{'status':'PASS','checkpoints':checkpoints,'final_residual_bound':enc(residual),'not_empirical':True},
 'sources':sources,
 'open':['Realize and verify three known preparations','Independent physical clock and metric-scale references',
         'Validate grade-scalar metric, diagonal gains and K=H^-1 A_w model',
         'Off-diagonal metric and sensor cross-talk not identified','Offsets/drift/nonlinearities require separate modeling',
         'Independent review and apparatus execution']})
write('VALIDATION.json',{'status':'PASS','exact_directed_jet_identity':True,
 'exact_full_carrier_cross_channel_products_zero':6,
 'exact_gain_initial_map_identity_dimension':189,'exact_anchored_log_matrix_determinant':-1,
 'full_finite_rank_analytical':197,'parity_checked_in_actual_carrier_Taylor_powers':True,
 'finite_forward_points':3,'synthetic_projected_inverse':'PASS','interval_precision_bits':ctx.prec,
 'constructor_only':True,'runtime':{'python':platform.python_version(),**{x:importlib.metadata.version(x) for x in ['numpy','scipy','sympy','python-flint']}}})
print(json.dumps({'status':'PASS','finite_rank':197,'normalized_ratio_condition_upper':[3,2],
 'ratio_error_display':float(eq.mid()),'metric_error_display':float(metric_error.mid()),
 'rate_error_display':float(rate_error.mid()),'iterations':n},indent=2))

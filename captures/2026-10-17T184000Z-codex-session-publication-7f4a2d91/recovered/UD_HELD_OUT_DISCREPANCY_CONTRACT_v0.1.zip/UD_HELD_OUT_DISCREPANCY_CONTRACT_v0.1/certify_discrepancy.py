"""Certify a held-out discrepancy contract; no experimental data are used.

python certify_discrepancy.py
The complete-basis protocol is specified compactly, not allocated/executed.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import lcm,factorial
import json,hashlib,platform,importlib.metadata
import numpy as np
from scipy.sparse import csr_matrix
from flint import arb,ctx

ROOT=Path(__file__).resolve().parent;ctx.prec=256
def a(x):
    x=Q(x);return arb(x.numerator)/x.denominator
def pair(x):x=Q(x);return [x.numerator,x.denominator]
def enc(x):return {'arb_enclosure':str(x),'display_only':float(x.mid())}
def write(name,x):(ROOT/name).write_text(json.dumps(x,indent=2)+'\n')
def read(name):return json.loads((ROOT/'sources'/name).read_text())

eta=Q(3,10**9);rhat=Q(2,10**9);dh=Q(5,10**10);dw=Q(4,10**10)
lo=Q(15,16);epsg=Q(33,16*10**13);gamma=epsg/lo
Gamma=a((1+eta)/(1-eta)).sqrt()
kmax=4*(1+eta)/(1-eta)
eps=4*dw/(1-eta)+4*(1+rhat)*dh/(1-eta)**2+kmax*Q(1,10**12)/lo
N=2640;m=2048;delta=Q(1,32);ecol=Q(1,10**13)
ev=arb(N).sqrt()*a(ecol)
trms=a(Q((m-1)*(2*m-1),24)).sqrt()
sfit=a(Q(1,524288)).sqrt()*a(Q(97,100))
TA=Q(1,400000);TB=Q(1,8*10**9)
nullA=a(gamma)*Gamma+Gamma**2*a(eps)*trms+ev
nullB=(1+a(gamma))*Gamma**3*a(eps*delta)+ev*(1+Gamma)
assert nullA<a(TA) and nullB<a(TB)
actual_s=sfit-a(TA)-ev
actual_condition=(Gamma+a(TA)+ev)/actual_s
assert actual_s>0 and actual_condition<748
Qerror=(a(TB)+ev*(1+Gamma))/actual_s
logfactor=32/(2-a(Q(5,32)).exp())
assert logfactor<40
Kerror=logfactor*Qerror
assert Kerror<a(Q(1,250000))
assert 2*ev<a(Q(2,10**11))

screen_basis=[0,4,120,152,928,2040]
screen_times=[Q(0),Q(1,32),Q(1,16),Q(1,2)]
screen=[];screen_thresholds=[]
evaluation_error=Q(1,10**20)
for t in screen_times:
    null_model=a(gamma)*Gamma+Gamma**2*a(eps*t)
    threshold=null_model+a(ecol)+a(evaluation_error)
    guaranteed=null_model+2*a(ecol)+2*a(evaluation_error)
    screen_thresholds.append(threshold)
    screen.append({'time':pair(t),'unit_preparation_null_residual_threshold':enc(threshold),
                   'guaranteed_signal_rejection_above':enc(guaranteed)})

z=np.load(ROOT/'sources/operators.npz')
A=csr_matrix((z['A_data'].astype(np.int64),z['A_indices'],z['A_indptr']),shape=(N,N))
obs=z['obs'].tolist();assert len(obs)==189 and len(set(obs))==189
assert 0 not in obs and 4 in obs and 120 not in obs
assert int(A[0,120])==1
grade=np.repeat(np.arange(4),[120,720,1200,600])
rows=[]
for i in range(N):
    rows.append([(int(A.indices[k]),int(A.data[k]),2*int(min(grade[i],grade[A.indices[k]]))+int(grade[i]>grade[A.indices[k]]))
                 for k in range(A.indptr[i],A.indptr[i+1])])
def mul(rows0,nums,x):return [sum(val*nums[k]*x[j] for j,val,k in row) for row in rows0]
preps=[]
for indices in [[1,1680],[133,2040]]:
    p=[0]*N
    for i in indices:p[i]=1
    preps.append(p)
features=[(1,1,1),(0,133,-1),(0,486,-1),(1,878,1),(1,1680,-1),(0,2040,1)]
hcal=Q(1,32)

def model_features(q,degree=32):
    den=lcm(*(x.denominator for x in q));nums=[int(x*den) for x in q]
    coeffbase=hcal/den;sums=[Q(0)]*6
    for run,p in enumerate(preps):
        x=p[:];coefficient=Q(1)
        for n in range(1,degree+1):
            x=mul(rows,nums,x);coefficient*=coeffbase/n
            for k,(which,i,sign) in enumerate(features):
                if which==run:sums[k]+=sign*coefficient*x[i]/hcal
    zz=a(4*max(q)*hcal)
    rem=2*zz.exp()*zz**(degree+1)/factorial(degree+1)/a(hcal)
    assert rem<a(Q(1,10**50))
    return [a(x) for x in sums],rem

# A concrete excluded metric: mix vertices 0 and 4. It is SPD for |rho|<1,
# has distance |rho| from identity, and creates K[4,120]=-rho/(1-rho^2).
rho=Q(1,10**6);den=10**12-1
metric_rows=[]
for i in range(N):
    accum={}
    terms=[(i,den)]
    if i==0:terms=[(0,10**12),(4,-10**6)]
    if i==4:terms=[(4,10**12),(0,-10**6)]
    for source,factor in terms:
        for j,val,_ in rows[source]:accum[j]=accum.get(j,0)+factor*val
    metric_rows.append([(j,value,0) for j,value in sorted(accum.items()) if value])
assert Q(dict((j,val) for j,val,_ in metric_rows[4]).get(120,0),den)==-rho/(1-rho*rho)
def metric_forward(p,outputs,t,degree=32):
    x=p[:];coefficient=Q(1);sums=[Q(p[i]) for i in outputs]
    for n in range(1,degree+1):
        x=mul(metric_rows,[1],x);coefficient*=t/den/n
        for k,i in enumerate(outputs):sums[k]+=coefficient*x[i]
    zz=a(4*t/(1-rho))
    pnorm=a(sum(x*x for x in p)).sqrt()
    rem=pnorm*zz.exp()*zz**(degree+1)/factorial(degree+1)
    return [a(x) for x in sums],rem

alternative_data=[None]*6;alternative_rem=arb(0)
for run,p in enumerate(preps):
    records=[(k,i,sign) for k,(which,i,sign) in enumerate(features) if which==run]
    values,rem=metric_forward(p,[i for _,i,_ in records],hcal)
    alternative_rem+=arb(3).sqrt()*rem/a(hcal)
    for (k,_,sign),value in zip(records,values):alternative_data[k]=sign*value/a(hcal)
qfit=[Q(1)]*6
for _ in range(18):
    model,_=model_features(qfit)
    qfit=[Q(str(round(float(qfit[k])+float(alternative_data[k].mid())-float(model[k].mid()),14))) for k in range(6)]
assert all(lo<=q<=Q(17,16) for q in qfit)
fitted,fitrem=model_features(qfit)
cal_residual=sum(abs(x-y) for x,y in zip(fitted,alternative_data))+fitrem+alternative_rem
assert cal_residual<a(Q(1,10**12))
hs=[Q(1)];ws=[]
for k in range(3):
    ws.append(hs[-1]*qfit[2*k]);hs.append(hs[-1]*qfit[2*k]/qfit[2*k+1])
assert max(abs(x-1) for x in hs+ws)<Q(2,10**9)

# Held-out response at e120, output4, delta=1/32, compared with the fitted
# family prediction. Its synthetic signal is enclosed by exact Taylor sums.
p=[0]*N;p[120]=1
actual,actual_rem=metric_forward(p,[4],delta)
def model_coordinate(q,p,i,t,degree=32):
    denq=lcm(*(x.denominator for x in q));nums=[int(x*denq) for x in q]
    x=p[:];coefficient=Q(1);total=Q(p[i])
    for n in range(1,degree+1):
        x=mul(rows,nums,x);coefficient*=t/denq/n;total+=coefficient*x[i]
    zz=a(4*max(q)*t)
    rem=zz.exp()*zz**(degree+1)/factorial(degree+1)
    return a(total),rem
pred,predrem=model_coordinate(qfit,p,4,delta)
signal=abs(actual[0]-pred)-actual_rem-predrem
assert signal>a(Q(3,10**8))
assert signal>2*screen_thresholds[1]

# A cross-talk example invisible to all 197 original calibration scalars.
# Row for observed coordinate4 was never among the six dynamic scalars; pG
# has coefficient0 at input0. The new input e0 at time0 isolates this entry.
assert all(i!=4 for _,i,_ in features)
assert 0 not in obs
cross_epsilon=Q(1,10**9)
assert cross_epsilon>2*ecol

# Exact non-identifiability witnesses.
u0=[int(i<120) for i in range(N)]
assert not any(mul(rows,[1]*6,u0))
freq=read('FREQUENCY_CERTIFICATE.json')
assert len(freq['mu_root_intervals'])==53
# At most105 temporal frequencies per input under the nominal A. The three
# original preparations therefore span at most315 dimensions over all time.
original_preparations=3;temporal_frequencies=105
cyclic_upper=original_preparations*temporal_frequencies
assert cyclic_upper==315 and N-cyclic_upper==2325

source_hashes=[{'path':'sources/'+x.name,'size_bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted((ROOT/'sources').iterdir()) if x.is_file()]
write('DISCREPANCY_CERTIFICATE.json',{
 'status':'DERIVED_CONDITIONAL_CONSTRUCTOR_VERIFIED','physical_promotion':0,'independent_review':'pending',
 'scope':'Falsification and operator-validation contract; no physical measurements or claim of empirical passage',
 'instrument_contract':{'normalized_blank_corrected_response_error_per_preparation_vector':pair(ecol),
   'matrix_error_bound':enc(ev),'includes':'noise, preparation, timing and blank correction; external total-response contract'},
 'null_parameters':{'metric_weight_uncertainty':pair(dh),'rate_uncertainty':pair(dw),
   'effective_generator_error':pair(eps),'gain_normalization_error':pair(gamma),'propagator_bound':enc(Gamma)},
 'targeted_screen':{'held_out_unit_inputs':screen_basis,'blank_input':True,
   'times':[pair(t) for t in screen_times],'epochs':2,'sensor_scalars':2*7*4*189,
   'thresholds':screen,'blank_rejection_threshold':pair(ecol),
   'paired_drift_rejection_threshold':pair(2*ecol),'guaranteed_observable_drift_detection_above':pair(4*ecol)},
 'complete_basis_benchmark':{'unit_inputs':2640,'blank_input_extra':True,'baseline_samples':m,
   'baseline_step':[1,2],'relative_shift':pair(delta),'sensor_outputs':189,
   'basis_sensor_scalar_count':2640*2*m*189,'including_one_blank_run':2641*2*m*189,
   'readout_leakage_statistic':'Frobenius norm of t0 response with each allowed diagonal-gain entry masked out',
   'leakage_rejection_threshold':enc(ev),'passing_cross_talk_Frobenius_bound':enc(2*ev),
   'guaranteed_cross_talk_operator_detection_above':[2,10**11],
   'frame_operator_rejection_threshold':pair(TA),'null_frame_threshold_expression':enc(nullA),
   'shift_residual_operator_rejection_threshold':pair(TB),'null_shift_threshold_expression':enc(nullB),
   'passing_actual_sigma_min_lower':enc(actual_s),'passing_actual_condition_upper':748,
   'passing_actual_rank':2640,'passing_actual_kernel_dimension':0,
   'passing_short_propagator_error_bound':enc(Qerror),
   'continuous_generator_additional_assumption':'repeatable LTI; ||Keff||<=5 in these fixed coordinates',
   'log_Lipschitz_factor':enc(logfactor),'passing_continuous_generator_error_bound':enc(Kerror),
   'declared_generator_error_upper':[1,250000]},
 'synthetic_cross_talk_witness':{'matrix':'epsilon * output_row4 * input_column0^T',
   'epsilon':pair(cross_epsilon),'original_197_calibration_values_unchanged':True,
   'held_out_e0_time0_signal':pair(cross_epsilon),'not_empirical':True},
 'synthetic_excluded_metric_witness':{'matrix':'I+rho(e0 e4^T+e4 e0^T)',
   'rho':pair(rho),'exact_forbidden_K_entry_4_120':pair(-rho/(1-rho*rho)),
   'fitted_ratios':[pair(q) for q in qfit],'fitted_metric_weights':[pair(x) for x in hs],
   'fitted_rates':[pair(x) for x in ws],'original_calibration_feature_fit_residual':enc(cal_residual),
   'original_estimated_metric_and_rate_acceptance_gate_passed':True,
   'held_out_input':120,'held_out_output':4,'time':pair(delta),
   'held_out_signal_certified_lower':enc(signal),'not_empirical':True},
 'no_go':{'harmonic_metric':'H=I+eta u0 u0^T/120 leaves H^-1 A=A',
   'original_three_preparation_cyclic_space_dimension_upper':cyclic_upper,
   'arbitrary_readout_blind_directions_per_row_lower':N-cyclic_upper,
   'sample_alias':'Kprime=A+64 pi J, J=A(-A^2)^(-1/2) on active space, 0 on kernel; identical histories on grid1/32',
   'arbitrary_temporal_drift':'Finite epochs cannot exclude unsampled bursts without a regularity bound',
   'general_nonlinearity':'Complete unit-basis tests do not prove global linearity'},
 'sources':source_hashes})
write('VALIDATION.json',{'status':'PASS','interval_precision_bits':ctx.prec,
 'null_frame_and_shift_thresholds_certified':True,'full_basis_pass_condition_bound_certified':748,
 'continuous_generator_bound_certified_conditional':True,'harmonic_metric_integer_witness':True,
 'cross_talk_original_calibration_blindness_checked':True,'excluded_metric_refit_and_held_out_signal_checked':True,
 'complete_basis_data_allocated':False,'physical_data_used':False,
 'runtime':{'python':platform.python_version(),**{x:importlib.metadata.version(x) for x in ['numpy','scipy','python-flint']}}})
print(json.dumps({'status':'PASS','full_basis_sensor_scalars':2640*2*m*189,
 'passing_actual_condition_upper':748,'K_error_bound_display':float(Kerror.mid()),
 'metric_witness_held_out_signal_lower_display':float(signal.mid()),
 'metric_witness_calibration_fit_residual_display':float(cal_residual.mid())},indent=2))

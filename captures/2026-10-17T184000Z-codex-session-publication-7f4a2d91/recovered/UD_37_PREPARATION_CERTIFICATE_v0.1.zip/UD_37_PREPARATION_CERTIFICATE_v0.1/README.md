# UD thirty seven preparation design

The report `UD_37_PREPARATION_CERTIFICATE_v0.1.md` explains the explicit preparation matrix, its minimality for full observable Hankel excitation, the finite-sample schedules and bounded-error signal-rank rule.

`PREPARATIONS.npz` contains the 2640 by 37 integer sign numerator and denominator 52. `PREPARATION_DESIGN.json` freezes the generator convention. `PREPARATION_CERTIFICATE.json` contains all 53 modal interval certificates and the three finite schedules. `CROSS_MOMENTS.json.gz` stores exact integer data used for interval evaluation.

Run `python validate_preparations.py` with the pinned dependencies and `OPENBLAS_NUM_THREADS=1` to replay construction in an isolated directory. This avoids writing into frozen capture files.

All results concern the frozen real nominal model and the original 62-channel observer. Physical promotion is zero, independent review is pending, and physical preparation and clock implementations remain open.

"""Explicit rational37-preparation design and exact cross moments."""
from pathlib import Path
import hashlib,json,gzip,time
import numpy as np
from scipy.sparse import csr_matrix
from flint import nmod_mat
root=Path(__file__).resolve().parent
domain=b'UD-600cell-original-link-37-preparations-v0.1-2026-10-17'
bits=np.unpackbits(np.frombuffer(hashlib.shake_256(domain).digest((2640*37+7)//8),dtype=np.uint8),bitorder='little')[:2640*37]
S=(2*bits.astype(np.int64)-1).reshape(2640,37)
gram=S.T@S
assert np.all(np.diag(gram)==2640)
assert nmod_mat(gram.tolist(),1009).rank()==37
gram_bound=int(np.max(np.abs(gram).sum(axis=1)))
assert gram_bound<=2*52**2
np.savez_compressed(root/'PREPARATIONS.npz',numerator=S.astype(np.int8),denominator=np.array(52,dtype=np.int64))
z=np.load(root/'sources/OPERATORS.npz');A=csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(2640,2640),dtype=np.int64)
L=(-A@A).tocsr();obs=z['obs']
assert (A+A.T).nnz==0
co=json.loads((root/'sources/ANNIHILATOR_COEFFICIENTS.json').read_text())['qL_coefficients_descending']
def mul(M,C):
    out=np.zeros((M.shape[0],C.shape[1]),dtype=object);c=C.tocoo()
    for i,j,a in zip(c.row,c.col,c.data):out[:,j]+=int(a)*M[:,i]
    return out
G=[];J=[];cur=S.T.astype(object);ann=np.zeros(cur.shape,dtype=object)
for k in range(54):
    ann+=int(co[53-k])*cur
    if k<=52:
        G.append(cur[:,obs].T.tolist())
        J.append((-mul(cur,A)[:,obs].T).tolist())
    if k<53:cur=mul(cur,L)
    if k%10==0:print('exact moment',k,flush=True)
assert not np.any(ann)
assert G[0]==S[obs].tolist() and J[0]==(A@S)[obs].tolist()
with gzip.open(root/'CROSS_MOMENTS.json.gz','wt') as f:json.dump({'G':G,'J':J,'denominator':52,'rows':62,'columns':37},f,separators=(',',':'))
out={'status':'EXACT_CONSTRUCTOR_VERIFIED','domain':domain.decode(),'algorithm':'SHAKE256 byte stream, little-bit order, row-major2640x37, bit0->-1 bit1->+1, divide52',
 'dimension':2640,'preparations':37,'denominator':52,'squared_norm_each':[165,169],
 'Gram_absolute_row_sum_numerator_max':gram_bound,'operator_norm_squared_upper':[2,1],
 'Gram_rank_mod1009':37,'full_carrier_qL_annihilator_on_preparations_checked':True,
 'G0_and_J0_checked':True,'S_sha256':hashlib.sha256(S.astype(np.int8).tobytes()).hexdigest(),
 'scope':'Known rational source preparations in frozen nominal real model; protocol choice, not theory constant or physical implementation',
 'physical_promotion':0,'independent_review':'pending'}
(root/'PREPARATION_DESIGN.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'preparations':37,'norm_squared':[165,169],'Gram_row_bound':gram_bound}),flush=True)

"""Interval certificate for37 explicit inputs and finite sampled Hankel matrices."""
from pathlib import Path
from fractions import Fraction
import gzip,json,math
import numpy as np
import sympy as sy
from flint import arb,arb_mat,acb,acb_mat,ctx
root=Path(__file__).resolve().parent;ctx.prec=512
freq=json.loads((root/'sources/FREQUENCY_CERTIFICATE.json').read_text())
table=json.loads((root/'sources/MULTIPLICITY_TABLE.json').read_text())
ranks={r['factor_L']:r['observable_multiplicity_per_eigenvalue'] for r in table}
with gzip.open(root/'CROSS_MOMENTS.json.gz','rt') as f:mom=json.load(f)
Gs=[arb_mat(v) for v in mom['G']];Js=[arb_mat(v) for v in mom['J']];del mom
co=json.loads((root/'sources/ANNIHILATOR_COEFFICIENTS.json').read_text())['qL_coefficients_descending']
dco=[a*(len(co)-1-j) for j,a in enumerate(co[:-1])]
x=sy.Symbol('x');rows=[];refined=[];alpha=None;beta=None
def rat(p):return arb(str(p[0]))/int(p[1])
def pair(q):return [int(q.p),int(q.q)]
def ceil_sqrt_fraction(q):
    n=math.isqrt(q.numerator//q.denominator)
    while n*n*q.denominator<q.numerator:n+=1
    return n
for ri,r in enumerate(freq['mu_root_intervals']):
    a=sy.Rational(*r['a']);b=sy.Rational(*r['b'])
    if a!=b:a,b=sy.refine_root(sy.sympify(r['factor']),a,b,eps=sy.Rational(1,2**400))
    ap,bp=pair(a),pair(b);refined.append({'factor':r['factor'],'a':ap,'b':bp})
    aa,bb=rat(ap),rat(bp);mu=arb((aa+bb)/2,(bb-aa)/2)
    cc=[arb(1)]
    for c in co[1:-1]:cc.append(arb(c)+mu*cc[-1])
    derivative=arb(0)
    for c in dco:derivative=derivative*mu+c
    assert derivative.abs_lower()>0
    gg=arb_mat(62,37);jj=arb_mat(62,37)
    for k,c in enumerate(cc):gg+=Gs[52-k]*c;jj+=Js[52-k]*c
    gg=gg*(1/derivative);jj=jj*(1/derivative)
    if ri==0:
        B=acb_mat([[acb(gg[i,j]/52) for j in range(37)] for i in range(62)])
    else:
        omega=mu.sqrt()
        B=acb_mat([[acb(gg[i,j]/104,-jj[i,j]/(104*omega)) for j in range(37)] for i in range(62)])
    gram=B.conjugate().transpose()*B;rank=ranks[r['factor']]
    mid=np.array([[complex(float(gram[i,j].real.mid()),float(gram[i,j].imag.mid())) for j in range(37)] for i in range(37)])
    vals,U=np.linalg.eigh((mid+mid.conj().T)/2)
    UU=acb_mat([[acb(float(U[i,j].real),float(U[i,j].imag)) for j in range(37)] for i in range(37)])
    adj=UU.conjugate().transpose();D=adj*gram*UU;G=adj*UU
    eta=max(sum((abs(G[i,j]-(1 if i==j else 0)) for j in range(37)),arb(0)).upper() for i in range(37))
    residual=max(sum((abs(D[i,j]-(float(vals[i]) if i==j else 0)) for j in range(37)),arb(0)).upper() for i in range(37))
    assert eta<1
    lower=(arb(float(vals[37-rank]))-residual)/(1+eta)
    upper=(arb(float(vals[-1]))+residual)/(1-eta)
    assert lower.lower()>0,(ri,r['factor'],str(lower))
    if alpha is None or lower.lower()<alpha:alpha=lower.lower()
    if beta is None or upper.upper()>beta:beta=upper.upper()
    rows.append({'factor_L':r['factor'],'root_interval':{'a':ap,'b':bp},'rank_per_signed_frequency':rank,
                 'B_gram_positive_eigenvalue_lower':str(lower.lower()),'B_gram_max_eigenvalue_upper':str(upper.upper()),
                 'diagonalization_residual_upper':str(residual),'unitarity_defect_upper':str(eta)})
    print('mode',ri,r['factor'],'rank',rank,'sigma2_min',float(lower.lower()),flush=True)
    (root/'MODAL_CERTIFICATE_PARTIAL.json').write_text(json.dumps({'components':rows},indent=2)+'\n')
assert sum(z['rank_per_signed_frequency']*(1 if j==0 else 2) for j,z in enumerate(rows))==1893
den=1
while arb(1)/den>=alpha:den*=2
upper_dyadic=Fraction(1)
while arb(upper_dyadic.numerator)/upper_dyadic.denominator<beta:upper_dyadic*=2
while arb(upper_dyadic.numerator)/(2*upper_dyadic.denominator)>beta:upper_dyadic/=2
C=arb(freq['temporal_row_sum_bound']);assert C<1786
protocols=[]
for M,eps in [(2048,Fraction(7,8)),(4096,Fraction(1,2)),(8192,Fraction(1,4))]:
    assert C/M<arb(eps.numerator)/eps.denominator
    lo=(1-eps)**2/den;hi=(1+eps)**2*upper_dyadic
    cond=ceil_sqrt_fraction(hi/lo);inv=ceil_sqrt_fraction(1/lo)
    ratio=hi/lo;rn=math.isqrt(ratio.numerator);rd=math.isqrt(ratio.denominator)
    assert rn*rn==ratio.numerator and rd*rd==ratio.denominator
    exact_cond=Fraction(rn,rd)
    # A rational per-preparation vector-error budget for a quarter-gap margin.
    error_den=1
    while Fraction(37,error_den**2)>lo/16:error_den*=2
    noise=Fraction(1,error_den)
    robust_cond=exact_cond*Fraction(4,3)+Fraction(1,3)
    robust_cond_integer=(robust_cond.numerator+robust_cond.denominator-1)//robust_cond.denominator
    protocols.append({'axis_samples':M,'step':[1,2],'raw_time_samples_per_preparation':2*M-1,
       'last_time':[M-1,1],'matrix_rows':62*M,'matrix_columns':37*M,'normalization':[1,M],
       'scalar_outputs':37*62*(2*M-1),'rank':1893,'sigma_min_nonzero_squared_lower':[lo.numerator,lo.denominator],
       'sigma_max_squared_upper':[hi.numerator,hi.denominator],'condition_number_nonzero_upper':cond,
       'condition_number_nonzero_upper_rational':[exact_cond.numerator,exact_cond.denominator],
       'pseudoinverse_norm_upper':inv,'per_raw_output_vector_total_error_ceiling':[noise.numerator,noise.denominator],
       'Hankel_operator_error_bound':'sqrt(37)*epsilon <= sigma_min_lower/4',
       'retained_rank_condition_upper_under_error_ceiling':robust_cond_integer,
       'retained_rank_condition_upper_rational':[robust_cond.numerator,robust_cond.denominator],
       'rank_selection_threshold':'one half of the declared nominal smallest-nonzero singular-value lower bound; top1893 only'})
out={'status':'CERTIFIED_INTERVAL_CONSTRUCTOR','physical_promotion':0,'independent_review':'pending','precision_bits':512,
 'preparations':37,'sensor_channels':62,'history_rank_excited':1893,'minimal_preparation_count_real_model':37,
 'minimality_proof':'The observable eigenspace at eigenvalue+2i has complex dimension37; p preparations span at mostp directions there. The explicit design excites every observable eigenvalue.',
 'components':rows,'modal_sigma_squared_lower':[1,den],'modal_sigma_squared_upper':[upper_dyadic.numerator,upper_dyadic.denominator],
 'modal_sigma_squared_lower_enclosure':str(alpha),'modal_sigma_squared_upper_enclosure':str(beta),
 'factorization':'H_M=(V_M tensor I62) diag_lambda(R E_lambda X) (V_M^T tensor I37), V_M[j,lambda]=exp(j lambda/2)/sqrt(M)',
 'temporal_Gram_spectrum':'[1-epsilon,1+epsilon] at both axes; reciprocal-sine sumC<1786',
 'protocols':protocols,'scope':'Frozen nominal real A, original62-channel shell, exact declared preparations and clock. Total output-vector error budget conditional; no physical data or model-independent identifiability.',
 'not_claimed':['Recovery of original747-dimensional hidden subspace','Hardware preparation implementation','Full-rank noisy Hankel matrix','Gauge or physical-clock derivation','Transfer to characteristic13']}
(root/'REFINED_ROOT_INTERVALS.json').write_text(json.dumps(refined,indent=2)+'\n')
(root/'PREPARATION_CERTIFICATE.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'modal_sigma2_lower':[1,den],'modal_sigma2_upper':str(upper_dyadic),'conditions':[p['condition_number_nonzero_upper'] for p in protocols]}),flush=True)

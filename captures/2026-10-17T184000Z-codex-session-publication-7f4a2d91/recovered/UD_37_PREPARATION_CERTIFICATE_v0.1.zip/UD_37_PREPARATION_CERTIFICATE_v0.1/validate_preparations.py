"""Full isolated replay of exact preparation moments and interval certificate."""
from pathlib import Path
import gzip,json,hashlib,shutil,subprocess,tempfile,sys
import numpy as np
root=Path(__file__).resolve().parent
prov=json.loads((root/'PROVENANCE.json').read_text())
for item in prov['sources']:
    b=(root/item['path']).read_bytes()
    assert len(b)==item['size_bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
with tempfile.TemporaryDirectory(prefix='ud-preparation-replay-') as temp:
    p=Path(temp);shutil.copytree(root/'sources',p/'sources')
    for script in ['build_preparations.py','certify_preparations.py']:
        shutil.copy2(root/script,p/script)
        r=subprocess.run([sys.executable,script],cwd=p,capture_output=True,text=True)
        assert r.returncode==0,r.stdout+'\n'+r.stderr
    for name in ['PREPARATION_DESIGN.json','PREPARATION_CERTIFICATE.json','REFINED_ROOT_INTERVALS.json']:
        assert json.loads((root/name).read_text())==json.loads((p/name).read_text()),name
    with gzip.open(root/'CROSS_MOMENTS.json.gz','rt') as a,gzip.open(p/'CROSS_MOMENTS.json.gz','rt') as b:
        assert json.load(a)==json.load(b)
    a=np.load(root/'PREPARATIONS.npz');b=np.load(p/'PREPARATIONS.npz')
    assert a.files==b.files
    for key in a.files:assert np.array_equal(a[key],b[key])
cert=json.loads((root/'PREPARATION_CERTIFICATE.json').read_text())
from fractions import Fraction
assert [Fraction(*p['condition_number_nonzero_upper_rational']) for p in cert['protocols']]==[Fraction(15360),Fraction(3072),Fraction(5120,3)]
assert [p['rank'] for p in cert['protocols']]==[1893]*3
for p in cert['protocols']:
    noise=Fraction(*p['per_raw_output_vector_total_error_ceiling'])
    low=Fraction(*p['sigma_min_nonzero_squared_lower'])
    assert 37*noise*noise<=low/16
out={'status':'PASS','physical_promotion':0,'independent_review':'pending','isolated_replay':'preparations, exact integer cross moments, root intervals and all modal interval bounds match',
     'modal_roots_checked':53,'signed_frequencies':105,'response_rank':1893,'preparations':37,'finite_protocols':3,
     'noise_gap_budgets_checked':True,'not_verified':['Physical instrument','Preparation implementation','Clock calibration','Independent review']}
(root/'VALIDATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

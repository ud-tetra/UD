"""Isolated fitted-family certificate replay and exact transfer witnesses."""
from pathlib import Path
import json,hashlib,shutil,tempfile,subprocess,sys
from fractions import Fraction as F
import numpy as np
import sympy as s
root=Path(__file__).resolve().parent
prov=json.loads((root/'PROVENANCE.json').read_text())
for item in prov['sources']:
    b=(root/item['path']).read_bytes()
    assert len(b)==item['size_bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
with tempfile.TemporaryDirectory(prefix='ud-fitted-replay-') as temp:
    p=Path(temp);shutil.copytree(root/'sources',p/'sources');shutil.copy2(root/'certify_fitted.py',p/'certify_fitted.py');shutil.copy2(root/'certify_shape_gate.py',p/'certify_shape_gate.py')
    r=subprocess.run([sys.executable,'certify_fitted.py'],cwd=p,capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    assert json.loads((root/'FITTED_FAMILY_CERTIFICATE.json').read_text())==json.loads((p/'FITTED_FAMILY_CERTIFICATE.json').read_text())
    shape=subprocess.run([sys.executable,'certify_shape_gate.py'],cwd=p,capture_output=True,text=True)
    assert shape.returncode==0,shape.stderr
    assert json.loads((root/'SHAPE_CALIBRATION_GATE.json').read_text())==json.loads((p/'SHAPE_CALIBRATION_GATE.json').read_text())
    a=np.load(root/'FITTED_PREPARATIONS.npz');b=np.load(p/'FITTED_PREPARATIONS.npz')
    assert a.files==b.files
    for k in a.files:assert np.array_equal(a[k],b[k])
# A small exact instance tests the input/readout and retiming identity in powers.
A=s.Matrix([[0,-1],[1,0]]);Q=s.diag(1,s.Rational(65,64));c=s.Rational(33,32)
K=c*Q.inv()*A*Q;R=s.eye(2);X=s.Matrix([[1,2],[3,4]])/7
for k in range(12):assert R*Q*(K/c)**k*Q.inv()*X==R*A**k*X
d=json.loads((root/'FITTED_FAMILY_CERTIFICATE.json').read_text())
assert [p['retained_signal_condition_upper'] for p in d['protocols']]==[19410,3385,1930]
assert F(*d['common_scale_family']['temporal_C_upper_rational'])<1792
assert d['improvements']['residual_rate_metric_extra_skew_tolerance_ratio']==[8,1]
out={'status':'PASS','physical_promotion':0,'independent_review':'pending','isolated_replay':'all certificate fields and preparation arrays identical',
     'sparse_similarity_entries_verified':d['fitted_centre']['all_sparse_entries_similarity_checked'],
     'retained_signal_conditions':[19410,3385,1930],'common_scale_interval_verified':True,'residual_relaxation_factor':8,
     'six_ratio_shape_gate_verified':True,
     'fit_is_empirical':False,'not_verified':['Physical calibration','Generic unmatched fitted generator','Actual residual envelope','Independent review']}
(root/'VALIDATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

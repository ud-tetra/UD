"""Clock- and metric-scale-free calibration algebra and sufficient uncertainty gate."""
from pathlib import Path
from fractions import Fraction as F
import json
from flint import arb,ctx
root=Path(__file__).resolve().parent;ctx.prec=256
def pair(x):return [x.numerator,x.denominator]
def a(x):return arb(str(x.numerator))/x.denominator
fit=json.loads((root/'FITTED_FAMILY_CERTIFICATE.json').read_text())
directed=[F(*v) for v in fit['fitted_centre']['directed_ratios']]
ds=directed[:3];us=directed[3:]
q=[F(*v) for v in fit['fitted_centre']['grade_Q']];c=F(*fit['fitted_centre']['common_rate'])
q2=F(1)
for k in range(3):
    q2*=ds[k]/us[k]
    assert q2==q[k+1]**2
    assert ds[k]*us[k]==c*c
# Measured six positive directed ratios in the old local domain, but without
# requiring separately identified common clock or overall metric scale.
delta=F(1,2**39);observed_shape=F(1,2**38);lower=F(15,16)
logerr=a(delta/(lower-delta))
metric=(6*logerr).exp()-1
rate=(1+a(F(1,1024)))*((1+a(observed_shape))*(7*logerr).exp()-1)
target=a(F(1,2**35))
assert metric<target and rate<target
out={'status':'DERIVED_CONDITIONAL_INTERVAL_CERTIFIED','physical_promotion':0,'independent_review':'pending',
 'effective_measured_ratios':'D_k=alpha w_k/h_(k-1), U_k=alpha w_k/h_k',
 'metric_shape_reconstruction':'qhat_0=1; qhat_k^2=product_(j<=k)(Dhat_j/Uhat_j)',
 'effective_rates':'s_k=sqrt(D_k U_k); chat=(shat_1 shat_2 shat_3)^(1/3)',
 'matched_family_test':'shat_k/chat close to1; common clock and metric scales cancel in relative shapes',
 'six_directed_ratio_absolute_error_ceiling':pair(delta),'measured_ratio_lower_domain':pair(lower),
 'estimated_effective_rate_shape_gate':pair(observed_shape),'common_scale_gate':[1,1024],
 'log_ratio_error_bound':str(logerr),'metric_shape_error_bound':str(metric),
 'normalized_native_rate_shape_error_bound':str(rate),'both_below_residual_ceiling':[1,2**35],
 'coefficient_bound_proof':'metric-root errors contribute at most5*logerr on adjacent grades; effective-rate normalization contributes2*logerr, giving7*logerr total',
 'exact_candidate_centre_reconstruction_checked':True,
 'scope':'Conditional algebra from bounded six-ratio estimates. No empirical ratio estimates or finite calibration protocol at this tighter precision supplied.',
 'not_established':['Extra skewJ bound','Full-domain readout bound','A physical time map','Generic unmatched effective-rate transfer']}
(root/'SHAPE_CALIBRATION_GATE.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'directed_ratio_error':pair(delta),'metric_bound':float(metric),'rate_bound':float(rate),'target':float(target)}))

"""Exact fitted-family transfer and interval robust signal-gap certificate."""
from pathlib import Path
from fractions import Fraction as F
import math,json
import numpy as np
from flint import arb,ctx
root=Path(__file__).resolve().parent;ctx.prec=256
def pair(q):q=F(q);return [q.numerator,q.denominator]
def ball(q):q=F(q);return arb(str(q.numerator))/q.denominator
def enc(a):return {'arb_enclosure':str(a),'display_only':float(a.mid())}
def ceil_upper(x):
    k=math.ceil(float(x.upper()))
    while arb(k)<=x.upper():k+=1
    return k
parent=json.loads((root/'sources/PARENT_PREPARATION_CERTIFICATE.json').read_text())
freq=json.loads((root/'sources/FREQUENCY_CERTIFICATE.json').read_text())
old=json.loads((root/'sources/PARENT_INSTRUMENT_CONTRACT.json').read_text())
z=np.load(root/'sources/OPERATORS.npz');data=z['A_data'];indices=z['A_indices'];indptr=z['A_indptr'];obs=z['obs']
grade_sizes=[120,720,1200,600]
q=[F(1),F(65,64),F(33,32),F(67,64)];c=F(33,32)
h=[v*v for v in q];w=[c*q[k-1]*q[k] for k in range(1,4)]
qs=[v for k,v in enumerate(q) for _ in range(grade_sizes[k])]
hs=[v*v for v in qs];assert len(qs)==2640
# Verify both exact fitted similarity and H-skewness on every sparse entry.
entries={}
for i in range(2640):
    for kk in range(int(indptr[i]),int(indptr[i+1])):
        j=int(indices[kk]);a=int(data[kk]);v=c*qs[j]/qs[i]*a
        assert qs[i]*v/qs[j]==c*a
        entries[i,j]=v
for (i,j),v in entries.items():assert hs[i]*v+hs[j]*entries.get((j,i),0)==0
base=np.load(root/'sources/BASE_PREPARATIONS.npz');S=base['numerator'].astype(np.int64);den=int(base['denominator'])
# A single exact common denominator for Xhat=Q^-1 S/52.
common=math.lcm(*(int((F(1,den)/v).denominator) for v in q))
row_multipliers=np.array([int(F(common,den)/v) for v in qs],dtype=np.int64)
num=S*row_multipliers[:,None]
assert np.max(np.abs(num))<2**31
np.savez_compressed(root/'FITTED_PREPARATIONS.npz',numerator=num.astype(np.int32),denominator=np.array(common,dtype=np.int64),observed_grade_factors_num=np.array([qs[int(i)].numerator for i in obs]),observed_grade_factors_den=np.array([qs[int(i)].denominator for i in obs]))
raw_norm=sum(F(n,den*den)/(qq*qq) for n,qq in zip(grade_sizes,q));stock=F(165,169)
assert raw_norm<=stock
assert sum(hh*F(n,den*den)/(qq*qq) for n,qq,hh in zip(grade_sizes,q,h))==stock
directed=[c*q[k]/q[k-1] for k in range(1,4)]+[c*q[k-1]/q[k] for k in range(1,4)]
assert all(F(15,16)<=v<=F(17,16) for v in directed)
input_gain=max(qs);output_gain=max(qs[int(i)] for i in obs)
assert input_gain==F(67,64) and output_gain==F(33,32)
assert all(F(*r['b'])<16 for r in freq['mu_root_intervals'])
C=arb(freq['temporal_row_sum_bound']);assert C<1786
d=F(1,1024)
Ccap=F(1786)/(1-3*d)
assert Ccap<1792
# Primitive common-factor errors can be individually much larger.
a_common=F(1,4096)
scale_low=(1-a_common)**2/(1+a_common)
scale_high=(1+a_common)**2/(1-a_common)
assert scale_low>=1-d and scale_high<=1+d
# Residual errors are measured after the fitted whitening and time change.
prep=rho=F(1,2**25);nu=F(1,2**26)
origin=jitter=F(1,2**29);tau=origin+jitter
r=eta=sigma=F(1,2**35)
qmax=1+d
e=(4*r+sigma+4*qmax*eta)/(1-eta)
g=ball((1+eta)/(1-eta)).sqrt();a=ball(stock).sqrt()
u=g*((1+ball(rho))*ball(prep)+ball(rho)*a+a*ball(4*qmax+e)*ball(tau))+ball(nu)
v=g*a*ball(e)
protocols=[]
for p in parent['protocols']:
    M=p['axis_samples'];eps={2048:F(7,8),4096:F(1,2),8192:F(1,4)}[M]
    assert Ccap/M<eps
    s=ball(F(*p['sigma_min_nonzero_squared_lower'])).sqrt();B=ball(F(*p['sigma_max_squared_upper'])).sqrt()
    mean=F(M-1,2);second=F(7*M*M-12*M+5,24)
    beta=(arb(37)*(u*u+2*u*v*ball(mean)+v*v*ball(second))).sqrt()
    assert beta<s/4,(M,str(beta/s))
    cond=(B+beta)/(s-beta)
    protocols.append({'axis_samples':M,'fitted_raw_sampling_step':pair(1/(2*c)),'last_fitted_raw_time':pair(F(M-1)/c),
      'normalized_last_time':[M-1,1],'raw_vectors_per_preparation':2*M-1,
      'temporal_epsilon_upper':pair(eps),'nominal_common_family_rank':1893,
      'nominal_family_condition_bound':p['condition_number_nonzero_upper_rational'],
      'Hankel_residual_error':enc(beta),'residual_error_over_signal_lower':enc(beta/s),
      'retained_signal_condition_upper':ceil_upper(cond),'retained_signal_condition_enclosure':enc(cond),
      'signal_count_above_half_nominal_lower_threshold':1893,
      'worst_raw_response_error_to_common_family':enc(u+v*(M-1)),
      'parent_pointwise_error_budget_required':False})
out={'status':'EXACT_AND_INTERVAL_CONDITIONAL_CERTIFIED','physical_promotion':0,'independent_review':'pending',
 'fit_status':'Explicit candidate fitted centre; no empirical fit supplied or claimed',
 'fitted_centre':{'grade_Q':list(map(pair,q)),'grade_H':list(map(pair,h)),'common_rate':pair(c),'native_rates':list(map(pair,w)),
  'directed_ratios':list(map(pair,directed)),'formula':'Khat=c Q^-1 A Q = Hhat^-1 A(what)',
  'all_sparse_entries_similarity_checked':len(entries),'H_skew_checked':True,
  'input_formula':'Xhat=Q^-1 X','corrected_readout':'R Q; if raw readout isR, multiply each measured channel byits fitted gradeQ factor',
  'sampling_step':pair(1/(2*c)),'raw_preparation_squared_norm':pair(raw_norm),'Hhat_stock_each':pair(stock),
  'input_whitening_norm':pair(input_gain),'output_correction_norm':pair(output_gain),
  'raw_to_normalized_sufficient_error_factors':{'preparation_raw_ceiling_factor':pair(1/input_gain),'raw_readout_operator_ceiling_factor':pair(1/output_gain),'raw_additive_vector_ceiling_factor':pair(1/output_gain),'raw_origin_and_jitter_ceiling_factor':pair(1/c)},
  'known_offset_penalty':'zero under the exact coordinate/input/readout/time transfer'},
 'common_scale_family':{'q_range':[pair(1-d),pair(1+d)],'uncertainty':pair(d),
  'constant_over_entire_run':True,
  'temporal_C_upper_rational':pair(Ccap),'sine_proof':'For0<x<2, sinx>=x/3. Thus|sin(qx)| >= (1-3d) sinx for|q-1|<=d. C(q)<=C/(1-3d).',
  'modal_blocks_unchanged':True,'primitive_common_factor_ceiling_each':pair(a_common),
  'primitive_scale_formula':'q=alpha*beta/lambda, for common clock, rate and metric scales; each within1/4096 ofone',
  'primitive_q_enclosure':[pair(scale_low),pair(scale_high)],'requires_separate_identification_of_factors_for_signal_rank':False},
 'residual_model':'G=Htilde^-1(q A+DeltaA+J), q in common scale interval, ||Htilde-I||<=eta, ||DeltaA||<=4r, J skew, ||J||<=sigma',
 'residual_generator_bound':pair(e),'propagator_bound':enc(g),'response_error_u':enc(u),'response_error_v':enc(v),
 'residual_tolerances':{'preparation':pair(prep),'readout':pair(rho),'additive_output':pair(nu),'origin':pair(origin),'jitter':pair(jitter),'rate_shape_each':pair(r),'metric_shape':pair(eta),'extra_skew':pair(sigma)},
 'improvements':{'effective_common_scale_tolerance_ratio_to_old_clock_cap':pair(d/F(*old['tolerances']['relative_clock_scale_error'])),
  'primitive_common_factor_tolerance_ratio_to_old_rate_metric_cap':pair(a_common/F(*old['tolerances']['rate_error_each'])),
  'residual_rate_metric_extra_skew_tolerance_ratio':pair(r/F(*old['tolerances']['rate_error_each']))},
 'protocols':protocols,
 'scope':'37-input real original-shell signal gap after declared fitted-coordinate transfer; no claim that arbitrary fitted grade ratios lie in the matched family or that hardware meets the residual bounds',
 'open':['Generic independently fitted nonuniform rates require fresh modal/cluster certificates','Existing grade uncertainty bounds do not establish the anisotropic residual tolerances','Physical input/readout conversion and clock bridge','Independent review']}
(root/'FITTED_FAMILY_CERTIFICATE.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'step':pair(1/(2*c)),'native_rates':list(map(pair,w)),
 'conditions':[p['retained_signal_condition_upper'] for p in protocols],
 'error_ratios':[p['residual_error_over_signal_lower']['display_only'] for p in protocols],
 'common_scale_tolerance':pair(d),'residual_tolerance':pair(r),'improvements':out['improvements']}))

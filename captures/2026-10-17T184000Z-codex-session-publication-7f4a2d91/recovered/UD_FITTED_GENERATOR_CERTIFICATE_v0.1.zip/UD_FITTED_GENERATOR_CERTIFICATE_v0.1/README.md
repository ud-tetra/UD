# UD fitted generator certificate

Read `UD_FITTED_GENERATOR_CERTIFICATE_v0.1.md` for the fitted-coordinate theorem, common-scale tolerance and residual-error scope. `FITTED_PREPARATIONS.npz` contains the transformed 37 rational preparations; the certificate lists their denominator and channel correction factors.

Run `python validate_fitted.py` with the pinned dependencies to replay the construction in an isolated directory. It checks all 14880 sparse similarity entries, H-skewness, transformed preparation arrays, common-scale interval bounds, retained-signal conditions and the six-ratio shape-calibration gate.

The centre is an explicit candidate, not an empirical calibration. Generic unmatched fitted generators are outside the transferred numerical certificate. Physical promotion is zero and independent review is pending.

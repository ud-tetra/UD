# UD instrument error contract

Read `UD_37_INSTRUMENT_ERROR_CONTRACT_v0.1.md` for the joint error theorem, candidate tolerances and calibration limitations. `INSTRUMENT_CONTRACT.json` contains the rigorous interval bounds, and `CALIBRATION_REQUIREMENTS.json` records the evidence required before claiming instrument verification.

Run `python validate_instrument.py` to replay the interval certificate in an isolated directory, verify source hashes and check exact small-matrix instances of the calibration ambiguities. Earlier large observation and preparation certificates are inherited, not recomputed here.

No empirical calibration or SI clock conversion is claimed. Physical promotion is zero; independent review is pending. The numerical tolerances are sufficient protocol allocations, not necessary limits or theory constants.

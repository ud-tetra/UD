"""Joint sufficient instrument-error contract in declared model units."""
from pathlib import Path
from fractions import Fraction as F
import json,math
from flint import arb,ctx
root=Path(__file__).resolve().parent;ctx.prec=256
parent=json.loads((root/'sources/PARENT_PREPARATION_CERTIFICATE.json').read_text())
single=json.loads((root/'sources/REAL_SINGLE_LINK_RESULTS.json').read_text())
freq=json.loads((root/'sources/FREQUENCY_CERTIFICATE.json').read_text())
def ball(q):
    q=F(q);return arb(str(q.numerator))/q.denominator
def pair(q):
    q=F(q);return [q.numerator,q.denominator]
def ceiling_upper(x):
    n=math.ceil(float(x.upper()))
    while arb(n)<=x.upper():n+=1
    return n
def enclosure(x):return {'arb_enclosure':str(x),'display_only':float(x.mid())}
assert max(F(*r['b']) for r in freq['mu_root_intervals'])<16
# Common candidate protocol allocation; these are distinct typed tolerances.
prep=F(1,2**25);rho=F(1,2**25);nu=F(1,2**26)
origin=F(1,2**29);jitter=F(1,2**29);tau=origin+jitter
r=eta=sigma=clock=F(1,2**38)
eps=(4*r+sigma+4*eta)/(1-eta)
eps_effective=eps+(4+eps)*clock
g=(ball((1+eta)/(1-eta))).sqrt();a=(arb(165)/169).sqrt()
u=g*((1+ball(rho))*ball(prep)+ball(rho)*a+a*ball(4+eps)*ball(tau))+ball(nu)
v=g*a*ball(eps_effective)
protocols=[]
for p in parent['protocols']:
    M=p['axis_samples'];T=F(M-1);mean=F(M-1,2);second=F(7*M*M-12*M+5,24)
    # Independent integer-sum verification of the triangular Hankel weights.
    weighted_n=0;weighted_t=F(0);weighted_t2=F(0)
    for k in range(2*M-1):
        weight=k+1 if k<M else 2*M-1-k
        weighted_n+=weight;weighted_t+=weight*F(k,2);weighted_t2+=weight*F(k*k,4)
    assert weighted_n==M*M and weighted_t/(M*M)==mean and weighted_t2/(M*M)==second
    end=u+v*ball(T)
    error=(arb(37)*(u*u+2*u*v*ball(mean)+v*v*ball(second))).sqrt()
    s=ball(F(*p['sigma_min_nonzero_squared_lower'])).sqrt()
    b=ball(F(*p['sigma_max_squared_upper'])).sqrt()
    raw_budget=F(*p['per_raw_output_vector_total_error_ceiling'])
    assert end<ball(raw_budget)
    assert error<s/4
    retained=(b+error)/(s-error)
    protocols.append({'axis_samples':M,'raw_time_vectors_per_preparation':2*M-1,'last_time':pair(T),
      'mean_Hankel_time':pair(mean),'mean_squared_Hankel_time':pair(second),
      'parent_per_vector_budget':pair(raw_budget),'worst_raw_vector_error_upper':enclosure(end),
      'Hankel_operator_error_upper':enclosure(error),'Hankel_error_over_nominal_sigma_min':enclosure(error/s),
      'parent_budget_verified':True,'quarter_signal_gap_verified':True,
      'signal_count_above_half_nominal_lower_threshold':1893,
      'retained_condition_upper':ceiling_upper(retained),'retained_condition_enclosure':enclosure(retained),
      'least_retained_singular_lower':enclosure(s-error),'remaining_singular_upper':enclosure(error)})
# Distinct calibration obstructions: do not sum their dimensions.
reachable_upper=0;details=[];full_max=0
for c in single['components']:
    d=c['degree'];zero=c['factor']=='x';num=1 if zero else 2*d
    mult=c['ambient_dimension'] if zero else c['ambient_dimension']//num
    assert mult*num==c['ambient_dimension'];full_max=max(full_max,mult)
    reachable_upper+=num*min(37,mult)
    if mult>37:details.append({'factor_L':c['factor'],'full_multiplicity_per_signed_eigenvalue':mult,'signed_eigenvalue_count':num,'missing_lower':num*(mult-37)})
blind=2640-reachable_upper;N=single['dynamic_unobservable_dimension']
assert reachable_upper==2430 and blind==210 and N==747 and full_max==72
blindness={'actual37_input_reachable_dimension_upper':reachable_upper,'unexcited_bulk_dimension_lower':blind,
 'arbitrary_readout_blind_dimension_per_row_lower':blind,'arbitrary62_row_readout_blind_parameters_lower':62*blind,
 'skew_generator_blind_parameters_on_unexcited_subspace_lower':blind*(blind-1)//2,
 'nominal_observer_unobservable_dimension':N,'skew_generator_blind_parameters_inside_nominal_N':N*(N-1)//2,
 'minimum_generic_inputs_for_full_carrier_excitation':full_max,'modal_details':details,
 'scope':'Algebraic obstructions, not extra measured noise or additive counts; arbitrary extra skew generator family allowed by the declared contract'}
out={'status':'DERIVED_CONDITIONAL_INTERVAL_CERTIFIED','physical_promotion':0,'independent_review':'pending','precision_bits':256,
 'plant':'K=H^-1(A(w)+J), H SPD, ||H-I||<=eta, |w_k-1|<=r, J^T=-J and||J||<=sigma',
 'preparation':'actual state=x_a+d_a, ||d_a||<=prep; nominal||x_a||=sqrt(165/169)',
 'readout':'C_(a,k)=R+E_(a,k), ||E||<=rho; additive vector error<=nu',
 'clock':'actual model time=(1+theta)t+b+zeta, |theta|<=clock, |b|<=origin, |zeta|<=jitter',
 'generator_bound':pair(eps),'clock_and_generator_effective_bound':pair(eps_effective),'H_skew_propagator_bound':enclosure(g),
 'uniform_response_bound':'||y_actual(t)-R exp(tA)x_a||<=u+v*t',
 'u':enclosure(u),'v':enclosure(v),
 'tolerances':{'preparation_norm_error':pair(prep),'readout_operator_norm_error':pair(rho),'additive_output_vector_error':pair(nu),
  'time_origin_model_units':pair(origin),'time_jitter_model_units':pair(jitter),'relative_clock_scale_error':pair(clock),
  'rate_error_each':pair(r),'metric_operator_error':pair(eta),'extra_skew_generator_operator_error':pair(sigma)},
 'Hankel_bound':'beta<=sqrt(37)*sqrt(u^2+2*u*v*(M-1)/2+v^2*(7M^2-12M+5)/24)',
 'protocols':protocols,'calibration_obstructions':blindness,
 'scope':'Sufficient candidate tolerances in normalized model coordinates; no measured calibration or SI time map. Signal gap only; perturbed system may have additional weak observable modes.',
 'not_claimed':['Calibration from the37 response data alone','Physical realization','An unchanged perturbed-system algebraic rank or kernel','Gauge groups or physical-clock identification']}
(root/'INSTRUMENT_CONTRACT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'conditions':[p['retained_condition_upper'] for p in protocols],
                 'error_ratios':[p['Hankel_error_over_nominal_sigma_min']['display_only'] for p in protocols],
                 'max_raw_errors':[p['worst_raw_vector_error_upper']['display_only'] for p in protocols],
                 'readout_blind_parameters':62*blind,'N_skew_blind_parameters':N*(N-1)//2}))

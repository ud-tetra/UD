"""Isolated certificate replay plus exact algebraic ambiguity witnesses."""
from pathlib import Path
import json,hashlib,shutil,subprocess,sys,tempfile
from fractions import Fraction as F
import sympy as s
root=Path(__file__).resolve().parent
prov=json.loads((root/'PROVENANCE.json').read_text())
for item in prov['sources']:
    b=(root/item['path']).read_bytes()
    assert len(b)==item['size_bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
with tempfile.TemporaryDirectory(prefix='ud-instrument-contract-') as temp:
    p=Path(temp);shutil.copytree(root/'sources',p/'sources');shutil.copy2(root/'certify_instrument.py',p/'certify_instrument.py')
    r=subprocess.run([sys.executable,'certify_instrument.py'],cwd=p,capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    assert json.loads((root/'INSTRUMENT_CONTRACT.json').read_text())==json.loads((p/'INSTRUMENT_CONTRACT.json').read_text())
d=json.loads((root/'INSTRUMENT_CONTRACT.json').read_text())
assert [p['retained_condition_upper'] for p in d['protocols']]==[16657,3156,1755]
assert all(p['quarter_signal_gap_verified'] and p['parent_budget_verified'] for p in d['protocols'])
# Exact low-dimensional instances of the general operator obstructions.
J=s.Matrix([[0,-1],[1,0]]);A=s.diag(J,J);R=s.Matrix([[1,0,0,0],[0,1,0,0]])
D=s.diag(s.zeros(2),2*J)
assert D.T==-D
for k in range(12):assert R*(A+D)**k==R*A**k
x=s.Matrix([1,0,0,0]);E=s.Matrix([[0,0,1,0],[0,0,0,0]])
for k in range(12):assert E*A**k*x==s.zeros(2,1)
c=s.Rational(7,5);alpha=s.Rational(3,2)
assert alpha*A==(c*alpha)*(A/c)
Az=s.diag(s.zeros(1),J);H=s.diag(s.Rational(9,8),1,1)
assert H.inv()*Az==Az
# Constitutive generator bound algebra.
t=d['tolerances'];r=F(*t['rate_error_each']);eta=F(*t['metric_operator_error']);sigma=F(*t['extra_skew_generator_operator_error'])
assert F(*d['generator_bound'])==(4*r+sigma+4*eta)/(1-eta)
out={'status':'PASS','physical_promotion':0,'independent_review':'pending','isolated_interval_certificate_replay':'all fields match',
 'exact_triangular_time_moments_checked':True,'protocols_checked':3,'algebraic_witnesses':['hidden skew dynamics','readout invisible on input reach','clock-rate scaling','null-mode metric shadow'],
 'source_hashes_verified':len(prov['sources']),'not_verified':['Physical calibration','Chosen tolerances as necessary conditions','SI time map','Independent review']}
(root/'VALIDATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

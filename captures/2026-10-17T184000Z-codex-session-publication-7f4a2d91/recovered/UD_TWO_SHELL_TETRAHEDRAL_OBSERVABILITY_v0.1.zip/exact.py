import json,time,math,gzip
from pathlib import Path
import numpy as np,scipy.sparse as sp,sympy as s
from flint import fmpz_mat,nmod_mat
D=Path(__file__).resolve().parent;z=np.load(D/'selected_operators.npz');N=2640;obs=z['obs'];ns=len(obs)
A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(N,N));L=(-A@A).tocsr();x=s.Symbol('x');q=s.Poly.from_list(json.loads((D/'sources/modular_results.json').read_text())['qL_coefficients'],x)
def mul(M,S):
 out=np.zeros((M.shape[0],S.shape[1]),dtype=object);co=S.tocoo()
 for i,j,a in zip(co.row,co.col,co.data):out[:,j]+=int(a)*M[:,i]
 return out
R=np.eye(N,dtype=np.int64)[obs].astype(object);P=[R];cur=R
for k in range(1,54):
 cur=mul(cur,L);P.append(cur)
 if k%10==0:print('integer power',k,flush=True)
ann=sum((int(a)*P[q.degree()-i] for i,a in enumerate(q.all_coeffs())),np.zeros(R.shape,dtype=object));assert not np.any(ann)
print('observer annihilator PASS',flush=True)
mom={'G':[v[:,obs].tolist() for v in P[:53]],'J':[mul(v,A)[:,obs].tolist() for v in P[:53]],'sensor_count':ns}
with gzip.open(D/'moments.json.gz','wt') as f:json.dump(mom,f,separators=(',',':'))
res=[]
for ff,e in s.factor_list(q)[1]:
 h=q.exquo(ff);co=list(map(int,h.all_coeffs()));base=sum((a*P[h.degree()-i] for i,a in enumerate(co)),np.zeros(R.shape,dtype=object));t=base;rows=[]
 for j in range(ff.degree()):rows.extend([t,mul(t,A)]);t=mul(t,L)
 M=np.concatenate(rows)
 for row in M:
  g=math.gcd(*map(int,row))
  if g>1:row//=g
 rank=fmpz_mat(M.tolist()).rank();without=M[[i for i in range(M.shape[0]) if i%ns!=ns-1]];rank2=fmpz_mat(without.tolist()).rank()
 lows=[nmod_mat([[int(v)%p for v in row] for row in M],p).rank() for p in [1009,1013]];assert lows==[rank,rank]
 res.append({'factor':str(ff.as_expr()),'degree':ff.degree(),'augmented_rank':rank,'two_shell_rank':rank2,'modular_augmented_ranks':lows})
 print(str(ff.as_expr()),rank2,rank,flush=True)
 (D/'EXACT_RANKS.json').write_text(json.dumps({'status':'EXACT','components':res,'complete':len(res)==30,'two_shell_rank':sum(r['two_shell_rank'] for r in res),'augmented_rank':sum(r['augmented_rank'] for r in res),'sensor_count':ns,'annihilator_exact':True},indent=2)+'\n')

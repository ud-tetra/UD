import json,time,itertools
from pathlib import Path
import numpy as np,scipy.sparse as sp
from flint import nmod_mat
D=Path(__file__).resolve().parent;p=1009;z=np.load(D/'sources/operators.npz');N=2640
A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(N,N));obs=z['obs'];R=np.eye(N,dtype=np.int64)[obs]
src=json.loads((D/'sources/COMPLEX_AND_ACTION.json').read_text());S=[[tuple(t) for t in s] for s in src['simplices']];off=np.cumsum([0]+list(map(len,S)));idx=[{t:i for i,t in enumerate(s)} for s in S]
def shell(v):return sorted(int(off[k])+idx[k][tuple(x for x in t if x!=v)] for k in range(3) for t in S[k+1] if v in t)
rows=[];cur=R.copy()
for j in range(105):rows.append(cur);cur=(A.T@cur.T).T%p
O=np.concatenate(rows);rr,rank=nmod_mat(O.tolist(),p).rref();assert rank==1893
piv=[]
for i in range(rank):piv.append(next(j for j in range(N) if rr[i,j]))
free=sorted(set(range(N))-set(piv));K=np.zeros((N,len(free)),dtype=np.int64);K[free]=np.eye(len(free),dtype=np.int64)
K[piv]=np.array([[-int(rr[i,j])%p for j in free] for i in range(rank)])
print('baseline kernel',K.shape,flush=True);del rr,O,rows
# Representatives of all exact inner-product levels relative to vertex zero.
levels={}
for v,c in enumerate(src['vertices']):
 if v:levels.setdefault(tuple(-int(a) for a in c[0]),v)
print('second-vertex levels',levels,flush=True)
# shell(v) list comprehension contains duplicates? each simplex has unique coface adjoining v.
cases=[]
for ip,v in sorted(levels.items(),key=lambda a:a[1]):
 sh=shell(v);assert len(sh)==62 and len(set(sh))==62
 cases.append({'v':v,'twice_inner_product_phi_coeffs':ip,'shell':sh,'union':sorted(set(obs)|set(sh))})
# One specified tetrahedral coordinate incident to the first centre.
tet=next(i for i,t in enumerate(S[3]) if 0 in t);port=2040+tet
cur=K;blocks=[[] for c in cases]
for k in range(105):
 for j,c in enumerate(cases):blocks[j].append(cur[c['shell']+[port]].astype(np.uint16))
 cur=(A@cur)%p
 if k%20==0:print('kernel powers',k,flush=True)
for c,bl in zip(cases,blocks):
 M=np.concatenate(bl).astype(np.int64);rows_noport=[i for i in range(M.shape[0]) if i%63!=62]
 gain=nmod_mat(M[rows_noport].tolist(),p).rank();gainport=nmod_mat(M.tolist(),p).rank()
 c.update({'two_shell_rank_mod':1893+gain,'augmented_rank_mod':1893+gainport,'augmented_kernel_mod':747-gainport,'sensor_count':len(c['union'])+1,'tetrahedron_index':tet,'tetrahedron':S[3][tet],'port_index':port});print('case',c['v'],c['twice_inner_product_phi_coeffs'],c['two_shell_rank_mod'],c['augmented_rank_mod'],c['sensor_count'],flush=True)
best=max(cases,key=lambda c:(c['augmented_rank_mod'],-c['sensor_count'],-c['v']))
(D/'SELECTION.json').write_text(json.dumps({'status':'MODULAR_SCREEN_ONLY','prime':p,'first_vertex':0,'fixed_tetrahedral_port':port,'cases':cases,'selected':best,'selection_rule':'max augmented modular rank, then fewer distinct sensors, then lowest vertex index; one representative per exact dot-product level, not all pairs or tetrahedral ports'},indent=2,default=int)+'\n')
np.savez_compressed(D/'selected_operators.npz',A_data=A.data,A_indices=A.indices,A_indptr=A.indptr,obs=np.array(best['union']+[port]),two_shell_obs=np.array(best['union']))
print('selected',best['v'],flush=True)

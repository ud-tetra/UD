from pathlib import Path
import shutil,tempfile,subprocess,sys,json,os
D=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as td:
 t=Path(td);shutil.copytree(D/'sources',t/'sources')
 for n in ['moments.json.gz','EXACT_RANKS.json','SELECTION.json','selected_operators.npz','frequency_certificate.py','spatial_certificate.py','summarize.py','validate.py']:shutil.copy2(D/n,t/n)
 env=dict(os.environ);env['OPENBLAS_NUM_THREADS']='2'
 for n in ['frequency_certificate.py','spatial_certificate.py','summarize.py','validate.py']:subprocess.run([sys.executable,str(t/n)],check=True,env=env)
 for n in ['FREQUENCY_CERTIFICATE.json','RESULTS.json','VALIDATION.json','SURVIVING_DARK_WITNESSES.json']:assert (t/n).read_bytes()==(D/n).read_bytes(),n
 a=json.loads((t/'CONDITIONING_CERTIFICATE.json').read_text());b=json.loads((D/'CONDITIONING_CERTIFICATE.json').read_text())
 for k in ['spatial_alpha_squared_rational_lower','normalized_sampling_sigma_min_squared_lower','normalized_sampling_sigma_max_squared_upper','condition_number_upper_integer','inverse_noise_amplification_upper_integer','sampled_observation_rank','sampled_kernel_dimension']:assert a[k]==b[k],k
(D/'CLEAN_REPLAY.json').write_text(json.dumps({'status':'PASS','scope':'clean replay of temporal/spatial certification, summary and validation using preserved exact moments/ranks; full placement screen and exact integer-rank run not repeated','byte_identical_outputs':['FREQUENCY_CERTIFICATE.json','RESULTS.json','VALIDATION.json','SURVIVING_DARK_WITNESSES.json'],'rational_conditioning_bounds_identical':True},indent=2)+'\n');print('CLEAN CERTIFICATE REPLAY PASS')

import json,gzip,math
from pathlib import Path
import numpy as np,scipy.sparse as sp
from flint import fmpz_mat,arb,ctx
D=Path(__file__).resolve().parent;ctx.prec=256;checks={}
def ck(n,b):assert b,n;checks[n]=True
z=np.load(D/'selected_operators.npz');obs=z['obs'];A=sp.csr_matrix((z['A_data'],z['A_indices'],z['A_indptr']),shape=(2640,2640));L=(-A@A).tocsr();src=json.loads((D/'sources/COMPLEX_AND_ACTION.json').read_text());sel=json.loads((D/'SELECTION.json').read_text());r=json.loads((D/'EXACT_RANKS.json').read_text());cert=json.loads((D/'CONDITIONING_CERTIFICATE.json').read_text());fc=json.loads((D/'FREQUENCY_CERTIFICATE.json').read_text())
assert (A+A.T).nnz==0
ck('observer_unique_coordinates',len(obs)==125 and len(set(obs))==125);ck('selected_orthogonal_centres',sel['selected']['v']==45 and src['vertices'][45][0]==[0,0]);ck('selected_tetrahedral_port',int(obs[-1])==2040 and src['simplices'][3][0]==[0,33,34,41])
ck('exact_rank_totals',r['complete'] and r['two_shell_rank']==2493 and r['augmented_rank']==2498);ck('kernel_reduction',747-(2640-r['augmented_rank'])==605);ck('all_component_modular_checks',all(c['modular_augmented_ranks']==[c['augmented_rank']]*2 for c in r['components']))
ck('temporal_certificate',fc['samples']==8192 and arb(fc['temporal_epsilon_upper'])<arb(1)/4)
ck('observed_band_below_four',fc['mu_root_intervals'][-1]['b'][0] < 16*fc['mu_root_intervals'][-1]['b'][1])
ck('all_53_spatial_components',len(cert['components'])==53)
ck('all_spatial_bounds',all(arb(c['spatial_squared_singular_lower'])>arb(1)/1048576 for c in cert['components']))
ck('sampling_condition_bound',1183**2*3>=4194304 and cert['condition_number_upper_integer']==1183)
ck('modal_ranks_sum',sum(c['rank_per_signed_frequency']*(1 if i==0 else 2) for i,c in enumerate(cert['components']))==2498)
# A fully explicit surviving dark component, unaffected by the C3 port.
rv=obs[obs<120];rows=np.vstack([(L[:120,:120]-14*sp.eye(120,dtype=np.int64)).toarray(),np.eye(120,dtype=np.int64)[rv]])
K,null=fmpz_mat(rows.tolist()).nullspace();ck('graph_dark_dimension',null==12)
def mul(x):
 return np.array([sum(int(v)*x[j] for j,v in zip(A.indices[A.indptr[i]:A.indptr[i+1]],A.data[A.indptr[i]:A.indptr[i+1]])) for i in range(2640)],dtype=object)
def enc(x):return [[i,int(a)] for i,a in enumerate(x) if a]
pairs=[]
for col in range(null):
 v=[int(K[i,col]) for i in range(120)];g=math.gcd(*v);x=np.array([a//g for a in v]+[0]*2520,dtype=object);y=mul(x)
 assert not np.any(x[obs]) and not np.any(y[obs]) and np.array_equal(mul(y),-14*x)
 pairs.append({'x':enc(x),'Ax':enc(y)})
ck('all_24_dark_vectors',len(pairs)==12)
# Stationary C3 cycle is observed by the new port.
tets=src['simplices'][3];faces={}
for j,t in enumerate(tets):
 for k in range(4):faces.setdefault(tuple(t[:k]+t[k+1:]),[]).append((j,(-1)**k))
nb=[[] for t in tets]
for ((a,sa),(b,sb)) in faces.values():nb[a].append((b,-sa*sb));nb[b].append((a,-sa*sb))
cells=[0]*600;cells[0]=1;todo=[0]
while todo:
 a=todo.pop()
 for b,sign in nb[a]:
  if cells[b]:assert cells[b]==sign*cells[a]
  else:cells[b]=sign*cells[a];todo.append(b)
h=np.array([0]*2040+cells,dtype=object);ck('C3_cycle_stationary_but_now_seen',not np.any(mul(h)) and not np.any(h[obs[:-1]]) and h[obs[-1]]==1)
(D/'SURVIVING_DARK_WITNESSES.json').write_text(json.dumps({'frequency_squared':14,'basis_pairs':pairs,'dimension':24,'evolution':'exp(tA)x=cos(sqrt14 t)x+sin(sqrt14 t)Ax/sqrt14','stationary_cycle_now_observed':enc(h)},indent=2)+'\n')
(D/'VALIDATION.json').write_text(json.dumps({'status':'PASS','checks':checks,'check_count':len(checks)},indent=2)+'\n');print('VALIDATION PASS',len(checks))

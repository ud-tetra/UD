"""Reproduce conditional perturbation certificates; no fitted physical constants.

Run: python certify_robustness.py (working directory immaterial).
Reads frozen parent certificates; verifies exact sparse channel identities and
Arb interval inequalities. This is constructor verification, not peer review.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib
import json
import platform
import importlib.metadata
import numpy as np
from scipy.sparse import csr_matrix, bmat
from flint import arb, ctx

ROOT = Path(__file__).resolve().parent
ctx.prec = 256

def read(name):
    return json.loads((ROOT / 'sources' / name).read_text())

def a(q):
    q = Q(q)
    return arb(q.numerator) / q.denominator

def pair(q):
    q = Q(q)
    return [q.numerator, q.denominator]

def enclosed(x):
    return {'arb_enclosure': str(x), 'display_only': float(x.mid())}

def write(name, obj):
    (ROOT / name).write_text(json.dumps(obj, indent=2) + '\n')

f = read('FREQUENCY_CERTIFICATE.json')
assert len(f['mu_root_intervals']) == 53
for root in f['mu_root_intervals']:
    assert Q(*root['b']) < 16
z = np.load(ROOT / 'sources' / 'operators.npz')
A = csr_matrix((z['A_data'].astype(np.int64), z['A_indices'], z['A_indptr']), shape=(2640,2640))
assert (A+A.T).nnz == 0
obs = z['obs']
assert len(obs) == len(set(obs)) == 189
assert obs.tolist() == read('RESULTS.json')['observed_coordinates']
assert read('RESULTS.json')['history_rank'] == 2640
cuts = [0,120,840,2040,2640]
grades = [slice(cuts[i],cuts[i+1]) for i in range(4)]
channels = []
for k in range(3):
    blocks = [[None]*4 for _ in range(4)]
    # Explicit zero diagonal blocks fix all row/column dimensions.
    for i in range(4):
        n = cuts[i+1]-cuts[i]
        blocks[i][i] = csr_matrix((n,n), dtype=np.int64)
    blocks[k][k+1] = A[grades[k],grades[k+1]]
    blocks[k+1][k] = A[grades[k+1],grades[k]]
    channels.append(bmat(blocks, format='csr'))
assert (sum(channels)-A).nnz == 0
for i in range(3):
    for j in range(3):
        if i != j:
            product = channels[i] @ channels[j]
            product.eliminate_zeros()
            assert product.nnz == 0

# Exact identifiability witnesses at arbitrary nonzero scale c.
# The symbolic proof is recorded in the report; rational instance checks
# guard the declared transformations without numerical tolerances.
c = Q(1000001,1000000)
assert c * (1/c) == 1
assert c / c == 1

r = eta = Q(3,10**9)
rho = Q(1,100000)
tau = Q(3,10**6)
theta = Q(3,100)
eps = 4*(r+eta)/(1-eta)
g = (a((1+eta)/(1-eta))).sqrt()
offset = rho + (4+eps)*tau
rows = []
for p in read('SCHEDULE_CERTIFICATES.json')['protocols']:
    assert p['rank'] == 2640 and p['kernel'] == 0
    assert p['step'] == [1,2] and p['sigma_max_squared_upper'] == [1,1]
    M = p['samples']
    s2 = Q(*p['sigma_min_squared_lower'])
    s = a(s2).sqrt()
    mean_t = Q(M-1,4)
    rms_t2 = Q((M-1)*(2*M-1),24)
    rms_t = a(rms_t2).sqrt()
    beta = g * a(offset**2+2*offset*eps*mean_t+eps**2*rms_t2).sqrt()
    beta_simple = g*(a(offset)+a(eps)*rms_t)
    beta_unstructured = (a(eps*(Q(M-1,2)+tau))).exp() * (a(offset)+a(eps)*rms_t)
    assert beta <= beta_simple
    assert beta_simple < a(theta)*s
    assert beta_unstructured < a(theta)*s
    guaranteed_s2 = (1-theta)**2*s2
    k_upper = {2048:748,4096:375,8192:306}[M]
    assert (1+a(theta)*s)/((1-a(theta))*s) < k_upper
    # Joint theta enclosure leaves exact delta <= s X / 20 noise allocation.
    assert theta+Q(1,20) == Q(2,25)
    rows.append({
        'samples':M, 'step':[1,2], 'last_time':pair(Q(M-1,2)),
        'nominal_sigma_min_squared_lower':pair(s2),
        'mean_time':pair(mean_t), 'rms_time_squared':pair(rms_t2),
        'beta_H_skew':enclosed(beta),
        'beta_H_skew_simple':enclosed(beta_simple),
        'beta_over_nominal_sigma_min':enclosed(beta/s),
        'beta_unstructured_same_epsilon':enclosed(beta_unstructured),
        'joint_margin_ratio_upper':pair(theta),
        'actual_sigma_min_squared_lower':pair(guaranteed_s2),
        'actual_sigma_max_upper':'1 + (3/100) sqrt('+str(s2)+')',
        'actual_condition_number_upper_integer':k_upper,
        'actual_rank':2640, 'actual_kernel_dimension':0,
        'nominal_decoder_systematic_error_upper_per_state_norm':pair(theta),
        'noise_RMS_allowance_per_state_bound':enclosed(s/20),
        'nominal_total_error_per_state_bound':pair(Q(2,25)),
        'isolated_H_identity_5percent_budgets':{
            'generator_epsilon':enclosed(s/(20*rms_t)),
            'uniform_rate_r':enclosed(s/(80*rms_t)),
            'readout_rho':enclosed(s/20),
            'timing_tau_internal_units':enclosed(s/80)
        }
    })

source_hashes = [dict(path='sources/'+p.name, size_bytes=p.stat().st_size,
                      sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                 for p in sorted((ROOT/'sources').iterdir()) if p.is_file()]
write('ROBUSTNESS_CERTIFICATE.json', {
    'status':'DERIVED_CONDITIONAL_INTERVAL_CERTIFIED',
    'arithmetic_precision_bits':ctx.prec,
    'dimension':2640, 'channels':189,
    'joint_candidate_constitutive_envelope':{
        'rule':'K = H^(-1) A(a,b,c); H symmetric positive definite',
        'rate_relative_error_upper':pair(r), 'metric_operator_error_upper':pair(eta),
        'readout_operator_error_upper':pair(rho), 'timing_jitter_upper':pair(tau),
        'generator_operator_error_upper':pair(eps),
        'H_skew_propagator_norm_upper':enclosed(g),
        'physical_time_calibration':'not supplied; tau uses model time'
    },
    'protocols':rows,
    'assumptions':['Fixed common state coordinates and known nominal observer',
        'K is constant; H-skew branch uses one fixed SPD H',
        'Sample-dependent readout error norms <= rho; timing errors <= tau',
        'Model/rate/metric tolerances are sufficient candidate budgets, not measured facts',
        'Parent nominal spectral and conditioning certificates accepted as inputs'],
    'physical_promotion':0, 'independent_review':'pending', 'sources':source_hashes
})
write('VALIDATION.json', {
    'status':'PASS', 'exact_skew_symmetry':True,
    'exact_grade_channel_sum':True,
    'exact_distinct_grade_channel_products_zero':6,
    'distinct_readout_coordinates':189,
    'parent_squared_frequency_intervals_checked_below_16':53,
    'joint_H_skew_margin_certified_protocols':3,
    'unstructured_same_epsilon_margin_certified_protocols':3,
    'condition_number_integer_bounds_certified':[748,375,306],
    'runtime':{'python':platform.python_version(), **{
        name:importlib.metadata.version(name) for name in ['numpy','scipy','python-flint']}},
    'scope':'Exact sparse structure + 256-bit interval robustness inequalities; parent spectrum not rederived; proofs in report; not independent review'
})
print(json.dumps({'status':'PASS', 'joint_beta_over_s':[r['beta_over_nominal_sigma_min']['display_only'] for r in rows],
                  'condition_upper':[r['actual_condition_number_upper_integer'] for r in rows]},indent=2))

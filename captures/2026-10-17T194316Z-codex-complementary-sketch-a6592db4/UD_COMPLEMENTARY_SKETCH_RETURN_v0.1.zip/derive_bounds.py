"""Exact witness identities and inherited-baseline uniform perturbation bounds."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import numpy as np
from flint import ctx,arb,fmpq,fmpz_mat
from proof_math import up,down
ctx.prec=512
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rule=json.loads((P/'inputs/SKETCH_RULE.json').read_text())
short=json.loads((P/'inputs/NULL_VECTOR.json').read_text())['vector'];assert len(short)==320
v=np.pad(np.array(short,dtype=np.int64),(0,1974));W=np.random.default_rng(172026).choice([-1.,1.],size=(2294,160)).astype(np.int64)
products=v@W;assert np.all(products==0) and int(v@v)==16228
minor=int(fmpz_mat(W[:160].tolist()).det());assert minor and minor==rule['first160_W_minor_determinant']
assert sum(int(x)*int(x) for x in v)==16228
baseline=P/'results/sketch-clean-v1/SKETCH_CERTIFICATE.json';c=json.loads(baseline.read_text())
a=lambda pair:arb(fmpq(*pair))
N=a(rule['noise_squared_ceiling']).sqrt();L=a(c['retained_sigma_lower'])-N;U=a(c['largest_sigma_upper'])+N;tail=a(c['discarded_sigma_upper'])+N;cut=a(rule['cutoff'])
assert L>cut and tail<cut
result={'status':'EXACT_COMPLEMENT_AND_VALIDATED_UNIFORM_BOUNDS','physical_promotion':0,'independent_review':'pending','witness_sha256':sha(P/'inputs/NULL_VECTOR.json'),'baseline_sketch_certificate_sha256':sha(baseline),'witness_stores_prefix':320,'implicit_zero_suffix':1974,'exact_products_vT_W':[int(x) for x in products],'exact_last_coordinate_vT_Splus':[4057,32],'old_rank':160,'new_rank':161,'old_kernel_dimension':2134,'new_kernel_dimension':2133,'old_kernel_intersection_new_kernel':'ker(W^T) intersect v-perp','repair_is_targeted_not_universal':True,'additional_physical_readings':0,'additive_gate_vector_squared':[1,2**40],'uniform_retained_count':105,'uniform_sigma105_lower':down(L),'uniform_sigma1_upper':up(U),'uniform_sigma106_upper':up(tail),'uniform_retained_condition_upper':up(U/L),'cutoff':rule['cutoff'],'sketch_frobenius_squared':rule['frobenius_squared'],'additional_float64_trajectory_bytes':8191*8,'additional_float64_Gram_bytes':(161**2-160**2)*8,'additional_sketch_columns_fraction':[1,160],'noise_envelope_increase_fraction_upper':up((a(rule['frobenius_squared'])/(arb(2294*160)/4096)).sqrt()-1),'full_Hankel_condition_not_certified_by_this_bound':True,'nominal_observer_kernel_747_not_modified':True,'readable':{'uniform_sigma105_lower':float(L.lower()),'uniform_sigma1_upper':float(U.upper()),'uniform_sigma106_upper':float(tail.upper()),'uniform_retained_condition_upper':float((U/L).upper()),'cutoff':float(F(*rule['cutoff']))}}
(P/'EXACT_COMPLEMENT_CERTIFICATE.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['readable'],indent=2))

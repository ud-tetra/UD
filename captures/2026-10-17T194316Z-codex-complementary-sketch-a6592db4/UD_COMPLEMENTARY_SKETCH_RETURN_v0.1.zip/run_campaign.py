"""Sequential frozen controls; retain failures and never retry fitting."""
import subprocess,sys,json,time
from pathlib import Path
P=Path(__file__).resolve().parent;freeze=json.loads((P/'CAMPAIGN_FREEZE.json').read_text());runs=[]
for case in freeze['cases']:
 n=case['case'];record=str((P/case['record_path']).resolve())
 if n!='clean':
  t=time.monotonic()
  with (P/f'sketch-{n}.log').open('x') as log:
   r=subprocess.run([sys.executable,str(P/'certify_sketch.py'),record,str(P/f'results/sketch-{n}')],stdout=log,stderr=subprocess.STDOUT,cwd=P)
  runs.append({'case':n,'stage':'exact_sketch_certificate','returncode':r.returncode,'wall_seconds':time.monotonic()-t})
  assert r.returncode==0
 t=time.monotonic()
 with (P/f'proposal-{n}.log').open('x') as log:
  r=subprocess.run([sys.executable,str(P/'propose_complementary.py'),record,str(P/'inputs/FROZEN_CONTRACT.json'),str(P/f'results/proposal-{n}')],stdout=log,stderr=subprocess.STDOUT,cwd=P)
 runs.append({'case':n,'stage':'untrusted_proposal','returncode':r.returncode,'wall_seconds':time.monotonic()-t})
 (P/'RUN_EXECUTIONS.json').write_text(json.dumps(runs,indent=2))
 assert r.returncode==0
n='bounded_null_impulse';case=next(c for c in freeze['cases'] if c['case']==n);t=time.monotonic()
with (P/'full-certificate-bounded_null_impulse.log').open('x') as log:
 r=subprocess.run([sys.executable,str(P/'certify_record.py'),str((P/case['record_path']).resolve()),str(P/'inputs/FROZEN_CONTRACT.json'),str(P/f'results/proposal-{n}/PROPOSAL.npz'),str(P/f'results/full-certificate-{n}')],stdout=log,stderr=subprocess.STDOUT,cwd=P)
runs.append({'case':n,'stage':'full_Hankel_certificate','returncode':r.returncode,'wall_seconds':time.monotonic()-t})
(P/'RUN_EXECUTIONS.json').write_text(json.dumps(runs,indent=2));assert r.returncode==0
print(json.dumps(runs,indent=2))

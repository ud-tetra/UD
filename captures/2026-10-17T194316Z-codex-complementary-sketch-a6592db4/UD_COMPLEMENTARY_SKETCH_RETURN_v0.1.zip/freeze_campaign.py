from pathlib import Path
import json,datetime,hashlib
from fractions import Fraction as F
import numpy as np
from flint import ctx,arb,fmpq,fmpz_mat
from proof_math import up
ctx.prec=512
P=Path(__file__).resolve().parent
v=np.pad(np.array(json.loads((P/'inputs/NULL_VECTOR.json').read_text())['vector'],dtype=np.int64),(0,1974))
assert v.shape==(2294,) and int(v@v)==16228
W=np.random.default_rng(172026).choice([-1.,1.],size=(2294,160)).astype(np.int64)
assert np.all(v@W==0)
det=int(fmpz_mat(W[:160].tolist()).det());assert det
n2=F(37*8191*371097,4096*2**40);cut=up(2*arb(fmpq(n2.numerator,n2.denominator)).sqrt())
rule={'version':'COMPLEMENTARY_SKETCH_v0.1','columns':161,'integer_matrix':'[2W | v]','denominator':128,'original_rank':160,'augmented_rank':161,'original_kernel_dimension':2134,'augmented_kernel_dimension':2133,'witness_squared_norm':16228,'complement_squared_norm':[4057,4096],'frobenius_squared':[371097,4096],'noise_squared_ceiling':[n2.numerator,n2.denominator],'cutoff':cut,'first160_W_minor_determinant':det,'provenance':'Targeted known-witness engineering control; not a UD theory constant; not independent preregistration','physical_promotion':0}
assert not (P/'CAMPAIGN_FREEZE.json').exists()
(P/'inputs/SKETCH_RULE.json').write_text(json.dumps(rule,indent=2))
cases={
 'clean':('../observer-work/inputs/normalized_history.i64le','full positive sketch check; proposal; no new full Hankel proof needed'),
 'bounded_null_impulse':('../sketch-blind-work/records/bounded_null_impulse.i64le','sketch check; new proposal; full Hankel certificate'),
 'bounded_null_alternating':('../sketch-blind-work/records/bounded_null_alternating.i64le','sketch check and proposal'),
 'strong_null_alternating':('../sketch-blind-work/records/strong_null_alternating.i64le','sketch check and preserved proposer outcome including HOLD'),
 'dense_sign':('../noise-campaign/records/dense_sign.i64le','sketch check and proposal'),
}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze={'status':'CONSTRUCTOR_TARGETED_IMPLEMENTATION_FROZEN_BEFORE_NEW_EXECUTION','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'known_prior_controls':True,'independent_preregistration':False,'physical_promotion':0,'code_sha256':{n:sha(P/n) for n in ['propose_complementary.py','certify_sketch.py','certify_record.py','proof_math.py','residual_preflight.py']},'contract_sha256':sha(P/'inputs/FROZEN_CONTRACT.json'),'rule_sha256':sha(P/'inputs/SKETCH_RULE.json'),'witness_sha256':sha(P/'inputs/NULL_VECTOR.json'),'cases':[{'case':n,'record_path':p,'record_sha256':sha(P/p),'planned_scope':scope} for n,(p,scope) in cases.items()],'acceptance':'Frozen full Hankel threshold, count1893, cap2029 unchanged; discovery sketch is new development version, no retroactive admission','failures':'Retain every run and HOLD; no optimizer retry or model/order extension in this campaign','setup_note':'Before freeze, validation rejected a mistaken 2294-entry assumption: pinned witness stores its first320 entries, followed implicitly by1974 zeros. A setup invocation without a freeze failed before reading any record. Logs retained; code corrected before actual campaign.'}
(P/'CAMPAIGN_FREEZE.json').write_text(json.dumps(freeze,indent=2));print(json.dumps(rule,indent=2))

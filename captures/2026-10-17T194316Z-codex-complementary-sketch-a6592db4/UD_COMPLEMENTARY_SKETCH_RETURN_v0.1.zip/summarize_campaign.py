from pathlib import Path
from fractions import Fraction as F
import json,hashlib,datetime
P=Path(__file__).resolve().parent
freeze=json.loads((P/'CAMPAIGN_FREEZE.json').read_text());rows=[]
for case in freeze['cases']:
 n=case['case'];d=P/('results/sketch-clean-v1' if n=='clean' else f'results/sketch-{n}')
 c=json.loads((d/'SKETCH_CERTIFICATE.json').read_text());audit=json.loads((P/f'results/proposal-{n}/DISCOVERY_AUDIT.json').read_text())
 rows.append({'case':n,'record_sha256':case['record_sha256'],'exact_sketch_order':c['above_cutoff_count'],'retained_condition_upper':c['retained_condition_upper'],'readable_bounds':c['readable'],'proposer_status':'HOLD' if (P/f'results/proposal-{n}/HOLD.json').exists() else 'UNTRUSTED_PROPOSAL_ONLY','prior_original_sketch_order':105,'full_Hankel_replay_in_this_campaign':n=='bounded_null_impulse'})
runs=json.loads((P/'RUN_EXECUTIONS.json').read_text());strongtimes=[r['wall_seconds'] for r in runs if r['case']=='strong_null_alternating'];assert len(strongtimes)==2
full=P/'results/full-certificate-bounded_null_impulse';cert=json.loads((full/'CERTIFICATE.json').read_text());b=json.loads((full/'BENCHMARK.json').read_text())
summary={'status':'TARGETED_COMPLEMENT_CAMPAIGN_EXECUTED','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'physical_promotion':0,'independent_review':'pending','known_constructed_records':True,'new_independent_data':False,'cases':rows,'strong_certified_discovery_and_proposal_wall_seconds':sum(strongtimes),'strong_HOLD_reason':'Current proposer only models one stationary mode plus non-Nyquist conjugate pairs; the detected106-component order is unsupported. No true full-record spectral failure conclusion.','full_positive_status':cert['status'],'full_positive_bounds':cert['readable'],'full_positive_benchmark':b,'new_version_not_retroactive_acquisition_admission':True,'no_universal_fitting_convergence_claim':True,'reduced_sketch_kernel_dimensions':[2134,2133],'nominal_dynamical_observer_kernel_747_unchanged':True}
(P/'CAMPAIGN_RESULTS.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'strong_seconds':sum(strongtimes),'full':cert['readable'],'status':cert['status']},indent=2))

from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
P=Path(__file__).resolve().parent;repo=P.parent/'ud-repo';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ID=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H%M%SZ')+'-codex-complementary-sketch-a6592db4'
omitted=[];freeze=json.loads((P/'CAMPAIGN_FREEZE.json').read_text())
for c in freeze['cases']:
 p=P/c['record_path'];assert sha(p)==c['record_sha256']
 omitted.append({'case':c['case'],'filename':p.name,'size_bytes':p.stat().st_size,'sha256':sha(p),'regeneration':'Pinned inherited noisy/sketch-blind recipes and original baseline; source hashes in CAMPAIGN_FREEZE.json','reason':'150-MB raw record; not replaced with a synthetic placeholder'})
for p in P.glob('results/*/FACTOR_GRAMS.npz'):
 omitted.append({'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'regeneration':'Unchanged full verifier plus included new proposal and pinned raw record','reason':'Large full-Hankel factor Grams; five small exact sketch Grams are included'})
(P/'OMITTED_DATA.json').write_text(json.dumps({'files':omitted,'physical_promotion':0,'no_data_substitution':True},indent=2))
files=[p for p in P.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ['FACTOR_GRAMS.npz','PACKAGE_MANIFEST.json']]
(P/'PACKAGE_MANIFEST.json').write_text(json.dumps({'artifact':'UD_COMPLEMENTARY_SKETCH_RETURN_v0.1','physical_promotion':0,'independent_review':'pending','files':[{'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]},indent=2));files.append(P/'PACKAGE_MANIFEST.json')
out=repo/'captures'/ID;out.mkdir(parents=True,exist_ok=False)
z=out/'UD_COMPLEMENTARY_SKETCH_RETURN_v0.1.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(files):archive.write(p,p.relative_to(P).as_posix())
for n in ['README.md','THEOREMS.md','CLAIM_LEDGER.json','PROVENANCE.json','CAMPAIGN_FREEZE.json','CAMPAIGN_RESULTS.json','EXACT_COMPLEMENT_CERTIFICATE.json','SKETCH_REPLAY_RESULTS.json','VALIDATION.json','HOSTILE_TEST_RESULTS.txt','OMITTED_DATA.json','PACKAGE_MANIFEST.json','propose_complementary.py','certify_sketch.py','replay_sketch.py','test_complement.py','validate_campaign.py']:
 shutil.copyfile(P/n,out/n)
entries=[{'path':p.relative_to(repo).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'status':'EXACT / VALIDATED_FINITE_MATRIX_DERIVATION / CONSTRUCTOR_EXECUTED as typed in CLAIM_LEDGER.json','provenance':'Source-frozen targeted constructor controls and exact residual proof replays; independent review pending'} for p in sorted(out.iterdir())]
(out/'MANIFEST.json').write_text(json.dumps({'capture_id':ID,'physical_promotion':0,'status':'CONSTRUCTOR_TARGETED_COMPLEMENT_RETURN','supersedes':[],'extends':['2026-10-17T192300Z-codex-sketch-blind-audit-84e2c6d1','2026-10-17T193338Z-codex-residual-preflight-7c3d916a'],'verification_scope':'Exact sketch kernel reduction, uniform finite conditioning, five exact small-Gram replays, four hostile tests and one fresh full-record signature certificate; no independent/physical promotion','files':entries},indent=2))
(repo/'events'/f'{ID}.json').write_text(json.dumps({'capture_id':ID,'event':'targeted_complementary_sketch_with_uniform_conditioning','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'physical_promotion':0,'summary':'Append known-witness complement: sketch kernel2134→2133; uniform105-component separation and condition<29.246; known oversized control yields106 and model/order HOLD; new bounded positive proposal still meets full1893 signature. Other blind families, independent review and full acquisition remain open.'},indent=2))
print(json.dumps({'capture':str(out),'zip_bytes':z.stat().st_size,'zip_sha256':sha(z),'files':len(files)}))

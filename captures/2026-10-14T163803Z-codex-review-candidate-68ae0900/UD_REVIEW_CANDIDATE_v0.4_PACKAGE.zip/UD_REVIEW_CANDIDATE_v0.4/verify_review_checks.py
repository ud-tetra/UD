"""Additional exact assertions for the review candidate; run after finite replay."""
from pathlib import Path
import json
import sympy as s
root=Path(__file__).resolve().parent
results=json.loads((root/'replay/results.json').read_text())
x=s.symbols('x')
expected={
 'core_star':x*(x*x+2)*(x*x+3)**2*(x*x+4)**3*(x*x+5)**3*(x*x+6)**2*(x**4+9*x*x+16)**3*(x**4+10*x*x+20)**3,
 'chain':x*(x*x+2)*(x*x+3)*(x*x+4)**3*(x*x+5)**4*(x*x+6)*(x*x+7)*(x**4+8*x*x+13)*(x**6+12*x**4+43*x*x+47)*(x**6+14*x**4+63*x*x+91)*(x**8+20*x**6+141*x**4+404*x*x+376)}
for name,p in expected.items():
    assert s.expand(s.sympify(results[name]['characteristic_polynomial'])-p)==0
    assert s.degree(p,x)==47
# Independently test the stated collective top-cell decomposition.
H=s.Matrix(results['core_star']['top_gram'])
b=s.Matrix([1,-1,1,-1])
v0=s.Matrix([1,0,0,0,0]);v1=s.Matrix([0,*list(b/2)])
V=v0.row_join(v1)
assert V.T*V==s.eye(2)
assert H*V==V*s.Matrix([[4,2],[2,4]])
assert (H-4*s.eye(5)).nullspace().__len__()==3
# Representation invariance of a correlation-aware discrimination score.
Sigma=s.Matrix([[1,s.Rational(1,2)],[s.Rational(1,2),1]])
delta=s.Matrix([1,1]);T=s.Matrix([[2,1],[0,3]])
assert (delta.T*Sigma.inv()*delta)[0]==s.Rational(4,3)
assert ((T*delta).T*(T*Sigma*T.T).inv()*(T*delta))[0]==s.Rational(4,3)
report={'status':'PASS','exact_expected_full_polynomials':2,'polynomial_degree':47,
 'core_star_collective_block':'PASS','three_dimensional_frequency_two_sector':'PASS',
 'transported_covariance_mahalanobis_invariance':'PASS',
 'limits':'finite symbolic assertions; no independent review or floating interval certification'}
(root/'REVIEW_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))

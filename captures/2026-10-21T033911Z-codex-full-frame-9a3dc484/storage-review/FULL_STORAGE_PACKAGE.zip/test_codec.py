"""Synthetic-source-excluded actual CLI codec tests, independent byte oracle."""
from pathlib import Path
import copy,gzip,hashlib,json,os,subprocess,sys,time
BASE=Path(__file__).absolute().parent
ROOT=BASE.parent
FRAME=ROOT/'c33_estimator_review'/'synthetic_frame'
H=lambda b:hashlib.sha256(b).hexdigest()
J=lambda x:(json.dumps(x,indent=2,sort_keys=True)+'\n').encode()

def guard(p):
 p=Path(p).absolute();assert p!=BASE and p.is_relative_to(BASE)
 for a in [p,*p.parents]:
  assert not a.is_symlink()
  if a==BASE:break
 assert p.resolve().is_relative_to(BASE.resolve());return p

def write(p,b):
 p=guard(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb')as f:f.write(b)

def run(name,tool,args):
 cmd=[sys.executable,str(ROOT/tool),*map(str,args)]
 t=time.monotonic();r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
 d={'command':cmd,'returncode':r.returncode,'elapsed_seconds':time.monotonic()-t}
 write(BASE/'logs'/(name+'.stdout'),r.stdout);write(BASE/'logs'/(name+'.stderr'),r.stderr)
 write(BASE/'logs'/(name+'.json'),J(d));return d

def summarize_and_remove_rows(out):
 # Only test-created literal row files are removed, after byte hashing. Original fixture untouched.
 rows={p.name:H(p.read_bytes())for p in sorted(out.glob('row_*.i128.gz'))}if out.exists()else{}
 for n in rows:
  assert len(n)==16 and n.startswith('row_') and n.endswith('.i128.gz')
  guard(out/n).unlink()
 return rows

def main():
 f=json.loads((BASE/'FREEZE.json').read_bytes());sources=f['source_hashes']
 assert H(Path(__file__).read_bytes())==f['test_source_sha256']
 assert H((BASE/'PLAN.json').read_bytes())==f['plan_sha256']
 for n,h in sources.items():assert H((ROOT/n).read_bytes())==h
 fb=(FRAME/'FULL_FRAME.json').read_bytes();fh=H(fb);assert fh==f['synthetic_frame_sha256']
 meta=json.loads(fb)
 for row in meta['rows']:assert H((FRAME/row['output_row_file']).read_bytes())==row['output_row_sha256']
 inv=[];checks={};cleanup={}
 out=BASE/'wrong_pack_hash'
 r=run('wrong_pack_hash','c33_pack.py',['--frame',FRAME,'--frame-sha256','0'*64,'--out',out]);inv.append(r)
 assert r['returncode']!=0 and not(out/'FRAME_INDEX.json').exists();checks['wrong_pack_hash']=True
 parts=BASE/'parts'
 r=run('positive_pack','c33_pack.py',['--frame',FRAME,'--frame-sha256',fh,'--out',parts]);inv.append(r);assert r['returncode']==0
 ib=(parts/'FRAME_INDEX.json').read_bytes();idx=json.loads(ib);assert len(idx['parts'])==32
 assert [x['row_count']for x in idx['parts']]==[64]*31+[15]
 # Independent byte parser checks all part headers, lengths, order and original gzip bytes.
 observed=[]
 for k,part in enumerate(idx['parts']):
  b=(parts/part['file']).read_bytes();assert b[:8]==b'UD33FRM1' and H(b)==part['sha256'] and len(b)==part['size_bytes']
  at=8
  for row in meta['rows'][k*64:k*64+64]:
   col=int.from_bytes(b[at:at+4],'little');n=int.from_bytes(b[at+4:at+8],'little');at+=8
   assert col==row['column'] and b[at:at+n]==(FRAME/row['output_row_file']).read_bytes();at+=n;observed.append(col)
  assert at==len(b)
 assert observed==list(range(1999));checks['independent_verbatim_part_parse']=True
 def unpack(name,p,ih=H(ib),metadata=FRAME/'FULL_FRAME.json',mh=fh):
  out=BASE/'outputs'/name
  r=run(name,'c33_unpack.py',['--parts',p,'--index-sha256',ih,'--metadata',metadata,'--metadata-sha256',mh,'--out',out]);inv.append(r)
  return r,out
 r,out=unpack('positive_unpack',parts);assert r['returncode']==0 and (out/'FULL_FRAME.json').read_bytes()==fb
 restored=summarize_and_remove_rows(out)
 assert restored=={row['output_row_file']:row['output_row_sha256']for row in meta['rows']}
 write(BASE/'RESTORED_ROW_HASHES.json',J(restored));cleanup['positive_unpack']=len(restored);checks['all_1999_rows_and_metadata_byte_identical']=True
 for name,ih,mh in [('wrong_index_hash','0'*64,fh),('wrong_metadata_hash',H(ib),'0'*64)]:
  r,out=unpack(name,parts,ih=ih,mh=mh);assert r['returncode']!=0 and not(out/'FULL_FRAME.json').exists();checks[name]=True
 # Variant directories contain only their changed index and part0, except full coverage probe.
 for name in ['corrupt_part','authenticated_wrong_magic','authenticated_trailing_bytes','forged_part_path','forged_start_row','missing_last_part','forged_output_path']:
  p=BASE/'variants'/name;p.mkdir(parents=True);ii=copy.deepcopy(idx);b=(parts/'FRAME_00.bin').read_bytes();md=FRAME/'FULL_FRAME.json';mh=fh
  if name=='corrupt_part':b=b[:-1]+bytes([b[-1]^1])
  if name=='authenticated_wrong_magic':b=b'BADMAGIC'+b[8:]
  if name=='authenticated_trailing_bytes':b+=b'X'
  if name in ['authenticated_wrong_magic','authenticated_trailing_bytes']:
   ii['parts'][0]['sha256']=H(b);ii['parts'][0]['size_bytes']=len(b)
  if name=='forged_part_path':ii['parts'][0]['file']='../FRAME_00.bin'
  if name=='forged_start_row':ii['parts'][0]['start_row']=1
  if name=='missing_last_part':ii['parts']=ii['parts'][:-1]
  if name=='forged_output_path':
   mm=copy.deepcopy(meta);mm['rows'][0]['output_row_file']='../escape.i128.gz';mb=J(mm);md=p/'metadata.json';write(md,mb);mh=H(mb);ii['frame_receipt_sha256']=mh
  if name=='missing_last_part':
   # Hard links share immutable existing bytes, avoiding a duplicate archive payload.
   for part in ii['parts']:os.link(parts/part['file'],p/part['file'])
  else:write(p/'FRAME_00.bin',b)
  iib=J(ii);write(p/'FRAME_INDEX.json',iib)
  r,out=unpack(name,p,ih=H(iib),metadata=md,mh=mh)
  assert r['returncode']!=0 and not(out/'FULL_FRAME.json').exists();checks[name]=True
  restored=summarize_and_remove_rows(out);cleanup[name]=len(restored)
  if restored:write(BASE/'partial_output_hashes'/(name+'.json'),J(restored))
 assert not(BASE/'outputs'/'escape.i128.gz').exists()
 for n,h in sources.items():assert H((ROOT/n).read_bytes())==h
 assert H((FRAME/'FULL_FRAME.json').read_bytes())==fh
 for row in meta['rows']:assert H((FRAME/row['output_row_file']).read_bytes())==row['output_row_sha256']
 rec={'status':'PASS_SYNTHETIC_ACTUAL_STORAGE_CLI_BYTE_AND_REJECTION_TESTS',
  'scope':'Integrity codec testing only; trusted index, metadata, source commit/root remain external premises; no actual UD or physical source admission',
  'checks':checks,'invocations':inv,'source_hashes':sources,'synthetic_frame_sha256':fh,
  'packed_index_sha256':H(ib),'parts':32,'rows':1999,
  'cleanup_verified_test_only_row_counts':cleanup,
  'retention':'All restored row bytes independently hashed then test-created duplicates removed; originals and verbatim packed32parts retained; partial hashes and all CLI logs retained',
  'application_data_allowlist':[str(FRAME),str(BASE)],'actual_UD_inputs_read':False,
  'physical_promotion':0,'external_promotion_review':'PENDING'}
 write(BASE/'REVIEW_RECEIPT.json',J(rec))
 manifest={str(p.relative_to(BASE)):H(p.read_bytes())for p in sorted(BASE.rglob('*'))if p.is_file()}
 write(BASE/'REVIEW_MANIFEST.json',J(manifest));print(json.dumps({'status':rec['status'],'checks':len(checks),'parts':32,'rows':1999}))

if __name__=='__main__':main()

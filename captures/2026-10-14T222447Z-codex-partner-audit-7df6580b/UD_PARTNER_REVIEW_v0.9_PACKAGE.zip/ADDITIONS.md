## D.10 Recurrence and transfer under explicit metric contracts

### D.10.1 Incommensurability permits uniformly close returns

Let $A$ be a finite real skew matrix with $r\ge1$ distinct positive frequencies $\omega_1,\ldots,\omega_r$. For every integer $N\ge1$ there is $1\le q\le N^{r-1}$ such that, at $s=2\pi q/\omega_1$,

\[
\|e^{sA}-I\|_2\le\frac{2\pi}{N}.
\]

For $r>1$, partition the $(r-1)$-torus into $N^{r-1}$ cubes of side $1/N$. Among the $N^{r-1}+1$ points with coordinates $\{j\omega_k/\omega_1\}$, $j=0,\ldots,N^{r-1}$ and $k=2,\ldots,r$, two share a cube. Their index difference is the required $q$, with each phase within $2\pi/N$ of an integer multiple of $2\pi$. Orthogonal block diagonalization of $A$ reduces the operator error to the largest rotation-block error, bounded by the phase error. Zero modes contribute zero error. For $r=1$, choose $q=1$ and the return is exact. If $r=0$, the flow is the identity.

Consequently, irrational frequency ratios exclude an exact common period but do not exclude approximate recurrence. If there is no exact period, the approximating times have an unbounded subsequence; otherwise a bounded subsequence would yield an exact return as $N\to\infty$. In the periodic case, arbitrarily late exact returns exist. This is a finite-flow statement; no thermodynamic limit, mixing, dissipation or record formation follows from it.

### D.10.2 A protected sector for a specified inclusion

Use the complexes $K_A,K_B$ of §6.1 and the coordinate inclusion $T:\mathbb R^{23}\to\mathbb R^{27}$ that fixes every simplex of $K_A$. This is an inclusion of subcomplexes, not a boundary-fixing 2-to-3 replacement. Write $A=\mathcal A_{K_A}$, $B=\mathcal A_{K_B}$ and $L=-A^2$. With unit metrics,

\[
T^TT=I,\quad d_BT=Td_A,\quad R=BT-TA,
\]

where $d$ is the total boundary. Exact signed incidence gives

\[
\operatorname{rank}R=4,\quad RR^TR=2R,\quad
\operatorname{rank}\begin{pmatrix}R\\RA\end{pmatrix}=8.
\]

Thus the four nonzero singular values of $R$ are $\sqrt2$. The polynomial projectors are

\[
P_0=\frac{(L-3I)(L-5I)}{15},\quad
P_3=\frac{L(5I-L)}6,\quad P_5=\frac{L(L-3I)}{10}.
\]

They are mutually orthogonal and sum to $I$. Direct incidence identities give $R(P_0+P_5)=0$ and $\operatorname{rank}(P_0+P_5)=15$. Since this projector commutes with $A$, its image lies in the kernel of every $RA^j$. The displayed rank-eight two-block matrix shows that no larger protected space exists. Therefore

\[
\bigcap_{j\ge0}\ker(RA^j)=\operatorname{im}(P_0+P_5),\qquad
e^{sB}Tx=Te^{sA}x
\]

for precisely these initial states. A zero instantaneous residual alone would give a larger, insufficient kernel.

The remaining eight-dimensional sector admits a more detailed description. Put $L_B=-B^2$ and $P^B_2=L_B(5I-L_B)/6$. The positive compression

\[
W=P_3T^TP^B_2TP_3
\]

has rank four and satisfies $W^2=(2/3)W$. On $\operatorname{im}P_3$ its eigenvalues are $2/3$ and $0$, each fourfold. Corresponding normalized states have squared spectral-projection weights $(2/3,1/3)$ or $(0,1)$ in the $L_B=2,5$ sectors. These are instantaneous spectral weights after a stipulated inclusion, not transmission probabilities of a derived scattering experiment. Their exact matrices and ranks are replayed in [23].

### D.10.3 Stellar subdivision: diagonal obstruction and a general-metric counterexample

Subdivide $[0123]$ using interior vertex 4 into $0124,0134,0234,1234$. Let $d_c,d_f$ be the coarse and fine total boundaries. The map $S$ fixes the old boundary and sends the oriented top cell to

\[
S[0123]=[0124]-[0134]+[0234]-[1234].
\]

Then $d_fS=Sd_c$ and $S^TS=I_{14}\oplus[4]$. Boundary fixation and the unique filling force this image: the fine $d_3$ is injective. Hence this map cannot be an isometry for unit simplex metrics.

For a positive *diagonal* fine metric $H$, the adjoint is $d_f^{\dagger_H}=H^{-1}d_f^TH$. Adjoint intertwining on the old four boundary faces would require a matrix with four separate nonzero face-to-cell entries to equal the rank-one matrix $S_3d_{c,3}^T$. Positive diagonal weights cannot change these ranks. Thus diagonal weighting alone cannot provide this stronger intertwining contract.

That argument does not exclude all positive metrics. Define the simplicial chain retraction $\Pi$ by sending vertex 4 to 0 and fixing 0,1,2,3; a simplex with repeated image vertices maps to zero, and other images carry their permutation sign. It obeys

\[
\Pi S=I,\qquad \Pi d_f=d_c\Pi.
\]

Put $N=I-S\Pi$ and choose the degree-preserving, generally non-diagonal metric

\[
H=\Pi^T\Pi+N^TN.
\]

For any $v$, $v^THv=\|\Pi v\|^2+\|Nv\|^2>0$ unless $v=0$, since $v=S\Pi v+Nv$. Also $S^THS=I$. The decomposition $\operatorname{im}S\oplus\ker\Pi$ is $H$-orthogonal and each summand is $d_f$-invariant. Therefore the weighted adjoint preserves the same summands and restricts on $\operatorname{im}S$ to the coarse Euclidean adjoint. It follows that

\[
A_H=H^{-1}d_f^TH-d_f,\qquad
A_HS=S(d_c^T-d_c),\qquad A_H^TH+HA_H=0.
\]

This explicitly refutes an unrestricted positive-metric no-go. It does not supply unit-metric intertwining or a native choice of $H$. The weighted generator is an added model, with correlated simplex coordinates; its locality and physical admissibility require a separate contract. The supplied certificate verifies all identities exactly and gives positive rational LDL pivots [23].

## D.11 A prepared channel: retained coherence, fixed ratios and branching

The following operators are declared mathematical channels, motivated by the partner working notes [23]. They are not derived from a UD carrier-to-bath interaction. For a two-state Hilbert space, take

\[
K_0=\begin{pmatrix}1/\sqrt2&0\\0&1/\sqrt3\end{pmatrix},\qquad
K_1=\begin{pmatrix}0&\sqrt{2/3}\\1/\sqrt2&0\end{pmatrix},\qquad
\mathcal E(\rho)=\sum_{j=0}^1K_j\rho K_j^\dagger.
\]

Completeness is $\sum_jK_j^\dagger K_j=I$. In Bloch coordinates $\rho=(I+r_x\sigma_x+r_y\sigma_y+r_z\sigma_z)/2$, direct multiplication gives

\[
r_x'=a_xr_x,\quad r_y'=a_yr_y,\quad
r_z'=-r_z/6+1/6,
\qquad a_x=\frac{1+\sqrt2}{\sqrt6},\quad
a_y=\frac{1-\sqrt2}{\sqrt6}.
\]

All linear eigenvalues have modulus less than one, so the unique fixed point is $\rho_*=\operatorname{diag}(4/7,3/7)$. The repeated channel has $r_x(k)=a_x^kr_x(0)$, $r_y(k)=a_y^kr_y(0)$ and $r_z(k)-1/7=(-1/6)^k(r_z(0)-1/7)$. Coherences decay asymptotically; they are not erased in one step.

For qubit states, trace distance is half the Euclidean distance of their Bloch vectors. The sharp one-step contraction coefficient, and its $k$-step counterpart, are consequently

\[
\eta(\mathcal E)=a_x\simeq0.985599,\qquad
\eta(\mathcal E^k)=a_x^k.
\]

Opposite $\sigma_x$ eigenstates attain the bound. The same sharp factor applies to distance from $\rho_*$ by taking sufficiently small $x$-axis perturbations around that full-rank state. Thus $(5/7)^k$ is not a valid universal bound for this channel. An additional projection could change a contracted readout, but requires its own defined action and comparison domain.

The population transition rates are $u=1/2$ from state 1 to 2 and $v=2/3$ from 2 to 1. For arbitrary $0<u,v<1$, the same construction with $K_0=\operatorname{diag}(\sqrt{1-u},\sqrt{1-v})$ and off-diagonal $K_1$ yields stationary populations $(v,u)/(u+v)$. Therefore $p_1^*/p_2^*=v/u$. The value $4/3$ follows from the chosen rates; its numerical agreement with a separately stated geometric ratio does not derive those rates or identify the populations with that geometry. At some other rates the population fixed point need not be the unique full-state fixed point; uniqueness above was proved for the displayed channel.

A three-state extension makes the dependence explicit. For $0\le\alpha\le1$, let

\[
K_0=\operatorname{diag}(1/\sqrt2,1/\sqrt3,1/\sqrt7),
\]
\[
K_1=\begin{pmatrix}0&\sqrt{2\alpha/3}&0\\1/\sqrt2&0&0\\0&0&0\end{pmatrix},\qquad
K_2=\begin{pmatrix}0&0&0\\0&0&\sqrt{6/7}\\0&\sqrt{2(1-\alpha)/3}&0\end{pmatrix}.
\]

Their products sum to $I_3$ and diagonal states remain diagonal. Their stationary population vector is

\[
p_* =\frac{(12\alpha,9,7(1-\alpha))}{16+5\alpha},\qquad
\frac{p_1^*}{p_2^*}=\frac43\alpha.
\]

At $\alpha=7/9$, it is $(84,81,14)/179$, not $(28,27,6)/61$; the latter is not stationary for the declared channel. At $\alpha=1$, state 3 receives no input from state 2 but can still decay into it: this is absence of incoming branching, not full dynamical decoupling of state 3. No general full-state convergence theorem for this three-state family is asserted here.

Finally, a channel alone fixes no energy cost. An explicit Stinespring isometry $V|\psi\rangle=\sum_jK_j|\psi\rangle\otimes|j\rangle_E$ shows that its implementation requires a supplied environment input and that discarded correlations reside in the environment. It does not fix Hamiltonians, switching work, bath renewal, clock cost or temperature. Those are additional entries in §11's resource account; no entropy-area or gravitational normalization follows from these fixed populations.


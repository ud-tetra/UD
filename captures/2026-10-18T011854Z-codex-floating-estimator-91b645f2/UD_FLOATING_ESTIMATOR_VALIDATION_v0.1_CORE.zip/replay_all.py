from pathlib import Path
import json,subprocess,sys,time
P=Path(__file__).resolve().parent;f=json.loads((P/'CAMPAIGN_FREEZE.json').read_text());runs=[]
for c in f['cases']:
 n=c['case'];t=time.monotonic()
 with (P/f'replay-{n}.log').open('x') as log:r=subprocess.run([sys.executable,str(P/'certify_floating.py'),n,'--portable'],stdout=log,stderr=subprocess.STDOUT,cwd=P)
 runs.append({'case':n,'stage':'portable_saved_arrays','returncode':r.returncode,'seconds':time.monotonic()-t});(P/'REPLAY_EXECUTIONS.json').write_text(json.dumps(runs,indent=2));assert r.returncode==0
r=subprocess.run([sys.executable,str(P/'validate_campaign.py')],cwd=P);assert r.returncode==0

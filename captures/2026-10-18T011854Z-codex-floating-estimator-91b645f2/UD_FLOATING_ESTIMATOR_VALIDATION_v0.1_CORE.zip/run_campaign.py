from pathlib import Path
import subprocess,json,sys,time
P=Path(__file__).resolve().parent;freeze=json.loads((P/'CAMPAIGN_FREEZE.json').read_text());runs=[]
for c in freeze['cases']:
 n=c['case'];out=P/f'results/{n}';t=time.monotonic()
 with (P/f'proposer-{n}.log').open('x') as log:
  r=subprocess.run([sys.executable,str(P/'instrumented_proposer.py'),str(P/c['record_path']),str(P/'inputs/FROZEN_CONTRACT.json'),str(out)],stdout=log,stderr=subprocess.STDOUT,cwd=P)
 runs.append({'case':n,'stage':'captured_floating_proposer','returncode':r.returncode,'seconds':time.monotonic()-t});(P/'RUN_EXECUTIONS.json').write_text(json.dumps(runs,indent=2));assert r.returncode==0
 t=time.monotonic()
 with (P/f'verifier-{n}.log').open('x') as log:r=subprocess.run([sys.executable,str(P/'certify_floating.py'),n],stdout=log,stderr=subprocess.STDOUT,cwd=P)
 runs.append({'case':n,'stage':'exact_floating_output_verifier','returncode':r.returncode,'seconds':time.monotonic()-t});(P/'RUN_EXECUTIONS.json').write_text(json.dumps(runs,indent=2));assert r.returncode==0
print(json.dumps(runs,indent=2))

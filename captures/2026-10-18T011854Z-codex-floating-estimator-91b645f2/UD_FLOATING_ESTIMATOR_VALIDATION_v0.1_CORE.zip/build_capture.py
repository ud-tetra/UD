from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
P=Path(__file__).resolve().parent;repo=P.parent/'ud-repo';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ID=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H%M%SZ')+'-codex-floating-estimator-91b645f2';out=repo/'captures'/ID;out.mkdir(parents=True,exist_ok=False)
freeze=json.loads((P/'CAMPAIGN_FREEZE.json').read_text());arrays=[];archives=[];large=set();omitted=[]
for case in freeze['cases']:
 n=case['case'];raw=P/case['record_path'];assert sha(raw)==case['record_sha256']
 omitted.append({'case':n,'filename':raw.name,'size_bytes':raw.stat().st_size,'sha256':sha(raw),'reason':'Parent raw record omitted; exact projected sketch retained','recovery':'Pinned clean baseline and coherent-control recipes from PR184; source hashes in freeze'})
 for role,name in [('float','FLOAT_WITNESS.npz'),('sketch','EXACT_RECORD_SKETCH.npz')]:
  p=P/f'results/{n}/{name}';large.add(p);archive=out/f'WITNESS_{n}_{role}.zip'
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:z.write(p,p.relative_to(P).as_posix())
  arrays.append({'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'archive':archive.name})
  archives.append({'filename':archive.name,'size_bytes':archive.stat().st_size,'sha256':sha(archive)})
(P/'WITNESS_INDEX.json').write_text(json.dumps({'status':'COMPLETE_ACTUAL_FLOAT_AND_EXACT_SKETCH_ARRAYS','physical_promotion':0,'arrays':arrays,'archives':archives,'instructions':'Extract core and every witness archive into one folder, then run replay_package.py'},indent=2))
(P/'OMITTED_DATA.json').write_text(json.dumps({'files':omitted,'all_float_and_exact_sketch_arrays_retained':True,'physical_promotion':0},indent=2))
files=[p for p in P.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p not in large and p.name!='PACKAGE_MANIFEST.json']
(P/'PACKAGE_MANIFEST.json').write_text(json.dumps({'artifact':'UD_FLOATING_ESTIMATOR_VALIDATION_v0.1','physical_promotion':0,'independent_review':'pending','witness_arrays_index':'WITNESS_INDEX.json','files':[{'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]},indent=2));files.append(P/'PACKAGE_MANIFEST.json')
z=out/'UD_FLOATING_ESTIMATOR_VALIDATION_v0.1_CORE.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(files):archive.write(p,p.relative_to(P).as_posix())
for n in ['README.md','THEOREMS.md','CLAIM_LEDGER.json','PROVENANCE.json','CAMPAIGN_FREEZE.json','VALIDATION.json','HOSTILE_TEST_RESULTS.txt','WITNESS_INDEX.json','OMITTED_DATA.json','PACKAGE_MANIFEST.json','numeric_math.py','certify_floating.py','instrumented_proposer.py','test_adapter.py','validate_campaign.py','replay_package.py']:
 shutil.copyfile(P/n,out/n)
entries=[{'path':p.relative_to(repo).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'status':'Exact theorem / validated constructor outputs / same-constructor replay as typed in CLAIM_LEDGER.json','provenance':'Frozen actual floating runs, byte-identical parent proposals, exact all-readings sketches and saved-array residual replays; independent review pending'} for p in sorted(out.iterdir())]
(out/'MANIFEST.json').write_text(json.dumps({'capture_id':ID,'physical_promotion':0,'status':'CONSTRUCTOR_ACTUAL_FLOATING_ESTIMATOR_VALIDATION','supersedes':[],'extends':['2026-10-18T010653Z-codex-phase-stability-f0358a9c'],'verification_scope':'Actual captured floating phase outputs on three pinned records; all floats and exact sketches retained; exact residual/rounding gates and six tests; no uniform all-input, independent-review or physical promotion','files':entries},indent=2))
(repo/'events'/f'{ID}.json').write_text(json.dumps({'capture_id':ID,'event':'actual_floating_phase_estimator_output_validation','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'physical_promotion':0,'summary':'Three actual floating phase outputs certify unique fitted-reference matching; parent proposals byte-identical; exact source sketches and floating witnesses retained. Bounds<4.50e-10,<7.06e-8,<1.805e-5 radians/sample. Three saved-array replays and six tests pass. Independent review and uniform all-input guarantees remain open.'},indent=2))
print(json.dumps({'capture':str(out),'core_bytes':z.stat().st_size,'core_sha256':sha(z),'total_payload_bytes':sum(p.stat().st_size for p in out.glob('*.zip')),'archives':len(archives)+1,'core_files':len(files)}))

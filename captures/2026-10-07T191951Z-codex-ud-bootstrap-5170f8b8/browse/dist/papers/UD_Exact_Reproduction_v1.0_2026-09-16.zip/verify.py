#!/usr/bin/env python3
"""Exact checks for the two review papers. Python 3.10+, standard library only."""
from fractions import Fraction as F
from itertools import combinations, permutations, product
from collections import Counter, deque
from pathlib import Path
import json, math, time, hashlib
ROOT=Path(__file__).resolve().parent
checks=[]
def ok(name,test):
    if not test: raise AssertionError(name)
    checks.append(name)
def tr(a): return list(map(list,zip(*a)))
def zeros(n,m): return [[0]*m for _ in range(n)]
def eye(n): return [[int(i==j) for j in range(n)] for i in range(n)]
def mul(a,b): return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
def add(a,b,k=1): return [[x+k*y for x,y in zip(ar,br)] for ar,br in zip(a,b)]
def scale(a,k): return [[k*x for x in row] for row in a]
def rank(a):
 a=[[F(x) for x in row] for row in a];r=0
 for j in range(len(a[0])):
  p=next((i for i in range(r,len(a)) if a[i][j]),None)
  if p is None: continue
  a[r],a[p]=a[p],a[r];v=a[r][j];a[r]=[x/v for x in a[r]]
  for i in range(r+1,len(a)):
   if a[i][j]: v=a[i][j];a[i]=[x-v*y for x,y in zip(a[i],a[r])]
  r+=1
  if r==len(a):break
 return r

def complex_data(tops):
 bases=[sorted(set(s for t in tops for s in combinations(t,k+1))) for k in range(4)]
 bs=[]
 for k in range(1,4):
  b=zeros(len(bases[k-1]),len(bases[k]));idx={s:i for i,s in enumerate(bases[k-1])}
  for j,t in enumerate(bases[k]):
   for h in range(k+1):b[idx[t[:h]+t[h+1:]]][j]=(-1)**h
  bs.append(b)
 offsets=[sum(map(len,bases[:k])) for k in range(4)];n=sum(map(len,bases));a=zeros(n,n)
 for k,b in enumerate(bs):
  for i,row in enumerate(b):
   for j,v in enumerate(row):a[offsets[k]+i][offsets[k+1]+j]=-v;a[offsets[k+1]+j][offsets[k]+i]=v
 return {'simplices':bases,'boundaries':bs,'generator':a}
def signed_map(src,dst,p):
 s=sum(src['simplices'],[]);d=sum(dst['simplices'],[]);idx={x:i for i,x in enumerate(d)};out=zeros(len(d),len(s))
 for j,t in enumerate(s):
  mapped=[p[x] for x in t];sgn=(-1)**sum(mapped[i]>mapped[j] for i in range(len(t)) for j in range(i+1,len(t)))
  out[idx[tuple(sorted(mapped))]][j]=sgn
 return out

def build():
 data={k:complex_data(v) for k,v in {'tetra':[(0,1,2,3)],'A':[(0,1,2,3),(0,1,2,4)],'B':[(0,1,2,3),(0,1,2,4),(0,1,3,4)],'C':[(0,1,3,4),(0,2,3,4),(1,2,3,4)]}.items()}
 for name,d in data.items():
  bs=d['boundaries'];a=d['generator'];n=len(a)
  ok(name+' boundary squared',all(mul(bs[k],bs[k+1])==zeros(len(bs[k]),len(bs[k+1][0])) for k in range(2)))
  ok(name+' skew',tr(a)==scale(a,-1))
  rr=[rank(b) for b in bs];dims=list(map(len,d['simplices']));betti=[dims[k]-(rr[k-1] if k else 0)-(rr[k] if k<3 else 0) for k in range(4)]
  ok(name+' homology',betti==[1,0,0,0]);d['boundary_ranks']=rr
  l=scale(mul(a,a),-1);spec={'tetra':{0:1,4:14},'A':{0:1,3:8,5:14},'B':{0:1,2:4,5:22},'C':{0:1,2:4,5:22}}[name]
  ok(name+' exact squared-frequency multiplicities',all(n-rank(add(l,eye(n),-v))==m for v,m in spec.items()))
  # Since L is symmetric, these eigenspaces exhaust its dimension.
  ok(name+' eigenspaces exhaustive',sum(spec.values())==n)
  d['laplacian_spectrum']={str(k):v for k,v in spec.items()}
 # Exact polynomial cut balance: singleton selectors span every cut selector.
 for name,d in data.items():
  a=d['generator'];n=len(a);offsets=[sum(map(len,d['simplices'][:k])) for k in range(4)]
  for selected in range(n):
   selector=zeros(n,n);selector[selected][selected]=1
   derivative=add(mul(tr(a),selector),mul(selector,a));flux=zeros(n,n)
   for degree,boundary in enumerate(d['boundaries']):
    for i,row in enumerate(boundary):
     for j,b in enumerate(row):
      lo=offsets[degree]+i;hi=offsets[degree+1]+j
      coefficient=b*(int(selected==hi)-int(selected==lo))
      flux[lo][hi]=flux[hi][lo]=coefficient
   ok('I T5.1 cut balance '+name,derivative==flux)
 a=data['tetra']['generator'];ph=zeros(15,15)
 for i in range(4):
  for j in range(4):ph[i][j]=F(1,4)
 ok('T4.4 single-cell square',mul(a,a)==scale(add(eye(15),ph,-1),-4))
 P=signed_map(data['B'],data['C'],{0:3,1:4,2:2,3:0,4:1})
 ok('T6.2 signed isomorphism',mul(tr(P),P)==eye(27) and mul(data['C']['generator'],P)==mul(P,data['B']['generator']))
 T=signed_map(data['A'],data['B'],{i:i for i in range(5)})
 ok('P6.3 inclusion isometry',mul(tr(T),T)==eye(23))
 residual=add(mul(data['B']['generator'],T),mul(T,data['A']['generator']),-1)
 ok('P6.3 inclusion is not dynamical intertwiner',any(any(row) for row in residual))
 data['event_maps']={'A_to_B':T,'B_to_C':P,'A_to_B_dynamic_residual':residual}
 # Oriented Pachner identity as formal chains.
 bd=lambda t:{t[:h]+t[h+1:]:F((-1)**h) for h in range(len(t))}
 left={(0,1,2,3):1,(0,1,2,4):-1,(1,2,3,4):1,(0,2,3,4):-1,(0,1,3,4):1}
 ok('T6.1 oriented Pachner boundary',left==bd((0,1,2,3,4)))
 accum=Counter()
 for t,v in left.items():
  for u,w in bd(t).items():accum[u]+=v*w
 ok('T6.1 exterior boundary equal',all(x==0 for x in accum.values()))
 ok('NG6.5 binary labels',not any(all(sum(bits[i] for i in t)==2 for t in combinations(range(5),4)) for bits in product(range(2),repeat=5)))
 # Unique-simplex equal ownership.
 tops=[(0,1,2,3),(0,1,2,4)]
 ok('T5.2 ownership',all(sum(F(1,sum(set(s)<=set(t) for t in tops)) for t in tops if set(s)<=set(t))==1 for s in sum(data['A']['simplices'],[])))
 perms=list(permutations(range(4)));edges=list(combinations(range(4),2));fib=Counter(tuple(sorted((p[0],p[1]))) for p in perms for _ in range(8))
 ok('P3.3 edge fibers',len(fib)==6 and set(fib.values())=={32})
 match=[frozenset([frozenset((0,1)),frozenset((2,3))]),frozenset([frozenset((0,2)),frozenset((1,3))]),frozenset([frozenset((0,3)),frozenset((1,2))])]
 induced=[]
 for p in perms:induced.append(tuple(match.index(frozenset(frozenset(p[x] for x in e) for e in m)) for m in match))
 ok('P3.1 matching quotient',len(set(induced))==6 and sum(x==(0,1,2) for x in induced)==4)
 ok('P3.2 matching stabilizer order',sum(x[0]==0 for x in induced)==8)
 b1=data['tetra']['boundaries'][0];b2=data['tetra']['boundaries'][1]
 cut=scale(mul(tr(b1),b1),F(1,4));cycle=scale(mul(b2,tr(b2)),F(1,4))
 ok('P4.5 projectors',mul(cut,cut)==cut and mul(cycle,cycle)==cycle and add(cut,cycle)==eye(6) and mul(cut,cycle)==zeros(6,6))
 for p in perms:
  pp=signed_map(data['tetra'],data['tetra'],dict(enumerate(p)));p0=[row[:4] for row in pp[:4]];p1=[row[4:10] for row in pp[4:10]]
  recovered=scale(add(mul(mul(b1,p1),tr(b1)),[[1]*4 for _ in range(4)]),F(1,4))
  ok('P7.4 relative-frame extraction',recovered==p0 and mul(b1,p1)==mul(p0,b1))
 swap=[[0,1],[1,0]];Q=[[1,0],[0,2]]
 ok('P8.1 second quadratic form',mul(tr(swap),swap)==eye(2) and mul(mul(tr(swap),Q),swap)!=Q)
 bits=list(product(range(2),repeat=3));ok('P3.5 shell counts',[sum(sum(t)==w for t in bits) for w in range(4)]==[1,3,3,1])
 for p in set(induced):
  for shift in bits:
   mapping=[]
   for t in bits:
    v=[0]*3
    for j in range(3):v[p[j]]=t[j]
    mapping.append(tuple((v[j]+shift[j])%2 for j in range(3)))
   r=sum(shift);ok('T7.2 affine bijection',len(set(mapping))==8)
   ok('T7.3 commutator',sum((sum(y)-sum(x))**2 for x,y in zip(bits,mapping))==8*r)
   for w in range(4):
    for wp in range(4):
     twice=w+r-wp;s=twice//2
     expected=math.comb(r,s)*math.comb(3-r,w-s) if twice%2==0 and 0<=s<=r and 0<=w-s<=3-r else 0
     ok('T7.3 transition ranks',sum(sum(x)==w and sum(y)==wp for x,y in zip(bits,mapping))==expected)
 # Exact parity-degree witness: even support A=4, odd support B=1.
 c=[F(0)]*15;c[0]=2;c[4]=1;cp=[F(0)]*15;cp[0]=1;cp[4]=2
 ok('NG2.1 same support, distinct ray',sum(x*x for x in c)==sum(x*x for x in cp)==5 and c!=cp)
 nodes=sum(data['tetra']['simplices'],[]);node_names=[('v' if len(t)==1 else 'e' if len(t)==2 else 'f' if len(t)==3 else 't')+''.join(map(str,t)) for t in nodes];ni={x:i for i,x in enumerate(node_names)}
 split=json.loads((ROOT/'data/split.json').read_text());inc=[]
 for label in split['canonical_incidence_order']:
  u,v=label.split('-');i,j=ni[u],ni[v];inc.append((i,j,-a[i][j]))
 ok('II NG2.1 same incidence currents',all(2*b*c[i]*c[j]==2*b*cp[i]*cp[j] for i,j,b in inc))
 train=split['training_indices_zero_based'];held=split['heldout_indices_zero_based'];adj=[[] for _ in nodes]
 for e in train:
  i,j,_=inc[e];adj[i].append((j,e));adj[j].append((i,e))
 def path(u,v):
  todo=deque([(u,[])]);seen={u}
  while todo:
   x,p=todo.popleft()
   if x==v:return p
   for y,e in adj[x]:
    if y not in seen:seen.add(y);todo.append((y,p+[e]))
  raise AssertionError('Disconnected tree')
 C=[]
 for h in held:
  p=path(*inc[h][:2]);C.append([sum((-1)**k for k,e in enumerate(p) if e==t) for t in train])
 S=[[int(k in inc[e][:2]) for k in range(15)] for e in train];H=[[int(k in inc[e][:2]) for k in range(15)] for e in held]
 ok('T5.1 tree ranks',rank(S)==14 and rank(H)==10)
 ok('T5.2 C map',mul(C,S)==H)
 ok('T5.2 paths',Counter(sum(abs(x) for x in row) for row in C)=={3:8,5:5,7:1})
 cov=[[F(int(i==j))+F(1,10) for j in range(14)] for i in range(14)]
 # Finite zero-mean source: rows of a factor R and their negatives.
 R=[[10*int(i==j) for j in range(14)]+[1] for i in range(14)]
 X=tr(R)+scale(tr(R),-1);sigma=scale(mul(tr(X),X),F(1,len(X)));Y=mul(X,tr(C));direct=scale(mul(tr(Y),Y),F(1,len(Y)))
 ok('T6.1 covariance',direct==mul(mul(C,sigma),tr(C)))
 # PSR fixtures including disconnected support and zero coordinates, two forest orders.
 fixtures=[]
 for vec in ([F((-1)**i*(i+1)) for i in range(15)],c,[F(2),F(-3)]+[F(0)]*13):
  support=[i for i,x in enumerate(vec) if x];q=[x*x for x in vec];norm=sum(q);rho=[v/norm for v in q]
  for reverse in (False,True):
   g=[[] for _ in nodes]
   for i,j,b in (reversed(inc) if reverse else inc):
    if vec[i] and vec[j]:g[i].append(j);g[j].append(i)
   signs={};forest=[];roots=[]
   for root in support:
    if root in signs:continue
    signs[root]=1 if vec[root]>0 else -1;roots.append([root,signs[root]]);queue=deque([root])
    while queue:
     u=queue.popleft()
     for v in g[u]:
      if v not in signs:
       chi=1 if vec[u]*vec[v]>0 else -1;signs[v]=signs[u]*chi;forest.append([u,v,chi]);queue.append(v)
   ok('T3.2 PSR and T4.1 forest gauge',all(signs[i]==(1 if vec[i]>0 else -1) for i in support) and all(rho[i]*norm==vec[i]**2 for i in support))
   fixtures.append({'state':vec,'rho':rho,'forest':forest,'roots':roots})
  for i,j,b in inc:ok('P3.3 current square',(2*b*vec[i]*vec[j])**2==4*q[i]*q[j])
 data['psr']={'nodes':node_names,'incidences':inc,'S':S,'H':H,'C':C,'Sigma_T':sigma,'Sigma_H':direct,'fixtures':fixtures}
 return data

def encode(v):
 if isinstance(v,F):return str(v)
 raise TypeError(type(v))
def main():
 t=time.perf_counter();data=build();serialized=json.dumps(data,default=encode,indent=2)+'\n';target=ROOT/'data/exact_artifacts.json'
 if '--write-artifacts' in __import__('sys').argv:target.write_text(serialized)
 else:ok('Archived matrices and fixtures match regeneration',json.loads(target.read_text())==json.loads(serialized))
 if (ROOT/'SHA256SUMS.json').exists():
  manifest=json.loads((ROOT/'SHA256SUMS.json').read_text())
  for name,h in manifest.items():ok('File integrity '+name,hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h)
 print(json.dumps({'status':'PASS','assertions':len(checks),'check_families':sorted(set(checks)),'seconds':round(time.perf_counter()-t,3)},indent=2))
if __name__=='__main__':main()

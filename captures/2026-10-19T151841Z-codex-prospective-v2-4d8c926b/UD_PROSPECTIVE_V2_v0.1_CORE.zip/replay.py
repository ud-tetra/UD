"""Complete frozen campaign saved-factor replay, optionally regenerate and reproject raw."""
import argparse,json,os,sys,subprocess,shutil
from pathlib import Path
from bindings import P,sha,freeze
from offline_intake import intake

def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--baseline',type=Path);a=p.parse_args();out=a.out.absolute();assert not out.exists();out.mkdir(parents=True);f=freeze()
 for key in ['PACKAGE_MANIFEST.json','ARRAY_INDEX.json']:
  for row in json.loads((P/key).read_text())['files']:
   path=Path(row['path']);assert not path.is_absolute() and '..' not in path.parts;q=P/path
   assert q.is_file() and q.stat().st_size==row['size_bytes'] and sha(q)==row['sha256']
 receipt={'status':'RUNNING','mode':'raw_and_saved_factors' if a.baseline else 'saved_factors','commands':[],'new_estimator_or_SVD_runs':0,'reviewer_identity':None,'external_review':'PENDING','physical_promotion':0}
 def go(work,args,tag):
  r=subprocess.run([sys.executable,*args],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'});log=out/(tag+'.log');log.write_bytes(r.stdout);receipt['commands'].append({'tag':tag,'argv':args,'exit_code':r.returncode,'log_sha256':sha(log)});assert r.returncode==0,tag
 try:
  for key in ['rounding','contract']:intake(a.repo.resolve(),key,out)
  work=out/'prospective-v2-work';shutil.copytree(P,work,ignore=shutil.ignore_patterns('__pycache__','records','INTEGER_*.npz'))
  helper=out/'record-contract-work'
  for n,h in f['helper_sha256'].items():assert sha(helper/n)==h
  if a.baseline:
   assert sha(a.baseline)==f['baseline_sha256'];target=out/f['baseline'];target.parent.mkdir(parents=True);os.link(a.baseline.resolve(),target)
   go(work,['make_records.py','--regenerate',str(out/'generated')],'raw-regeneration')
  go(work,['materialize.py',*(['--raw-records',str(out/'generated')] if a.baseline else [])],'materialize')
  code='import full_svd; from bindings import P,freeze\nfor n in freeze()["cases"]:\n full_svd.P=P/"results"/n\n full_svd.certify("integer_projection")\n'
  go(work,['-c',code],'full-factor-certificate')
  go(work,['gates.py','--replay'],'original-policy')
  go(work,['v2.py','--repo',str(a.repo.resolve()),'--replay'],'published-v2')
  for n,h in f['helper_sha256'].items():assert sha(helper/n)==h
  receipt.update(status='PASS_COMPLETE_PROSPECTIVE_CAMPAIGN_REPLAY',cases=3,helpers_checked_before_after=True)
 except Exception as e:receipt.update(status='FAIL',error=type(e).__name__+': '+str(e));raise
 finally:(out/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()

"""Post-fit supplemental exact comparisons and hostile witnesses; policies unchanged."""
import sys,json,hashlib
from fractions import Fraction as F
import numpy as np
from bindings import P,freeze,sha
from v2 import policy
from flint import arb,fmpq,ctx
sys.path.insert(0,str(P.parent/'record-contract-work'))
from numeric_math import encode,encode_complex,diffnorm,cmul,complex_residual
from proof_math import fm,up,down
ctx.prec=512

def verify(repo):
 f=freeze();sf=json.loads((P/'SUPPLEMENT_FREEZE.json').read_text());assert sha(__file__)==sf['code_sha256']
 for n,h in sf['output_sha256'].items():assert sha(P/n)==h
 mod=policy(repo);rows=[]
 for name in f['cases']:
  d=P/'results'/name/'results/integer_projection';U=np.vstack([np.load(d/f'FACTOR_{k}.npz')['left'] for k in range(3)])[:,:209]
  with np.load(d/'PHASE_META.npz',allow_pickle=False) as z:T=z['shift']
  un,bu=encode(U);tn,bt=encode(T);norm,pair=diffnorm(fm(un[2:]),bu,fm(un[:-2])*fm(tn),bu+bt);sq=F(*pair)
  rows.append({'case':name,'exact_raw_shift_residual_squared':[str(sq.numerator),str(sq.denominator)],'strict_v1_shift_violation':sq>F(1,1<<68),'v1_gate_ratio_upper':up(norm*(1<<34)),'v1_gate_ratio_lower':down(norm*(1<<34))})
 name=f['cases'][0];d=P/'results'/name/'results/integer_projection';original=sha(d/'PHASE_META.npz')
 with np.load(d/'PHASE_META.npz',allow_pickle=False) as z:V=z['eigenvectors'];H=np.zeros_like(z['inverse'])
 vr,vi,bv=encode_complex(V);hr,hi,bh=encode_complex(H);ident=(fm(np.eye(209,dtype=object)),fm(np.zeros((209,209),dtype=object)))
 rho,pair=complex_residual(cmul(fm(vr),fm(vi),fm(hr),fm(hi)),bv+bh,ident,0);assert F(*pair)==209
 row=json.loads((P/'GATE_RESULTS.json').read_text())['rows'][0];metrics=dict(row['metrics']);metrics['inverse_residual']=up(rho);metrics['proposed_inverse_norm']=[0,1];bad=mod.evaluate(metrics,True);assert bad['status']=='HOLD_V2' and 'inverse_residual' in bad['failed'];assert sha(d/'PHASE_META.npz')==original
 q=P/'results'/name/'SKETCH_DELTA_0.npz';oldsha=sha(q)
 with np.load(q,allow_pickle=False) as z:delta=z['delta'].copy()
 s=f['integer_anchor'][0]
 with np.load(P.parent/s['path'],allow_pickle=False) as z:n=z['numerator']+delta.astype(np.int64)
 n[0,0]+=1;corrupt_hash=hashlib.sha256((n.astype(float)/2.**55).astype('<f8').tobytes()).hexdigest()
 with np.load(d/'FACTOR_0.npz',allow_pickle=False) as z:
  try:assert corrupt_hash==str(z['projection_sha256'])
  except AssertionError:refused=True
  else:refused=False
 assert refused and sha(q)==oldsha
 return {'status':'PASS_EXACT_GATE_COMPARISONS_AND_TWO_ACTUAL_WITNESS_CONTROLS','rows':rows,
         'controls':[{'name':'zero_inverse_actual_saved_eigensystem','exact_inverse_residual_squared':209,'status':'HOLD_V2','failed_gate':'inverse_residual'},
                     {'name':'one_integer_projected_entry_mutation','status':'REFUSED_PROJECTION_HASH','original_arrays_unchanged':True}],
         'physical_promotion':0,'external_review':'PENDING'}

if __name__=='__main__':
 import argparse
 from pathlib import Path
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--replay',action='store_true');a=p.parse_args();r=verify(a.repo.resolve());q=P/'SUPPLEMENT_RESULTS.json'
 if a.replay:assert json.loads(q.read_text())==r
 else:
  assert not q.exists();q.write_text(json.dumps(r,indent=2))
 print(json.dumps(r),flush=True)

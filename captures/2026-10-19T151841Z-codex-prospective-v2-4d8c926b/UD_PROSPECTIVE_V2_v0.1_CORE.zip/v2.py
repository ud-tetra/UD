"""Apply byte-pinned published PR213 v2; never derive a new allowance here."""
import importlib.util,json,argparse
from pathlib import Path
from bindings import P,freeze,sha

def policy(repo):
 f=freeze()['v2_capture'];root=repo/'captures'/f['id'];assert sha(root/'MANIFEST.json')==f['manifest_sha256']
 for e in json.loads((root/'MANIFEST.json').read_text())['files']:
  p=Path(e['path']);assert not p.is_absolute() and '..' not in p.parts and p.is_relative_to(Path('captures')/f['id']);q=repo/p
  assert q.is_file() and not q.is_symlink() and q.stat().st_size==e['size_bytes'] and sha(q)==e['sha256']
 spec=importlib.util.spec_from_file_location('published_source_math',root/'source_math.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 assert mod.derive()==json.loads((root/'SOURCE_ALLOWANCE.json').read_text());return mod

def verify(repo,replay=False):
 f=freeze();mod=policy(repo);rows=[]
 for old in json.loads((P/'GATE_RESULTS.json').read_text())['rows']:
  if old.get('learned_order')!=209 or 'metrics' not in old:r={'status':'HOLD_SOURCE_ORDER_OR_FACTORS'}
  else:r=mod.evaluate(old['metrics'],old['raw_eligible'])
  rows.append({'case':old['case'],'record_sha256':old['record_sha256'],'v1_status':old['status'],'v2':r});print(json.dumps(rows[-1]),flush=True)
 result={'status':'PROSPECTIVE_THREE_RECORD_FROZEN_V2_EVALUATION','rows':rows,'published_v2_source_allowance':mod.derive(),'prospective_relative_to_v2':True,'independent_or_blinded':False,'external_review':'PENDING','physical_promotion':0}
 dest=P/'V2_RESULTS.json'
 if replay:assert json.loads(dest.read_text())==result
 else:
  assert not dest.exists();dest.write_text(json.dumps(result,indent=2))
 return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--replay',action='store_true');a=p.parse_args();verify(a.repo.resolve(),a.replay)

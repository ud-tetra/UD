"""Three prospectively frozen one-quantum patterns; no outcome-driven tuning."""
import argparse,json
from pathlib import Path
import numpy as np
from bindings import P,sha,freeze

def patterns(name):
 a=np.arange(37)[:,None];t=np.arange(8191)[None,:]
 if name=='rotating_checker':return np.broadcast_to((a+3*t)%62,(37,8191)).copy(),np.broadcast_to(1-2*((a+t)%2),(37,8191)).copy()
 if name=='block128':
  rng=np.random.default_rng(219101);blocks=(8191+127)//128
  channel=rng.integers(0,62,size=(37,blocks),dtype=np.int64);sign=rng.integers(0,2,size=(37,blocks),dtype=np.int64)*2-1
  return channel[:,np.arange(8191)//128],sign[:,np.arange(8191)//128]
 if name=='directed_period4':
  s=json.loads((P/'inputs/SPATIAL_SELECTION.json').read_text());time=np.array([1,1,-1,-1],np.int64)[np.arange(8191)%4]
  return np.broadcast_to(np.array(s['channels'],np.int64)[:,None],(37,8191)).copy(),np.array(s['signs'],np.int64)[:,None]*time[None,:]
 raise ValueError(name)

def generate(dest,replay=False):
 f=freeze();base=P.parent/f['baseline'];assert sha(base)==f['baseline_sha256'];Y=np.memmap(base,dtype='<i8',mode='r',shape=(37,8191,62));dest=Path(dest);dest.mkdir(parents=True,exist_ok=False);rows=[]
 for name in f['cases']:
  channels,signs=patterns(name);assert channels.shape==signs.shape==(37,8191) and np.all(abs(signs)==1) and np.all((channels>=0)&(channels<62))
  raw=dest/(name+'.i64le')
  with raw.open('xb') as stream:stream.truncate(150321232)
  Z=np.memmap(raw,dtype='<i8',mode='r+',shape=Y.shape);Z[:]=Y;ts=np.arange(8191)
  for j in range(37):Z[j,ts,channels[j]]+=signs[j]
  Z.flush();count=0
  for start in range(0,8191,256):
   end=min(start+256,8191);diff=Z[:,start:end]-Y[:,start:end];expected=np.zeros_like(diff)
   for j in range(37):expected[j,np.arange(end-start),channels[j,start:end]]=signs[j,start:end]
   assert np.array_equal(diff,expected) and np.all(np.sum(diff*diff,axis=-1)==1);count+=diff.size
  assert count==18790154
  rows.append({'case':name,'record_sha256':sha(raw),'bytes':raw.stat().st_size,'readings_checked':count,'vector_integer_squared_error_max':1,'noise_budget':[1,1<<48],'scalar_quantum':[1,1<<48],'baseline_sha256':sha(base),'new_apparatus_data':False});del Z
  print(json.dumps(rows[-1]),flush=True)
 assert sha(base)==f['baseline_sha256']
 record={'status':'ALL_RAW_HASHES_FROZEN_BEFORE_FITTING','protocol_sha256':sha(P/'PROTOCOL_FREEZE.json'),'records':rows,'physical_promotion':0}
 if replay:
  assert record==json.loads((P/'DATA_FREEZE.json').read_text());(dest/'RAW_REGENERATION_RECEIPT.json').write_text(json.dumps({'status':'PASS_ALL_THREE_RAW_HASHES_AND_DIFFERENCES','records':rows,'physical_promotion':0},indent=2))
 else:
  assert not (P/'DATA_FREEZE.json').exists();(P/'DATA_FREEZE.json').write_text(json.dumps(record,indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--regenerate',type=Path);args=p.parse_args();generate(args.regenerate or P/'records',args.regenerate is not None)

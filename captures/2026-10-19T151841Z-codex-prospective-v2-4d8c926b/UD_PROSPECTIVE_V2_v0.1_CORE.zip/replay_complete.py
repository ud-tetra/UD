"""Post-run complete wrapper includes frozen original replay and supplemental controls."""
import argparse,json,subprocess,sys,os
from pathlib import Path
from bindings import P,sha
def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--baseline',type=Path);a=p.parse_args();out=a.out.absolute();assert not out.exists();out.mkdir(parents=True);f=json.loads((P/'REPLAY_COMPLETE_FREEZE.json').read_text());assert sha(__file__)==f['code_sha256'];receipt={'status':'RUNNING','commands':[],'reviewer_identity':None,'external_review':'PENDING','physical_promotion':0}
 def go(cwd,cmd,tag):
  r=subprocess.run([sys.executable,*cmd],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'});q=out/(tag+'.log');q.write_bytes(r.stdout);receipt['commands'].append({'tag':tag,'argv':cmd,'exit_code':r.returncode,'log_sha256':sha(q)});assert r.returncode==0,tag
 try:
  go(P,['replay.py','--repo',str(a.repo.resolve()),'--out',str(out/'campaign'),*(['--baseline',str(a.baseline.resolve())] if a.baseline else [])],'campaign')
  parent=json.loads((out/'campaign/REPLAY_RECEIPT.json').read_text());assert parent['status']=='PASS_COMPLETE_PROSPECTIVE_CAMPAIGN_REPLAY'
  go(out/'campaign/prospective-v2-work',['supplement.py','--repo',str(a.repo.resolve()),'--replay'],'supplement')
  receipt.update(status='PASS_FULL_PROSPECTIVE_V2_REPLAY_AND_CONTROLS',cases=3,new_estimator_or_SVD_runs=0,mode=parent['mode'],parent_receipt_sha256=sha(out/'campaign/REPLAY_RECEIPT.json'))
 except Exception as e:receipt.update(status='FAIL',error=type(e).__name__+': '+str(e));raise
 finally:(out/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()

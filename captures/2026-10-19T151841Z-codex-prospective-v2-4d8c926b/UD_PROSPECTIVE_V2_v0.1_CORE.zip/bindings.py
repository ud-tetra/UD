from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def freeze():
 f=json.loads((P/'PROTOCOL_FREEZE.json').read_text())
 for n,h in f['code_sha256'].items():assert sha(P/n)==h,'frozen source changed'
 for n,h in f['inputs_sha256'].items():assert sha(P/'inputs'/n)==h,'frozen input changed'
 return f

"""Lossless witness recovery; optional full fresh raw projection check."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from bindings import P,freeze,sha
from sketch import sketch

def check(rawdir=None,write_index=False):
 f=freeze();anchor=[]
 for s in f['integer_anchor']:
  q=P.parent/s['path'];assert sha(q)==s['sha256']
  with np.load(q,allow_pickle=False) as z:anchor.append(z['numerator'])
 A=sketch();bound=2*np.abs(A).reshape(62,37,321).max(axis=0).sum(axis=0);allrows=[];count=0
 for row in json.loads((P/'DATA_FREEZE.json').read_text())['records']:
  case=P/'results'/row['case'];pieces=[];chunks=[]
  for k in range(3):
   q=case/f'SKETCH_DELTA_{k}.npz'
   with np.load(q,allow_pickle=False) as z:delta=z['delta'];assert delta.dtype==np.int16 and delta.shape==anchor[k].shape and np.all(np.abs(delta.astype(np.int64))<=bound[None,:])
   n=anchor[k]+delta.astype(np.int64);assert max(abs(int(n.min())),abs(int(n.max())))<2**53
   target=case/'results'/f'INTEGER_{k}.npz'
   if target.exists():
    with np.load(target,allow_pickle=False) as z:assert np.array_equal(z['numerator'],n)
   else:np.savez_compressed(target,numerator=n)
   digest=hashlib.sha256(n.astype('<i8').tobytes()).hexdigest()
   with np.load(case/'results/integer_projection'/f'FACTOR_{k}.npz',allow_pickle=False) as z:assert str(z['projection_sha256'])==hashlib.sha256((n.astype(float)/2.**55).astype('<f8').tobytes()).hexdigest()
   chunks.append({'chunk':k,'shape':list(n.shape),'integer_bytes_sha256':digest,'delta_path':q.relative_to(P).as_posix(),'delta_sha256':sha(q)});pieces.append(n);count+=n.size
  if rawdir is not None:
   raw=rawdir/(row['case']+'.i64le');assert sha(raw)==row['record_sha256'];Y=np.memmap(raw,dtype='<i8',mode='r',shape=(37,8191,62));X=np.array(Y.transpose(1,2,0).reshape(8191,2294),np.int64);mx=max(abs(int(X.min())),abs(int(X.max())));assert mx*int(np.abs(A).sum(axis=0).max())<2**63;assert np.array_equal(X@A,np.vstack(pieces))
  allrows.append({'case':row['case'],'raw_sha256':row['record_sha256'],'chunks':chunks})
 index={'cases':allrows,'integer_entries':count,'physical_promotion':0}
 if write_index:
  assert not (P/'INTEGER_INDEX.json').exists();(P/'INTEGER_INDEX.json').write_text(json.dumps(index,indent=2))
 else:assert json.loads((P/'INTEGER_INDEX.json').read_text())==index
 result={'status':'PASS_COMPLETE_RAW_AND_NUMERATOR_REPLAY' if rawdir is not None else 'PASS_LOSSLESS_NUMERATOR_REPLAY','cases':3,'integer_entries':count,'physical_promotion':0};print(json.dumps(result),flush=True);return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--raw-records',type=Path);p.add_argument('--write-index',action='store_true');a=p.parse_args();check(a.raw_records,a.write_index)

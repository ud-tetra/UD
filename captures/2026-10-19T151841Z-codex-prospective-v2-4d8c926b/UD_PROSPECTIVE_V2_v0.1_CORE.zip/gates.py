"""Exactly evaluate unchanged PR210 gates on new percase actual saved arrays."""
import json,sys
from pathlib import Path
import numpy as np
from flint import arb,acb,ctx
from bindings import P,sha,freeze
sys.path.insert(0,str(P.parent/'record-contract-work'))
from numeric_math import encode,encode_complex,complex_residual,cmul,diffnorm
from proof_math import fm,arr,up
ctx.prec=512

def op(r,i,b):
 R,I=fm(r),fm(i);g=arr(R.transpose()*R+I.transpose()*I);h=arr(R.transpose()*I-I.transpose()*R);tr=sum(int(g[j,j]) for j in range(g.shape[0]));row=max(sum(abs(int(g[j,k]))+abs(int(h[j,k])) for k in range(g.shape[0])) for j in range(g.shape[0]));return arb(min(tr,row)).sqrt()/(1<<b)
def verify(replay=False):
 f=freeze();from flint import fmpq
 a=lambda p:arb(fmpq(*p));policy=json.loads((P/'inputs/PARENT_GATE_FREEZE.json').read_text())['gates'];rows=[]
 for name in f['cases']:
  d=P/'results'/name/'results/integer_projection';disc=json.loads((d/'DISCOVERY.json').read_text());cert=json.loads((d/'CERTIFICATE.json').read_text());r={'case':name,'record_sha256':disc['record_sha256'],'learned_order':disc['learned_order'],'raw_eligible':True,'physical_promotion':0}
  if cert['status']!='CERTIFIED_ACTUAL_SVD_ORDER' or cert['learned_order']!=209:r['status']='HOLD_SOURCE_ORDER';rows.append(r);continue
  U=np.vstack([np.load(d/f'FACTOR_{k}.npz')['left'] for k in range(3)])[:,:209]
  with np.load(d/'PHASE_META.npz') as z:T=z['shift'];ev=z['eigenvalues'];angles=z['angles'];V=z['eigenvectors'];H=z['inverse']
  with np.load(d/'PHASE_PROPOSAL.npz') as z:em=z['two_step_phase']
  un,bu=encode(U);tn,bt=encode(T);shift,_=diffnorm(fm(un[2:]),bu,fm(un[:-2])*fm(tn),bu+bt);vr,vi,bv=encode_complex(V);ir,ii,bi=encode_complex(H);lr,li,bl=encode_complex(ev);vf=(fm(vr),fm(vi));ident=(fm(np.eye(209,dtype=object)),fm(np.zeros((209,209),dtype=object)));rho,_=complex_residual(cmul(*vf,fm(ir),fm(ii)),bv+bi,ident,0);hinv=op(ir,ii,bi);eigres,_=complex_residual((fm(tn)*vf[0],fm(tn)*vf[1]),bt+bv,(fm(vr*lr[None,:]-vi*li[None,:]),fm(vr*li[None,:]+vi*lr[None,:])),bv+bl)
  arg=arb(0)
  for j in range(209):
   n,de=float(angles[j]).as_integer_ratio();v,z=divmod(n*(1<<60),de);assert int(em[j])==v+int(2*z>de or(2*z==de and v%2));z=acb(arb(int(lr[j]))/(1<<bl),arb(int(li[j]))/(1<<bl));err=z.arg()-arb(int(em[j]))/(1<<60);v=min(arb(abs(err).upper()),arb(abs(err+2*arb.pi()).upper()),arb(abs(err-2*arb.pi()).upper()));arg=max(arg,v)
  metrics={'full_left_orthogonality':a(cert['eta_left_upper']),'full_right_orthogonality':a(cert['eta_right_upper']),'full_SVD_error':a(cert['singular_error_upper']),'raw_shift_residual':shift,'inverse_residual':rho,'proposed_inverse_norm':hinv,'eigenpair_residual':eigres,'emitted_argument_error':arg};checks={n:bool(v<=a(policy[n])) for n,v in metrics.items()};failed=[n for n in checks if not checks[n]];r.update(status='ADMITTED_UNIFORM_OUTPUT_CONTRACT' if not failed else 'HOLD_OUTPUT_GATES',checks=checks,failed_gates=failed,metrics={n:up(v) for n,v in metrics.items()},readable={n:float(v.upper()) for n,v in metrics.items()},phase_error_bound_if_admitted=json.loads((P/'inputs/UNIFORM_CERTIFICATE.json').read_text())['phase_error_upper'] if not failed else None,phase_failure_claimed=False);rows.append(r);print(json.dumps({'case':name,'status':r['status'],'failed_gates':failed,'readable':r['readable']}),flush=True)
 result={'status':'FROZEN_ADVERSARIAL_GATE_CAMPAIGN','rows':rows,'physical_promotion':0,'external_review':'PENDING','gates_unchanged':True,'new_records':len(rows),'full_Hankel_claim':False}
 if replay:assert json.loads((P/'GATE_RESULTS.json').read_text())==result
 else:
  assert not (P/'GATE_RESULTS.json').exists();(P/'GATE_RESULTS.json').write_text(json.dumps(result,indent=2))
 return result
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--replay',action='store_true');a=p.parse_args();verify(a.replay)

"""Prepare complete archive set; immutable root manifest follows clean replay."""
from pathlib import Path
import json,hashlib,datetime,zipfile
P=Path(__file__).resolve().parent;repo=P.parent/'ud-repo'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ID=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H%M%SZ')+'-codex-prospective-v2-4d8c926b'
out=repo/'captures'/ID;out.mkdir(exist_ok=False)
all_arrays=sorted(P.glob('results/**/*.npz'))
arrays=[p for p in all_arrays if not p.name.startswith('INTEGER_')]
assert len(arrays)==27 and all(0<p.stat().st_size<10*1024**2 for p in arrays)
omitted=[{'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'recovery':'Pinned parentnumerators+retainedprojecteddeltas yield identical arrays; compressedNPZbyteidentity not required.'} for p in all_arrays if p not in arrays]
omitted += [{'path':'records/'+r['case']+'.i64le','size_bytes':r['bytes'],'sha256':r['record_sha256'],'recovery':'Frozen recipe on hash-pinned PR195baseline; baseline recovery recipes in PR195/210.'} for r in json.loads((P/'DATA_FREEZE.json').read_text())['records']]
(P/'OMISSIONS.json').write_text(json.dumps({'files':omitted,'physical_promotion':0},indent=2))
groups=[];group=[];size=0
for p in arrays:
 if group and size+p.stat().st_size>10*1024**2:groups.append(group);group=[];size=0
 group.append(p);size+=p.stat().st_size
if group:groups.append(group)
entries=[]
for k,g in enumerate(groups,1):
 archive=out/f'UD_PROSPECTIVE_V2_v0.1_WITNESS_{k:02d}.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_STORED) as z:
  for p in g:
   rel=p.relative_to(P).as_posix();z.write(p,rel);entries.append({'path':rel,'size_bytes':p.stat().st_size,'sha256':sha(p),'archive':archive.name})
 assert archive.stat().st_size<12*1024**2
(P/'ARRAY_INDEX.json').write_text(json.dumps({'files':entries,'physical_promotion':0},indent=2))
small=[p for p in sorted(P.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.py','.json','.md','.log','.txt'} and not p.relative_to(P).parts[0]=='records' and p.name!='PACKAGE_MANIFEST.json']
(P/'PACKAGE_MANIFEST.json').write_text(json.dumps({'files':[{'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in small],'scope':'Frozen archive memberbytes; rootmanifest additionally binds postpackaging replayreceipts/finalreview.','physical_promotion':0},indent=2))
core=out/'UD_PROSPECTIVE_V2_v0.1_CORE.zip'
with zipfile.ZipFile(core,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in small+[P/'PACKAGE_MANIFEST.json']:z.write(p,p.relative_to(P).as_posix())
assert core.stat().st_size<12*1024**2
from offline_intake import archive_plan
plan=archive_plan(sorted(out.glob('*.zip')));assert not any(Path(row[2]).parts[0]=='records' for row in plan)
(out/'BUILD_RECEIPT.json').write_text(json.dumps({'archives':len(groups)+1,'retained_numeric_NPZ':len(arrays),'payload_bytes':sum(p.stat().st_size for p in out.glob('*.zip')),'safe_unique_members':len(plan),'uncompressed_bytes':sum(x[4] for x in plan),'raw_tree_excluded':True,'physical_promotion':0},indent=2))
for n in ['README.md','THEOREMS.md','PROTOCOL_FREEZE.json','DATA_FREEZE.json','RESULT_SUMMARY.json','PROVENANCE.json','CLAIM_LEDGER.json','ARRAY_INDEX.json','OMISSIONS.json']:(out/n).write_bytes((P/n).read_bytes())
(P.parent/'PROSPECTIVE_V2_CAPTURE_PATH.txt').write_text(str(out))
print(json.dumps({'capture':str(out),**json.loads((out/'BUILD_RECEIPT.json').read_text())}))

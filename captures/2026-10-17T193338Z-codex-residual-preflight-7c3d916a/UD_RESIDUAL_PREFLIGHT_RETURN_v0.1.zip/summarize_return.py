"""Collect execution receipts without manufacturing numerical evidence."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,datetime
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((P/'inputs/receipt-corpus/strong_null_alternating/BENCHMARK.json').read_text())
new=json.loads((P/'results/strong_null_alternating_isolated/BENCHMARK.json').read_text())
pos=json.loads((P/'results/bounded_null_impulse/BENCHMARK.json').read_text())
attempts=[]
for n in ['strong_null_alternating','bounded_null_impulse','strong_null_alternating_serial','strong_null_alternating_isolated']:
 d=P/'results'/n;b=json.loads((d/'BENCHMARK.json').read_text());res=json.loads((d/'RECORD_RESIDUAL.json').read_text())
 baseline=P/'inputs/receipt-corpus'/('bounded_null_impulse' if n=='bounded_null_impulse' else 'strong_null_alternating')
 assert (d/'RECORD_RESIDUAL.json').read_bytes()==(baseline/'RECORD_RESIDUAL.json').read_bytes()
 attempts.append({'output_directory':f'results/{n}','benchmark':b,'record_residual_matches_parent_bytes':True,'co_schedule':'no other campaign verifier concurrent' if n.endswith('isolated') else 'brief overlap with another new campaign control; not an isolated timing comparison','scalar_readings_checked':res['scalar_readings_checked']})
gate=json.loads((P/'results/strong_null_alternating_isolated/RESIDUAL_PREFLIGHT.json').read_text())
comparison={'status':'CONSTRUCTOR_BENCHMARK','physical_promotion':0,'historical_full_strong_control':old,'new_isolated_strong_control':new,'observed_wall_seconds_saved':old['wall_seconds']-new['wall_seconds'],'observed_wall_reduction_fraction':1-new['wall_seconds']/old['wall_seconds'],'observed_speed_ratio':old['wall_seconds']/new['wall_seconds'],'observed_peak_rss_reduction_fraction':1-new['peak_rss_kib']/old['peak_rss_kib'],'comparison_limit':'Historical baseline versus fresh isolated optimized run in same development runtime, not an interleaved randomized benchmark or hardware-independent guarantee','all_completed_new_attempts':attempts,'completed_new_all_readings_executions':4,'total_readings_checked_including_repeats':4*18790154,'true_proposal_residual_lower_readable':float(F(*gate['true_proposal_residual_frobenius_lower'])),'threshold_readable':float(F(*gate['selection_threshold'])),'positive_certificate_byte_identical':(P/'results/bounded_null_impulse/CERTIFICATE.json').read_bytes()==(P/'inputs/receipt-corpus/bounded_null_impulse/CERTIFICATE.json').read_bytes(),'all_attempts_retained':True,'setup_note':'An initial unittest invocation from the parent directory failed to import the test module; the corrected working-directory invocation passed. No data record was changed.'}
(P/'BENCHMARK_COMPARISON.json').write_text(json.dumps(comparison,indent=2))
(P/'PROVENANCE.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Same-constructor exact derivation, residual receipt regression and fresh full-record computation','parent_capture':'2026-10-17T192300Z-codex-sketch-blind-audit-84e2c6d1','parent_merge_commit':'9c7a223e4d1d2eedc36d51dd48ba00e055de3aa8','parent_source_verifier_sha256':'6398ae88749cb0e88d6b0b216a8cf6da641a5484301b6bbe597db5f71a2cfedb','independent_review':'pending; review HOLD #177 unchanged','physical_promotion':0,'lane':'development; no registry entry','code_freeze':'IMPLEMENTATION_FREEZE.json','record_and_proposal_bindings':'RECORD_RESIDUAL.json in each execution directory','no_new_apparatus_measurements':True,'source_operator_or_nominal_modes_used':False},indent=2))
print(json.dumps({k:comparison[k] for k in ['observed_wall_seconds_saved','observed_wall_reduction_fraction','observed_speed_ratio','positive_certificate_byte_identical']},indent=2))

"""Replay preflight on exact archived residuals, not a fresh all-readings run."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json
import numpy as np
from residual_preflight import residual_preflight
ROOT=Path(__file__).resolve().parent;PARENT=ROOT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[('baseline_v02',PARENT/'observer-work/certified-v02',PARENT/'observer-work/output/PROPOSAL.npz')]
for n in ['coherent_dc','dense_sign','ramp','single_vector']:
    cases.append((n,PARENT/f'noise-campaign/results/certificate-{n}',PARENT/f'noise-campaign/results/new-{n}/PROPOSAL.npz'))
for n in ['bounded_null_impulse','bounded_null_alternating','strong_null_alternating']:
    cases.append((n,PARENT/f'sketch-blind-work/results/certificate-{n}',PARENT/f'sketch-blind-work/results/proposal-{n}/PROPOSAL.npz'))
contract=json.loads((ROOT/'inputs/FROZEN_CONTRACT.json').read_text());T=F(*contract['spectral_rule']['selection_threshold']);rows=[]
for n,d,p in cases:
    residual=json.loads((d/'RECORD_RESIDUAL.json').read_text());cert=json.loads((d/'CERTIFICATE.json').read_text())
    assert residual['input_sha256']['proposal']==sha(p),(n,'Proposal hash mismatch')
    assert residual['input_sha256']['contract']==sha(ROOT/'inputs/FROZEN_CONTRACT.json')
    with np.load(p,allow_pickle=False) as z:
        coeff=z['coeff'];bound=sum(int(v) for v in np.max(np.abs(coeff[1:]),axis=1))
    gate=residual_preflight(F(*residual['exact_weighted_squared_error']),bound,T)
    new_status='HOLD' if gate['status']=='EARLY_HOLD' else cert['status']
    assert new_status==cert['status']
    rows.append({'case':n,'scope':'archived exact residual replay; not a fresh record verification','residual_receipt_sha256':sha(d/'RECORD_RESIDUAL.json'),'parent_certificate_sha256':sha(d/'CERTIFICATE.json'),'input_sha256':residual['input_sha256'],'old_status':cert['status'],'preflight':gate,'composed_status':new_status,'decision_preserved':True})
(ROOT/'RECEIPT_REPLAY.json').write_text(json.dumps({'status':'PASS','cases':rows,'case_count':len(rows),'full_new_runs_claimed':False,'physical_promotion':0},indent=2))
print([(r['case'],r['preflight']['status'],r['composed_status']) for r in rows])

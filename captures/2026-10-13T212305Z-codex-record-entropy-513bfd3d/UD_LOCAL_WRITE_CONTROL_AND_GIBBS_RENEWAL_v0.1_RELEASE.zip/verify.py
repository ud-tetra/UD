"""Local write fanout, switching work and exact thermal refresh certificates."""
from pathlib import Path
from fractions import Fraction as F
import json
root=Path(__file__).resolve().parent
src=root/'inputs.json'
if src.exists():inp=json.loads(src.read_text())
else:
 inp={'boundary':json.loads((root.parent/'carrier_write/boundary_source.json').read_text()),
 'encoding':json.loads((root.parent/'retention_encoding/results.json').read_text()),
 'comparison':json.loads((root.parent/'area_cost/results.json').read_text())}
faces=inp['boundary']['boundary_face_labels'];N=len(faces);size=2**N
edges=[(i,j) for i in range(N) for j in range(i+1,N) if len(set(faces[i])&set(faces[j]))==2]
neighbors=[[j for j in range(N) if (min(i,j),max(i,j)) in edges] for i in range(N)]
path=inp['encoding']['optimal_monotone_path_masks']
def energy(m):return 2*sum(((m>>i)&1)!=((m>>j)&1) for i,j in edges)
gates=[];ledger=[]
for k,(old,new) in enumerate(zip(path,path[1:])):
 bit=(old^new).bit_length()-1;assert old^new==1<<bit
 parent=None if k==0 else next(j for j in neighbors[bit] if old&(1<<j))
 gates.append({'target':bit,'parent':parent,'carrier_seed':k==0})
 before=2*sum(((old>>bit)&1)!=((old>>j)&1) for j in neighbors[bit])
 after=2*sum(((new>>bit)&1)!=((new>>j)&1) for j in neighbors[bit])
 assert -before+after==energy(new)-energy(old)
 ledger.append({'target':bit,'switch_off_work_in_J':-before,'restore_work_in_J':after,
 'net_work_in_J':after-before,'post_gate_memory_energy_in_J':energy(new)})
for r in (0,1):
 m=r # local carrier-to-bit-0 seed
 for gate in gates[1:]:
  if (m>>gate['parent'])&1:m^=1<<gate['target']
 assert m==(size-1 if r else 0)
for gate in gates[1:]:
 p,t=gate['parent'],gate['target'];assert (min(p,t),max(p,t)) in edges
 def cnot(m):return m^(1<<t) if (m>>p)&1 else m
 assert len({cnot(m) for m in range(size)})==size
 assert all(cnot(cnot(m))==m for m in range(size))
assert sum(z['net_work_in_J'] for z in ledger)==0
assert sum(z['switch_off_work_in_J'] for z in ledger)==-36
assert sum(z['restore_work_in_J'] for z in ledger)==36
assert max(energy(m) for m in path)==10

# Exact Gibbs refresh: swap a correlated old bath with a fresh matched-energy cell.
# Classical certificate supplements the general quantum swap identity.
old_joint={(0,0):F(1,3),(0,1):F(1,6),(1,0):F(1,6),(1,1):F(1,3)}
for q in (F(1,4),F(1,28)):
 fresh=(1-q,q);new_joint={}
 for (m,old),p in old_joint.items():
  for new,pnew in enumerate(fresh):
   # outgoing reservoir takes old; refreshed bath takes new
   new_joint[m,new]=new_joint.get((m,new),F(0))+p*pnew
 assert all(new_joint[m,b]==F(1,2)*fresh[b] for m in (0,1) for b in (0,1))
 # Pair swap conserves energy for either nonzero matched gap.
 for a in (0,1):
  for b in (0,1):assert 2*a+2*b==2*b+2*a and 6*a+6*b==6*b+6*a

out={'status':'PASS under declared protocol','physical_promotion':0,'independent_review':'OPEN','lane':'development — no registry entry',
 'local_ground_write_gates':gates,'conditional_R1_memory_switch_work':ledger,
 'ground_mean_switch_off_work_in_J':'-18','ground_mean_restore_work_in_J':'18','ground_mean_net_write_work_in_J':'0',
 'onehot_mean_switch_off_work_in_J':'0','onehot_mean_restore_work_in_J':'3','onehot_mean_net_write_work_in_J':'3',
 'ground_peak_conditional_memory_energy_in_J':10,
 'bath_renewal':'matched-energy SWAP with fresh independent Gibbs stream; exports old correlations',
 'renewal_swap_work':'0','fresh_bath_pair_energy_exact_in_J':'5/7',
 'bath_pair_count_for_32_storage_updates':32,'incoming_stream_energy_inventory_in_J':'160/7',
 'site_control_renewal':'SWAP with independent uniform degenerate 12-state cell',
 'comparison_32_storage_updates':{e['encoding']:e['rows'][-1] for e in inp['comparison']['encodings']},
 'clock_latency':{'onehot':'tau_g + 32 tau_b','ground':'12 tau_g + 32 tau_b'},
 'locality_scope':'write gates local to one memory edge; thermal collision local star, not proved two-local',
 'remaining_sources':'bond/coupling switches, timing, bath stream preparation/transport, physical pulse losses, readout and reset',
 'finite_closed_bath_cyclic_reuse':'not supplied by refresh stream','G_input':False}
# Repeated cost comparison: kBT units, eta recovers memory switching energy,
# gamma is equal excess work per write gate, c0 common remaining overhead.
import math
K=math.log(3)/2
compare=out['comparison_32_storage_updates']
bh=compare['one_hot']['memory_cycle_work_lower_bound_display_in_kBT']
bg=compare['ground']['memory_cycle_work_lower_bound_display_in_kBT']
ratio=compare['ground']['retained_information_display_nats']/compare['one_hot']['retained_information_display_nats']
out['cost_law_kBT']={'onehot':'b_h + gamma + c0','ground':'b_g + 12 gamma + 18 betaJ (1-eta) + c0',
 'b_h_display':bh,'b_g_display':bg,'betaJ':'(ln3)/2',
 'eta_scope':'memory bond-switch energy recovery only; other pulse/control losses in gamma',
 'memory_recovery_threshold_for_lower_total_bound_at_gamma0_display':1-(bh-bg)/(18*K),
 'gate_overhead_threshold_at_eta1_display_in_kBT':(bh-bg)/11,
 'actual_reset_and_common_overhead':'not numerically assigned; laws are lower bounds plus declared excess costs'}
assert ratio>12 and ratio*bh-bg-18*K>0
out['information_per_cost_comparison_scope']='ground wins within common nonnegative gamma/c0 and eta in [0,1] ledger; different technology costs need separate comparison'
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: 12 local write gates, signed switching work, Gibbs refresh factorization')
print('mean ground switching work: -18J + 18J = 0; peak branch energy 10J')
print('32 matched Gibbs pairs: incoming energy inventory 160J/7, not dissipative work')

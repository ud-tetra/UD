# Local write and bath refresh

Run `python3 verify.py` with Python's standard library. The supplied inputs.json contains exact boundary labels and earlier results. Proof, switching ledger, refresh certificates and repeated comparison are in this bundle.

Development — no registry entry. Physical promotion 0; independent review OPEN.

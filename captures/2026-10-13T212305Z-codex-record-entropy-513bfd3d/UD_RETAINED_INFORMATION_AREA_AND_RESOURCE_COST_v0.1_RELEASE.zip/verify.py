"""Retained information density and typed memory-cycle thermodynamic bounds."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import json,math
root=Path(__file__).resolve().parent
source=root/'boundary_source.json'
if not source.exists():source=root.parent/'carrier_write/boundary_source.json'
faces=json.loads(source.read_text())['boundary_face_labels'];N=len(faces);size=2**N
edges=[(i,j) for i in range(N) for j in range(i+1,N) if len(set(faces[i])&set(faces[j]))==2]
neighbors=[[j for j in range(N) if (min(i,j),max(i,j)) in edges] for i in range(N)]
def energy(m):return 2*sum(((m>>i)&1)!=((m>>j)&1) for i,j in edges)
E=[energy(m) for m in range(size)];K=math.log(3)/2
Z=sum(F(1,3)**(v//2) for v in E);assert Z==F(2**23,3**13)
logZ=23*math.log(2)-13*math.log(3)
trans=[]
for m in range(size):
 flips=[]
 for i in range(N):
  ones=sum((m>>j)&1 for j in neighbors[i]);maj=int(ones>=2)
  q=1 if abs(2*ones-3)==3 else 7
  a=q if 1-((m>>i)&1)!=maj else 28-q
  flips.append((m^(1<<i),a))
 trans.append(flips+[(m,336-sum(a for _,a in flips))])
def step(p):
 out=defaultdict(int)
 for m,w in p.items():
  for t,a in trans[m]:out[t]+=w*a
 return dict(out)
def entropy(weights,den):
 return -sum((w/den)*math.log(w/den) for w in weights.values() if w)
results=[]
for name,word in [('one_hot',1),('ground',size-1)]:
 p0={0:1};p1={word:1};den=1;write=F(E[word],2);rows=[]
 for r in range(33):
  assert sum(p0.values())==sum(p1.values())==den
  union=p0.keys()|p1.keys();mixed={m:p0.get(m,0)+p1.get(m,0) for m in union}
  Hbar=entropy(mixed,2*den);Hcond=(entropy(p0,den)+entropy(p1,den))/2;I=Hbar-Hcond
  meanE=F(sum(w*E[m] for m,w in mixed.items()),2*den)
  Q=write-meanE
  D=F(sum(abs(p0.get(m,0)-p1.get(m,0)) for m in union),2*den)
  sigma=Hbar-math.log(2)+K*float(Q)
  reset=Hbar-K*float(meanE)
  memory_cycle=K*float(write)+reset
  assert sigma>=-1e-11
  assert abs(memory_cycle-(math.log(2)+sigma))<1e-11
  # Independent Gibbs-relative-entropy evaluation of reset free-energy change.
  Dg=sum((w/(2*den))*(math.log(w/(2*den))+K*E[m]+logZ) for m,w in mixed.items() if w)
  assert abs(reset-(logZ-Dg))<1e-11
  if r in (0,1,8,16,32):
   rows.append({'updates':r,'retained_information_display_nats':I,
    'information_density_coefficient_of_1_over_a0':I/12,
    'optimal_error_exact':str((1-D)/2),'memory_entropy_display_nats':Hbar,
    'conditional_memory_entropy_display_nats':Hcond,
    'mean_memory_energy_exact_in_J':str(meanE),'cumulative_bath_heat_exact_in_J':str(Q),
    'storage_marginal_entropy_production_display':sigma,
    'reset_work_lower_bound_display_in_kBT':reset,
    'memory_cycle_work_lower_bound_display_in_kBT':memory_cycle,
    'memory_cycle_bound_with_accessible_reference_display_in_kBT':memory_cycle-I,
    'retained_nats_per_memory_cycle_bound_in_kBT':I/memory_cycle})
  if r<32:p0=step(p0);p1=step(p1);den*=336
 results.append({'encoding':name,'pulse_work_exact_in_J':str(write),'rows':rows})
ratio=results[1]['rows'][-1]['retained_information_display_nats']/results[0]['rows'][-1]['retained_information_display_nats']
out={'status':'PASS under declared model','lane':'development — no registry entry',
 'physical_promotion':0,'independent_review':'OPEN','area':'12 a0',
 'information_density':'I(R:M_r)/(12 a0); not thermodynamic horizon entropy density',
 'betaJ':'(ln3)/2; declared replay point','initial_blank_preparation_work_bound_in_kBT':logZ,
 'initial_blank_preparation_work_bound_exact':'23 ln2 - 13 ln3',
 'encodings':results,'retained_information_density_ratio_at_32_display':ratio,
 'cycle_bound_scope':'memory returned to blank by blind reset, outgoing baths exported, source reference unavailable; bound not complete apparatus cost',
 'fresh_resource_vector_at_32':{'bath_qubits':64,'degenerate_uniform_12_state_site_controls':32,'memory_bits':12},
 'controller_bath_renewal_and_readout_cost':'OPEN; no actual complete-cost ranking',
 'G_input':False}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: exact states/energies; two independent reset-bound evaluations')
for enc in results:
 row=enc['rows'][-1]
 print(enc['encoding'],json.dumps(row))
print('information density ratio',ratio,'preparation bound/kBT',logZ)

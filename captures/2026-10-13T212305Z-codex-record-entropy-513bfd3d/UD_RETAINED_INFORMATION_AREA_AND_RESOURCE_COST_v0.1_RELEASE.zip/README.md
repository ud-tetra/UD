# Retained information, area and costs

Run `python3 verify.py` (standard library). Exact states, rational energies/errors and independent reset-bound expressions are checked. Logarithm values are floating displays. Read the report for the distinction between memory-cycle bounds and unclosed complete apparatus costs.

Physical promotion 0; independent review OPEN. Development — no registry entry.

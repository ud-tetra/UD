"""Common-deadline retention and seed/fanout fault propagation."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import json,math
root=Path(__file__).resolve().parent
src=root/'inputs.json'
if src.exists():inp=json.loads(src.read_text())
else:inp=json.loads((root.parent/'local_control_renewal/results.json').read_text())
boundary=root/'boundary_source.json'
if not boundary.exists():boundary=root.parent/'carrier_write/boundary_source.json'
faces=json.loads(boundary.read_text())['boundary_face_labels'];N=len(faces);size=2**N;full=size-1
edges=[(i,j) for i in range(N) for j in range(i+1,N) if len(set(faces[i])&set(faces[j]))==2]
neighbors=[[j for j in range(N) if (min(i,j),max(i,j)) in edges] for i in range(N)]
gates=inp['local_ground_write_gates']
trans=[]
for m in range(size):
 flips=[]
 for i in range(N):
  ones=sum((m>>j)&1 for j in neighbors[i]);maj=int(ones>=2)
  q=1 if abs(2*ones-3)==3 else 7
  a=q if 1-((m>>i)&1)!=maj else 28-q
  flips.append((m^(1<<i),a))
 trans.append(flips+[(m,336-sum(a for _,a in flips))])
def step(p):
 out=defaultdict(int)
 for m,w in p.items():
  for t,a in trans[m]:out[t]+=w*a
 return dict(out)
def H(p,den):return -sum(w/den*math.log(w/den) for w in p.values() if w)
def metrics(p0,p1,den,seed):
 # Normalize post-seed binary mixtures with one extra exact denominator.
 a,b=seed.numerator,seed.denominator
 keys=p0.keys()|p1.keys()
 r0={m:(b-a)*p0.get(m,0)+a*p1.get(m,0) for m in keys}
 r1={m:a*p0.get(m,0)+(b-a)*p1.get(m,0) for m in keys}
 d0=F(sum(abs(p0.get(m,0)-p1.get(m,0)) for m in keys),2*den)
 d=F(sum(abs(r0[m]-r1[m]) for m in keys),2*den*b)
 assert d==(1-2*seed)*d0
 error=(1-d)/2
 assert error==seed+(1-2*seed)*(1-d0)/2 and error>=seed
 mix={m:r0[m]+r1[m] for m in keys}
 info=H(mix,2*den*b)-(H(r0,den*b)+H(r1,den*b))/2
 return {'seed_fault':str(seed),'optimal_error_exact':str(error),'error_display':float(error),
 'information_display_nats':info,'information_density_coefficient_of_1_over_a0':info/12}

cases=[];ground_ideal_error=None
# Ground initial fanout errors are bijective with the 11 child-parent parities.
for fault in (F(0),F(1,2000),F(1,100),F(1,20)):
 a,b=fault.numerator,fault.denominator
 p={}
 for m in range(size):
  if m&1:continue
  k=sum(((m>>z['target'])^(m>>z['parent']))&1 for z in gates[1:])
  w=a**k*(b-a)**(11-k)
  if w:p[m]=w
 den=b**11;assert sum(p.values())==den
 # Root bit is always S, even if fanout gates have faults.
 assert all(not (m&1) for m in p)
 initial_entropy=H(p,den)
 hq=0 if not fault else -float(fault)*math.log(float(fault))-(1-float(fault))*math.log(1-float(fault))
 assert abs(initial_entropy-11*hq)<1e-11
 for r in range(33):
  if r in (0,32):
   other={m^full:w for m,w in p.items()}
   rows=[metrics(p,other,den,ps) for ps in (F(0),F(1,10000),F(1,1000),F(1,100))]
   cases.append({'encoding':'ground','fanout_fault':str(fault),'storage_updates':r,
    'write_slots':12,'total_slots':12+r,'rows':rows})
   if fault==0 and r==32:ground_ideal_error=F(rows[0]['optimal_error_exact'])
   if fault==F(1,2000) and r==32:assert F(rows[1]['optimal_error_exact'])<F(1,100)
  if r<32:p=step(p);den*=336
# One-hot has only the seed fault; compare both 32-storage and 44-total-slot cases.
p0={0:1};p1={1:1};den=1
for r in range(44):
 if r in (0,32,43):cases.append({'encoding':'one_hot','fanout_fault':'not applicable','storage_updates':r,
 'write_slots':1,'total_slots':1+r,
 'rows':[metrics(p0,p1,den,ps) for ps in (F(0),F(1,10000),F(1,1000),F(1,100))]})
 if r<43:p0=step(p0);p1=step(p1);den*=336
threshold=(F(1,100)-ground_ideal_error)/(1-2*ground_ideal_error)
assert 0<threshold<F(1,1000)
# Independent three-seed majority is a distinct candidate, not fanout repair.
from itertools import product
seed_majority=[]
for p in (F(1,1000),F(1,100)):
 error=sum((p**sum(s)*(1-p)**(3-sum(s)) for s in product((0,1),repeat=3) if sum(s)>=2),F(0))
 assert error==3*p*p-2*p*p*p and error<threshold
 seed_majority.append({'single_seed_error':str(p),'independent_three_seed_majority_error':str(error)})
out={'status':'PASS under declared fault channel','physical_promotion':0,'independent_review':'OPEN',
 'lane':'development — no registry entry','clock_choice':'one write gate and one full collision/refresh step each take one declared slot',
 'common_deadline_slots':44,'seed_model':'R -> S=R XOR Bernoulli(p_s)',
 'fanout_model':'independent target XOR fault after each of 11 neighbor CNOTs, before bond restoration',
 'exact_seed_error_law':'e(p_s)=p_s+(1-2p_s)e(0)',
 'source_information_ceiling':'I(R:M_r) <= ln2-h(p_s)',
 'ground_seed_fault_ceiling_for_error_le_1percent_at_32_exact':str(threshold),
 'ground_seed_fault_ceiling_display':float(threshold),'cases':cases,
 'three_seed_conditional_candidate':seed_majority,
 'noise_energy_resource':'OPEN; fault environment not supplied, ideal cost thresholds not reused for noisy runs',
 'fault_rates_empirical':False,'G_input':False}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: exact seed-error law; independent fanout entropy; common-deadline cases')
print('seed threshold',float(threshold))
for c in cases:
 if c['storage_updates']:
  print(c['encoding'],c['fanout_fault'],c['storage_updates'],[(r['seed_fault'],r['error_display'],r['information_display_nats']) for r in c['rows']])

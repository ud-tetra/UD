from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path(__file__).resolve().parent;work=root.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'results.json').read_text())['status']=='PASS under declared fault channel'
shutil.copyfile(work/'carrier_write/boundary_source.json',root/'boundary_source.json')
shutil.copyfile(work/'local_control_renewal/results.json',root/'inputs.json')
dep=root/'dependencies';dep.mkdir(exist_ok=True)
parent=work/'UD_LOCAL_WRITE_CONTROL_AND_GIBBS_RENEWAL_v0.1_RELEASE.zip'
shutil.copyfile(parent,dep/parent.name)
receipt={'status':'PASS under declared choices','physical_promotion':0,'independent_review':'OPEN',
 'lane':'development — no registry entry','parent_SHA256':sha(parent),
 'source_SHA256':{n:sha(work/'project_sources'/n) for n in ['20-UD_COEFFICIENT_PROVENANCE_LEDGER_v0.39-2-.md','21-UD_GOVERNANCE_CRL2_SUBDIVISION_v1.0.md']},
 'scope':'exact noise and deadline test; source receipt majority conditional only; physical rate and cost OPEN',
 'external_updates':'none','G_input':False}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts)
(root/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(root)}\n' for p in files))
out=work/'UD_WRITE_FAULT_AND_COMMON_DEADLINE_v0.1_RELEASE.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[root/'SHA256SUMS']:z.write(p,p.relative_to(root))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps({'file':str(out),'bytes':out.stat().st_size,'SHA256':sha(out)}))

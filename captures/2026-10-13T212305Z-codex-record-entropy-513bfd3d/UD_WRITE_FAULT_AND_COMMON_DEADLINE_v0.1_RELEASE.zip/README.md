# Write faults and deadline

Run `python3 verify.py` using the standard library. inputs.json and boundary_source.json supply the prior local gate and topology data. The replay uses exact integer probabilities and fractions; logarithm outputs are floating displays.

All fault rates and clock ratios are declared test inputs, not empirical or native UD laws. Development — no registry entry. Physical promotion 0; independent review OPEN.

"""Exact write map and retained binary information under boundary thermal updates."""
from pathlib import Path
from itertools import combinations
from fractions import Fraction as F
from collections import defaultdict
import json,math
root=Path(__file__).resolve().parent
source=root/'boundary_source.json'
if not source.exists():source=root.parent/'boundary_memory/boundary_source.json'
faces=[tuple(f) for f in json.loads(source.read_text())['boundary_face_labels']]
core=(0,1,2,3)
cells=[core]+[tuple(sorted(f+(4+i,))) for i,f in enumerate(combinations(core,3))]
labels=[s for k in range(1,5) for s in sorted({s for c in cells for s in combinations(c,k)})]
idx={s:i for i,s in enumerate(labels)};n=len(labels)
faceidx=[idx[f] for f in faces];N=len(faces);size=2**N
edges=[(i,j) for i in range(N) for j in range(i+1,N) if len(set(faces[i])&set(faces[j]))==2]
neighbors=[[j for j in range(N) if (min(i,j),max(i,j)) in edges] for i in range(N)]
masks={faceidx[f]:1<<f for f in range(N)}
assert n==47 and len(edges)==18
# Full write permutation U|j,m>=|j,m XOR mask(j)>.
for j in range(n):
 image={m^masks.get(j,0) for m in range(size)}
 assert len(image)==size
 assert all((m^masks.get(j,0))^masks.get(j,0)==m for m in range(size))
assert len({masks.get(j,0) for j in range(n)})==13

D=[[0]*n for _ in range(n)]
for j,s in enumerate(labels):
 if len(s)>1:
  for k in range(len(s)):D[idx[s[:k]+s[k+1:]]][j]=(-1)**k
B=[[D[j][i]-D[i][j] for j in range(n)] for i in range(n)]
assert all(not B[i][j] for i in faceidx for j in faceidx)
assert any(B[i][j] for i in faceidx for j in range(n) if j not in faceidx)

def energy(m):return 2*sum(((m>>i)&1)!=((m>>j)&1) for i,j in edges)
assert energy(0)==0 and all(energy(1<<i)==6 for i in range(N))
# Rational thermal kernel at x=1/3. Common denominator 336 per step.
transitions=[]
for m in range(size):
 flips=[]
 for i in range(N):
  ones=sum((m>>j)&1 for j in neighbors[i]);majority=int(ones>=2)
  qhigh=1 if abs(2*ones-3)==3 else 7 # qhigh /28
  opposite=1-((m>>i)&1)
  a=qhigh if opposite!=majority else 28-qhigh
  flips.append((m^(1<<i),a))
 stay=336-sum(a for _,a in flips)
 assert stay>0
 transitions.append(flips+[(m,stay)])
def step(weights):
 out=defaultdict(int)
 for m,w in weights.items():
  for t,a in transitions[m]:out[t]+=w*a
 return dict(out)
def mi_binary(p0,p1,den):
 out=0.
 for m in p0.keys()|p1.keys():
  a=p0.get(m,0);b=p1.get(m,0)
  if a:out+=a/(2*den)*math.log(2*a/(a+b))
  if b:out+=b/(2*den)*math.log(2*b/(a+b))
 return out
initial=[{0:1},{1:1}];current=initial;den=1;rows=[];previous_tv=F(1)
for r in range(33):
 assert all(sum(p.values())==den for p in current)
 union=current[0].keys()|current[1].keys()
 tv=F(sum(abs(current[0].get(m,0)-current[1].get(m,0)) for m in union),2*den)
 assert tv<=previous_tv;previous_tv=tv
 E=[F(sum(w*energy(m) for m,w in p.items()),den) for p in current]
 if r in (0,1,2,4,8,16,32):
  probs=[F(sum(w for m,w in p.items() if m&1),den) for p in current]
  rows.append({'updates':r,'full_memory_trace_distance':str(tv),
   'optimal_equal_prior_error':str((1-tv)/2),'reference_memory_information_display_nats':mi_binary(*current,den),
   'target_bit_one_probabilities':[str(v) for v in probs],
   'conditional_memory_energy_in_J':[str(v) for v in E],
   'mean_memory_energy_in_J':str(sum(E)/2),
   'cumulative_mean_bath_heat_in_J':str(3-sum(E)/2)})
 if r==1:
  assert tv==F(11,12) and (1-tv)/2==F(1,24)
  assert E==[F(3,14),F(81,14)] and sum(E)/2==3
 if r<32:current=[step(p) for p in current];den*=336

# Finite-temperature full-support Gibbs pointer: imperfect write without a blank.
thermal_weights={m:3**(14-energy(m)//2) for m in range(size)}
thermal_den=sum(thermal_weights.values())
flipped={m^1:w for m,w in thermal_weights.items()}
thermal_tv=F(sum(abs(thermal_weights[m]-flipped[m]) for m in range(size)),2*thermal_den)
thermal_work=F(sum(w*(energy(m^1)-energy(m)) for m,w in thermal_weights.items()),2*thermal_den)
assert 0<thermal_tv<1 and thermal_work>0
assert thermal_tv==F(51,64) and thermal_work==F(25,12)
same_neighbors=F(sum(w for m,w in thermal_weights.items() if len({(m>>j)&1 for j in neighbors[0]})==1),thermal_den)
assert same_neighbors==F(133,192)
assert {m^1:1 for m in range(size)}=={m:1 for m in range(size)}
out={'status':'PASS','lane':'development — no registry entry','physical_promotion':0,'independent_review':'OPEN',
 'carrier_dimension':n,'memory_dimension':size,'write_basis_involution_checks':n*size,
 'write':'U=P_out tensor I + sum_f P_f tensor X_f',
 'blank_memory':'all-zero ferromagnetic ground configuration; declared resource',
 'initial_boundary_readout_alphabet':13,'binary_test':'interior core cell vs first exposed face, equal prior',
 'initial_reference_memory_information':'ln2','binary_mean_write_work':'3J for real basis inputs',
 'general_mean_write_work':'6J p_boundary + Tr[(Q H_C Q-H_C) rho]',
 'native_energy_covariance_of_write':'fails; driven control/resource required',
 'retention_kernel':'uniform-site thermal conditional resampling at x=1/3',
 'retention_checks':rows,'long_time_trace_distance':0,
 'Gibbs_pointer_binary_write':{'trace_distance':str(thermal_tv),'optimal_equal_prior_error':str((1-thermal_tv)/2),
 'reference_memory_information_display_nats':mi_binary(thermal_weights,flipped,thermal_den),
 'mean_write_work_in_J':str(thermal_work)},
 'mixing_minorization':'P^12(m,t) >= 336^(-12); alpha=4096/336^12',
 'native_J_epsilon_clock_bath_supply':'OPEN','G_input':False}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: write involution, energy formula structure, exact thermal retention')
for row in rows:
 print(row['updates'],'D=',float(F(row['full_memory_trace_distance'])),'Perror=',float(F(row['optimal_equal_prior_error'])),
       'I=',row['reference_memory_information_display_nats'],'Qbath/J=',float(F(row['cumulative_mean_bath_heat_in_J'])))

# Carrier write and retained distinguishability

Run `python3 verify.py` with Python's standard library. The included boundary_source.json supplies the exact prior boundary labels. Exact rational retention results are saved to results.json. Read the proof for candidate scope and energy/resource limitations.

Physical promotion 0; independent review OPEN. Development — no registry entry.

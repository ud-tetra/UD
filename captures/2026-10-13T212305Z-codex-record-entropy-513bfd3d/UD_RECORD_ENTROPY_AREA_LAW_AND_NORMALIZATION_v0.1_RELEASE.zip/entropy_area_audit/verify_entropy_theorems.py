"""Exact finite-record and curvature checks; no G or Planck scale input."""
from itertools import combinations,product
from fractions import Fraction as Q
from collections import defaultdict
from pathlib import Path
import json

def primes(n):
 out={};p=2
 while p*p<=n:
  while n%p==0:out[p]=out.get(p,0)+1;n//=p
  p+=1
 if n>1:out[n]=out.get(n,0)+1
 return out
def entropy(probabilities):
 # Exact sum of rational coefficients times logarithms of primes.
 assert sum(probabilities,Q(0))==1 and all(p>=0 for p in probabilities)
 out=defaultdict(Q)
 for p in probabilities:
  if not p:continue
  for r,e in primes(p.denominator).items():out[r]+=p*e
  for r,e in primes(p.numerator).items():out[r]-=p*e
 return {r:c for r,c in out.items() if c}
def scaled(d,a):return {r:a*c for r,c in d.items() if a*c}

labels=[z for n in range(1,5) for z in combinations(range(4),n)]
idx={z:i for i,z in enumerate(labels)};n=len(labels)
D=[[0]*n for _ in range(n)]
for j,z in enumerate(labels):
 if len(z)>1:
  for k in range(len(z)):D[idx[z[:k]+z[k+1:]]][j]=(-1)**k
def mm(A,B):return [[sum(A[i][k]*B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def mv(A,x):return [sum(a*b for a,b in zip(row,x)) for row in A]
assert n==15 and mm(D,D)==[[0]*n for _ in range(n)]
B=[[D[j][i]-D[i][j] for j in range(n)] for i in range(n)]
assert all(B[i][j]==-B[j][i] for i in range(n) for j in range(n))
e=[Q(int(len(z)==4)) for z in labels];Be=mv(B,e)
assert mv(B,Be)==[-4*z for z in e]
f=[z/2 for z in Be]
assert sum(z*z for z in f)==1 and sum(a*b for a,b in zip(e,f))==0
assert all(not f[i] or len(labels[i])==3 for i in range(n))
native=[]
for tag,p_top in [('u=0',Q(1)),('u=pi/8',Q(1,2)),('u=pi/4',Q(0))]:
 p_degree=[Q(0),Q(0),1-p_top,p_top]
 p_coordinate=[p_top*e[i]*e[i]+(1-p_top)*f[i]*f[i] for i in range(n)]
 native.append({'parameter':tag,'degree_probabilities':[str(z) for z in p_degree],
 'degree_entropy_log_coefficients':{str(r):str(c) for r,c in entropy(p_degree).items()},
 'coordinate_entropy_log_coefficients':{str(r):str(c) for r,c in entropy(p_coordinate).items()}})
assert entropy([Q(1,2),Q(1,2)])=={2:Q(1)}
assert native[0]['degree_entropy_log_coefficients']=={}
assert native[1]['degree_entropy_log_coefficients']=={'2':'1'}
assert native[2]['degree_entropy_log_coefficients']=={}
assert native[2]['coordinate_entropy_log_coefficients']=={'2':'2'}

records=[]
for q in [Q(1,2),Q(1,4)]:
 for count in [1,2,4,8]:
  states=list(product([0,1],repeat=count))
  probabilities=[q**sum(s)*(1-q)**(count-sum(s)) for s in states]
  h=entropy(probabilities);assert h==scaled(entropy([q,1-q]),count)
  records.append({'cells':count,'q':str(q),'entropy_log_coefficients':{str(p):str(c) for p,c in h.items()}})
correlated=entropy([Q(1,2),Q(1,2)])
assert correlated=={2:Q(1)}
assert 3**3>2**4 # h(1/2)>h(1/4), an exact nonunique entropy-density example.

# Curvature of S^2(+1) x H^2(-1), in an orthonormal product frame.
R={}
for i,j,k in [(0,1,1),(2,3,-1)]:
 for aa,bb,sg1 in [(i,j,1),(j,i,-1)]:
  for cc,dd,sg2 in [(i,j,1),(j,i,-1)]:R[aa,bb,cc,dd]=sg1*sg2*k
ric=[[sum(R.get((i,a,i,b),0) for i in range(4)) for b in range(4)] for a in range(4)]
assert ric==[[1,0,0,0],[0,1,0,0],[0,0,-1,0],[0,0,0,-1]]
scalar=sum(ric[i][i] for i in range(4));assert scalar==0
def g(a,b):return int(a==b)
for a,b,c,d in product(range(4),repeat=4):
 W=Q(R.get((a,b,c,d),0))-Q(g(a,c)*ric[b][d]-g(a,d)*ric[b][c]-g(b,c)*ric[a][d]+g(b,d)*ric[a][c],2)+Q(scalar,6)*(g(a,c)*g(b,d)-g(a,d)*g(b,c))
 assert W==0
assert ric[0][0]!=ric[2][2]

out={'status':'PASS','lane':'development — no registry entry','physical_promotion':0,'independent_review':'OPEN',
 'G_input':False,'Planck_scale_input':False,'native_carrier':{'dimension':15,'f_vector':[4,6,4,1],
 'boundary_squared_zero':True,'skew_generator':True,'top_cell_oscillator':'b(u)=cos(2u)e_top+sin(2u)*B*e_top/2','checks':native},
 'product_boundary_records':records,'perfectly_correlated_fair_N_bits_entropy':'ln(2), independently of N',
 'conditional_area_density':'k_B*h(q)/a0, only for declared independent boundary-record state and supplied area a0',
 'single_projective_register_entropy_bound':'k_B ln(m)<=k_B ln(d)',
 'physical_normalization':'UNDERDETERMINED; area rescaling changes eta while preserving this dimensionless record distribution',
 'curvature_counterexample':{'model':'S^2(+1) x H^2(-1)','Ricci_diagonal':[1,1,-1,-1],'scalar':0,'Weyl_tensor_zero':True,
 'Kahler':'product of oriented constant-curvature complex curves','Bochner_flat':'Weyl zero implies vanishing Kahler Bochner component',
 'Einstein_metric':False,'scope':'does not refute a separately specified sourced dimensional reduction; rules out inference from Bochner-flatness alone'}}
Path('exact_entropy_results.json').write_text(json.dumps(out,indent=2)+'\n')
print('Exact native entropy, conditional boundary-law and curvature checks PASS')

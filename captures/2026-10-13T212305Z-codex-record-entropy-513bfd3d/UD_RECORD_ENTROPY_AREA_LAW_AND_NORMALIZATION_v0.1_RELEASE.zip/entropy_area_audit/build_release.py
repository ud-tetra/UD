"""Hash-verified mathematical entropy audit; source PDF extracts excluded."""
from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parent;base=root.parent
result=json.loads((root/'exact_entropy_results.json').read_text());assert result['status']=='PASS'
source_paths=[base/'project_sources/20-UD_COEFFICIENT_PROVENANCE_LEDGER_v0.39-2-.md',
              base/'project_sources/21-UD_GOVERNANCE_CRL2_SUBDIVISION_v1.0.md',
              base/'project_sources/19-Unified-Dynamics-Distinction-Theory-v2.2_-Master-Manuscript.pdf']
source_audit={'date_local':'2026-10-12','timezone':'America/Chicago',
 'sources_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths},
 'external_time_generation':{'author':'Harold D. Kirk III','doi':'10.5281/zenodo.18662525',
 'library_file_id':'libfile_7f06cf4b37b8819199d21baa1cf20d50',
 'file_id':'file_00000000406481f69dad53f1f73f4975','read_pages':[1,13,14,15],
 'normalization_audit':'Equations 44-45 use Planck cutoff and Bekenstein-Hawking matching; not independent entropy-first normalization.'},
 'external_flag_manifold':{'author':'Harold D. Kirk','doi':'10.5281/zenodo.19302283',
 'version':'2.0','publication_date':'2026-03-28','metadata_read':True,'full_pdf_read':False,
 'claim_status':'Related reduction claim located; not verified or imported into Mayes UD'},
 'primary_papers':[
 {'author':'Ted Jacobson','doi':'10.1103/PhysRevLett.75.1260','arxiv':'gr-qc/9504004v2'},
 {'authors':'Christopher Eling, Raf Guedens, Ted Jacobson','doi':'10.1103/PhysRevLett.96.121301','arxiv':'gr-qc/0602001'},
 {'author':'Robert L. Bryant','arxiv':'math/0003099v3','journal':'J. Amer. Math. Soc. 14 (2001), 623-715'}],
 'external_mutation':False,'source_identity':'Kirk programme is distinct from Benjamin Walker Mayes tetrahedral UD',
 'unavailable_attachment':'Gap2_FINAL_Finite_Genesis.png; unused'}
(root/'source_audit.json').write_text(json.dumps(source_audit,indent=2)+'\n')
receipt={'exact_finite_checks':'PASS','proof_scope':'explicit finite substrate and declared coarse-graining; conditional product-boundary extension',
 'native_entropy_monotonicity':'COUNTEREXAMPLE CHECKED','single_register_positive_extensive_area_law':'NO-GO under stated projective representation',
 'conditional_boundary_area_law':'PROVED for declared independent record state and supplied areas',
 'universal_horizon_area_law':'OPEN; horizon identification and state selection not derived',
 'unique_physical_normalization':'UNDERDETERMINED from current inputs; no G backsolve performed',
 'Bochner_flat_implies_Einstein_metric':'COUNTEREXAMPLE CHECKED; separate sourced reductions not ruled out',
 'physical_promotion':0,'independent_review':'OPEN','lane':'development — no registry entry',
 'G_or_Planck_input':False,'registry_mutation':False,'site_mutation':False}
(root/'verification_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=sorted(p for p in root.iterdir() if p.is_file() and p.name!='SHA256SUMS')
(root/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files))
dest=base/'UD_RECORD_ENTROPY_AREA_LAW_AND_NORMALIZATION_v0.1_RELEASE.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[root/'SHA256SUMS']:z.write(p,root.name+'/'+p.name)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for p in files:assert hashlib.sha256(z.read(root.name+'/'+p.name)).digest()==hashlib.sha256(p.read_bytes()).digest()
print(dest)
print('SHA256',hashlib.sha256(dest.read_bytes()).hexdigest())
print(json.dumps(receipt,indent=2))

# Record entropy and area-law audit

Read the main proof before interpreting the normalization. Run `python3 verify_entropy_theorems.py` using Python 3.12; no third-party packages are needed. All finite incidence, entropy log-coefficient and curvature checks use integers or exact fractions.

The area law is conditional on the declared product boundary-record state and supplied patch areas. Physical normalization and horizon identification remain OPEN. No G or Planck-scale value is used as an input.

No independent review, physical promotion or external source/repository edits are claimed. Raw extracted manuscripts under sources/ are working intermediates and are excluded from the release.

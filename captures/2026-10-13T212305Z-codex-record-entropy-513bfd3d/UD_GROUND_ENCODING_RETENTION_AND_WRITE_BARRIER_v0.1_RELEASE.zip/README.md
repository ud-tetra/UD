# Ground encoding retention and barrier

Run `python3 verify.py` (standard library). Boundary labels are in boundary_source.json. The code computes exact finite-state probabilities, both barrier certificates, and optimal/majority readout errors. Parent release included under dependencies.

This is a declared candidate encoding/control comparison. Development — no registry entry. Physical promotion 0; independent review OPEN.

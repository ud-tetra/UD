"""Exact complementary-ground encoding, barriers and thermal retention."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict,deque
import json,math
root=Path(__file__).resolve().parent
src=root/'boundary_source.json'
if not src.exists():src=root.parent/'carrier_write/boundary_source.json'
faces=json.loads(src.read_text())['boundary_face_labels'];N=len(faces);size=2**N;full=size-1
edges=[(i,j) for i in range(N) for j in range(i+1,N) if len(set(faces[i])&set(faces[j]))==2]
neighbors=[[j for j in range(N) if (min(i,j),max(i,j)) in edges] for i in range(N)]
def cuts(m):return sum(((m>>i)&1)!=((m>>j)&1) for i,j in edges)
cut=[cuts(m) for m in range(size)]
assert [m for m in range(size) if cut[m]==0]==[0,full]
assert all(cut[m]==cut[m^full] for m in range(size))

# Exact minimal monotone flip-path maximum disagreement count.
barrier=[0]*size;prev=[None]*size
for m in sorted(range(1,size),key=int.bit_count):
 choices=[(barrier[m^(1<<i)],m^(1<<i)) for i in range(N) if m&(1<<i)]
 v,p=min(choices);barrier[m]=max(cut[m],v);prev[m]=p
path=[full]
while path[-1]:path.append(prev[path[-1]])
path.reverse()
assert len(path)==N+1 and max(cut[m] for m in path)==barrier[full]

# Independent unrestricted threshold-reachability test; revisits allowed.
def reachable(k):
 seen={0};q=deque([0])
 while q:
  m=q.popleft()
  for i in range(N):
   t=m^(1<<i)
   if t not in seen and cut[t]<=k:seen.add(t);q.append(t)
 return full in seen
unrestricted=next(k for k in range(max(cut)+1) if reachable(k))
assert unrestricted<=barrier[full]

trans=[]
for m in range(size):
 flips=[]
 for i in range(N):
  ones=sum((m>>j)&1 for j in neighbors[i]);majority=int(ones>=2)
  qhigh=1 if abs(2*ones-3)==3 else 7
  opposite=1-((m>>i)&1)
  a=qhigh if opposite!=majority else 28-qhigh
  flips.append((m^(1<<i),a))
 trans.append(flips+[(m,336-sum(a for _,a in flips))])
# Symmetric thermal dynamics: the complemented initial word remains complemented.
for m in range(size):assert {t^full:a for t,a in trans[m]}==dict(trans[m^full])
def step(p):
 out=defaultdict(int)
 for m,w in p.items():
  for t,a in trans[m]:out[t]+=w*a
 return dict(out)
def info(p,den):
 out=0.
 for m in range(size):
  a=p.get(m,0);b=p.get(m^full,0)
  if a:out+=a/den*math.log(2*a/(a+b))
 return out
p={0:1};den=1;rows=[];prior=F(1)
for r in range(129):
 assert sum(p.values())==den
 d=F(sum(abs(p.get(m,0)-p.get(m^full,0)) for m in range(size)),2*den)
 assert d<=prior;prior=d
 # Majority decoder with random tie; a feasible classical readout.
 error_majority=F(sum(w for m,w in p.items() if m.bit_count()>N//2),den)+F(sum(w for m,w in p.items() if m.bit_count()==N//2),2*den)
 assert error_majority>=(1-d)/2
 if r in (0,1,2,4,8,16,32,64,128):
  E=F(sum(w*2*cut[m] for m,w in p.items()),den)
  rows.append({'updates':r,'trace_distance':str(d),'optimal_error':str((1-d)/2),
    'majority_decoder_error':str(error_majority),'information_display_nats':info(p,den),
    'mean_memory_energy_in_J':str(E),'cumulative_mean_bath_heat_in_J':str(-E)})
 if r<=5:assert d==1 and error_majority==0
 if r==6:assert error_majority>0
 if r<128:p=step(p);den*=336

out={'status':'PASS','physical_promotion':0,'independent_review':'OPEN','lane':'development — no registry entry',
 'encoding':'R=0 -> all-zero; R=1 -> all-one, prepared blank',
 'candidate_write':'(I-P_f) tensor I + P_f tensor product_i X_i',
 'mean_endpoint_memory_write_work_for_real_test_inputs_in_J':'0',
 'nontrivial_zero_endpoint_work_encoding_unique_relative_to_blank':True,
 'minimal_monotone_barrier_in_J':2*barrier[full],
 'minimal_unrestricted_single_bit_barrier_in_J':2*unrestricted,
 'optimal_monotone_path_masks':path,
 'optimal_monotone_path_energies_in_J':[2*cut[m] for m in path],
 'thermal_Gibbs_pointer_signal_under_global_flip':0,
 'retention':rows,'long_time_distinguishability':0,
 'perfect_optimal_readout_updates':'0 through 5; full-word Hamming supports disjoint',
 'comparison_scope':'two encodings; endpoint-energy minimization exact; no claim of global lifetime optimality',
 'native_control_preparation_J_clock':'OPEN','G_input':False}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS; barriers/J:',2*barrier[full],2*unrestricted)
for row in rows:print(row['updates'],float(F(row['optimal_error'])),float(F(row['majority_decoder_error'])),row['information_display_nats'])

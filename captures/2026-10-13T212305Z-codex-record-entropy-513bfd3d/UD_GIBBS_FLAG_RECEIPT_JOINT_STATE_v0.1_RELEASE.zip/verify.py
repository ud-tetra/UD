"""Declared Gibbs flag apparatus: joint receipt state and accuracy gates."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,math
root=Path(__file__).resolve().parent
src=root/'parent_results.json'
if not src.exists():src=root.parent/'receipt_majority/results.json'
parent=json.loads(src.read_text());e0=F(parent['base_storage_errors_exact']['32']);target=F(1,100)
smax=(target-e0)/(1-2*e0)
loc=F(1,100);q=F(1,10000)
def bern(v,p):return p if v else 1-p
def H(dist):return -sum(float(w)*math.log(float(w)) for w in dist if w)
def maj(z):return int(sum(z)>=2)
rows=[]
for common in (F(0),F(1,100000),F(1,20000),F(1,10000)):
 weights={}
 for c,z0,z1,z2 in product((0,1),repeat=4):
  env=(c,z0,z1,z2);w=bern(c,common)*bern(z0,loc)*bern(z1,loc)*bern(z2,loc)
  weights[env]=w
 # Full receipt unitary |R,c,z,s> -> |R,c,z,s XOR R1 XOR c1 XOR z>.
 for R in (0,1):
  images=set()
  for env in weights:
   c,*z=env
   for old in product((0,1),repeat=3):
    new=tuple(old[i]^R^c^z[i] for i in range(3))
    assert tuple(new[i]^R^c^z[i] for i in range(3))==old
    images.add((env,new))
  assert len(images)==16*8
 error={z:F(0) for z in product((0,1),repeat=3)}
 for env,w in weights.items():
  c,*z=env;e=tuple(c^v for v in z);error[e]+=w
 assert sum(error.values())==1
 for e,w in error.items():
  k=sum(e)
  assert w==(1-common)*loc**k*(1-loc)**(3-k)+common*loc**(3-k)*(1-loc)**k
 marg=sum(w*e[0] for e,w in error.items())
 pair=sum(w*e[0]*e[1] for e,w in error.items())
 triple=error[(1,1,1)]
 m=sum(w for e,w in error.items() if maj(e))
 p3=3*loc*loc-2*loc**3
 assert marg==loc+common*(1-2*loc)
 assert pair==loc*loc+common*(1-2*loc)
 assert triple==(1-common)*loc**3+common*(1-loc)**3
 assert m==3*pair-2*triple==p3+common*(1-2*p3)
 bmin=max(F(0),2*pair-marg);bmax=min(pair,1-3*marg+3*pair)
 assert bmin<=triple<=bmax
 # Independent Gibbs decision flags, used as target XOR controls.
 combined_error=F(0)
 for env,w in weights.items():
  c,*z=env;errs=tuple(c^v for v in z)
  for d in product((0,1),repeat=4):
   wd=w
   for v in d:wd*=bern(v,q)
   decision_parity=sum(d)%2
   combined_error+=wd*int(maj(errs)^decision_parity)
 u4=(1-(1-2*q)**4)/2
 assert combined_error==m+u4-2*m*u4
 exact_final=e0+(1-2*e0)*combined_error
 robust_seed=3*pair+4*q
 robust_final=e0+(1-2*e0)*robust_seed
 assert exact_final<=robust_final
 rho=(pair-marg*marg)/(marg*(1-marg))
 rows.append({'local_flag_probability':str(loc),'shared_flag_probability':str(common),
 'receipt_marginal':str(marg),'receipt_pair_joint':str(pair),'receipt_triple_joint':str(triple),
 'receipt_average_pair_correlation_exact':str(rho),
 'joint_error_state_diagonal':{''.join(map(str,e)):str(w) for e,w in error.items()},
 'majority_error_exact':str(m),'effective_seed_error_exact':str(combined_error),
 'exact_final_error':str(exact_final),'exact_final_error_display':float(exact_final),
 'exact_model_passes':exact_final<=target,'robust_bound_passes':robust_seed<=smax,
 'robust_final_error_bound_display':float(robust_final),
 'receipt_error_entropy_display_nats':H(error.values()),
 'receipt_error_entropy_product_upper_bound_display':3*(-float(marg)*math.log(float(marg))-(1-float(marg))*math.log(1-float(marg)))})
assert rows[1]['robust_bound_passes'] and rows[1]['exact_model_passes']
assert not rows[2]['robust_bound_passes'] and rows[2]['exact_model_passes']
assert not rows[3]['exact_model_passes']
robust_c=(smax-4*q-3*loc*loc)/(3*(1-2*loc))
u4=(1-(1-2*q)**4)/2;p3=3*loc*loc-2*loc**3
exact_c=(smax-u4-(1-2*u4)*p3)/((1-2*u4)*(1-2*p3))
out={'status':'PASS conditional Gibbs-flag apparatus','physical_promotion':0,'independent_review':'OPEN',
 'lane':'development — no registry entry','state':'tau_c tensor tau_p^3 tensor tau_q^4, receipts initially pure blank',
 'receipt_joint_state':'diagonal mixture (1-c) Bern(p)^tensor3 + c complemented Bern(p)^tensor3',
 'flag_Hamiltonian':'Delta_c n_c + Delta_p sum n_zi + Delta_q sum n_dj',
 'thermal_probability_law':'p_alpha=1/(1+exp(beta Delta_alpha))',
 'receipt_copy_energy':'zero net free energy change for held source and degenerate targets; gate work/resource preparation separate',
 'flag_count_per_majority_run':8,'source-selected_gaps_and_couplings':'OPEN',
 'robust_common_flag_ceiling_exact':str(robust_c),'robust_common_flag_ceiling_display':float(robust_c),
 'exact_independent_decision_common_flag_ceiling_exact':str(exact_c),
 'exact_independent_decision_common_flag_ceiling_display':float(exact_c),
 'rows':rows,'source_provenance':'apparatus declared, not derived from current native UD source files','G_input':False}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: receipt permutation, Gibbs-state marginalization, joint moments and final-error gates')
for r in rows:print(r['shared_flag_probability'],r['receipt_pair_joint'],r['exact_final_error_display'],r['exact_model_passes'],r['robust_bound_passes'])
print('shared probability ceilings',float(robust_c),float(exact_c))

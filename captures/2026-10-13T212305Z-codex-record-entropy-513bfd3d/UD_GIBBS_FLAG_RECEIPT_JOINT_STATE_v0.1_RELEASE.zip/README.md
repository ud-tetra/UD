# Joint receipt apparatus

Run `python3 verify.py` (standard library). parent_results.json supplies the prior storage error. Receipt permutations, joint Gibbs marginalization, moments, decision flags and criterion checks are exact fractions. Decimal thresholds and entropies are displays.

The apparatus is a declared candidate. Native Hamiltonian/gap selection remains OPEN. Physical promotion 0; independent review OPEN. Development — no registry entry.

# Record energy and spatial boundary audit

Read UD_RECORD_ENERGY_AND_SPATIAL_BOUNDARY_v0.1.md. Run `python3 verify.py` (standard library) for exact matrix, unitary-permutation, five-tetrahedron topology, rank, subdivision-entropy log coefficients and thermal-SWAP entropy-balance checks.

All new physical choices remain CANDIDATE. Development — no registry entry. Physical promotion 0; independent review OPEN.

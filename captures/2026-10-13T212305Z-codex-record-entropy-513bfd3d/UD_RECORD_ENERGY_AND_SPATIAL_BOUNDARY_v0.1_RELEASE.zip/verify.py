"""Exact checks for recording dilation, energy obstruction and spatial boundary."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json, math

def mm(a,b):
 return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]
def sub(a,b):return [[x-y for x,y in zip(r,s)] for r,s in zip(a,b)]
def diag(a):return [[a[i][j] if i==j else F(0) for j in range(len(a))] for i in range(len(a))]
def tr(a):return sum(a[i][i] for i in range(len(a)))
def factors(x):
 out={};k=2
 while k*k<=x:
  while x%k==0:out[k]=out.get(k,0)+1;x//=k
  k+=1
 if x>1:out[x]=out.get(x,0)+1
 return out
def hlogs(prob):
 assert sum(prob)==1
 out={}
 for p in prob:
  if not p:continue
  for prime,e in factors(p.denominator).items():out[prime]=out.get(prime,F(0))+p*e
  for prime,e in factors(p.numerator).items():out[prime]=out.get(prime,F(0))-p*e
 return {k:v for k,v in out.items() if v}

labels=[s for k in range(1,5) for s in combinations(range(4),k)]
idx={s:i for i,s in enumerate(labels)};n=len(labels)
D=[[F(0)]*n for _ in range(n)]
for j,s in enumerate(labels):
 if len(s)>1:
  for k in range(len(s)):D[idx[s[:k]+s[k+1:]]][j]=F((-1)**k)
B=sub([[D[j][i] for j in range(n)] for i in range(n)],D)
assert mm(D,D)==[[0]*n for _ in range(n)]
assert all(B[i][j]==-B[j][i] for i in range(n) for j in range(n))
top=idx[(0,1,2,3)]
rho=[[F(int(i==top and j==top)) for j in range(n)] for i in range(n)]
comm=sub(mm(B,rho),mm(rho,B))
assert diag(comm)==[[0]*n for _ in range(n)]
assert any(x for r in comm for x in r)
assert sub(mm(B,diag(rho)),mm(diag(rho),B))==comm
assert diag(B)==[[0]*n for _ in range(n)]
# H=i*epsilon*B: dephasing sends the energy observable to zero.
# An incidence-plane pure complex state has energy +/-epsilon before writing.
a,b=next((i,j) for i in range(n) for j in range(i+1,n) if B[i][j])
energy_before=-B[a][b] # state (|a>+i|b>)/sqrt(2), in epsilon units
assert abs(energy_before)==1

# Controlled cyclic copying is a permutation on all 15^3 basis states.
def write(j,m,e):return j,(m+j)%n,(e+j)%n
images={write(j,m,e) for j in range(n) for m in range(n) for e in range(n)}
assert len(images)==n**3
assert all(write(j,0,0)==(j,j,j) for j in range(n))
# Tracing E kills unequal j,k; retaining M yields the declared instrument.
assert all((write(j,0,0)[2]==write(k,0,0)[2])==(j==k) for j in range(n) for k in range(n))

# Core tetrahedron with one new apex on each face.
core=(0,1,2,3)
cells=[core]+[tuple(sorted(face+(4+i,))) for i,face in enumerate(combinations(core,3))]
simplexes=[sorted({s for c in cells for s in combinations(c,k)}) for k in range(1,5)]
counts=[len(s) for s in simplexes]
assert counts==[8,18,16,5]
owners={f:[c for c in cells if set(f)<=set(c)] for f in simplexes[2]}
boundary=[f for f,v in owners.items() if len(v)==1]
internal=[f for f,v in owners.items() if len(v)==2]
assert len(boundary)==12 and len(internal)==4
bedges={e for f in boundary for e in combinations(f,2)}
assert all(sum(set(e)<=set(f) for f in boundary)==2 for e in bedges)
assert len(simplexes[0])-len(bedges)+len(boundary)==2

# One-hot spatial outcomes: one face or the complement, not 12 binary bits.
assert len(boundary)+1==13
# Subdivision of one category preserves coarse probability and changes entropy
# by p*ln(m) when m resolved children are equiprobable.
p=F(1,3)
for m in (2,4,8):
 children=[p/m]*m
 assert sum(children)==p
 before=hlogs([p,1-p]);after=hlogs(children+[1-p])
 delta={k:after.get(k,F(0))-before.get(k,F(0)) for k in set(before)|set(after)}
 assert {k:v for k,v in delta.items() if v}=={k:p*e for k,e in factors(m).items()}

# Independent classical SWAP certificate for the thermal entropy identity.
# Reservoir Gibbs weights (3/4,1/4), beta*(E1-E0)=ln3; system fair.
thermal=hlogs([F(3,4),F(1,4)]);fair=hlogs([F(1,2),F(1,2)])
delta_s={k:thermal.get(k,F(0))-fair.get(k,F(0)) for k in set(thermal)|set(fair)}
balance=dict(delta_s);balance[3]=balance.get(3,F(0))+F(1,4)
assert balance=={2:F(1),3:-F(1,2)} # D(fair || Gibbs), I after SWAP=0

# Finite-reservoir exact pure erasure rank obstruction, r>1 and full-rank bath.
for rank in (2,4,13):
 for bath_dim in (2,15,128):assert rank*bath_dim>bath_dim

out={'status':'PASS','lane':'development — no registry entry','physical_promotion':0,'independent_review':'OPEN',
 'copy_unitary_basis_dimension':n**3,'copy_dilation':'|j,0,0> -> |j,j,j>',
 'simplex_dephasing_covariant_with_native_H':False,
 'diagonal_native_energy_observable':'zero','complex_state_energy_before_in_epsilon_units':str(energy_before),
 'complex_state_energy_after_in_epsilon_units':'0',
 'five_tetrahedron_f_vector':counts,'chain_dimension':sum(counts),
 'exposed_faces':len(boundary),'internal_faces':len(internal),'boundary_euler_characteristic':2,
 'boundary_face_labels':boundary,'spatial_single_carrier_alphabet':13,
 'single_carrier_boundary_record_entropy_bound':'k_B ln 13; k_B ln 12 when boundary-supported',
 'refinement_resolution_increment':'k_B p ln m for equiprobable resolved children; zero for redundant copies',
 'finite_full_rank_thermal_bath_exact_pure_erasure':'impossible for local memory reset of rank>1',
 'thermal_SWAP_balance_log_coefficients':{str(k):str(v) for k,v in balance.items()},
 'native_energy_scale_epsilon':'candidate, not calibrated','G_input':False}
Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

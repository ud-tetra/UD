from pathlib import Path
import json,hashlib,zipfile,shutil
root=Path(__file__).resolve().parent
work=root.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'results.json').read_text())['status']=='PASS'
dep=root/'dependencies';dep.mkdir(exist_ok=True)
parent=work/'UD_NATIVE_PROPAGATION_AND_RECORD_ENTROPY_RATE_v0.1_RELEASE.zip'
shutil.copyfile(parent,dep/parent.name)
sources=[work/'upload/Pasted text(1).txt',work/'upload/Pasted text(2).txt',
 work/'project_sources/20-UD_COEFFICIENT_PROVENANCE_LEDGER_v0.39-2-.md',
 work/'project_sources/21-UD_GOVERNANCE_CRL2_SUBDIVISION_v1.0.md',
 work/'project_sources/12-carrier_definition.md',work/'project_sources/07-coherence_equation.md',
 work/'project_sources/08-master_action.md']
receipt={'status':'PASS under declared choices','physical_promotion':0,'independent_review':'OPEN',
 'lane':'development — no registry entry','source_SHA256':{str(p.relative_to(work)):sha(p) for p in sources},
 'parent_SHA256':sha(parent),'external_source':'Reeb–Wolf arXiv:1306.4352v3, Theorem 3',
 'external_updates':'none','unavailable_image':'Gap2_FINAL_Finite_Genesis.png, unused'}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts)
(root/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(root)}\n' for p in files))
out=work/'UD_RECORD_ENERGY_AND_SPATIAL_BOUNDARY_v0.1_RELEASE.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[root/'SHA256SUMS']:z.write(p,p.relative_to(root))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps({'file':str(out),'bytes':out.stat().st_size,'SHA256':sha(out)}))

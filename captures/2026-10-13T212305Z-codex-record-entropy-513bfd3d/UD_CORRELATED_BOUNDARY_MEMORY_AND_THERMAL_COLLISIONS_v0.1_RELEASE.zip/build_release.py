from pathlib import Path
import json,hashlib,shutil,zipfile
root=Path(__file__).resolve().parent;work=root.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'results.json').read_text())['status']=='PASS'
shutil.copyfile(work/'entropy_energy_boundary/results.json',root/'boundary_source.json')
dep=root/'dependencies';dep.mkdir(exist_ok=True)
parent=work/'UD_RECORD_ENERGY_AND_SPATIAL_BOUNDARY_v0.1_RELEASE.zip'
shutil.copyfile(parent,dep/parent.name)
source_names=['20-UD_COEFFICIENT_PROVENANCE_LEDGER_v0.39-2-.md','21-UD_GOVERNANCE_CRL2_SUBDIVISION_v1.0.md']
receipt={'status':'PASS under declared choices','physical_promotion':0,'independent_review':'OPEN',
 'lane':'development — no registry entry','parent_SHA256':sha(parent),
 'source_SHA256':{name:sha(work/'project_sources'/name) for name in source_names},
 'exact_checks':['4096 memory configurations','49152 detailed-balance flips','196608 energy-conserving collision and involution checks','tree multiplicities','refinement effective weight'],
 'scope':'memory Gibbs entropy and collision; no native carrier record coupling derived',
 'G_input':False,'external_updates':'none'}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts)
(root/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(root)}\n' for p in files))
out=work/'UD_CORRELATED_BOUNDARY_MEMORY_AND_THERMAL_COLLISIONS_v0.1_RELEASE.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[root/'SHA256SUMS']:z.write(p,p.relative_to(root))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps({'file':str(out),'bytes':out.stat().st_size,'SHA256':sha(out)}))

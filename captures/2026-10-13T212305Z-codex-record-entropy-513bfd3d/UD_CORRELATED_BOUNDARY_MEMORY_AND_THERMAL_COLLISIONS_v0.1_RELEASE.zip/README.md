# Correlated boundary memory

Read UD_CORRELATED_BOUNDARY_MEMORY_AND_THERMAL_COLLISIONS_v0.1.md. Run `python3 verify.py` using Python's standard library. Exact enumeration uses fractions; decimal entropies are display checks only.

The prerequisite five-tetrahedron boundary labels are supplied in boundary_source.json; the parent release is included under dependencies. Replay is self-contained after extracting this ZIP.

This is a declared physical candidate, not a derived native UD recorder. Physical promotion 0; independent review OPEN. Development — no registry entry.

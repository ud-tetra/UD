"""Declared boundary-memory Gibbs state and conserving collision checks."""
from fractions import Fraction as F
from collections import Counter
from itertools import product
from pathlib import Path
import json, math

root=Path(__file__).resolve().parent
source=root/'boundary_source.json'
if not source.exists():source=root.parent/'entropy_energy_boundary/results.json'
faces=json.loads(source.read_text())['boundary_face_labels']
N=len(faces)
edges=[(i,j) for i in range(N) for j in range(i+1,N) if len(set(faces[i])&set(faces[j]))==2]
neighbors=[[j for j in range(N) if (min(i,j),max(i,j)) in edges] for i in range(N)]
assert N==12 and len(edges)==18 and all(len(z)==3 for z in neighbors)
states=list(product((0,1),repeat=N))
def cuts(s,ee=edges):return sum(s[i]!=s[j] for i,j in ee)
counts=Counter(cuts(s) for s in states)
assert sum(counts.values())==2**N and counts[0]==2

# Symbolic partition P(x)=sum_k n_k x^k; x=exp(-2 beta J).
# Exact rational replay point x=1/3, beta J=(ln3)/2, not a native choice.
x=F(1,3)
Z=sum(n*x**k for k,n in counts.items())
mean_k=sum(k*n*x**k for k,n in counts.items())/Z
pi={s:x**cuts(s)/Z for s in states}
assert sum(pi.values())==1
def high_label(s,i):
 majority=int(sum(s[j] for j in neighbors[i])>=2)
 return int(s[i]!=majority)
def gap_units(s,i):return abs(sum(1 if s[j] else -1 for j in neighbors[i]))
def new_prob(s,i,bit):
 temp=list(s);temp[i]=bit
 g=gap_units(s,i);q=x**g/(1+x**g)
 return q if high_label(temp,i) else 1-q

# Independent exact detailed-balance check on all 49,152 oriented flips.
for s in states:
 assert sum(new_prob(s,i,1-s[i]) for i in range(N))/N>=F(1,28)
 for i in range(N):
  t=list(s);t[i]^=1;t=tuple(t)
  assert pi[s]*new_prob(s,i,t[i])/N==pi[t]*new_prob(t,i,s[i])/N

# Fresh Gibbs bath qubits have gaps 2J and 6J.
# Controlled SWAP in the majority-defined energy basis is a permutation
# conserving total memory+bath energy for all basis states.
def collision(s,b,i):
 majority=int(sum(s[j] for j in neighbors[i])>=2)
 which=0 if gap_units(s,i)==1 else 1
 h=int(s[i]!=majority)
 ss=list(s);bb=list(b)
 ss[i]=majority ^ b[which];bb[which]=h
 return tuple(ss),tuple(bb)
def total_energy_units(s,b):return 2*cuts(s)+2*b[0]+6*b[1]
for i in range(N):
 images=set()
 for s in states:
  for b in product((0,1),repeat=2):
   t,c=collision(s,b,i)
   assert total_energy_units(s,b)==total_energy_units(t,c)
   assert collision(t,c,i)==(s,b)
   images.add((t,c))
 assert len(images)==2**(N+2)

# A breadth-first spanning tree provides an independently solvable comparison.
seen={0};front=[0];tree=[]
while front:
 i=front.pop(0)
 for j in neighbors[i]:
  if j not in seen:seen.add(j);front.append(j);tree.append((i,j))
assert len(tree)==N-1
tree_counts=Counter(cuts(s,tree) for s in states)
assert tree_counts==Counter({k:2*math.comb(N-1,k) for k in range(N)})
tree_Z=sum(n*x**k for k,n in tree_counts.items())
assert tree_Z==2*(1+x)**(N-1)

# Classical conditional entropy bound for maximum degree 3.
h=lambda q:-q*math.log(q)-(1-q)*math.log(1-q)
entropy=math.log(float(Z))+float(mean_k)*math.log(3)
entropy_tree=math.log(2)+(N-1)*h(.25)
assert N*h(1/28)<=entropy<=N*math.log(2)
assert Z==F(2**23,3**13) and mean_k==F(11,4)

# Erasing an inserted degree-two spin generates an effective coupling.
# If each subdivided edge has strength J', x'=exp(-2 beta J'),
# equal endpoint weight 1+x'^2; unequal weight 2x'.
# Exact test at x'=1/3: x_eff=3/5, different from original 1/3.
effective_x=2*x/(1+x*x)
assert effective_x==F(3,5) and effective_x!=x

out={'status':'PASS','lane':'development — no registry entry','physical_promotion':0,'independent_review':'OPEN',
 'candidate':'one tensor-product binary memory per exposed face; Gibbs ferromagnetic disagreement energy',
 'face_count':N,'dual_edges':edges,'maximum_degree':3,
 'partition_polynomial_coefficients':{str(k):n for k,n in sorted(counts.items())},
 'replay_x':'1/3; declared test point only','partition_at_replay':str(Z),
 'mean_disagreements_at_replay':str(mean_k),
 'entropy_at_replay_exact':'ln('+str(Z)+') + ('+str(mean_k)+') ln3',
 'entropy_at_replay_simplified':'23 ln2 - (41/4) ln3',
 'entropy_at_replay_display_nats':entropy,'entropy_tree_display_nats':entropy_tree,
 'heatbath_flip_detailed_balance_checks':N*2**N,
 'collision_energy_and_involution_checks':N*2**(N+2),
 'fresh_bath_excitation_probabilities':['1/4','1/28'],
 'configuration_exit_probability_per_uniform_site_update_lower_bound':'1/28',
 'spanning_tree_edges':tree,'tree_partition':'2 (1+x)^(N-1)',
 'tree_entropy':'ln2+(N-1)h(x/(1+x))',
 'edge_subdivision_effective_x_at_replay':str(effective_x),
 'native_J_temperature_clock':'OPEN','memory_carrier_record_coupling':'OPEN',
 'carrier_memory_mutual_information_under_independent_preparation':0,
 'horizon_map':'OPEN','G_input':False}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

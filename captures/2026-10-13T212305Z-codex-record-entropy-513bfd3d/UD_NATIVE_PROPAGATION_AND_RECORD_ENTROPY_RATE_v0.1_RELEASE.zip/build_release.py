"""Package the exact candidate calculation and its source receipt."""
from pathlib import Path
import hashlib, json, zipfile

root=Path(__file__).resolve().parent
workspace=root.parent
results=json.loads((root/'record_interaction_exact_results.json').read_text())
assert results['status']=='PASS' and results['physical_promotion']==0
assert results['G_or_Planck_input'] is False
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source_names=['21-UD_GOVERNANCE_CRL2_SUBDIVISION_v1.0.md',
              '20-UD_COEFFICIENT_PROVENANCE_LEDGER_v0.39-2-.md']
receipt={
 'status':'PASS under declared candidate recording interaction',
 'physical_promotion':0, 'independent_review':'OPEN',
 'lane':'development — no registry entry',
 'verification':'Exact rational kernels and log coefficients; independent explicit path enumeration through four steps; history recursion through eight steps; six-step mixing certificate; redundant refinement.',
 'candidate_inputs':['unit metric','projective dephased recording','fresh retained memory','record observable','sampling interval'],
 'not_derived':['native physical recording law','heat and environment balance','physical clock calibration','spatial boundary placement','horizon identification','universal area coefficient'],
 'source_receipt':{name:digest(workspace/'project_sources'/name) for name in source_names},
 'parent_dependency_sha256':digest(root/'dependencies/UD_RECORD_ENTROPY_AREA_LAW_AND_NORMALIZATION_v0.1_RELEASE.zip'),
 'external_updates':'none',
 'unavailable_Genesis_image':'unused'}
(root/'verification_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256SUMS')
(root/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(root)}\n' for p in files))
target=workspace/'UD_NATIVE_PROPAGATION_AND_RECORD_ENTROPY_RATE_v0.1_RELEASE.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[root/'SHA256SUMS']:
  z.write(p,p.relative_to(root))
with zipfile.ZipFile(target) as z: assert z.testzip() is None
print(json.dumps({'file':str(target),'bytes':target.stat().st_size,'sha256':digest(target)},indent=2))

"""Exact declared recording channels driven by native tetrahedral rotation."""
from itertools import combinations,product
from fractions import Fraction as Q
from collections import defaultdict
from pathlib import Path
import json,math
def factor(n):
 out={};k=2
 while k*k<=n:
  while n%k==0:out[k]=out.get(k,0)+1;n//=k
  k+=1
 if n>1:out[n]=out.get(n,0)+1
 return out
def H(prob):
 assert sum(prob,Q(0))==1 and all(x>=0 for x in prob)
 out=defaultdict(Q)
 for x in prob:
  if not x:continue
  for p,e in factor(x.denominator).items():out[p]+=x*e
  for p,e in factor(x.numerator).items():out[p]-=x*e
 return {p:x for p,x in out.items() if x}
def add(a,b):
 out=defaultdict(Q,a)
 for p,x in b.items():out[p]+=x
 return {p:x for p,x in out.items() if x}
def scale(a,c):return {p:c*x for p,x in a.items() if c*x}
def ser(a):return {str(p):str(x) for p,x in a.items()}
def mm(A,B):return [[sum(A[i][k]*B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
labels=[z for k in range(1,5) for z in combinations(range(4),k)];idx={z:i for i,z in enumerate(labels)};n=15
D=[[Q(0)]*n for _ in range(n)]
for j,z in enumerate(labels):
 if len(z)>1:
  for k in range(len(z)):D[idx[z[:k]+z[k+1:]]][j]=Q((-1)**k)
B=[[D[j][i]-D[i][j] for j in range(n)] for i in range(n)]
assert all(B[i][j]==-B[j][i] for i in range(n) for j in range(n))
assert mm(D,D)==[[0]*n for _ in range(n)]
P0=[[Q(1,4) if len(labels[i])==len(labels[j])==1 else Q(0) for j in range(n)] for i in range(n)]
BB=mm(B,B)
assert all(BB[i][j]==-4*(int(i==j)-P0[i][j]) for i in range(n) for j in range(n))
assert mm(B,P0)==[[0]*n for _ in range(n)]

# A two-plane degree-record chain. Each fresh record uses the same sampling gap.
degree=[]
for gap,q in [('pi/12',Q(1,4)),('pi/8',Q(1,2)),('pi/4',Q(1)),('pi/2',Q(0))]:
 rate=H([q,1-q]);rows=[]
 for steps in [1,2,4,8]:
  histories=[]
  for path in product([0,1],repeat=steps):
   p=Q(1);previous=0
   for label in path:p*=q if label!=previous else 1-q;previous=label
   histories.append(p)
  assert H(histories)==scale(rate,steps)
  support_count=sum(p>0 for p in histories)
  assert support_count==(2**steps if 0<q<1 else 1)
  endpoint=sum(p for path,p in zip(product([0,1],repeat=steps),histories) if path[-1]==1)
  assert endpoint==(1-(1-2*q)**steps)/2
  rows.append({'steps':steps,'history_entropy':ser(H(histories)),'endpoint_probability':str(endpoint),
 'minimum_lossless_orthogonal_memory_dimension':support_count})
 degree.append({'gap':gap,'flip_probability':str(q),'entropy_rate':ser(rate),'history_checks':rows})

# Full simplex records: U=P0+c(I-P0)+(s/2)B.
# The symmetric part and skew part have disjoint off-diagonal support.
full=[]
for gap,c,s2 in [('pi/4',Q(0),Q(1)),('pi/6',Q(1,2),Q(3,4))]:
 P=[]
 for i in range(n):
  row=[]
  for j in range(n):
   sym=P0[i][j]+c*(int(i==j)-P0[i][j])
   assert not sym or not B[i][j]
   row.append(sym*sym+s2*B[i][j]*B[i][j]/4)
  P.append(row)
 assert all(sum(row)==1 for row in P)
 assert all(P[i][j]==P[j][i] for i in range(n) for j in range(n))
 rowH=[H(row) for row in P];rate={}
 for z in rowH:rate=add(rate,scale(z,Q(1,15)))
 if gap=='pi/4':assert rate=={2:Q(32,15)}
 else:assert rate=={2:Q(58,15),3:-Q(7,10),5:-Q(5,24)}
 # Exact positivity of six-step kernel gives irreducibility and aperiodicity.
 P6=P
 for _ in range(5):P6=mm(P6,P)
 minimum=min(x for row in P6 for x in row);assert minimum>0
 alpha=15*minimum;assert 0<alpha<=1
 # Finite-history entropy with deterministic top-cell initial state.
 dist=[Q(int(len(z)==4)) for z in labels];hist={};prefix=[]
 paths=[int(len(z)==4) for z in labels]
 explicit={():Q(1)};top=idx[(0,1,2,3)]
 for t in range(1,9):
  increment={}
  for p,z in zip(dist,rowH):increment=add(increment,scale(z,p))
  hist=add(hist,increment)
  dist=[sum(dist[i]*P[i][j] for i in range(n)) for j in range(n)]
  paths=[sum(paths[i] for i in range(n) if P[i][j]>0) for j in range(n)]
  if t<=4:
   explicit={path+(j,):p*P[path[-1] if path else top][j]
             for path,p in explicit.items() for j in range(n)
             if P[path[-1] if path else top][j]}
   assert H(list(explicit.values()))==hist
   assert len(explicit)==sum(paths)
   assert [sum(p for path,p in explicit.items() if path[-1]==j) for j in range(n)]==dist
  prefix.append({'steps':t,'history_entropy':ser(hist),'marginal_entropy':ser(H(dist)),
 'independent_explicit_path_enumeration':t<=4,
 'minimum_lossless_orthogonal_memory_dimension':sum(paths)})
 # Stationary path reversal: pi_i P_ij=pi_j P_ji exactly.
 assert all(Q(1,15)*P[i][j]==Q(1,15)*P[j][i] for i in range(n) for j in range(n))
 full.append({'gap':gap,'transition_matrix':[[str(x) for x in row] for row in P],
 'stationary_distribution':'uniform 1/15','entropy_rate_log_coefficients':ser(rate),
 'entropy_rate_display_nats':sum(float(x)*math.log(p) for p,x in rate.items()),
 'six_step_minimum':str(minimum),'Doeblin_alpha':str(alpha),
 'history_transient_bound_coefficient_of_ln15':str(6/alpha),
 'stationary_Markov_path_entropy_production':0,'finite_history_checks':prefix})

# Redundant subdivision preserves the joint entropy, not independent bit count.
refinement=[]
for count in [2,4,8]:
 q=Q(1,4);joint=[q if all(s) else 1-q if not any(s) else Q(0) for s in product([0,1],repeat=count)]
 assert H(joint)==H([q,1-q])
 refinement.append({'children':count,'joint_entropy':ser(H(joint)),
 'total_child_area_equals_parent':'a0; each area a0/children'})
out={'status':'PASS','lane':'development — no registry entry','physical_promotion':0,'independent_review':'OPEN',
 'native_generator':'D^T-D, unit metric, filled tetrahedron','recording_operation':'DECLARED CANDIDATE: native evolution then projective dephased write into fresh memory',
 'degree_channel':degree,'simplex_channel':full,'refinement_checks':refinement,
 'steady_path_entropy_production_scope':'stationary carrier-label Markov chain only, not complete apparatus thermodynamics',
 'area_coefficient':'k_B*h_star/a0 only with one distinct record slot per equal-area boundary tile',
 'G_or_Planck_input':False,'native_recording_law':'OPEN','sampling_gap_selection':'OPEN','physical_patch_area':'OPEN','horizon_map':'OPEN'}
Path('record_interaction_exact_results.json').write_text(json.dumps(out,indent=2)+'\n')
print('Native rotation, recording-chain entropy rates and redundant refinement PASS')
for row in full:print(row['gap'],row['entropy_rate_log_coefficients'],'alpha',row['Doeblin_alpha'])

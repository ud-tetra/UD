# Native propagation and recording-entropy rate

Run `python3 verify_record_interaction.py` with Python 3.12. Standard library only. Exact incidence, transition, entropy-log and mixing calculations use fractions; decimal entropy rates are display only.

Read the proof for the distinction between native propagation and the declared recording operation. Neither a physical heat law nor a universal horizon-area normalization is certified. The parent entropy audit is included under dependencies/.

Development — no registry entry. Physical promotion 0; independent review OPEN.

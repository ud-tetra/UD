# Receipt dependence bounds

Run `python3 verify.py` using Python's standard library. It checks all Boolean patterns, sharp endpoint joint laws and the exact final-error inequality. The supplied parent_results.json provides the scoped prior storage error. Decimal thresholds are displays.

Physical promotion 0; independent review OPEN. Development — no registry entry.

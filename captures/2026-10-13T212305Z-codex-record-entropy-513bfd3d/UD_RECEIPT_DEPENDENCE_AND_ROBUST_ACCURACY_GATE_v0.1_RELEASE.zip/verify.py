"""Sharp majority bounds from joint moments; no receipt IID assumption."""
from fractions import Fraction as F
from itertools import product,combinations
from pathlib import Path
import json
root=Path(__file__).resolve().parent
src=root/'parent_results.json'
if not src.exists():src=root.parent/'receipt_majority/results.json'
parent=json.loads(src.read_text())
e0=F(parent['base_storage_errors_exact']['32']);ceiling=(F(1,100)-e0)/(1-2*e0)
for z in product((0,1),repeat=3):
 assert int(sum(z)>=2)==sum(z[i]*z[j] for i,j in combinations(range(3),2))-2*z[0]*z[1]*z[2]
def sharp(p,a):
 lo=max(F(0),2*a-p);hi=min(a,1-3*p+3*a)
 assert lo<=hi
 vals=[]
 for b in (lo,hi):
  Q=[1-3*p+3*a-b,3*p-6*a+3*b,3*a-3*b,b]
  assert all(v>=0 for v in Q) and sum(Q)==1
  dist={z:Q[sum(z)]/len([t for t in product((0,1),repeat=3) if sum(t)==sum(z)]) for z in product((0,1),repeat=3)}
  assert sum(dist.values())==1
  assert sum(w*sum(z)/3 for z,w in dist.items())==p
  assert sum(w*sum(z[i]*z[j] for i,j in combinations(range(3),2))/3 for z,w in dist.items())==a
  m=sum(w for z,w in dist.items() if sum(z)>=2)
  assert m==3*a-2*b
  vals.append(m)
 return min(vals),max(vals)
tests=[]
p=F(1,100)
for a in (p*p,F(1,1000),p):
 lo,hi=sharp(p,a)
 tests.append({'marginal_mean':str(p),'pair_joint_mean':str(a),'majority_error_min':str(lo),'majority_error_max':str(hi)})
assert sharp(p,p*p)==(F(1,10000),F(3,10000))
# Same 1% marginals permit no majority errors or a majority error of 1.5%.
assert sharp(p,F(0))[0]==0
Qworst=[1-3*p/2,0,3*p/2,0]
assert sum(F(k)*Qworst[k] for k in range(4))/3==p and Qworst[2]==F(3,200)

decision_q=F(1,10000)
robust_pair_ceiling=(ceiling-4*decision_q)/3
rho_ceiling=(robust_pair_ceiling-p*p)/(p*(1-p))
robust_seed=3*p*p+4*decision_q
robust_final=e0+(1-2*e0)*robust_seed
assert robust_seed==F(7,10000) and robust_final<F(1,100)
u4=(1-(1-2*decision_q)**4)/2
iid_pair_ceiling=(ceiling-u4)/(3*(1-2*u4))
out={'status':'PASS exact joint-moment bounds','physical_promotion':0,'independent_review':'OPEN','lane':'development — no registry entry',
 'majority_identity':'m=sum_{i<j} P(E_i E_j=1)-2 P(E1 E2 E3=1)',
 'moment_definitions':'p=mean marginal error, a=mean pair joint error, b=triple joint error',
 'triple_feasible_bounds':'max(0,2a-p) <= b <= min(a,1-3p+3a)',
 'majority_sharp_bounds':'3a-2 min(a,1-3p+3a) <= m <= 3a-2 max(0,2a-p)',
 'examples':tests,'marginals_only_at_1percent':'majority error can range from 0 to 3/200',
 'decision_fault_bound':'4 output-event marginals <= q imply parity probability <= 4q, without independence',
 'robust_sufficient_gate':'3a+4q <= (epsilon-e0)/(1-2e0)',
 'replay_p':'1/100','replay_q':'1/10000','robust_pair_joint_ceiling_exact':str(robust_pair_ceiling),
 'robust_pair_joint_ceiling_display':float(robust_pair_ceiling),
 'average_equal_marginal_correlation_ceiling_exact':str(rho_ceiling),
 'average_equal_marginal_correlation_ceiling_display':float(rho_ceiling),
 'pairwise_independent_receipt_robust_seed_bound':'7/10000',
 'pairwise_independent_receipt_robust_final_bound_exact':str(robust_final),
 'pairwise_independent_receipt_robust_final_bound_display':float(robust_final),
 'independent_decision_pair_ceiling_display':float(iid_pair_ceiling),
 'workspace_entropy':'H(E1,E2,E3) <= sum_i h(p_i); equality only with independence',
 'source_joint_moments':'OPEN; bounds specify required source law, not observed moments','G_input':False}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

# Reversible receipt-majority module

Run `python3 verify.py` with Python's standard library. Boundary labels are supplied in boundary_source.json. Truth tables, fractions and criterion checks are exact; entropy/logarithm values are displays.

This is a conditional candidate with declared independent fault rates, ideal reverse cleanup and fanout. Physical promotion 0; independent review OPEN. Development — no registry entry.

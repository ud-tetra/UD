"""Reversible three-receipt majority, workspace and retained-error budgets."""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
from collections import defaultdict
import json,math
root=Path(__file__).resolve().parent
src=root/'boundary_source.json'
if not src.exists():src=root.parent/'carrier_write/boundary_source.json'
faces=json.loads(src.read_text())['boundary_face_labels'];N=len(faces);size=2**N;full=size-1
edges=[(i,j) for i in range(N) for j in range(i+1,N) if len(set(faces[i])&set(faces[j]))==2]
neighbors=[[j for j in range(N) if (min(i,j),max(i,j)) in edges] for i in range(N)]
def maj(s):return int(sum(s)>=2)
def compute(a,b,c,o):return o^(a&b)^(a&c)^(b&c)
for a,b,c,o in product((0,1),repeat=4):
 assert compute(a,b,c,o)==o^maj((a,b,c))
 assert compute(a,b,c,compute(a,b,c,o))==o
for R in (0,1):
 for errs in product((0,1),repeat=3):
  receipts=tuple(R^e for e in errs)
  o=compute(*receipts,0);mem=o
  o=compute(*receipts,o)
  garbage=tuple(R^s for s in receipts)
  assert o==0 and garbage==errs and mem==R^maj(errs)
def h(p):return 0. if p==0 else -float(p)*math.log(float(p))-(1-float(p))*math.log(1-float(p))
trans=[]
for m in range(size):
 flips=[]
 for i in range(N):
  ones=sum((m>>j)&1 for j in neighbors[i]);majority=int(ones>=2)
  qhigh=1 if abs(2*ones-3)==3 else 7
  a=qhigh if 1-((m>>i)&1)!=majority else 28-qhigh
  flips.append((m^(1<<i),a))
 trans.append(flips+[(m,336-sum(a for _,a in flips))])
def step(p):
 out=defaultdict(int)
 for m,w in p.items():
  for t,a in trans[m]:out[t]+=w*a
 return dict(out)
base={};p={0:1};den=1
for r in range(33):
 if r in (20,32):
  D=F(sum(abs(p.get(m,0)-p.get(m^full,0)) for m in range(size)),2*den)
  base[r]=(1-D)/2
 if r<32:p=step(p);den*=336
rows=[]
for receipt_p in (F(1,1000),F(1,100)):
 p3=3*receipt_p**2-2*receipt_p**3
 enumerated=sum((receipt_p**sum(z)*(1-receipt_p)**(3-sum(z)) for z in product((0,1),repeat=3) if sum(z)>=2),F(0))
 assert enumerated==p3
 for logic_q in (F(0),F(1,10000),F(1,1000)):
  u3=(1-(1-2*logic_q)**3)/2
  u4=(1-(1-2*logic_q)**4)/2
  effective=p3+u4-2*p3*u4
  rows.append({'receipt_error':str(receipt_p),'decision_target_error':str(logic_q),
   'majority_receipt_error_exact':str(p3),'four_decision_fault_parity_exact':str(u4),
   'effective_seed_error_exact':str(effective),
   'blind_workspace_reset_bound_in_kBT_display':3*h(receipt_p)+h(u3),
   'final_error_32_updates_exact':str(effective+(1-2*effective)*base[32]),
   'final_error_32_display':float(effective+(1-2*effective)*base[32]),
   'final_error_common_44_slots_exact':str(effective+(1-2*effective)*base[20]),
   'final_error_common_44_slots_display':float(effective+(1-2*effective)*base[20])})
threshold=(F(1,100)-base[32])/(1-2*base[32])
# Exact passing/failing decision-fault examples.
assert F(rows[4]['final_error_32_updates_exact'])<F(1,100)
assert F(rows[5]['final_error_32_updates_exact'])>F(1,100)
out={'status':'PASS under declared receipt/decision fault model','lane':'development — no registry entry',
 'physical_promotion':0,'independent_review':'OPEN','workspace_bits':4,
 'majority_identity':'maj(a,b,c)=ab XOR ac XOR bc',
 'primitive_gate_counts':{'carrier_acquire':3,'Toffoli_compute':3,'copy_to_seed':1,'Toffoli_uncompute':3,'carrier_uncopy':3,'neighbor_fanout':11},
 'write_slots':24,'carrier_hold_slots':13,'storage_updates_at_44_slot_deadline':20,
 'decision_fault_scope':'3 forward majority target faults plus seed-copy target fault; reverse cleanup otherwise ideal',
 'workspace_garbage_entropy':'3 h(p) + h((1-(1-2q)^3)/2)',
 'common_mode_receipt_error':'c+(1-2c)(3p^2-2p^3); shared-flip source model',
 'perfect_fanout_seed_ceiling_at_32_updates_exact':str(threshold),
 'base_storage_errors_exact':{str(k):str(v) for k,v in base.items()},'rows':rows,
 'source_error_independence':'declared, not derived','noise_energy_and_reset_implementation':'OPEN',
 'physical_area_of_workspace':'OPEN; boundary area 12a0 is not total apparatus area','G_input':False}
(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: reversible majority truth table, error polynomial, garbage and retention')
for r in rows:print(r['receipt_error'],r['decision_target_error'],r['final_error_32_display'],r['final_error_common_44_slots_display'],r['blind_workspace_reset_bound_in_kBT_display'])

## D.12 Event comparisons, composable histories and winding observability

### D.12.1 A declared receipt alphabet does not specify its transition graph

The additional working notes [24] motivate the following conditional alphabet. A label contains incoming and outgoing Hamming weights $w,w'\in\{0,1,2,3\}$ and parity $\epsilon\in\{0,1\}$. Fixed-weight labels have $w'=w$ and no address, giving $|F|=8$. One-step labels have $w'-w=+1$ or $-1$, three possible adjacent weight steps in each direction and address $a\in\{0,1,2\}$. Thus $|O|=|E|=3\cdot3\cdot2=18$. These are coarse labels, not a count of underlying microstates or independently generated events. Their parity/address interpretation remains conditional on a supplied receipt map.

There are $\binom{44}{2}=946$ unordered pairs of distinct labels. Pair comparison differs from history composition: the ordered history $\ell_1$ then $\ell_2$ requires at least $w'_1=w_2$. Applying that necessary weight condition yields:

| Comparison block | All distinct unordered pairs | At least one weight-compatible ordering |
|:--|--:|--:|
| $F,F$ | 28 | 4 |
| $O,O$ | 153 | 72 |
| $E,E$ | 153 | 72 |
| $F,O$ | 144 | 72 |
| $F,E$ | 144 | 72 |
| $O,E$ | 324 | 108 |
| Total | 946 | 400 |

For $F,F$, weights must agree; only the two opposite-parity labels at each of four weights can form such a distinct pair. For $O,O$, the first weight step must end where the second starts: two successive step positions, each with $6\cdot6$ address/parity choices, give 72. Extinctions give the same count. Each onset or extinction label can compose with the two fixed labels at either endpoint, giving 72 in each mixed fixed block. For $O,E$, the two weight steps must be reverses: three step positions with $6\cdot6$ choices give 108. There are 520 ordered weight-compatible pairs when repetition is included. This last number is also $8^2+14^2+14^2+8^2$, from the incoming/outgoing label counts at each weight.

These are combinatorial compatibility results. Full bit patterns, address histories, transport gates, null events and frame consistency may impose further constraints. Neither the 946 comparisons nor all 400 weight-compatible pairs constitute a derived native transition graph. A partition by label type also need not be an invariant sector of an unspecified evolution operator.

The $O,E$ block demonstrates a useful collision of equal counts. Its same-address subset has $3\cdot6^2=108$ pairs. Its reverse-weight-step subset also has $3\cdot6^2=108$ pairs, but the intersection contains only $3\cdot3\cdot2^2=36$. The address and weight-step predicates are independent restrictions in this declared product alphabet. Equality of their cardinalities does not identify the subsets, their admissibility or their dynamics.

### D.12.2 When a receipt determines a winding or cost

Let $\mathcal H$ be a declared set of fine histories, $q:\mathcal H\to\mathcal R$ a receipt, and $W:\mathcal H\to\mathbb Z$ a winding increment. There exists a receipt-level function $\bar W$ on $q(\mathcal H)$ with $W=\bar W\circ q$ if and only if $W$ is constant on each fiber of $q$. Necessity follows by evaluating $\bar W$ on equal receipts. For sufficiency, define $\bar W(r)$ using any history in that fiber; the assumption makes the definition independent of the representative. The same criterion applies to any proposed cost functional.

A fixed-weight receipt alone does not satisfy this criterion for an unspecified winding. For a counterexample to the inference, extend the state to $(w,\epsilon,n)$, $n\in\mathbb Z$, and consider two candidate lifts that fix $w,\epsilon$ but update $n$ to $n$ or $n+1$. Both project to the same fixed-weight receipt; their winding increments differ. This proves underdetermination from the label premises alone. It does not declare either lift admissible under a future complete UD source law.

Even when a winding increment $\nu$ is independently known, a quadratic burden $B(n)=\kappa n^2$ gives

\[
\Delta B=\kappa(2n\nu+\nu^2).
\]

The first and second positive unit steps cost $\kappa$ and $3\kappa$ because their initial windings are 0 and 1. A cardinality ratio $324/108=3$ does not supply either winding, $\nu$, $\kappa$, a probability law or an address-to-winding map. If $\nu=0$ is separately established, then $\Delta B=0$; a zero Hamming change alone does not establish that premise. A zero change of this burden stock also does not establish zero complete apparatus cost.

For example, the notes propose the cross-block cost $c(\ell_O,\ell_E)=1+2\mathbf1_{a_O\ne a_E}$. This is an assigned pair cost, not a consequence of the pair counts. Replacing 2 by any nonnegative constant preserves the alphabet and all its counts. If the expression is asserted to be a metric on the whole label set, its nonzero diagonal first requires correction; the given formula is defined here only on the disjoint $O,E$ block. Under an additional uniform distribution on those 324 pairs, the proposed mean is

\[
\frac{108\cdot1+216\cdot3}{324}=\frac73,
\]

which is a different object from the count ratio 3. Thus label counting, history eligibility, winding inference, signed burden change and complete resource cost require separate maps. The new exact replay enumerates the declared alphabet and checks these counts [24]; the fiber criterion and counterexample supply the general logical boundary.


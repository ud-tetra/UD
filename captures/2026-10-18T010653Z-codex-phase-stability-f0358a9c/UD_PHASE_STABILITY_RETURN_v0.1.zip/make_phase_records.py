"""Known coherent phase-shift controls; floating constructor, exact encoded gate checks."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time
import numpy as np
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 freeze=json.loads((P/'CAMPAIGN_FREEZE.json').read_text());source=P/freeze['reference_record_path'];before=sha(source);assert before==freeze['reference_record_sha256']
 with np.load(P/'inputs/REFERENCE_PROPOSAL.npz',allow_pickle=False) as z:theta=z['theta'];coeff=z['coeff']
 j=int(np.argmin(np.diff(theta)));cos=coeff[2*j+1].reshape(62,37);sin=coeff[2*j+2].reshape(62,37)
 l1=max(sum(abs(int(x)) for x in cos[:,a])+sum(abs(int(x)) for x in sin[:,a]) for a in range(37));B=F(l1,2**60);assert B>0
 raw=np.memmap(source,dtype='<i8',mode='r',shape=(37,8191,62));records=P/'records';records.mkdir(exist_ok=True);rows=[]
 for exponent in freeze['phase_control_vector_budget_exponents']:
  delta=F(1,2**exponent);gamma=delta/(4*8190*B);num=gamma.numerator*2**60//gamma.denominator;assert num>0
  gamma=F(num,2**60);assert num<int(theta[j+1]-theta[j])//4
  k=np.arange(8191,dtype=float);mid=k*((float(int(theta[j]))+float(num)/2)/2.**60);half=k*float(gamma)/2
  dc=-2*np.sin(mid)*np.sin(half);ds=2*np.cos(mid)*np.sin(half)
  name=f'phase_budget_2neg{exponent}';dest=records/f'{name}.i64le';assert not dest.exists()
  new=np.memmap(dest,dtype='<i8',mode='w+',shape=(37,8191,62));maxsq=0;maxscalar=0
  for a in range(37):
   difference=np.rint((dc[:,None]*(cos[:,a].astype(float)/2.**60)+ds[:,None]*(sin[:,a].astype(float)/2.**60))*2.**48).astype(np.int64)
   assert np.max(abs(difference))<2**31
   norms=np.sum(difference*difference,axis=1);maxsq=max(maxsq,int(norms.max()));maxscalar=max(maxscalar,int(abs(difference).max()))
   new[a]=raw[a]+difference
  new.flush();del new
  assert F(maxsq,2**96)<=delta*delta
  assert F(maxscalar,2**48)<=F(1,2**23)
  rows.append({'case':name,'record_path':f'records/{name}.i64le','record_sha256':sha(dest),'bytes':dest.stat().st_size,'declared_vector_budget':[delta.numerator,delta.denominator],'exact_max_vector_error_squared':[maxsq,2**96],'exact_max_scalar_error':[maxscalar,2**48],'intended_positive_phase_index':j,'intended_phase_shift':[num,2**60],'constructor':'Floating trig differences rounded to exact encoded additive integers; encoded gates independently checked exactly','phase_shift_is_intended_parameter_not_measured_physical_truth':True})
 assert sha(source)==before
 (P/'FIXTURE_MANIFEST.json').write_text(json.dumps({'status':'CONSTRUCTOR_PHASE_CONTROLS','physical_promotion':0,'source_record_sha256':before,'cases':rows},indent=2));print(json.dumps(rows,indent=2))
if __name__=='__main__':run()

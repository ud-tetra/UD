import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;runs=[];fixtures=json.loads((P/'FIXTURE_MANIFEST.json').read_text())
for c in fixtures['cases']:
 n=c['case'];t=time.monotonic()
 with (P/f'proposal-{n}.log').open('x') as log:
  r=subprocess.run([sys.executable,str(P/'propose_complementary.py'),str(P/c['record_path']),str(P/'inputs/FROZEN_CONTRACT.json'),str(P/f'results/proposal-{n}')],stdout=log,stderr=subprocess.STDOUT,cwd=P)
 runs.append({'case':n,'stage':'untrusted_phase_fit','returncode':r.returncode,'wall_seconds':time.monotonic()-t})
 (P/'RUN_EXECUTIONS.json').write_text(json.dumps(runs,indent=2));assert r.returncode==0
c=next(x for x in fixtures['cases'] if x['case']=='phase_budget_2neg20');n=c['case'];t=time.monotonic()
with (P/f'full-{n}.log').open('x') as log:
 r=subprocess.run([sys.executable,str(P/'certify_record.py'),str(P/c['record_path']),str(P/'inputs/FROZEN_CONTRACT.json'),str(P/f'results/proposal-{n}/PROPOSAL.npz'),str(P/f'results/certificate-{n}')],stdout=log,stderr=subprocess.STDOUT,cwd=P)
runs.append({'case':n,'stage':'full_Hankel_signature','returncode':r.returncode,'wall_seconds':time.monotonic()-t});(P/'RUN_EXECUTIONS.json').write_text(json.dumps(runs,indent=2));assert r.returncode==0
print(json.dumps(runs,indent=2))

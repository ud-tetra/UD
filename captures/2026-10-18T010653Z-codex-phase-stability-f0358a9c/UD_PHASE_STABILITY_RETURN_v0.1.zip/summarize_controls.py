from pathlib import Path
from fractions import Fraction as F
import json,numpy as np
P=Path(__file__).resolve().parent
with np.load(P/'inputs/REFERENCE_PROPOSAL.npz',allow_pickle=False) as z:reference=z['theta'].astype(object)
fixtures=json.loads((P/'FIXTURE_MANIFEST.json').read_text());rows=[]
for case in fixtures['cases']:
 n=case['case'];out=P/f'results/proposal-{n}';report=json.loads((out/'PROPOSAL_REPORT.json').read_text())
 with np.load(out/'PROPOSAL.npz',allow_pickle=False) as z:theta=z['theta'].astype(object)
 expected=reference.copy();j=case['intended_positive_phase_index'];expected[j]+=case['intended_phase_shift'][0]
 assert len(theta)==52 and all(int(expected[i+1])>int(expected[i]) for i in range(51))
 discrepancy=max(abs(int(x)-int(y)) for x,y in zip(theta,expected));pairsquared=sum((int(x)-int(y))**2 for x,y in zip(theta,expected))
 rows.append({'case':n,'scope':'Observed fit discrepancy against intended coherent-control phase parameters, not true physical frequency or a validated floating algorithm bound','temporal_dimension':report['temporal_dimension'],'maximum_intended_phase_discrepancy_exact':[discrepancy,2**60],'sum_squared_intended_phase_discrepancy_exact':[pairsquared,2**120],'max_discrepancy_readable':float(F(discrepancy,2**60)),'proposal_report':report})
full=P/'results/certificate-phase_budget_2neg20';c=json.loads((full/'CERTIFICATE.json').read_text());b=json.loads((full/'BENCHMARK.json').read_text())
(P/'CONTROL_RESULTS.json').write_text(json.dumps({'status':'CONSTRUCTOR_PHASE_CONTROLS_EXECUTED','physical_promotion':0,'independent_review':'pending','cases':rows,'full_Hankel_control_status':c['status'],'full_Hankel_bounds':c['readable'],'full_Hankel_benchmark':b,'universal_fitting_convergence_claimed':False,'actual_floating_estimator_proof_closed':False},indent=2))
print(json.dumps({'phase_discrepancies':[r['max_discrepancy_readable'] for r in rows],'full':c['status'],'bounds':c['readable']},indent=2))

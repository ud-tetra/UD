from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
P=Path(__file__).resolve().parent;repo=P.parent/'ud-repo';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ID=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H%M%SZ')+'-codex-phase-stability-f0358a9c'
freeze=json.loads((P/'CAMPAIGN_FREEZE.json').read_text());fixtures=json.loads((P/'FIXTURE_MANIFEST.json').read_text());omitted=[]
p=P/freeze['reference_record_path'];assert sha(p)==freeze['reference_record_sha256'];omitted.append({'role':'clean reference raw record','filename':p.name,'size_bytes':p.stat().st_size,'sha256':sha(p),'recovery':'Inherited pinned record-only/sketch-blind baseline recipes; no nominal operator needed for verifier','reason':'150-MB inherited raw input'})
for c in fixtures['cases']:
 p=P/c['record_path'];assert sha(p)==c['record_sha256'];omitted.append({'role':c['case'],'path':c['record_path'],'size_bytes':p.stat().st_size,'sha256':sha(p),'recovery':'make_phase_records.py with pinned reference record/proposal and declared runtime; hash must match','reason':'150-MB generated control; exact recipe and gate receipts included'})
for p in P.glob('results/*/FACTOR_GRAMS.npz'):
 omitted.append({'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'recovery':'Unchanged certify_record.py plus pinned record and included new proposal','reason':'Large full spectral factor Grams'})
(P/'OMITTED_DATA.json').write_text(json.dumps({'files':omitted,'no_placeholder_substitution':True,'physical_promotion':0},indent=2))
files=[p for p in P.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.relative_to(P).as_posix().startswith('records/') and p.name not in ['FACTOR_GRAMS.npz','PACKAGE_MANIFEST.json']]
(P/'PACKAGE_MANIFEST.json').write_text(json.dumps({'artifact':'UD_PHASE_STABILITY_RETURN_v0.1','physical_promotion':0,'independent_review':'pending','files':[{'path':p.relative_to(P).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]},indent=2));files.append(P/'PACKAGE_MANIFEST.json')
out=repo/'captures'/ID;out.mkdir(parents=True,exist_ok=False);z=out/'UD_PHASE_STABILITY_RETURN_v0.1.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(files):archive.write(p,p.relative_to(P).as_posix())
for n in ['README.md','THEOREMS.md','CLAIM_LEDGER.json','PROVENANCE.json','CAMPAIGN_FREEZE.json','PHASE_STABILITY_CERTIFICATE.json','FIXTURE_MANIFEST.json','CONTROL_RESULTS.json','PHASE_REPLAY_RESULTS.json','VALIDATION.json','TEST_RESULTS.txt','OMITTED_DATA.json','PACKAGE_MANIFEST.json','phase_math.py','certify_phase.py','replay_phase.py','test_phase.py','validate_return.py']:
 shutil.copyfile(P/n,out/n)
entries=[{'path':p.relative_to(repo).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p),'status':'Typed exact conditional, computational, empirical, proof-limit and open claims in CLAIM_LEDGER.json','provenance':'Same-constructor phase perturbation proof and known-model coherent controls; independent review pending'} for p in sorted(out.iterdir())]
(out/'MANIFEST.json').write_text(json.dumps({'capture_id':ID,'physical_promotion':0,'status':'CONSTRUCTOR_CONDITIONAL_PHASE_STABILITY_RETURN','supersedes':[],'extends':['2026-10-17T194316Z-codex-complementary-sketch-a6592db4','2026-10-17T193338Z-codex-residual-preflight-7c3d916a'],'verification_scope':'Finite exact-arithmetic estimator theorem; all-readings fitted-reference sketch residual; portable arithmetic replay; two empirical coherent controls; one new full-record signature; no floating implementation or independent/physical promotion','files':entries},indent=2))
(repo/'events'/f'{ID}.json').write_text(json.dumps({'capture_id':ID,'event':'conditional_phase_stability_and_coherent_control_return','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'physical_promotion':0,'summary':'Append unique fitted-reference phase matching at2^-27 on frozen grid; full2^-20 proof inconclusive for unique matching, not observed failure. Two new coherent fits and one fresh1893-value full signature pass. Floating implementation validation and independent/metrology obligations remain open.'},indent=2))
print(json.dumps({'capture':str(out),'zip_bytes':z.stat().st_size,'zip_sha256':sha(z),'files':len(files)}))

"""Bounded same-team negative controls; all mutations confined to new fixtures."""
import importlib.util,json,hashlib,traceback,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np

P=Path(__file__).resolve().parent
SOURCE=P.parent/'rounding-replay-work'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def execute():
 freeze=json.loads((P/'CONTROLS_FREEZE.json').read_text())
 assert sha(__file__)==freeze['control_script_sha256']
 originals={str(x.relative_to(SOURCE)):sha(x) for x in [SOURCE/'certify.py',SOURCE/'FREEZE.json',*sorted((SOURCE/'results').rglob('*.npz'))]}
 assert originals==freeze['original_hashes']
 spec=importlib.util.spec_from_file_location('frozen_svd_certifier',SOURCE/'certify.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 outcomes=[]
 for name in freeze['controls']:
  root=P/'fixtures'/name;d=root/'results'/'legacy_gemm';d.mkdir(parents=True,exist_ok=False)
  for x in (SOURCE/'results').glob('INTEGER_*.npz'):(root/'results'/x.name).symlink_to(x)
  for x in (SOURCE/'results'/'legacy_gemm').glob('*.npz'):(d/x.name).symlink_to(x)
  targets=[d/f'FACTOR_{k}.npz' for k in range(3)] if name=='zero_all_left' else [d/'SVD_META.npz'] if name=='zero_right' else [d/'FACTOR_0.npz']
  for target in targets:
   with np.load(target,allow_pickle=False) as z:data={key:z[key].copy() for key in z.files}
   target.unlink()
   if name=='zero_all_left':data['left']=np.zeros_like(data['left'])
   elif name=='zero_right':data['right_transpose']=np.zeros_like(data['right_transpose'])
   else:data['delta'][0,0]+=1
   np.savez_compressed(target,**data)
  modified={str(x.relative_to(root)):sha(x) for x in targets}
  m.P=root;t=time.monotonic()
  try:
   result=m.certify('legacy_gemm',write=True)
  except AssertionError as exc:
   tb=traceback.format_exc();(root/'EXPECTED_REJECTION.log').write_text(tb)
   outcome={'control':name,'status':'EXPECTED_ASSERTION_REJECTION','exception_type':type(exc).__name__,'exception_message':str(exc),'traceback':tb,'modified_file_hashes':modified,'seconds':time.monotonic()-t}
  else:raise RuntimeError('Countercontrol unexpectedly returned: '+json.dumps(result))
  outcomes.append(outcome);print(json.dumps({k:outcome[k] for k in ['control','status','seconds']}),flush=True)
 after={str(x.relative_to(SOURCE)):sha(x) for x in [SOURCE/'certify.py',SOURCE/'FREEZE.json',*sorted((SOURCE/'results').rglob('*.npz'))]}
 assert after==originals
 result={'status':'PASS_THREE_EXPECTED_REJECTIONS','scope':'Same-team execution; not independent review; frozen original certifier redirected only to isolated fixtures','controls_freeze_sha256':sha(P/'CONTROLS_FREEZE.json'),'original_hashes_before':originals,'original_hashes_after':after,'all_originals_unchanged':True,'outcomes':outcomes,'physical_promotion':0}
 (P/'CONTROLS_RECEIPT.json').write_text(json.dumps(result,indent=2))

if __name__=='__main__':execute()

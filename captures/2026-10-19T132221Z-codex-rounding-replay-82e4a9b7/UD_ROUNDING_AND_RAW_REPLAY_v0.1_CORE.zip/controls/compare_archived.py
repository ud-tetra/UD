"""Supplemental read-only array comparison, not a new phase certificate."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
import numpy as np
P=Path(__file__).resolve().parent
fresh=P.parent/'rounding-replay-work/results/legacy_gemm'
archive=P.parent/'record-contract-work/inputs/cyclic_unit'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p,k):
 with np.load(p,allow_pickle=False) as z:return z[k].copy()
def ah(a):return hashlib.sha256(np.asarray(a).tobytes(order='C')).hexdigest()
checks=[]
fu=np.vstack([load(fresh/f'FACTOR_{k}.npz','left') for k in range(3)])[:,:209]
au=np.vstack([load(archive/f'BASIS_{k}.npz','basis') for k in ['A','B']])
arrays=[('left_retained209',fu,au)]
for key in ['shift','eigenvalues','angles']:arrays.append((key,load(fresh/'PHASE_META.npz',key),load(archive/'FLOAT_META.npz',key)))
arrays.append(('emitted_two_step_phase',load(fresh/'PHASE_PROPOSAL.npz','two_step_phase'),load(archive/'PHASE_PROPOSAL.npz','two_step_phase')))
for name,a,b in arrays:checks.append({'array':name,'shape':list(a.shape),'dtype':str(a.dtype),'same_shape_dtype':a.shape==b.shape and a.dtype==b.dtype,'exact_array_identity':bool(np.array_equal(a,b)),'fresh_array_bytes_sha256':ah(a),'archived_array_bytes_sha256':ah(b)})
files=[*sorted(fresh.glob('FACTOR_*.npz')),fresh/'PHASE_META.npz',fresh/'PHASE_PROPOSAL.npz',archive/'BASIS_A.npz',archive/'BASIS_B.npz',archive/'FLOAT_META.npz',archive/'PHASE_PROPOSAL.npz']
result={'status':'EXACT_IDENTITY' if all(x['exact_array_identity'] and x['same_shape_dtype'] for x in checks) else 'NOT_IDENTICAL','comparison':'Fresh legacy fullfactor execution versus pinned PR204 cyclic_unit input arrays','checks':checks,'source_file_hashes':{str(p):sha(p) for p in files},'new_phase_certificate':False,'independent_review':False,'physical_promotion':0}
(P/'ARCHIVED_ARRAY_COMPARISON.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:result[k] for k in ['status','checks']},indent=2))

# External raw-record and floating-witness replay handoff

Development — no registry entry. Physical promotion **0**. External nonconstructor review is **PENDING**. The fresh recovery and replay here were executed by the constructor team; neither a new process nor separately written arithmetic checks establishes external independence. No new estimator, SVD, apparatus observation or CRL promotion is claimed.

## Pinned scope

Target: PR204 capture `2026-10-18T200728Z-codex-record-contract-5b1e8a94`, the record-wise two-step floating-output admission contract. Its CORE plus all six WITNESS ZIPs contain77 unique members (40341027 uncompressed bytes). The37 root manifest entries match hashes and sizes; archive paths are unique, relative and traversal/symlink-free. These custody checks were separately written; archived scripts were not executed merely to ingest them.

PR204 portable replay is a cached-evidence and saved-array check. It verifies package hashes, basis/cross-Grams, exact scalar fit arithmetic and actual phase residuals. It does **not** regenerate omitted raw records. Full raw replay is separately recorded here.

## Raw recovery dependencies

1. Extract PR195 capture `2026-10-18T172041Z-codex-floating-timing-2f6a91ce`, CORE plus all WITNESS ZIPs. Its included `REFERENCE_PROPOSAL.npz` is sufficient to run the frozen `make_records.py --destination /new/empty/path`; no external codec or data source is required. This regenerates four records, not new apparatus observations. Stress SHA256: `25a0888972c8fb961774ef69430070e07e1cf6bd02ca05fd1bb0a5552c6e9f59`.
2. Stage stress at `floating-timing-work/records/ramp_clock_stress.i64le`, sibling to the other extracted package directories. Do not rewrite source capture files.
3. PR201 capture `2026-10-18T192301Z-codex-uniform-two-step-8a71c9d3`: run unmodified `make_record.py --regenerate /new/path/cyclic_unit.i64le`. SHA256: `fd819bea491085f222d9ad7fef325b922ec75a8690c7b6ac69b2429617c67339`. At preparation a/time k, add one raw quantum with sign (-1)^(a+floor(k/62)) at channel(a+k)%62.
4. PR200 capture `2026-10-18T184202Z-codex-two-step-noise-c54b7a12`: its full `make_records.py --destination /new/empty/path` reconstructs all six noisy records and both noise Grams. The bounded handoff recovery reconstructs only dense_a0 through the identical `default_rng(218209).integers(0,2,size=(37,8191,62),dtype=int64)*2-1` recipe, then verifies all differences and the complete hash. Dense SHA256: `93118b8da1b61f5a015ef7a6234b12ed417797f79a00a85b666246b6c3699817`.
5. Each raw file is150321232 bytes, exactly37 preparations×8191 times×62 channels×8 bytes, little-endian signed int64, raw quantum2^-48. Recovered raw files are omitted from the handoff; they are reproducible.
6. Copy the extracted PR204 package to a separate raw-replay directory. Remove only generated `RAW_REPLAY.json`/`PROJECTION_REPLAY.json` receipts from that copy. Stage the three raw records at its frozen sibling paths, then run `OPENBLAS_NUM_THREADS=1 python project.py --raw-replay` from that directory. This branch contains no SVD/proposer call.

## Independent acceptance checklist

- Record reviewer identity, nonconstructor declaration, affiliation, pinned repository commit, all package/input hashes, Python/library/platform versions, exact commands, UTC times and complete logs. Keep deviations/disagreements visible.
- Validate every archive member/hash before importing executable code. Require declared shapes, finite binary arrays and `allow_pickle=False`. Independently reconstruct source mapping `X[k,c*37+a]=raw[a,k,c]`, integer sketch A of shape2294×321 and scale2^-55.
- Recompute **all** raw differences and vector squared errors, with explicit overflow guards. Baseline peak0 and cyclic peak1 satisfy the frozen PR204 integer-squared budget1; dense peak62 must HOLD. Larger legacy noise gates do not override this gate.
- Recompute full raw sketch norm, all basis/source cross-Grams and raw-to-basis cross-Grams using exact arithmetic. The source sketch is8191×321; this is not full-Hankel validation. Check integer dot-product range before int64 multiplication.
- Recompute exact binary64 basis Grams, polar-alignment defect, both actual saved shift residuals, inverse/eigenpair residuals and emitted2^-60 ties-to-even arguments. Treat all numerical factors as untrusted proposals. Preserve order209/cutoff2^-24, unique209-target matching and original-frequency ambiguity moduloπ.
- Require baseline/cyclic PASS and dense raw HOLD; reproduce zero-coefficient and zero-eigenvector-inverse refusals in both eligible cases (four controls). Do not infer exhaustive adversarial robustness from four controls.
- Freeze review criteria before new checks; do not tune recipes/thresholds after observing results. Different BLAS output bases can differ by rotation; fresh floating runs require their own saved-array certificate and are distinct from byte-exact raw regeneration.
- Complete and sign/date an external receipt with hashes and findings. A missing receipt, externally attributed summary, same-team fresh replay or independent implementation inside the constructor team does not satisfy this external-review requirement. Promotion still requires applicable governance and a custodian ruling.

## Small separately implementable arithmetic checks

For exact dyadic U=u/2^b, C=c/2^d and B=N/2^55, save integer G=u^T u and K=u^T N. Recompute:

`fit_squared = sum(N^2)/2^110 + sum(c*(G*c))/2^(2b+2d) - 2*sum(c*K)/2^(b+55+d)`.

Use exact integers/rationals; reject negative results rather than clipping. A zero coefficient gives exactly `sum(N^2)/2^110`, independently checking the approximation-quality negative control. Separate checks directly summed basis and cross-Gram entries(0,0),(0,208),(104,104),(208,208) for each eligible case and independently expanded each full scalar above. Every sampled entry and both complete scalars matched. Sampling verifies selected entries only; full raw-to-Gram provenance requires the separate complete raw replay.

## Execution distinction

The ordinary cached-witness replay completed by the root constructor and the complete raw replay completed by this same-team worker are separate scopes. Their receipts/logs are retained separately. All four PR195 record hashes and generation-bound rows were freshly reproduced and independently rechecked against the original DATA_FREEZE. PR204 full raw replay checked56,370,462 scalar differences across three records and reproduced both eligible exact sketch-Gram sets. The ordinary replay preserved two actual phase PASS results, one raw HOLD and four negative controls. External nonconstructor review remains pending. An initial raw-replay launch used the wrong working directory and failed before running project.py; its error log is retained, followed by the corrected launch. No frozen numerical code or thresholds were changed.

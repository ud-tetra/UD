"""Reconstruct only the frozen PR200 dense-unit raw control; no fitting."""
from pathlib import Path
import json,hashlib
import numpy as np
P=Path(__file__).resolve().parent.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((P/'two-step-noise-work/NOISE_FREEZE.json').read_text());d=json.loads((P/'two-step-noise-work/DATA_FREEZE.json').read_text());row=next(x for x in d['records'] if x['case']=='dense_a0');assert f['seeds']['dense_sign']==218209 and row['integer_amplitude']==1
base=P/'floating-timing-work/records/ramp_clock_stress.i64le';assert sha(base)==f['baseline_sha256'];out=P/'two-step-noise-work/records/dense_a0.i64le';out.parent.mkdir(exist_ok=True);assert not out.exists();pattern=np.random.default_rng(f['seeds']['dense_sign']).integers(0,2,size=(37,8191,62),dtype=np.int64)*2-1
Y=np.memmap(base,dtype='<i8',mode='r',shape=pattern.shape)
with out.open('xb') as z:z.truncate(150321232)
Z=np.memmap(out,dtype='<i8',mode='r+',shape=pattern.shape);Z[:]=Y+pattern;Z.flush();del Z
Z=np.memmap(out,dtype='<i8',mode='r',shape=pattern.shape);n=0;peak=0
for k in range(0,8191,256):
 diff=Z[:,k:k+256]-Y[:,k:k+256];assert np.array_equal(diff,pattern[:,k:k+256]);peak=max(peak,int(np.sum(diff*diff,axis=-1).max()));n+=diff.size
assert n==18790154 and peak==62 and out.stat().st_size==150321232 and sha(out)==row['record_sha256'];assert sha(base)==f['baseline_sha256']
r={'status':'PASS_IDENTICAL_DENSE_A0_RAW_RECONSTRUCTION','case':'dense_a0','source_freeze_sha256':sha(P/'two-step-noise-work/NOISE_FREEZE.json'),'source_data_freeze_sha256':sha(P/'two-step-noise-work/DATA_FREEZE.json'),'script_sha256':sha(__file__),'seed':f['seeds']['dense_sign'],'raw_sha256':sha(out),'bytes':out.stat().st_size,'all_scalar_differences_checked':n,'max_vector_integer_squared_error':peak,'raw_vector_error_squared':[62,1<<96],'PR204_raw_eligibility':'HOLD_RAW_NOISE_BALL','new_estimator_runs':0,'external_independent_review':False,'physical_promotion':0};(P/'replay-handoff-work/DENSE_RECONSTRUCTION_RECEIPT.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))

# UD Registry Note — Parity Carrier CRL-2d Promotion

`UD_HODGE_EVENT_RETAINED_PARITY_CARRIER_THEOREM_v0.1` is now registered at **CRL-2d REPLICATED**.

Promotion basis:

- CRL-2c blinded execution PASS;
- fresh independent CRL-2d replication by Gemini / Google;
- frozen hash commitments matched;
- 12/12 valid cases passed;
- 6/6 adversarial controls rejected;
- 0 in-scope failures;
- custodian ruling `PROMOTE_TO_CRL2D`.

Permanent rider:

`PARITY_CARRIER_THEOREM_IS_TRANSPORT_CONSISTENCY_NOT_DYNAMICAL_DISCOVERY_v0.1`

This remains an internal carrier theorem. CRL-2d makes the claim eligible for CRL-3 consideration but does not create a physical bridge. Physical promotion remains 0.

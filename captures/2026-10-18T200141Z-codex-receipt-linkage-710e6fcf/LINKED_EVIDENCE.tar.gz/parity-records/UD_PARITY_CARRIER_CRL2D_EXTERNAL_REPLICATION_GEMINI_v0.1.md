# UD_PARITY_CARRIER_CRL2D_EXTERNAL_REPLICATION_GEMINI_v0.1

**Replication date:** 2026-09-18  
**Replicator:** Gemini (Independent Replication Harness)  
**Provider:** Google  
**Constructor involvement:** NO  
**CRL-2c executor:** NO  
**Saw sealed key before output hashing:** NO  
**Runtime:** Python 3.10 / NumPy  
**Reported output filename:** `UD_PARITY_CARRIER_CRL2D_REPLICATION_OUTPUT_v0.1.json`  
**Reported output SHA256:** `ca00425aad5a2ba6d5da33e9c74eb2c5bd9fca0738d33778727ba3e8b7e18380`  
**Physical promotion:** 0

## Frozen artifact verification

- blind cases SHA256: `74070e67e32a436920952278a0cfa8db76538d1a5fccbd4d952e85998858b3ee` — MATCH
- replication runner SHA256: `d9d16ff90b6ff2066f147605160c1a983d7f8b16459ec9235eaab2c39f682c97` — MATCH
- theorem SHA256: `47fea91d97f8e2c4441b7bab1f1ad06f9a8fc74507f34645433572791d74a863` — MATCH

## Blind scoring against sealed key

- 12/12 valid cases: `IN_SCOPE_PASS`
- 6/6 adversarial controls: `CONTROL_FAIL`
- 0 `IN_SCOPE_FAIL`
- missing IDs: 0
- extra IDs: 0
- classification mismatches: 0

## Replication verdict

**PASS**

The reported case classifications exactly match the frozen sealed answer key.

## Pre-freeze repair confirmation

The reciprocal-scaling control `403925e4b3d2a9` was reported as `CONTROL_FAIL`, confirming that the repaired runner distinguishes exact Q121 family membership from mere commutation with parity.

## Scope firewall

The permanent claim rider remains active:

`PARITY_CARRIER_THEOREM_IS_TRANSPORT_CONSISTENCY_NOT_DYNAMICAL_DISCOVERY_v0.1`

This independent replication confirms the frozen carrier-consistency theorem under the preregistered replication protocol. It does not establish physical parity, time reversal, CP/T, or SA-023.

## Registry consequence

Current governance requires a custodian ruling for promotion.

Accordingly, the replication state is:

**CRL-2c EXECUTED / INDEPENDENT REPLICATION PASS / CUSTODIAN RULING PENDING**

No CRL-2d registry promotion is claimed in this artifact.

**Physical promotion remains 0.**

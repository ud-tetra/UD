# UD Manuscript Addendum — Parity Carrier CRL-2d Replication

**Physical promotion:** 0

The theorem `UD_HODGE_EVENT_RETAINED_PARITY_CARRIER_THEOREM_v0.1` has advanced to **CRL-2d REPLICATED** after passing both a preregistered blinded execution and a fresh independent replication. The replication used a distinct blind set and runner lineage, with 12/12 valid cases passing, 6/6 adversarial controls correctly rejected, and no in-scope failures.

The permanent reviewer rider remains binding: the theorem is a carrier-parity transport/consistency identity, true largely by construction, and not a substantive dynamical discovery. The result does not imply SA-023, physical parity, physical time reversal, or CP/T. CRL-2d makes the theorem eligible for later CRL-3 consideration only if a separate physical-identification bridge is independently closed.

# UD_PARITY_CARRIER_CRL2D_CUSTODIAN_RULING_v0.1

**Ruling date:** 2026-09-18  
**Custodian ruling:** `PROMOTE_TO_CRL2D`  
**Claim:** `UD_HODGE_EVENT_RETAINED_PARITY_CARRIER_THEOREM_v0.1`  
**Previous status:** `CRL-2c EXECUTED / INDEPENDENT REPLICATION PASS / CUSTODIAN RULING PENDING`  
**Effective status:** `CRL-2d REPLICATED`  
**Physical promotion:** 0

## Frozen lineage

- theorem SHA256: `47fea91d97f8e2c4441b7bab1f1ad06f9a8fc74507f34645433572791d74a863`
- CRL-2c execution record SHA256: `762916a56873ddc3a1527e848ae72738aedda337e0cbc4d6f16a9b901e077088`
- independent Gemini replication report SHA256: `197022db6b964feef994db26af31a9aa3b334813ad679bfc90c5d87e1f6b9f4c`
- replication score ledger SHA256: `c02c6f87f99b2cafda8e6edd9f92d0a9391dbf247dede8e876d5ccb97dddfb2c`

## Promotion basis

The claim completed the CRL-2d replication gate:

1. CRL-2c blinded execution passed;
2. a fresh CRL-2d replication packet was frozen;
3. the independent replicator lineage was declared:
   - Gemini / Google;
   - not involved in theorem construction;
   - not the CRL-2c executor;
   - no sealed-key exposure before output hashing;
4. frozen theorem / blind-case / runner hashes matched;
5. 12/12 valid replication cases returned `IN_SCOPE_PASS`;
6. 6/6 adversarial controls returned `CONTROL_FAIL`;
7. 0 `IN_SCOPE_FAIL`;
8. 0 classification mismatches;
9. the pre-freeze reciprocal-scaling repair was exercised successfully.

No confidence rung was skipped.

## Effective registry status

**CRL-2d REPLICATED**

## Permanent rider

`PARITY_CARRIER_THEOREM_IS_TRANSPORT_CONSISTENCY_NOT_DYNAMICAL_DISCOVERY_v0.1`

The theorem remains an exact carrier-parity transport/consistency identity, true largely by construction. It must not be used to infer SA-023, physical parity, physical time reversal, or CP/T.

## Scope firewall

CRL-2d does not itself establish:

- physical identification;
- physical time reversal;
- physical parity;
- CP/T;
- SA-023;
- parity on the Hodge complement.

Under governance, CRL-2d makes the claim eligible for CRL-3 consideration only. Any physical-identification step requires its own independently closed bridge.

**Physical promotion remains 0.**

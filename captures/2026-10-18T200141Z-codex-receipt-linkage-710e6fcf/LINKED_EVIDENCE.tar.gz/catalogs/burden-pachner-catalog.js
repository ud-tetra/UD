export const burdenPachnerDocs = {
  "burdenPachnerSource1": {
    "title": "Burden Ancestry Tagging",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource1.html",
    "source": "./source/burden-pachner/SOURCE_ADDENDUM_BURDEN_ANCESTRY_TAGGING_v0.1.md"
  },
  "burdenPachnerSource2": {
    "title": "Burden Memory As Semigroup Retention",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource2.html",
    "source": "./source/burden-pachner/SOURCE_ADDENDUM_BURDEN_MEMORY_AS_SEMIGROUP_RETENTION_v0.2.md"
  },
  "burdenPachnerSource3": {
    "title": "Burden Viability As Response Capacity",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource3.html",
    "source": "./source/burden-pachner/SOURCE_ADDENDUM_BURDEN_VIABILITY_AS_RESPONSE_CAPACITY_v0.1.md"
  },
  "burdenPachnerSource4": {
    "title": "Reference Scale And Obstruction Candidate Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BSTAR_AND_FB_CANDIDATE_AUDIT_v0.1.csv",
    "source": "./source/burden-pachner/UD_BSTAR_AND_FB_CANDIDATE_AUDIT_v0.1.csv"
  },
  "burdenPachnerSource5": {
    "title": "Reference Scale And Obstruction Uniqueness",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BSTAR_AND_FB_UNIQUENESS_v0.1_HASH.json",
    "source": "./source/burden-pachner/UD_BSTAR_AND_FB_UNIQUENESS_v0.1_HASH.json"
  },
  "burdenPachnerSource6": {
    "title": "Burden Ancestry Tagging And Recursive Inherited Load",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BURDEN_ANCESTRY_TAGGING_AND_RECURSIVE_IINH_v0.1_HASH.json",
    "source": "./source/burden-pachner/UD_BURDEN_ANCESTRY_TAGGING_AND_RECURSIVE_IINH_v0.1_HASH.json"
  },
  "burdenPachnerSource7": {
    "title": "Burden Ancestry Tagging Schema",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BURDEN_ANCESTRY_TAGGING_SCHEMA_v0.1.csv",
    "source": "./source/burden-pachner/UD_BURDEN_ANCESTRY_TAGGING_SCHEMA_v0.1.csv"
  },
  "burdenPachnerSource8": {
    "title": "Burden Breathing Receipt State",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource8.html",
    "source": "./source/burden-pachner/UD_BURDEN_BREATHING_RECEIPT_STATE_v0.1%20%281%29.md"
  },
  "burdenPachnerSource9": {
    "title": "Burden Breathing State Rebase",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource9.html",
    "source": "./source/burden-pachner/UD_BURDEN_BREATHING_STATE_REBASE_v0.1%281%29.md"
  },
  "burdenPachnerSource10": {
    "title": "Burden Capacity And Composition Frontier",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BURDEN_CAPACITY_AND_COMPOSITION_FRONTIER_v0.1.csv",
    "source": "./source/burden-pachner/UD_BURDEN_CAPACITY_AND_COMPOSITION_FRONTIER_v0.1.csv"
  },
  "burdenPachnerSource11": {
    "title": "Burden Clock And Memory Comparison",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BURDEN_CLOCK_AND_MEMORY_COMPARISON_v0.1%281%29.csv",
    "source": "./source/burden-pachner/UD_BURDEN_CLOCK_AND_MEMORY_COMPARISON_v0.1%281%29.csv"
  },
  "burdenPachnerSource12": {
    "title": "Burden Clock And Memory",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BURDEN_CLOCK_AND_MEMORY_v0.1_HASH%281%29.json",
    "source": "./source/burden-pachner/UD_BURDEN_CLOCK_AND_MEMORY_v0.1_HASH%281%29.json"
  },
  "burdenPachnerSource13": {
    "title": "Burden Clock Normalization Reconciliation",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource13.html",
    "source": "./source/burden-pachner/UD_BURDEN_CLOCK_NORMALIZATION_RECONCILIATION_v0.1%281%29.md"
  },
  "burdenPachnerSource14": {
    "title": "Burden Memory Semigroup Adversarial Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource14.html",
    "source": "./source/burden-pachner/UD_BURDEN_MEMORY_SEMIGROUP_ADVERSARIAL_AUDIT_v0.1.md"
  },
  "burdenPachnerSource15": {
    "title": "Burden Memory Semigroup Retention",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource15.html",
    "source": "./source/burden-pachner/UD_BURDEN_MEMORY_SEMIGROUP_RETENTION_v0.1%281%29.md"
  },
  "burdenPachnerSource16": {
    "title": "Burden Obstruction Functional Uniqueness Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource16.html",
    "source": "./source/burden-pachner/UD_BURDEN_OBSTRUCTION_FUNCTIONAL_UNIQUENESS_AUDIT_v0.1.md"
  },
  "burdenPachnerSource17": {
    "title": "Burden Obstruction Map And Stock Normalization Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource17.html",
    "source": "./source/burden-pachner/UD_BURDEN_OBSTRUCTION_MAP_AND_STOCK_NORMALIZATION_AUDIT_v0.1.md"
  },
  "burdenPachnerSource18": {
    "title": "Burden Receipt And Frontier Homogenization",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BURDEN_RECEIPT_AND_FRONTIER_HOMOGENIZATION_v0.1_HASH%281%29.json",
    "source": "./source/burden-pachner/UD_BURDEN_RECEIPT_AND_FRONTIER_HOMOGENIZATION_v0.1_HASH%281%29.json"
  },
  "burdenPachnerSource19": {
    "title": "Burden State After Viability Closure",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource19.html",
    "source": "./source/burden-pachner/UD_BURDEN_STATE_AFTER_VIABILITY_CLOSURE_v0.1.md"
  },
  "burdenPachnerSource20": {
    "title": "Burden Stock Reference Scale Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource20.html",
    "source": "./source/burden-pachner/UD_BURDEN_STOCK_REFERENCE_SCALE_AUDIT_v0.1.md"
  },
  "burdenPachnerSource21": {
    "title": "Burden Storage Capacity Identifiability Limit And Source Requirement",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource21.html",
    "source": "./source/burden-pachner/UD_BURDEN_STORAGE_CAPACITY_NO_GO_AND_SOURCE_REQUIREMENT_v0.1.md"
  },
  "burdenPachnerSource22": {
    "title": "Burden Temporal Memory And Inherited Load Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource22.html",
    "source": "./source/burden-pachner/UD_BURDEN_TEMPORAL_MEMORY_AND_INHERITED_LOAD_AUDIT_v0.1%281%29.md"
  },
  "burdenPachnerSource23": {
    "title": "Burden Variational Viability Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource23.html",
    "source": "./source/burden-pachner/UD_BURDEN_VARIATIONAL_VIABILITY_AUDIT_v0.1.md"
  },
  "burdenPachnerSource24": {
    "title": "Burden Variational Viability Examples",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_BURDEN_VARIATIONAL_VIABILITY_EXAMPLES_v0.1.csv",
    "source": "./source/burden-pachner/UD_BURDEN_VARIATIONAL_VIABILITY_EXAMPLES_v0.1.csv"
  },
  "burdenPachnerSource25": {
    "title": "Burden Viability Coordinate Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource25.html",
    "source": "./source/burden-pachner/UD_BURDEN_VIABILITY_COORDINATE_AUDIT_v0.1%281%29.md"
  },
  "burdenPachnerSource26": {
    "title": "Burden Viability Scalar Closure Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource26.html",
    "source": "./source/burden-pachner/UD_BURDEN_VIABILITY_SCALAR_CLOSURE_AUDIT_v0.1%20%281%29.md"
  },
  "burdenPachnerSource27": {
    "title": "Capacity And Composition Frontier",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_CAPACITY_AND_COMPOSITION_FRONTIER_v0.1_HASH.json",
    "source": "./source/burden-pachner/UD_CAPACITY_AND_COMPOSITION_FRONTIER_v0.1_HASH.json"
  },
  "burdenPachnerSource28": {
    "title": "Obstruction Normalization And Viability Coarse Stability",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_FB_NORMALIZATION_AND_VIABILITY_COARSE_STABILITY_v0.1_HASH.json",
    "source": "./source/burden-pachner/UD_FB_NORMALIZATION_AND_VIABILITY_COARSE_STABILITY_v0.1_HASH.json"
  },
  "burdenPachnerSource29": {
    "title": "Frontier Admissibility Comparison",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_FRONTIER_ADMISSIBILITY_COMPARISON_v0.1%281%29.csv",
    "source": "./source/burden-pachner/UD_FRONTIER_ADMISSIBILITY_COMPARISON_v0.1%281%29.csv"
  },
  "burdenPachnerSource30": {
    "title": "Frontier Pseudomanifold Derivation Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource30.html",
    "source": "./source/burden-pachner/UD_FRONTIER_PSEUDOMANIFOLD_DERIVATION_AUDIT_v0.1%281%29.md"
  },
  "burdenPachnerSource31": {
    "title": "Geometry Homogenization Rate Examples",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_GEOMETRY_HOMOGENIZATION_RATE_EXAMPLES_v0.1.csv",
    "source": "./source/burden-pachner/UD_GEOMETRY_HOMOGENIZATION_RATE_EXAMPLES_v0.1.csv"
  },
  "burdenPachnerSource32": {
    "title": "Global Burden Operator And State Rebase",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_GLOBAL_BURDEN_OPERATOR_AND_STATE_REBASE_v0.1_HASH%281%29.json",
    "source": "./source/burden-pachner/UD_GLOBAL_BURDEN_OPERATOR_AND_STATE_REBASE_v0.1_HASH%281%29.json"
  },
  "burdenPachnerSource33": {
    "title": "Global Glued Burden Operator Q162",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource33.html",
    "source": "./source/burden-pachner/UD_GLOBAL_GLUED_BURDEN_OPERATOR_Q162_v0.1%281%29.md"
  },
  "burdenPachnerSource34": {
    "title": "Irregular Graph Neighbor Clock Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource34.html",
    "source": "./source/burden-pachner/UD_IRREGULAR_GRAPH_NEIGHBOR_CLOCK_AUDIT_v0.1.md"
  },
  "burdenPachnerSource35": {
    "title": "Local 3Manifold Link Adversarial Compatibility Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource35.html",
    "source": "./source/burden-pachner/UD_LOCAL_3MANIFOLD_LINK_ADVERSARIAL_COMPATIBILITY_AUDIT_v0.1%281%29.md"
  },
  "burdenPachnerSource36": {
    "title": "Ancestry Resolved Inherited Burden",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource36.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_ANCESTRY_RESOLVED_INHERITED_BURDEN_v0.1.md"
  },
  "burdenPachnerSource37": {
    "title": "Reference Scale And Obstruction Uniqueness",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource37.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_BSTAR_AND_FB_UNIQUENESS_v0.1.md"
  },
  "burdenPachnerSource38": {
    "title": "Burden Clock And Memory",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource38.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_BURDEN_CLOCK_AND_MEMORY_v0.1%281%29.md"
  },
  "burdenPachnerSource39": {
    "title": "Burden Receipt And Homogenization",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource39.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_BURDEN_RECEIPT_AND_HOMOGENIZATION_v0.1%281%29.md"
  },
  "burdenPachnerSource40": {
    "title": "Capacity And Composition Frontier",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource40.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_CAPACITY_AND_COMPOSITION_FRONTIER_v0.1.md"
  },
  "burdenPachnerSource41": {
    "title": "Obstruction Normalization And Viability Coarse Stability",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource41.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_FB_NORMALIZATION_AND_VIABILITY_COARSE_STABILITY_v0.1.md"
  },
  "burdenPachnerSource42": {
    "title": "Global Burden Operator And State Rebase",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource42.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_GLOBAL_BURDEN_OPERATOR_AND_STATE_REBASE_v0.1%281%29.md"
  },
  "burdenPachnerSource43": {
    "title": "Memory And Irregular Clock",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource43.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_MEMORY_AND_IRREGULAR_CLOCK_v0.1.md"
  },
  "burdenPachnerSource44": {
    "title": "Pachner Response And Port Hamiltonian Burden",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource44.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_PACHNER_RESPONSE_AND_PORT_HAMILTONIAN_BURDEN_v0.1.md"
  },
  "burdenPachnerSource45": {
    "title": "Temporal Burden And Spatial Manifold Scope",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource45.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_TEMPORAL_BURDEN_AND_SPATIAL_MANIFOLD_SCOPE_v0.1%281%29.md"
  },
  "burdenPachnerSource46": {
    "title": "Variational Burden Viability",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource46.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_VARIATIONAL_BURDEN_VIABILITY_v0.1.md"
  },
  "burdenPachnerSource47": {
    "title": "Viability And Clock Admission",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource47.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_VIABILITY_AND_CLOCK_ADMISSION_v0.1%20%281%29.md"
  },
  "burdenPachnerSource48": {
    "title": "Viability And Manifold Frontier",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource48.html",
    "source": "./source/burden-pachner/UD_MANUSCRIPT_ADDENDUM_VIABILITY_AND_MANIFOLD_FRONTIER_v0.1%281%29.md"
  },
  "burdenPachnerSource49": {
    "title": "Memory And Irregular Clock",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_MEMORY_AND_IRREGULAR_CLOCK_v0.1_HASH.json",
    "source": "./source/burden-pachner/UD_MEMORY_AND_IRREGULAR_CLOCK_v0.1_HASH.json"
  },
  "burdenPachnerSource50": {
    "title": "Obstruction Composition Principle Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource50.html",
    "source": "./source/burden-pachner/UD_OBSTRUCTION_COMPOSITION_PRINCIPLE_AUDIT_v0.1.md"
  },
  "burdenPachnerSource51": {
    "title": "Pachner 2↔3 Hodge Dirac Move Response",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource51.html",
    "source": "./source/burden-pachner/UD_PACHNER_23_HODGE_DIRAC_MOVE_RESPONSE_v0.1.md"
  },
  "burdenPachnerSource52": {
    "title": "Pachner 2↔3 Move Spectral Telemetry",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_PACHNER_23_MOVE_SPECTRAL_TELEMETRY_v0.1.csv",
    "source": "./source/burden-pachner/UD_PACHNER_23_MOVE_SPECTRAL_TELEMETRY_v0.1.csv"
  },
  "burdenPachnerSource53": {
    "title": "Pachner And Port Hamiltonian Frontier",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_PACHNER_AND_PORT_HAMILTONIAN_FRONTIER_v0.1_HASH.json",
    "source": "./source/burden-pachner/UD_PACHNER_AND_PORT_HAMILTONIAN_FRONTIER_v0.1_HASH.json"
  },
  "burdenPachnerSource54": {
    "title": "Partner Math Roadmap Analysis",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource54.html",
    "source": "./source/burden-pachner/UD_PARTNER_MATH_ROADMAP_ANALYSIS_v0.1.md"
  },
  "burdenPachnerSource55": {
    "title": "Partner Math Roadmap Analysis",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_PARTNER_MATH_ROADMAP_ANALYSIS_v0.1_HASH.json",
    "source": "./source/burden-pachner/UD_PARTNER_MATH_ROADMAP_ANALYSIS_v0.1_HASH.json"
  },
  "burdenPachnerSource56": {
    "title": "Partner Math Roadmap Priority Matrix",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_PARTNER_MATH_ROADMAP_PRIORITY_MATRIX_v0.1.csv",
    "source": "./source/burden-pachner/UD_PARTNER_MATH_ROADMAP_PRIORITY_MATRIX_v0.1.csv"
  },
  "burdenPachnerSource57": {
    "title": "Port Hamiltonian Burden Support Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource57.html",
    "source": "./source/burden-pachner/UD_PORT_HAMILTONIAN_BURDEN_SUPPORT_AUDIT_v0.1.md"
  },
  "burdenPachnerSource58": {
    "title": "Port Hamiltonian Burden Support Status",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_PORT_HAMILTONIAN_BURDEN_SUPPORT_STATUS_v0.1.csv",
    "source": "./source/burden-pachner/UD_PORT_HAMILTONIAN_BURDEN_SUPPORT_STATUS_v0.1.csv"
  },
  "burdenPachnerSource59": {
    "title": "Reciprocal Neighbor Proposal Clock Adversarial Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource59.html",
    "source": "./source/burden-pachner/UD_RECIPROCAL_NEIGHBOR_PROPOSAL_CLOCK_ADVERSARIAL_AUDIT_v0.1.md"
  },
  "burdenPachnerSource60": {
    "title": "Recursive Frontier Homogenization Audit",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource60.html",
    "source": "./source/burden-pachner/UD_RECURSIVE_FRONTIER_HOMOGENIZATION_AUDIT_v0.1.md"
  },
  "burdenPachnerSource61": {
    "title": "Recursive K₄ Inherited Burden Derivation",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource61.html",
    "source": "./source/burden-pachner/UD_RECURSIVE_K4_INHERITED_BURDEN_DERIVATION_v0.1.md"
  },
  "burdenPachnerSource62": {
    "title": "Recursive Tagged Multik4 Cell Viability",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_RECURSIVE_TAGGED_MULTIK4_CELL_VIABILITY_v0.1.csv",
    "source": "./source/burden-pachner/UD_RECURSIVE_TAGGED_MULTIK4_CELL_VIABILITY_v0.1.csv"
  },
  "burdenPachnerSource63": {
    "title": "Recursive Tagged Multik4 Viability Simulation",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource63.html",
    "source": "./source/burden-pachner/UD_RECURSIVE_TAGGED_MULTIK4_VIABILITY_SIMULATION_v0.1.md"
  },
  "burdenPachnerSource64": {
    "title": "Recursive Tagged Multik4 Viability Sim",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_RECURSIVE_TAGGED_MULTIK4_VIABILITY_SIM_v0.1.csv",
    "source": "./source/burden-pachner/UD_RECURSIVE_TAGGED_MULTIK4_VIABILITY_SIM_v0.1.csv"
  },
  "burdenPachnerSource65": {
    "title": "Spatial Manifold Branch Compatibility",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_SPATIAL_MANIFOLD_BRANCH_COMPATIBILITY_v0.1%281%29.csv",
    "source": "./source/burden-pachner/UD_SPATIAL_MANIFOLD_BRANCH_COMPATIBILITY_v0.1%281%29.csv"
  },
  "burdenPachnerSource66": {
    "title": "Temporal Burden And Spatial Manifold Scope",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_TEMPORAL_BURDEN_AND_SPATIAL_MANIFOLD_SCOPE_v0.1_HASH%281%29.json",
    "source": "./source/burden-pachner/UD_TEMPORAL_BURDEN_AND_SPATIAL_MANIFOLD_SCOPE_v0.1_HASH%281%29.json"
  },
  "burdenPachnerSource67": {
    "title": "Two K₄ Global Burden Operator Q162",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_TWO_K4_GLOBAL_BURDEN_OPERATOR_Q162_v0.1%281%29.csv",
    "source": "./source/burden-pachner/UD_TWO_K4_GLOBAL_BURDEN_OPERATOR_Q162_v0.1%281%29.csv"
  },
  "burdenPachnerSource68": {
    "title": "Two K₄ Irregular Clock Comparison",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_TWO_K4_IRREGULAR_CLOCK_COMPARISON_v0.1.csv",
    "source": "./source/burden-pachner/UD_TWO_K4_IRREGULAR_CLOCK_COMPARISON_v0.1.csv"
  },
  "burdenPachnerSource69": {
    "title": "Variational Burden Viability",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_VARIATIONAL_BURDEN_VIABILITY_v0.1_HASH.json",
    "source": "./source/burden-pachner/UD_VARIATIONAL_BURDEN_VIABILITY_v0.1_HASH.json"
  },
  "burdenPachnerSource70": {
    "title": "Variational Viability Coarse Graining Theorem",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "html",
    "file": "./content/burden-pachner/burdenPachnerSource70.html",
    "source": "./source/burden-pachner/UD_VARIATIONAL_VIABILITY_COARSE_GRAINING_THEOREM_v0.1.md"
  },
  "burdenPachnerSource71": {
    "title": "Viability And Clock Admission",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_VIABILITY_AND_CLOCK_ADMISSION_v0.1_HASH%20%281%29.json",
    "source": "./source/burden-pachner/UD_VIABILITY_AND_CLOCK_ADMISSION_v0.1_HASH%20%281%29.json"
  },
  "burdenPachnerSource72": {
    "title": "Viability And Clock Nonuniqueness Examples",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_VIABILITY_AND_CLOCK_NONUNIQUENESS_EXAMPLES_v0.1%20%281%29.csv",
    "source": "./source/burden-pachner/UD_VIABILITY_AND_CLOCK_NONUNIQUENESS_EXAMPLES_v0.1%20%281%29.csv"
  },
  "burdenPachnerSource73": {
    "title": "Viability And Manifold Frontier",
    "label": "Preserved source · read with current review",
    "note": "Original source and historical status labels retained. The current review qualifies model definitions, fixed-space memory, topology, storage and reproducibility.",
    "kind": "code",
    "file": "./source/burden-pachner/UD_VIABILITY_AND_MANIFOLD_FRONTIER_v0.1_HASH%281%29.json",
    "source": "./source/burden-pachner/UD_VIABILITY_AND_MANIFOLD_FRONTIER_v0.1_HASH%281%29.json"
  }
};
export const burdenPachnerOrder = ["burdenPachnerSource1", "burdenPachnerSource2", "burdenPachnerSource3", "burdenPachnerSource4", "burdenPachnerSource5", "burdenPachnerSource6", "burdenPachnerSource7", "burdenPachnerSource8", "burdenPachnerSource9", "burdenPachnerSource10", "burdenPachnerSource11", "burdenPachnerSource12", "burdenPachnerSource13", "burdenPachnerSource14", "burdenPachnerSource15", "burdenPachnerSource16", "burdenPachnerSource17", "burdenPachnerSource18", "burdenPachnerSource19", "burdenPachnerSource20", "burdenPachnerSource21", "burdenPachnerSource22", "burdenPachnerSource23", "burdenPachnerSource24", "burdenPachnerSource25", "burdenPachnerSource26", "burdenPachnerSource27", "burdenPachnerSource28", "burdenPachnerSource29", "burdenPachnerSource30", "burdenPachnerSource31", "burdenPachnerSource32", "burdenPachnerSource33", "burdenPachnerSource34", "burdenPachnerSource35", "burdenPachnerSource36", "burdenPachnerSource37", "burdenPachnerSource38", "burdenPachnerSource39", "burdenPachnerSource40", "burdenPachnerSource41", "burdenPachnerSource42", "burdenPachnerSource43", "burdenPachnerSource44", "burdenPachnerSource45", "burdenPachnerSource46", "burdenPachnerSource47", "burdenPachnerSource48", "burdenPachnerSource49", "burdenPachnerSource50", "burdenPachnerSource51", "burdenPachnerSource52", "burdenPachnerSource53", "burdenPachnerSource54", "burdenPachnerSource55", "burdenPachnerSource56", "burdenPachnerSource57", "burdenPachnerSource58", "burdenPachnerSource59", "burdenPachnerSource60", "burdenPachnerSource61", "burdenPachnerSource62", "burdenPachnerSource63", "burdenPachnerSource64", "burdenPachnerSource65", "burdenPachnerSource66", "burdenPachnerSource67", "burdenPachnerSource68", "burdenPachnerSource69", "burdenPachnerSource70", "burdenPachnerSource71", "burdenPachnerSource72", "burdenPachnerSource73"];

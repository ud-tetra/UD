export const sessionDocs = {
  "sessionFullFeedback": {
    "title": "Full acceleration-feedback sampling and inverse-mass contract",
    "label": "Development \u00b7 2026-09-25",
    "note": "Sampled full acceleration, inverse-mass conversion, independent force enclosure and complete comparison budget; 173 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionFullFeedback.html",
    "source": "./source/full-feedback-v0.1/UD_FULL_ACCELERATION_FEEDBACK_CONTRACT_v0.1.md"
  },
  "sessionSampledFeedback": {
    "title": "Sampled damping, sensing and latency contract",
    "label": "Development \u00b7 2026-09-25",
    "note": "Independent raw-force enclosure, bounded-age sensing and actuator residuals, two operator classes and delayed-power controls; 117 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionSampledFeedback.html",
    "source": "./source/sampled-feedback-v0.1/UD_SAMPLED_DAMPING_AND_LATENCY_CONTRACT_v0.1.md"
  },
  "sessionSharedDamping": {
    "title": "Shared dissipative-feedback and velocity-gap certificate",
    "label": "Development \u00b7 2026-09-25",
    "note": "Shared bounded PSD damping, independent trajectory/velocity-gap control, retained paired sign budgets and exact work identities; 81 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionSharedDamping.html",
    "source": "./source/shared-damping-v0.1/UD_SHARED_DISSIPATIVE_FEEDBACK_CERTIFICATE_v0.1.md"
  },
  "sessionPairedDisturbance": {
    "title": "Shared and differential canonical-force certificate",
    "label": "Development \u00b7 2026-09-25",
    "note": "Paired cancellation with Hessian and timing remainders; shared caps 256 times retained unequal-force caps under declared identical-history assumptions; 85 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionPairedDisturbance.html",
    "source": "./source/paired-disturbance-v0.1/UD_SHARED_AND_DIFFERENTIAL_FORCE_CERTIFICATE_v0.1.md"
  },
  "sessionComponentAdmissibility": {
    "title": "Active-emulator admissibility and structural sensitivity audit",
    "label": "Development \u00b7 2026-09-25",
    "note": "Exact acceleration-feedback model, command/plant error map, virtual-versus-platform energy distinction and early-time damping obstruction; 66 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionComponentAdmissibility.html",
    "source": "./source/component-admissibility-v0.1/UD_ACTIVE_EMULATOR_AND_STRUCTURAL_SENSITIVITY_AUDIT_v0.1.md"
  },
  "sessionImplementationDefect": {
    "title": "Implementation-defect, damping and external-work certificate",
    "label": "Development \u00b7 2026-09-25",
    "note": "Bounded deterministic residuals and mechanical forces, retained acquisition margins, damping caps and exact work receipts; 112 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionImplementationDefect.html",
    "source": "./source/implementation-defect-v0.1/UD_IMPLEMENTATION_DEFECT_AND_WORK_CERTIFICATE_v0.1.md"
  },
  "sessionUnitsCalibration": {
    "title": "Canonical mechanical target and units-calibration contract",
    "label": "Development \u00b7 2026-09-25",
    "note": "Exact nine-pair canonical chart, regular mechanical representation, symbolic SI dictionary and inherited calibration/readout budgets; 82 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionUnitsCalibration.html",
    "source": "./source/units-calibration-v0.1/UD_CANONICAL_MECHANICAL_AND_UNITS_CALIBRATION_CONTRACT_v0.1.md"
  },
  "sessionMismatchTiming": {
    "title": "Independent parameter mismatch and sampling-time certificate",
    "label": "Development \u00b7 2026-09-25",
    "note": "Independent fixed parameter errors, off-coupling leakage, asynchronous sampling and a combined error budget; 134 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionMismatchTiming.html",
    "source": "./source/mismatch-timing-v0.1/UD_PARAMETER_MISMATCH_AND_TIMING_CERTIFICATE_v0.1.md"
  },
  "sessionAccountingWindow": {
    "title": "Energy-accounting comparison and aggregate readout contract",
    "label": "Development \u00b7 2026-09-25",
    "note": "Longer certified intervals with a weaker source margin; general energy receipt, aggregate readout limits and deterministic uncertainty; 97 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionAccountingWindow.html",
    "source": "./source/accounting-window-v0.1/UD_ENERGY_ACCOUNTING_COMPARISON_AND_READOUT_CONTRACT_v0.1.md"
  },
  "sessionProjectedWindow": {
    "title": "Projected comparison and observable-error budgets",
    "label": "Development \u00b7 2026-09-25",
    "note": "Larger projected intervals, exact matrix error budgets, readout blind directions and a separate energy-accounting implication; 119 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionProjectedWindow.html",
    "source": "./source/projected-window-v0.1/UD_PROJECTED_COMPARISON_AND_OBSERVABLE_ERROR_BUDGET_v0.1.md"
  },
  "sessionPairedWindow": {
    "title": "Paired enclosure and launch-error budget",
    "label": "Development \u00b7 2026-09-25",
    "note": "Larger uniform comparison intervals and explicit initial-state-error allowances on positive-start windows; 66 new grouped checks. Bounds remain conservative and physically uncalibrated.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionPairedWindow.html",
    "source": "./source/paired-window-v0.1/UD_PAIRED_ENCLOSURE_AND_LAUNCH_ERROR_BUDGET_v0.1.md"
  },
  "sessionRobustWindow": {
    "title": "Uniform comparison bounds and preparation matching",
    "label": "Development \u00b7 2026-09-25",
    "note": "Uniform signs on three continuous matched parameter/preparation boxes, source-null admission, conservative intervals and an unmatched-launch obstruction; 73 new grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionRobustWindow.html",
    "source": "./source/robust-window-v0.1/UD_UNIFORM_COMPARISON_AND_MATCHING_AUDIT_v0.1.md"
  },
  "sessionFiniteWindow": {
    "title": "Finite-window sign certificate for the controlled comparison",
    "label": "Development \u00b7 2026-09-25",
    "note": "Rigorous residual bounds certify bulk excess and source-store deficit on finite intervals for three fixed diagnostic cases; 56 new grouped checks. Physical time and uncertainty domains remain open.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionFiniteWindow.html",
    "source": "./source/finite-window-v0.1/UD_FINITE_WINDOW_SIGN_CERTIFICATE_v0.1.md"
  },
  "sessionControlledComparison": {
    "title": "Controlled comparison and early energy transfer",
    "label": "Development \u00b7 2026-09-25",
    "note": "Identical initial states and total energy, exact leading bulk/source contrast, source controls and full-vector-field rational Taylor replay; 46 grouped checks.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionControlledComparison.html",
    "source": "./source/controlled-comparison-v0.1/UD_CONTROLLED_COMPARISON_AND_EARLY_TRANSFER_AUDIT_v0.1.md"
  },
  "sessionEnergyAttribution": {
    "title": "Energy attribution and signed readout",
    "label": "Development \u00b7 2026-09-25",
    "note": "Exact six-store ledger, transfer ambiguities, signed-readout requirements, dependent residuals and coupling-switch work; 104 check groups.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionEnergyAttribution.html",
    "source": "./source/energy-attribution-v0.1/UD_ENERGY_ATTRIBUTION_AND_SIGNED_READOUT_AUDIT_v0.1.md"
  },
  "sessionControllerCell": {
    "title": "Controller parity and cell coupling",
    "label": "Development \u00b7 2026-09-25",
    "note": "Minimum-degree controller parity, conditional cell excitation, reciprocal energy, prepared/developed-source powers and exact null controls; 134 check groups.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionControllerCell.html",
    "source": "./source/controller-cell-v0.1/UD_CONTROLLER_PARITY_AND_CELL_COUPLING_AUDIT_v0.1.md"
  },
  "sessionMatchingController": {
    "title": "Matching controller: reciprocal energy and source",
    "label": "Development \u00b7 2026-09-25",
    "note": "Smooth canonical controller, positive total energy, reciprocal exchange, supplied-asymmetry readout and a generic edge-only cell obstruction; 137 exact check groups.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionMatchingController.html",
    "source": "./source/matching-controller-v0.1/UD_MATCHING_CONTROLLER_ENERGY_AND_SOURCE_AUDIT_v0.1.md"
  },
  "sessionMatchingActivation": {
    "title": "Matching activation and chain compatibility",
    "label": "Development \u00b7 2026-09-24",
    "note": "Packet-energy receipts, rank-two chain defect, conditional face response, persistent cell exclusion and a selector symmetry trap; 283 exact check groups.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionMatchingActivation.html",
    "source": "./source/matching-activation-v0.1/UD_MATCHING_ACTIVATION_AND_CHAIN_COMPATIBILITY_AUDIT_v0.1.md"
  },
  "sessionPrediscriminator": {
    "title": "Pre-discriminator states and minimal selector requirements",
    "label": "Development \u00b7 2026-09-24",
    "note": "All 30 S4 subgroups and 15 four-position partitions classify permitted supports. A three-state matching orbit minimally supports C4 selection; joint cycle/parity selection needs six states. Source genesis remains open.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionPrediscriminator.html",
    "source": "./source/prediscriminator-v0.1/UD_PREDISCRIMINATOR_STATE_AND_MINIMAL_SELECTOR_AUDIT_v0.1.md"
  },
  "sessionCovarianceSelector": {
    "title": "Covariance, pair admissibility and orientation selectors",
    "label": "Development \u00b7 2026-09-24",
    "note": "All 64 pair graphs distinguish invariant support from covariant families and symmetric ensembles. Includes deterministic selector limits, a bare-role source candidate and conditional sign retention in the parent.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionCovarianceSelector.html",
    "source": "./source/covariance-selector-v0.1/UD_COVARIANCE_PAIR_ADMISSIBILITY_AND_ORIENTATION_AUDIT_v0.1.md"
  },
  "sessionFiniteStroke": {
    "title": "Finite-stroke mechanism and error-budget audit",
    "label": "Development \u00b7 2026-09-24",
    "note": "Candidate translating-slot geometry, finite stroke and contact-load bounds, absolute model-error budget and 72 exact checks. Signed readouts expose an energy-only sign alias and prevent double-counting dependent residuals.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionFiniteStroke.html",
    "source": "./source/finite-stroke-v0.1/UD_FINITE_STROKE_AND_ERROR_BUDGET_AUDIT_v0.1.md"
  },
  "sessionPassiveStorage": {
    "title": "Passive storage and independent readout audit",
    "label": "Development \u00b7 2026-09-24",
    "note": "An ideal mass and three constrained spring stores reproduce the separate parent energies and signed powers. Includes independent readout rules, preload work, follower inertia and 56 exact checks. Hardware and natural-carrier identification remain open.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionPassiveStorage.html",
    "source": "./source/passive-storage-v0.1/UD_PASSIVE_STORAGE_AND_INDEPENDENT_READOUT_AUDIT_v0.1.md"
  },
  "sessionCanonicalAction": {
    "title": "Canonical action, physical dictionary and conversion readout",
    "label": "Development \u00b7 2026-09-24",
    "note": "Global canonical leaf action; symbolic mechanical dictionary; exact energy-store and parameter-identifiability limits; independent uniform-mode conversion readout required.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionCanonicalAction.html",
    "source": "./source/canonical-action-v0.1/UD_CANONICAL_ACTION_AND_PHYSICAL_CORRESPONDENCE_AUDIT_v0.1.md"
  },
  "sessionParityParent": {
    "title": "Reciprocal parity seed and energy accounting",
    "label": "Development \u00b7 2026-09-24",
    "note": "Candidate parent; exact conditional balances. Seed preparation, coupling sources and physical identification remain open.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionParityParent.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_PARITY_PARENT_v0.1.md"
  },
  "sessionTransportLimit": {
    "title": "Fixed-chain dimensional transport obstruction",
    "label": "Development \u00b7 2026-09-24",
    "note": "Fixed graded skew flow has no propagator blocks spanning two or more degrees. Gluing and compatible fixed metrics retain the obstruction.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionTransportLimit.html",
    "source": "./source/session-2026-09-24/UD_TRANSPORT_AUDIT_REPORT_v0.1.md"
  },
  "sessionInternalEnergy": {
    "title": "Internal energy interpretation and dimensional channels",
    "label": "Development \u00b7 2026-09-24",
    "note": "Explicit adopted energy and time scales give consistent stocks and powers; the physical energy identity and absolute units are unselected.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionInternalEnergy.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_INTERNAL_ENERGY_v0.1.md"
  },
  "sessionHandedness": {
    "title": "Handedness, symmetry and zero-seed limits",
    "label": "Development \u00b7 2026-09-24",
    "note": "A4 symmetry alone does not create a native sequential cascade. A new vertex\u2013face interaction and an odd seed are additional assumptions.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionHandedness.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_HANDEDNESS_v0.1.md"
  },
  "sessionDimensional": {
    "title": "Premeasurement dimensional prediction table",
    "label": "Development \u00b7 2026-09-24",
    "note": "Degree-resolved stocks and currents for vertex, edge, face and cell launches. Internal design freeze; no empirical preregistration or physical data.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionDimensional.html",
    "source": "./source/session-2026-09-24/UD_DIMENSIONAL_PREDICTION_TABLE_v0.1.md"
  },
  "sessionClosedInteraction": {
    "title": "Closed one-incidence interaction audit",
    "label": "Development \u00b7 2026-09-24",
    "note": "A norm-conserving edge\u2013face perturbation permits conditional transfer but breaks the chain identity and full fixed S4 symmetry.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionClosedInteraction.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_CLOSED_INTERACTION_v0.1.md"
  },
  "sessionSourceSelection": {
    "title": "Incidence, metric and source selection",
    "label": "Development \u00b7 2026-09-23",
    "note": "Native source fidelity fixes h=1 in the tested family; a transported coordinate metric changes no dynamics. Weaker source constraints remain nonunique.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionSourceSelection.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_SELECTION_AUDIT_v0.1.md"
  },
  "sessionEndToEnd": {
    "title": "Admission-checked source-to-readout replay",
    "label": "Development \u00b7 2026-09-23",
    "note": "25 declared packets: nine admitted, fifteen rejected and one deferred. Executable integration does not select a source law.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionEndToEnd.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_END_TO_END_v0.1.md"
  },
  "sessionReceiptAcquisition": {
    "title": "Acquiring the local preparation receipt",
    "label": "Development \u00b7 2026-09-23",
    "note": "Address stocks alone are insufficient; an additional mixed or derivative intensity supplies the missing information under stated assumptions.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionReceiptAcquisition.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_RECEIPT_ACQUISITION_v0.1.md"
  },
  "sessionLocalReceipt": {
    "title": "Sufficient local preparation receipt",
    "label": "Development \u00b7 2026-09-23",
    "note": "Eight-coordinate local subsystem; seven stationary source numbers reduce to three with carrier symmetry. Source values are not chosen by the receipt.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionLocalReceipt.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_LOCAL_PREPARATION_RECEIPT_v0.1.md"
  },
  "sessionSpectralReadout": {
    "title": "Spectral stocks and derivative readouts",
    "label": "Development \u00b7 2026-09-23",
    "note": "Identical global spectral stocks can yield different local shapes. The earlier one-ratio description is restricted to M=f(L).",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionSpectralReadout.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_SPECTRAL_STOCKS_AND_READOUT_v0.1.md"
  },
  "sessionPreparation": {
    "title": "Symmetry, stationarity and preparation",
    "label": "Development \u00b7 2026-09-23",
    "note": "Isolated full symmetry forces an isotropic moment; glued topology permits an axis but does not uniquely select its source weights.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionPreparation.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_PREPARATION_SELECTION_v0.1.md"
  },
  "sessionEnsemble": {
    "title": "Ensemble parent reachability and moment closure",
    "label": "Development \u00b7 2026-09-23",
    "note": "Positive ensembles fill a five-dimensional convex region, with finite 21/18/15-coordinate moment realizations for the stated outputs.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionEnsemble.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_ENSEMBLE_PARENT_CLOSURE_v0.1.md"
  },
  "sessionQuadratic": {
    "title": "Quadratic parent observable interface",
    "label": "Development \u00b7 2026-09-23",
    "note": "A declared E plus T2 observable evolves under the existing chain. This is an observable interface, not a separately driven physical parent.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionQuadratic.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_QUADRATIC_PARENT_INTERFACE_v0.1.md"
  },
  "sessionContextDynamics": {
    "title": "Context dynamics and event-selection limits",
    "label": "Development \u00b7 2026-09-23",
    "note": "Exact six-dimensional context restrictions follow from the native chain; type selection, event triggers and independent coupling remain open.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionContextDynamics.html",
    "source": "./source/session-2026-09-24/UD_SOURCE_ADDENDUM_CONTEXT_DYNAMICS_v0.1.md"
  },
  "sessionContextCovariance": {
    "title": "Context covariance and current-source reconciliation",
    "label": "Development \u00b7 2026-09-23",
    "note": "Typed covariance maps reconciled against the retained publication anchor; historical ledger claims retain their source boundaries.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionContextCovariance.html",
    "source": "./source/session-2026-09-24/UD_CURRENT_STATE_AND_CONTEXT_COVARIANCE_v0.1.md"
  },
  "sessionRoleSeparation": {
    "title": "Role separation and Q82 parity corrections",
    "label": "Development \u00b7 2026-09-23",
    "note": "Corrected proxy scope, finite role-placement enumeration and cosine sign-blindness. Read before the initial four-role audit.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionRoleSeparation.html",
    "source": "./source/session-2026-09-24/UD_ROLE_SEPARATION_Q82_PARITY_AUDIT_v0.1.md"
  },
  "sessionColocation": {
    "title": "Co-location and transport-source audit",
    "label": "Development \u00b7 2026-09-23",
    "note": "Without implementation restrictions, logical registers can share sites. Vertex-gradient links alone have trivial loop holonomy.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionColocation.html",
    "source": "./source/session-2026-09-24/UD_COLOCATION_AND_TRANSPORT_SOURCE_AUDIT_v0.1.md"
  },
  "sessionFourRole": {
    "title": "Four-role genesis and A4 discriminator: initial audit",
    "label": "Development \u00b7 2026-09-23",
    "note": "Historical first audit, preserved with later scope corrections. Four functions are not yet four sites; direct pair-addressability gives conditional K4.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionFourRole.html",
    "source": "./source/session-2026-09-24/UD_FOUR_ROLE_K4_AND_A4_DISCRIMINATOR_AUDIT_v0.1.md"
  },
  "sessionFiniteModels": {
    "title": "Finite models and parity-graded operator: earlier audit",
    "label": "Development \u00b7 2026-09-23",
    "note": "Earlier finite verification, to be read with the later role-separation correction: the full 15-space is not scalar-even plus scalar-odd.",
    "kind": "html",
    "file": "./content/session-2026-09-24/sessionFiniteModels.html",
    "source": "./source/session-2026-09-24/UD_FINITE_MODEL_AND_PARITY_GRADED_OPERATOR_RESULTS_v0.1.md"
  },
  "sessionOverview": {
    "title": "September 24\u201325 session: full acceleration-feedback and implementation bounds",
    "label": "Current session update \u00b7 25 September 2026",
    "note": "Full acceleration-feedback sampling and inverse-mass conversion now have a conditional residual contract. Finite-word and controller-model accuracy remain open. Physical promotion 0.",
    "kind": "html",
    "file": "./content/session-2026-09-24/overview.html",
    "source": "./source/session-2026-09-24/UD_SESSION_UPDATE_2026-09-24.md"
  }
};
export const sessionOrder = ["sessionOverview", "sessionFullFeedback", "sessionSampledFeedback", "sessionSharedDamping", "sessionPairedDisturbance", "sessionComponentAdmissibility", "sessionImplementationDefect", "sessionUnitsCalibration", "sessionMismatchTiming", "sessionAccountingWindow", "sessionProjectedWindow", "sessionPairedWindow", "sessionRobustWindow", "sessionFiniteWindow", "sessionControlledComparison", "sessionEnergyAttribution", "sessionControllerCell", "sessionMatchingController", "sessionMatchingActivation", "sessionPrediscriminator", "sessionCovarianceSelector", "sessionFiniteStroke", "sessionPassiveStorage", "sessionCanonicalAction", "sessionParityParent", "sessionTransportLimit", "sessionInternalEnergy", "sessionHandedness", "sessionDimensional", "sessionClosedInteraction", "sessionSourceSelection", "sessionEndToEnd", "sessionReceiptAcquisition", "sessionLocalReceipt", "sessionSpectralReadout", "sessionPreparation", "sessionEnsemble", "sessionQuadratic", "sessionContextDynamics", "sessionContextCovariance", "sessionRoleSeparation", "sessionColocation", "sessionFourRole", "sessionFiniteModels"];

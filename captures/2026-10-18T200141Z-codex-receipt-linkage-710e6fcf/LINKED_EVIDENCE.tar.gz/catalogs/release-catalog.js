export const releaseDocs = {
  "signedSupport": {
    "title": "Signed-Support Burden and Mixed Winding",
    "label": "EXACT LAW + CONDITIONAL CLOSURE · 17 files",
    "note": "Exact conservative gate-switch redistribution; nonconservative burden sourcing remains blocked and mixed-history winding is receipt-conditional.",
    "kind": "html",
    "file": "./content/releases/signedSupport.html",
    "source": "./releases/UD_SIGNED_SUPPORT_BURDEN_AND_MIXED_WINDING_v0.1_RELEASE.zip"
  },
  "edgeSource": {
    "title": "Edge Source and Lineage-Prime Gate",
    "label": "PARTIAL PASS + EXACT THEOREM · 20 files",
    "note": "Six-edge source-to-vertex contrast structure and lineage-prime admission, with pair aggregation and net-primitive no-go boundaries.",
    "kind": "html",
    "file": "./content/releases/edgeSource.html",
    "source": "./releases/UD_EDGE_SOURCE_AND_LINEAGE_PRIME_GATE_v0.1_RELEASE.zip"
  },
  "edgeAmplitude": {
    "title": "Edge Amplitude and Lineage-Prime Stability",
    "label": "PARTIAL PASS · 19 files",
    "note": "Telemetry identifiability and full-stability competitor controls; pre-act amplitude and uniqueness remain source-gated.",
    "kind": "html",
    "file": "./content/releases/edgeAmplitude.html",
    "source": "./releases/UD_EDGE_AMPLITUDE_AND_LINEAGE_PRIME_STABILITY_v0.1_RELEASE.zip"
  },
  "kappaBoundary": {
    "title": "Kappa Calibration and Boundary/Scale Fixtures",
    "label": "SCOPED FIXTURE RESULTS · 25 files",
    "note": "Frozen held-out calibration and finite boundary-scale fixtures, explicitly separated from real burden telemetry or empirical bridge validation.",
    "kind": "html",
    "file": "./content/releases/kappaBoundary.html",
    "source": "./releases/UD_KAPPA_CALIBRATION_AND_BOUNDARY_SCALE_FIXTURES_v0.1_RELEASE.zip"
  },
  "burdenTelemetry": {
    "title": "Burden Telemetry and Multiscale Stability",
    "label": "SCOPED CONTROL PASS · 46 files",
    "note": "Null and unit-gain controls plus lineage-prime multiscale provenance; the null corpus is a control rather than a nonzero empirical bridge.",
    "kind": "html",
    "file": "./content/releases/burdenTelemetry.html",
    "source": "./releases/UD_BURDEN_TELEMETRY_AND_MULTISCALE_STABILITY_v0.1_RELEASE.zip"
  },
  "independentBurden": {
    "title": "Independent Burden and Dynamic Multiscale",
    "label": "HELD-OUT FAIL + SCOPED PASS · 42 files",
    "note": "Independent burden held-out failure retained alongside a scoped pass for dynamic source-renewal boundary-scale provenance.",
    "kind": "html",
    "file": "./content/releases/independentBurden.html",
    "source": "./releases/UD_INDEPENDENT_BURDEN_AND_DYNAMIC_MULTISCALE_v0.1_RELEASE.zip"
  },
  "intasetAdapter": {
    "title": "InTaSet Adapter and Mixed-Scale Merger",
    "label": "SCOPED PASS · 39 files",
    "note": "Typed four-state adapter work and mixed Hamming merger transport, with external four-state-to-edge-source identification kept open.",
    "kind": "html",
    "file": "./content/releases/intasetAdapter.html",
    "source": "./releases/UD_INTASET_ADAPTER_AND_MIXED_SCALE_MERGER_v0.1_RELEASE.zip"
  },
  "intasetSourceLift": {
    "title": "InTaSet Source Lift and Burden Correspondence",
    "label": "SOURCE MAP CLOSED / BURDEN NO-GO · 12 files",
    "note": "Target-blind actuator-contrast lift closes conditionally; conservation does not select a unique external-stock-to-burden map.",
    "kind": "html",
    "file": "./content/releases/intasetSourceLift.html",
    "source": "./releases/UD_INTASET_SOURCE_LIFT_AND_BURDEN_CORRESPONDENCE_v0.1_RELEASE.zip"
  },
  "intasetM1M2": {
    "title": "InTaSet M1/M2 and Pump-Calibration Source Audit",
    "label": "SOURCE-SIDE AUDIT COMPLETE · 14 files",
    "note": "No public source binds M1/M2 to explicit routing values or command speed to delivered flow; both numerical interfaces remain source-blocked.",
    "kind": "html",
    "file": "./content/releases/intasetM1M2.html",
    "source": "./releases/UD_INTASET_M1M2_AND_PUMP_CALIBRATION_SOURCE_AUDIT_v0.1_RELEASE.zip"
  },
  "intasetAcquisition": {
    "title": "InTaSet Acquisition and External-Burden No-Go",
    "label": "PARTIAL PASS / SOURCE BLOCKED · 11 files",
    "note": "The public archive is identified, but runtime binary retrieval and configuration-specific routing remain blocked; no routing matrix is fabricated.",
    "kind": "html",
    "file": "./content/releases/intasetAcquisition.html",
    "source": "./releases/UD_INTASET_ACQUISITION_AND_EXTERNAL_BURDEN_NO_GO_v0.1_RELEASE.zip"
  },
  "intasetGenerator": {
    "title": "InTaSet Upload Binding and Generator Audit",
    "label": "SOURCE AUTHENTICATED / DIAGNOSTIC · 15 files",
    "note": "Source authentication and generator diagnostics are retained while pre-outcome routing binding and exact identified-model K4 similarity remain blocked.",
    "kind": "html",
    "file": "./content/releases/intasetGenerator.html",
    "source": "./releases/UD_INTASET_UPLOAD_BINDING_AND_GENERATOR_AUDIT_v0.1_RELEASE.zip"
  },
  "intasetRouting": {
    "title": "InTaSet Source-Authored Routing Recovery",
    "label": "PARTIAL PASS · 9 files",
    "note": "A source-authored symbolic routing family is recovered; weighted-family results are conditional and numeric M1/M2 bindings remain unavailable.",
    "kind": "html",
    "file": "./content/releases/intasetRouting.html",
    "source": "./releases/UD_INTASET_SOURCE_AUTHORED_ROUTING_RECOVERY_v0.1_RELEASE.zip"
  },
  "windingLift": {
    "title": "Winding Lift and Holonomy Burden",
    "label": "PARTIAL PASS + LOCKED NO-GOS · 20 files",
    "note": "Path-resolved seam winding and normalized holonomy diagnostics close in scope; generic residual-to-integer winding and numerical burden closure do not.",
    "kind": "html",
    "file": "./content/releases/windingLift.html",
    "source": "./releases/UD_WINDING_LIFT_AND_HOLONOMY_BURDEN_v0.1_RELEASE.zip"
  },
  "packetExchange": {
    "title": "Packet-Exchange Winding and H12 Burden",
    "label": "PARTIAL PASS PLUS · 19 files",
    "note": "Fixed-Hamming exchange winding and H12 redistribution shape close exactly, while endpoint-only winding and scalar total-burden correction remain no-go.",
    "kind": "html",
    "file": "./content/releases/packetExchange.html",
    "source": "./releases/UD_PACKET_EXCHANGE_WINDING_AND_H12_BURDEN_v0.1_RELEASE.zip"
  },
  "c37Winding": {
    "title": "C3_7 Winding Automaton and Holonomy Lineage",
    "label": "EXACT RESULTS + LOCKED NO-GO · 19 files",
    "note": "First-return primitive winding and lineage-count structure are retained; categorical lineage receipts alone cannot determine scalar holonomy burden.",
    "kind": "html",
    "file": "./content/releases/c37Winding.html",
    "source": "./releases/UD_C3_7_WINDING_AUTOMATON_AND_HOLONOMY_LINEAGE_v0.1_RELEASE.zip"
  },
  "breathingBurden": {
    "title": "Breathing Burden and Relative Winding",
    "label": "PARTIAL PASS · 16 files",
    "note": "Innovation-lineage burden and relative open-system winding close only within declared source and measurement conditions.",
    "kind": "html",
    "file": "./content/releases/breathingBurden.html",
    "source": "./releases/UD_BREATHING_BURDEN_AND_RELATIVE_WINDING_v0.1_RELEASE.zip"
  },
  "externalMassAudit": {
    "title": "External Lattice-Constant/Mass Chain Audit",
    "label": "COMPLETE / SCOPED NO-GOS · 9 files",
    "note": "Historical arithmetic is preserved while multiple external lattice-to-mass inference routes are classified as scoped no-go results.",
    "kind": "html",
    "file": "./content/releases/externalMassAudit.html",
    "source": "./releases/UD_EXTERNAL_LATTICE_CONSTANT_MASS_CHAIN_AUDIT_v0.1_RELEASE.zip"
  },
  "xiHbar": {
    "title": "Xi-Hbar and Hodge–Dirac Action Recovery",
    "label": "PARTIAL PASS + EXACT INTERNAL · 12 files",
    "note": "Derives the internal Hodge–Dirac action geometry and exact 2π ratio; physical normalization and a numerical xi-hbar value remain open.",
    "kind": "html",
    "file": "./content/releases/xiHbar.html",
    "source": "./releases/UD_XI_HBAR_HD_ACTION_RECOVERY_v0.1_RELEASE.zip"
  },
  "nativeAction": {
    "title": "Native Action-Scale Tuple",
    "label": "PARTIAL PASS · 13 files",
    "note": "Closes native adjacency and recurrence coordinates while leaving the matter-burden coordinate open: (B_e, 1_edge, π_s).",
    "kind": "html",
    "file": "./content/releases/nativeAction.html",
    "source": "./releases/UD_NATIVE_ACTION_SCALE_TUPLE_v0.1_RELEASE.zip"
  },
  "beIntertwiner": {
    "title": "B_e Correction and Support Intertwiner",
    "label": "PARTIAL PASS + EXACT THEOREM + NO-GO · 22 files",
    "note": "Derives a two-dimensional S4-equivariant contrast-map space; symmetry cannot supply nonzero total burden or fix the open coefficients.",
    "kind": "html",
    "file": "./content/releases/beIntertwiner.html",
    "source": "./releases/UD_BE_CORRECTION_AND_SUPPORT_INTERTWINER_v0.1_RELEASE.zip"
  },
  "c37Nine": {
    "title": "C3_7 Source Addendum and Nine Invariants",
    "label": "PARTIAL PASS + EXACT THEOREM + NO-GO · 22 files",
    "note": "Constructs nine quadratic invariants and reduces Hodge-flow conservation to three sector totals; source-only QISO-1 selection remains nonunique.",
    "kind": "html",
    "file": "./content/releases/c37Nine.html",
    "source": "./releases/UD_C3_7_SOURCE_ADDENDUM_AND_NINE_INVARIANTS_v0.1_RELEASE.zip"
  },
  "boundarySelector": {
    "title": "Boundary Receipt and Hodge Selector",
    "label": "PRETARGET FROZEN / PARTIAL · 22 files",
    "note": "Conditionally closes frame parity and closure receipts, localizes the holonomy-sensitive lane to H12, and keeps endpoint winding and total B_e blocked.",
    "kind": "html",
    "file": "./content/releases/boundarySelector.html",
    "source": "./releases/UD_BOUNDARY_RECEIPT_AND_HODGE_SELECTOR_v0.1_RELEASE.zip"
  },
  "c37Evolution": {
    "title": "C3_7 Evolution and Quadratic Burden",
    "label": "EXACT CLASSIFICATION + SOURCE GATE · 15 files",
    "note": "Classifies all 23 quadratic S4-equivariant Hodge-to-burden channels—nine uniform and fourteen contrast—while fixing the precise source requirements for full defect evolution and preserving QISO-1 as a zero-parameter candidate.",
    "kind": "html",
    "file": "./content/releases/c37Evolution.html",
    "source": "./releases/UD_C3_7_EVOLUTION_AND_QUADRATIC_BURDEN_v0.1_RELEASE.zip"
  },
  "lehighSourceScorer": {
    "title": "Lehigh Zero-Touch G14/G23 Source Scorer",
    "label": "SCORER FROZEN / SOURCE RECEIPT OPEN · 20 files",
    "note": "Fail-closed, outcome-blind source-stream generation for the exact G14/G23 branch contrast; execution remains blocked until authenticated delivered-flow calibration is supplied.",
    "kind": "html",
    "file": "./content/releases/lehighSourceScorer.html",
    "source": "./releases/UD_LEHIGH_ZERO_TOUCH_G14_G23_SOURCE_SCORER_v0.1A_RELEASE.zip"
  },
  "cordobaFreshScorer": {
    "title": "Córdoba Zero-Touch Fresh Comparator Scorer",
    "label": "SCORER FROZEN / ACQUISITION OPEN · 16 files",
    "note": "Dual-implementation package for a fresh flowmeter-versus-level comparator with frozen windows, uncertainty law, and refusal rules; no real outcome is bundled.",
    "kind": "html",
    "file": "./content/releases/cordobaFreshScorer.html",
    "source": "./releases/UD_CORDOBA_ZERO_TOUCH_FRESH_SCORER_v0.1_RELEASE.zip"
  },
  "lehighTankComparator": {
    "title": "Lehigh Independent Tank-Side Comparator",
    "label": "PRETARGET FROZEN / SOURCE RECEIPTS OPEN · 10 files",
    "note": "Prospective fill-isolation comparator with a geometry-neutral storage law and source-authored receipt templates; tank geometry, isolation configuration, sensor metrology, and delivered-flow provenance remain pending.",
    "kind": "html",
    "file": "./content/releases/lehighTankComparator.html",
    "source": "./releases/UD_LEHIGH_INDEPENDENT_TANK_SIDE_COMPARATOR_PREREG_v0.1_RELEASE.zip"
  },
  "lehighLeakGate": {
    "title": "Lehigh Isolation and Leak Qualification",
    "label": "PRETARGET FROZEN / SOURCE RECEIPTS OPEN · 10 files",
    "note": "Freezes matched-level no-pump hold tests and conservatively propagates undetected leakage before the tank-side comparator may score; no generic leak tolerance is inserted.",
    "kind": "html",
    "file": "./content/releases/lehighLeakGate.html",
    "source": "./releases/UD_LEHIGH_ISOLATION_LEAK_QUALIFICATION_PREREG_v0.1_RELEASE.zip"
  },
  "lehighExecutionHarness": {
    "title": "Lehigh End-to-End Zero-Touch Harness",
    "label": "EXECUTION HARNESS FROZEN / SOURCE RECEIPTS OPEN · 30 files",
    "note": "Joins pump-flow provenance, source generation, leak qualification, tank comparison, independent replay, and cross-platform reporting under one fail-closed pre-score freeze.",
    "kind": "html",
    "file": "./content/releases/lehighExecutionHarness.html",
    "source": "./releases/UD_LEHIGH_END_TO_END_ZERO_TOUCH_EXECUTION_HARNESS_v0.1_RELEASE.zip"
  },
  "googleQecReplication": {
    "title": "Google QEC3v5 C1 and FIFT Replication",
    "label": "EMPIRICAL PASS / DUAL-SCORER VERIFIED · 16 files",
    "note": "A preregistered fresh-corpus test on 12,000,000 released syndrome-coordinate observations passes the C1 portability and FIFT enrichment gates with exact dual-scorer agreement; no QEC-to-K4 identity is inferred.",
    "kind": "html",
    "file": "./content/releases/googleQecReplication.html",
    "source": "./releases/UD_QEC_GOOGLE_QEC3V5_C1_FIFT_REPLICATION_v0.1A_RELEASE.zip"
  },
  "cmuHouseReplay": {
    "title": "CMU House Relative-Frame Replay",
    "label": "EMPIRICAL BOUNDARY RESULT / NEXT LAYER NAMED · 12 files",
    "note": "A preregistered replay shows that naive single-edge tree realization is inexact on noisy pairwise transports, preserves the noiseless theorem, and identifies source-only robust synchronization as the next admissible layer.",
    "kind": "html",
    "file": "./content/releases/cmuHouseReplay.html",
    "source": "./releases/UD_CMU_HOUSE_RELATIVE_FRAME_REPLAY_RESULT_v0.1_RELEASE.zip"
  },
  "releaseAuthority": {
    "title": "Release Authority Manifest",
    "label": "AUTHORITY SNAPSHOT PASS / LINEAGE EXCEPTIONS · 4 files",
    "note": "Hash-locks the 30-package antecedent release inventory, verifies all listed package files, records four ancillary-coverage exceptions, and preserves the unresolved manuscript-version lineage conflict without guessing.",
    "kind": "html",
    "file": "./content/releases/releaseAuthority.html",
    "source": "./releases/UD_RELEASE_AUTHORITY_MANIFEST_v0.1_RELEASE.zip"
  },
  "idleResponseLineage": {
    "title": "Idle-Response Lineage and Gate-History Boundary",
    "label": "EXACT LOCALIZATION / SOURCE CONTRACT OPEN · 17 files",
    "note": "Localizes the six primitive response classes and proves that lineage provenance or gate history alone cannot select close versus hold; the remaining idle-response source is named and preregistered.",
    "kind": "html",
    "file": "./content/releases/idleResponseLineage.html",
    "source": "./releases/UD_IDLE_RESPONSE_LINEAGE_GATE_HISTORY_NOGO_v0.1_RELEASE.zip"
  },
  "tdglEngineeredC4": {
    "title": "TDGL Kernel and Engineered Four-Junction Carrier",
    "label": "MODEL-EXACT / HARDWARE OPEN · 8 files",
    "note": "The generic TDGL kernel obstruction is isolated; an overdamped four-junction ring supplies exact projectability within the declared model. Hardware realization remains open.",
    "kind": "html",
    "file": "./content/releases/tdglEngineeredC4.html",
    "source": "./releases/UD_TDGL_ACTION_AND_FOUR_JUNCTION_C4_v0.1.zip"
  },
  "fourJunctionAction": {
    "title": "Four-Junction Action Normalization",
    "label": "MODEL-EXACT / PHYSICAL IDENTITY OPEN · 7 files",
    "note": "Derives active amplitude and modal action normalization within the model. The overdamped flow and oscillatory action mode retain distinct dynamical types.",
    "kind": "html",
    "file": "./content/releases/fourJunctionAction.html",
    "source": "./releases/UD_FOUR_JUNCTION_ACTION_NORMALIZATION_v0.1.zip"
  },
  "qpb1BlindHardware": {
    "title": "QPB1 Blind Hardware Scoring",
    "label": "SCORING PREPARED / NOT EXECUTED · 13 files",
    "note": "A frozen analysis packet and synthetic controls prepare a quantitative correspondence test. Hardware scoring has not run; impedance selection cannot serve as independent confirmation.",
    "kind": "html",
    "file": "./content/releases/qpb1BlindHardware.html",
    "source": "./releases/UD_FOUR_JUNCTION_QPB1_BLIND_HARDWARE_SCORING_v0.1.zip"
  },
  "qpb1ClassASource": {
    "title": "QPB1 Independent Source Selection",
    "label": "SOURCE AUDIT / RECONSTRUCTION PROTOCOL · 5 files",
    "note": "Documents predating source candidates and the reconstruction preregistration, separating independent source selection from the engineered correspondence lane.",
    "kind": "html",
    "file": "./content/releases/qpb1ClassASource.html",
    "source": "./releases/UD_QPB1_CLASS_A_SOURCE_PACKAGE_v0.1.zip"
  },
  "classAModal": {
    "title": "Class A Modal Reconstruction",
    "label": "PARTIAL MODEL RECONSTRUCTION · 8 files",
    "note": "Published-model ratios and generalized modal maps are reconstructed. Absolute action normalization and bias-specific scoring retain explicit source dependencies.",
    "kind": "html",
    "file": "./content/releases/classAModal.html",
    "source": "./releases/UD_CLASS_A_MODAL_RECONSTRUCTION_v0.2.zip"
  },
  "symplecticNormalization": {
    "title": "Symplectic Normalization and Action-Scale Freedom",
    "label": "EXACT SHAPE / COMMON SCALE OPEN · 7 files",
    "note": "Canonical compatibility fixes relative metric shape while leaving a common action scale. An independent normalization receipt is still needed.",
    "kind": "html",
    "file": "./content/releases/symplecticNormalization.html",
    "source": "./releases/UD_SYMPLECTIC_NORMALIZATION_ACTION_SCALE_GAUGE_v0.1.zip"
  },
  "dynamicalIntertwiner": {
    "title": "Physical-to-Hodge Dynamical Intertwiner",
    "label": "EXACT SPECTRAL CONDITION · 6 files",
    "note": "Derives the frequency-matching condition for a single mode and identifies the obstruction to mapping unequal-frequency modes into one native clock.",
    "kind": "html",
    "file": "./content/releases/dynamicalIntertwiner.html",
    "source": "./releases/UD_PHYSICAL_TO_HODGE_DYNAMICAL_INTERTWINER_v0.1.zip"
  },
  "amplitudeMetric": {
    "title": "Physical Amplitude Metric Selection",
    "label": "METRIC DEPENDENCY LOCALIZED · 6 files",
    "note": "Separates the native Euclidean metric from an external metric, which depends on a source-complete intertwiner; earlier isometric results retain their stated scope.",
    "kind": "html",
    "file": "./content/releases/amplitudeMetric.html",
    "source": "./releases/UD_PHYSICAL_AMPLITUDE_METRIC_SELECTION_v0.1.zip"
  },
  "actionLineage": {
    "title": "Action-Scale Historical Lineage Audit",
    "label": "SOURCE AUDIT / ACTION RECEIPT OPEN · 7 files",
    "note": "Audits historical energy, clock, residue, and action candidates and identifies the missing independent action-dimensional receipt.",
    "kind": "html",
    "file": "./content/releases/actionLineage.html",
    "source": "./releases/UD_ACTION_SCALE_HISTORICAL_LINEAGE_AUDIT_v0.1.zip"
  },
  "asar1Source": {
    "title": "ASAR-1 Minimal Action Receipt",
    "label": "SOURCE LAW / EXTERNAL EXECUTION OPEN · 9 files",
    "note": "Derives a specific canonical-action observable and freezes its acquisition contract. The carrier and amplitude map must be independently fixed before normalization.",
    "kind": "html",
    "file": "./content/releases/asar1Source.html",
    "source": "./releases/UD_ACTION_SCALE_SOURCE_ADDENDUM_ASAR1_v0.1.zip"
  },
  "asar1RawZenodo": {
    "title": "ASAR-1 Raw Data and Historical Action Lineage",
    "label": "SOURCE RECOVERY / CONDITIONAL BRIDGE · 8 files",
    "note": "Identifies a classical raw-data route and recovers the historical action-per-distinction postulate. Numerical raw-data execution and native amplitude calibration remain open.",
    "kind": "html",
    "file": "./content/releases/asar1RawZenodo.html",
    "source": "./releases/UD_ASAR1_RAW_AND_HISTORICAL_ZENODO_v0.2.zip"
  },
  "asar1ClassicalResidue": {
    "title": "Classical ASAR-1 Control and Historical Residue",
    "label": "CLASSICAL MODEL CONTROL · 8 files",
    "note": "Reconstructs a predating four-disc model as a classical action control. Empirical phase-space integration has not run, and the historical residue measure remains unrecovered.",
    "kind": "html",
    "file": "./content/releases/asar1ClassicalResidue.html",
    "source": "./releases/UD_ASAR1_CLASSICAL_AND_HISTORICAL_RESIDUE_v0.1.zip"
  },
  "genesisEventCount": {
    "title": "Genesis–Hodge Event-Count Bridge",
    "label": "CONDITIONAL FORMULA / COUNT GATES · 7 files",
    "note": "Derives conditional variation formulas and separates event coordinates, primitive increment, and integer-count requirements into named gates.",
    "kind": "html",
    "file": "./content/releases/genesisEventCount.html",
    "source": "./releases/UD_GENESIS_HODGE_EVENT_COUNT_BRIDGE_v0.1.zip"
  },
  "gh1Poisson": {
    "title": "GH1 Vertex Map and Poisson Count Repair",
    "label": "EXACT MAP / COUNT TYPING REPAIRED · 8 files",
    "note": "Constructs the source-typed vertex/gradient map and separates an expected count from an integer realized count. The pathwise lift and amplitude scale remain open.",
    "kind": "html",
    "file": "./content/releases/gh1Poisson.html",
    "source": "./releases/UD_GH1_POISSON_REPAIR_v0.1.zip"
  },
  "gh2Local": {
    "title": "GH2 Primitive Increment and Local Dynamics",
    "label": "LOCAL STRUCTURE / NORMALIZATION OPEN · 8 files",
    "note": "Closes projected event shape and linear operator structure, while identifying amplitude, time, and finite-amplitude nonlinear dependencies.",
    "kind": "html",
    "file": "./content/releases/gh2Local.html",
    "source": "./releases/UD_GH2_AND_LOCAL_DYNAMICS_v0.1.zip"
  },
  "boundaryManifold": {
    "title": "Boundary Quantization and Nonlinear Reduction",
    "label": "CONDITIONAL REDUCTION / SPECIAL RAYS · 8 files",
    "note": "Derives a conditional cubic-order reduction and exact special rays. Historical boundary data and a global all-orders reduction remain open.",
    "kind": "html",
    "file": "./content/releases/boundaryManifold.html",
    "source": "./releases/UD_BOUNDARY_QUANT_AND_INVARIANT_MANIFOLD_v0.1.zip"
  },
  "boundaryReconstruction": {
    "title": "Boundary Quantization Reconstruction",
    "label": "CANDIDATE RECONSTRUCTION / SOURCE GATE · 8 files",
    "note": "Recovers a quartic-cycle coefficient as an algebraic candidate and records the spectral and provenance conditions needed for further admission.",
    "kind": "html",
    "file": "./content/releases/boundaryReconstruction.html",
    "source": "./releases/UD_BOUNDARY_QUANTIZATION_RECONSTRUCTION_v0.2.zip"
  },
  "a10Spectral": {
    "title": "A.10 Semantics and Spectral Tests",
    "label": "SEMANTICS REPAIRED / SPECTRAL BOUNDARY · 8 files",
    "note": "Separates historical rank and amplitude meanings from a new boundary-ledger candidate. The scoped spectral test excludes exact affine spacing for the source-compatible quartic models.",
    "kind": "html",
    "file": "./content/releases/a10Spectral.html",
    "source": "./releases/UD_A10_SEMANTICS_SPECTRAL_FALSIFIER_v0.3.zip"
  },
  "v03Distribution": {
    "title": "Historical Source Recovery and Peak Distribution",
    "label": "CONDITIONAL DISTRIBUTION / CANDIDATE REPLAY · 12 files",
    "note": "Derives conditional peak-distribution laws and preserves a candidate replay separately from the unrecovered v0.3 source and raw data.",
    "kind": "html",
    "file": "./content/releases/v03Distribution.html",
    "source": "./releases/UD_V03_SOURCE_RECOVERY_AND_DISTRIBUTION_v0.1.zip"
  },
  "gap5OrderStat": {
    "title": "Gap5 Order Statistics and Boundary-Cycle Test",
    "label": "EXACT ORDER STATISTICS / SCOPED TEST · 14 files",
    "note": "Derives the parent-distribution requirements for affine expected rank and records the failed untuned strict-peak realization without claiming global candidate falsification.",
    "kind": "html",
    "file": "./content/releases/gap5OrderStat.html",
    "source": "./releases/UD_GAP5_ORDERSTAT_BQR1_v0.1.zip"
  },
  "nonautonomousCovariance": {
    "title": "Source-History Covariance and Segmentation",
    "label": "CONDITIONAL COVARIANCE / SIMULATION CONTROLS · 12 files",
    "note": "A conditional source-history propagator improves retrospective covariance agreement. Held-out segmentation controls do not reconstruct a universal historical cluster count.",
    "kind": "html",
    "file": "./content/releases/nonautonomousCovariance.html",
    "source": "./releases/UD_NONAUTONOMOUS_SIGMA7_COVSEG_v0.1.zip"
  },
  "sigma7Segmentation": {
    "title": "Finite-Torus Covariance and Watershed Segmentation",
    "label": "EXACT FORMULA / SEGMENTATION DEPENDENCY · 11 files",
    "note": "Derives a finite-torus covariance formula and canonical watershed construction. The historical count still requires a missing coarsening law.",
    "kind": "html",
    "file": "./content/releases/sigma7Segmentation.html",
    "source": "./releases/UD_SIGMA7_SEGMENTATION_v0.1.zip"
  },
  "phiTemporal": {
    "title": "Triadic Coherence and Temporal Admission",
    "label": "FUNCTIONAL DERIVED / LATER SCHEDULE REPAIR · 14 files",
    "note": "Derives a Gaussian coherence functional and temporal admission scale. The reported late autonomous drift is superseded by the later source-schedule repair.",
    "kind": "html",
    "file": "./content/releases/phiTemporal.html",
    "source": "./releases/UD_PHI_TEMPORAL_v0.1.zip"
  },
  "kappa4Joint": {
    "title": "Source-Schedule Repair and Joint Cluster Admission",
    "label": "SCHEDULE REPAIRED / SCOPED SIMULATION · 14 files",
    "note": "Corrects the source schedule, superseding the earlier late-drift conclusion. Joint cluster admission remains a source-regime candidate, with the historical count already known before testing.",
    "kind": "html",
    "file": "./content/releases/kappa4Joint.html",
    "source": "./releases/UD_KAPPA4_JOINT_CLUSTER_v0.1.zip"
  },
  "nonlocalKappa4": {
    "title": "Nonlocal Fourth Cumulant and Cross-Regime Tests",
    "label": "EXACT MODE COUPLING / REGIME BOUNDARY · 12 files",
    "note": "Derives nonlocal mode coupling and tests the J2 admission rule across changed coupling regimes. Results localize J2 to its source regime rather than a universal cluster count.",
    "kind": "html",
    "file": "./content/releases/nonlocalKappa4.html",
    "source": "./releases/UD_NONLOCAL_KAPPA4_J2_REGIME_v0.1.zip"
  },
  "genesisActionClock": {
    "title": "Genesis–Hodge Action and Clock Intertwiner",
    "label": "LOCAL CANONICAL RESULT / GLOBAL CLOCK OPEN · 7 files",
    "note": "Derives a local canonical reduction and conditional same-history action/clock relations. A global constant clock ratio requires a stationary or effective-frequency theorem; independent physical calibration remains open.",
    "kind": "html",
    "file": "./content/releases/genesisActionClock.html",
    "source": "./releases/UD_GENESIS_HODGE_ACTION_CLOCK_INTERTWINER_v0.1.zip"
  },
  "pairingAlignment": {
    "title": "Pairing Selection and Rank-Flow Alignment",
    "label": "SOURCE BRANCH / ALIGNMENT OPEN · 7 files",
    "note": "A burden-gradient source branch is distinguished from generic uniqueness; event-rank alignment still requires a source relation.",
    "kind": "html",
    "file": "./content/releases/pairingAlignment.html",
    "source": "./releases/UD_PAIRING_SELECTION_ALIGNMENT_PACKAGE_v0.1.zip"
  },
  "latentCrossing": {
    "title": "Latent Crossing and O09 Selection",
    "label": "EXACT CONDITIONAL / SOURCE GATE · 7 files",
    "note": "Fixed-integrity crossing determines a rank sign. O09 action ordering requires canonical pre-event maps and normalization.",
    "kind": "html",
    "file": "./content/releases/latentCrossing.html",
    "source": "./releases/UD_LATENT_CROSSING_O09_SELECTOR_PACKAGE_v0.1.zip"
  },
  "bgFiniteHistory": {
    "title": "Pairing Representation and Finite-History Receipts",
    "label": "REPRESENTATION BOUNDARY / EXACT RECEIPTS · 7 files",
    "note": "The absent pairing irrep identifies the required bridge; net lane change and gross turnover remain distinct receipts.",
    "kind": "html",
    "file": "./content/releases/bgFiniteHistory.html",
    "source": "./releases/UD_BG_O09_FINITE_HISTORY_OP03_PACKAGE_v0.1.zip"
  },
  "bilinearBg": {
    "title": "Bilinear Burden-to-Hodge Shape Bridge",
    "label": "EXACT SHAPE / CALIBRATION OPEN · 9 files",
    "note": "A bilinear construction supplies the missing shape channel. Amplitude calibration and independent held-out replay remain open.",
    "kind": "html",
    "file": "./content/releases/bilinearBg.html",
    "source": "./releases/UD_BILINEAR_BG_GSIGMA_XIFH_PACKAGE_v0.1.zip"
  },
  "binaryTriadic": {
    "title": "Binary–Triadic Split and Retract",
    "label": "EXACT FINITE ALGEBRA · 5 files",
    "note": "An exact parity retract splits the eight-state binary carrier into a two-dimensional kernel and one-dimensional image.",
    "kind": "html",
    "file": "./content/releases/binaryTriadic.html",
    "source": "./releases/UD_K4_BINARY_TRIADIC_SPLIT_PACKAGE_v0.1.zip"
  },
  "binaryDynamic": {
    "title": "Binary–Triadic Dynamics and Typed Intertwiner",
    "label": "EXACT TYPED RELATION · 7 files",
    "note": "Parity is an exact factor of the declared event dynamics; the real pairing plane and binary kernel share an A2 lattice parent.",
    "kind": "html",
    "file": "./content/releases/binaryDynamic.html",
    "source": "./releases/UD_BINARY_TRIADIC_DYNAMIC_INTERTWINER_PACKAGE_v0.1.zip"
  },
  "a2Replay": {
    "title": "A2 Source Lift and Parity Replay",
    "label": "SOURCE LIFT / SYNTHETIC CONTROLS · 7 files",
    "note": "Source weights lift to the pairing functional; synthetic replay distinguishes parity-visible and parity-invisible errors.",
    "kind": "html",
    "file": "./content/releases/a2Replay.html",
    "source": "./releases/UD_A2_SOURCE_PARITY_REPLAY_PACKAGE_v0.1.zip"
  },
  "pairingBgGate": {
    "title": "Burden-Gradient Source and OP03 Replay Gate",
    "label": "SOURCE BRANCH / VERIFICATION REPAIR · 7 files",
    "note": "The v0.2 harness repairs verification while retaining a covariant source branch. Independent authenticated OP03 events remain unavailable.",
    "kind": "html",
    "file": "./content/releases/pairingBgGate.html",
    "source": "./releases/UD_PAIRING_BG_SOURCE_OP03_GATE_PACKAGE_v0.2.zip"
  },
  "c3Custody": {
    "title": "C3 Exclusive Facet Receipt and E2 Custody",
    "label": "EXACT DISCRIMINATOR / LAB PROTOCOL · 21 files",
    "note": "C3 and MRR agree only in specified sectors. Acquisition schedules and independent provider custody are frozen; no real data are supplied.",
    "kind": "html",
    "file": "./content/releases/c3Custody.html",
    "source": "./releases/UD_C3_SELECTOR_AND_E2_REAL_LAB_CUSTODY_v0.1.zip"
  },
  "c2Contrast": {
    "title": "C2-to-C3 Facet Contrast and E2 Collaboration Plan",
    "label": "EXACT CONTRAST / COLLABORATION PROPOSED · 14 files",
    "note": "Native transport spans the four-dimensional facet-contrast sector. Proposed laboratory roles remain an internal execution plan.",
    "kind": "html",
    "file": "./content/releases/c2Contrast.html",
    "source": "./releases/UD_C2_FACET_CONTRAST_AND_E2_COALITION_v0.1.zip"
  },
  "primitiveC2": {
    "title": "Primitive C2 Projection and E2 First Contact",
    "label": "EXACT PROJECTION / CONTACT MATERIALS · 12 files",
    "note": "The contrast-visible projection and oscillator close exactly. Raw source origin remains open; first-contact materials are prepared.",
    "kind": "html",
    "file": "./content/releases/primitiveC2.html",
    "source": "./releases/UD_PRIMITIVE_C2_AND_E2_FIRST_CONTACT_v0.1.zip"
  },
  "openC2": {
    "title": "Open C2 Source Extraction and Apparatus Binding",
    "label": "EXACT EXTRACTION / SOURCE LAW OPEN · 13 files",
    "note": "Signed nonzero amplitudes permit source-residual recovery. State, additive source, and prospective source law remain distinct.",
    "kind": "html",
    "file": "./content/releases/openC2.html",
    "source": "./releases/UD_OPEN_C2_AND_E2_APPARATUS_BINDING_v0.1.zip"
  },
  "hardGateDryRun": {
    "title": "Hard-Gate Transduction and E2 Dry Run",
    "label": "EXACT GATE ENUMERATION / SYNTHETIC REHEARSAL · 13 files",
    "note": "Nonuniform face gates expose hidden support. The complete E2 rehearsal uses synthetic fixtures; the later endogenous-path result refines the zero-state boundary.",
    "kind": "html",
    "file": "./content/releases/hardGateDryRun.html",
    "source": "./releases/UD_HARD_GATE_AND_E2_FULL_DRY_RUN_v0.1.zip"
  },
  "faceGatePath": {
    "title": "Endogenous Face-Gate Path and Provisional Yale Binding",
    "label": "EXACT PATH / APPARATUS UNCONFIRMED · 14 files",
    "note": "Nonuniform gates admit a second-order C1-to-C3 path. A primitive face constructor and current apparatus confirmation remain required.",
    "kind": "html",
    "file": "./content/releases/faceGatePath.html",
    "source": "./releases/UD_FACE_GATE_ENDOGENOUS_PATH_AND_HARRIS_BINDING_v0.1.zip"
  },
  "yaleFollowup": {
    "title": "Yale E2 Technical Follow-Up Materials",
    "label": "PREPARED / NOT SENT · 5 files",
    "note": "The supplied packet contains a technical proposal, response schema, and email draft marked ready but not sent.",
    "kind": "html",
    "file": "./content/releases/yaleFollowup.html",
    "source": "./releases/UD_HARRIS_YALE_E2_TECHNICAL_FOLLOWUP_PACKAGE_v0.1.zip"
  },
  "facetFrame": {
    "title": "Facet-Frame Transport and Yale Response Shell",
    "label": "EXACT TRANSPORT / RESPONSE PENDING · 13 files",
    "note": "Shared-edge covariance and nontrivial matching holonomy are established internally; the response shell preserves the immutable scientific core.",
    "kind": "html",
    "file": "./content/releases/facetFrame.html",
    "source": "./releases/UD_DELTA4_FACET_FRAME_AND_YALE_RESPONSE_SHELL_v0.1.zip"
  },
  "facetCurvature": {
    "title": "Matching Curvature and Calorimetry Response Shells",
    "label": "EXACT FINITE BOUNDARY / RESPONSE PENDING · 17 files",
    "note": "Finite enumeration rules out nonzero globally parallel one-pair events; proposed calorimetry capabilities require explicit partner responses.",
    "kind": "html",
    "file": "./content/releases/facetCurvature.html",
    "source": "./releases/UD_FACET_CURVATURE_AND_CALORIMETRY_RESPONSE_SHELLS_v0.1.zip"
  },
  "localizedEvent": {
    "title": "Localized Events and E2 Consortium Handoff",
    "label": "CONDITIONAL LOCALITY / HANDOFF PROTOCOL · 14 files",
    "note": "A selected anchor gives a localized defect section. Later source-selection and locality repairs refine this historical candidate; custody requires a single event host.",
    "kind": "html",
    "file": "./content/releases/localizedEvent.html",
    "source": "./releases/UD_LOCALIZED_EVENT_AND_E2_CONSORTIUM_HANDOFF_v0.1.zip"
  },
  "derivedLocality": {
    "title": "Derived Event Locality and E2 Host Solver",
    "label": "CONDITIONAL DERIVATION / METHOD CONTROLS · 15 files",
    "note": "Unique lawful facet ownership derives one-packet locality. Synthetic host-solver controls pass; real partner responses remain pending.",
    "kind": "html",
    "file": "./content/releases/derivedLocality.html",
    "source": "./releases/UD_DERIVED_LOCALITY_AND_E2_CONSORTIUM_SOLVER_v0.1.zip"
  },
  "sourceSelector": {
    "title": "Source-Driven Facet Selection and Reply Pipeline",
    "label": "EXACT CONDITIONAL SELECTOR / SOURCE OPEN · 18 files",
    "note": "A strict source-drive maximum selects a facet at zero-contrast onset and persists in closed normalized flow away from recurrence zeros. Raw source origin and actual partner responses remain open.",
    "kind": "html",
    "file": "./content/releases/sourceSelector.html",
    "source": "./releases/UD_SOURCE_SELECTOR_AND_REPLY_PIPELINE_v0.1.zip"
  },
  "globalC3Harmonic": {
    "title": "Global C3 Evolution and Harmonic Neighbor Context",
    "label": "EXACT GLOBAL FLOW / OCCUPANCY OPEN · 8 files",
    "note": "The glued 3-skeleton has an exact global propagator and conserved neighbor harmonic mode. Its source shape selects the shared facet in the stated harmonic context; initial occupancy remains open.",
    "kind": "html",
    "file": "./content/releases/globalC3Harmonic.html",
    "source": "./releases/UD_GLOBAL_C3_HARMONIC_CONTEXT_v0.1.zip"
  },
  "edgeAnisotropy": {
    "title": "S4 Edge-to-Anisotropy Intertwiner",
    "label": "EXACT LINEAR CUT BRIDGE · 6 files",
    "note": "An exact rank-three partial isometry carries edge cut content into trace-free anisotropy and annihilates cycles. This finite representation bridge does not establish a physical metric.",
    "kind": "html",
    "file": "./content/releases/edgeAnisotropy.html",
    "source": "./releases/UD_S4_EDGE_TO_ANISOTROPY_INTERTWINER_v0.1_RELEASE.zip"
  },
  "cycleAnisotropy": {
    "title": "Cycle Anisotropy: Linear Boundary and Quadratic Construction",
    "label": "EXACT BOUNDARY / QUADRATIC CONSTRUCTION · 8 files",
    "note": "Full S4 symmetry excludes a nonzero linear cycle map. A quadratic traceless dyad supplies an admissible route whose image spans the five-dimensional target.",
    "kind": "html",
    "file": "./content/releases/cycleAnisotropy.html",
    "source": "./releases/UD_CYCLE_ANISOTROPY_LINEAR_NO_GO_AND_QUADRATIC_INTERTWINER_v0.1_RELEASE.zip"
  },
  "quadraticClassification": {
    "title": "Quadratic Cycle Intertwiner Classification",
    "label": "EXACT TWO-CHANNEL CLASSIFICATION · 8 files",
    "note": "All equivariant quadratic cycle maps have two independent channels. Finite symmetry fixes their form but leaves coefficient selection and overall scale open.",
    "kind": "html",
    "file": "./content/releases/quadraticClassification.html",
    "source": "./releases/UD_QUADRATIC_CYCLE_INTERTWINER_CLASSIFICATION_v0.1_RELEASE.zip"
  },
  "nrf1Refinement": {
    "title": "NRF-1 Quadratic Refinement: Ordering-Dependent Channel Flow",
    "label": "EXACT CONDITIONAL / ORDERING OPEN · 8 files",
    "note": "Local-first averaging scales the channels by 5/16 and 3/16; averaging the state first and exact chain retraction give different maps. Observable ordering remains a source dependency.",
    "kind": "html",
    "file": "./content/releases/nrf1Refinement.html",
    "source": "./releases/UD_NRF1_QUADRATIC_CHANNEL_REFINEMENT_COVARIANCE_v0.1_RELEASE.zip"
  },
  "anisotropyOrdering": {
    "title": "Anisotropy Observable Ordering: Source Audit",
    "label": "SOURCE AUDIT / ALO-1 CANDIDATE · 6 files",
    "note": "The supplied audit distinguishes support-stock additivity from anisotropy additivity. Local-first observation retains trace-free child covariance; ALO-1 remains a candidate.",
    "kind": "html",
    "file": "./content/releases/anisotropyOrdering.html",
    "source": "./releases/UD_ANISOTROPY_OBSERVABLE_ORDERING_SOURCE_AUDIT_v0.1_RELEASE.zip"
  },
  "kappaBsDualLane": {
    "title": "Burden-to-Support Normalization and OP03 Dual-Lane Acquisition",
    "label": "EXACT CONDITIONAL RE-ENTRY / ACQUISITION PREPARED · 37 files",
    "note": "An independent same-event formation stock would determine the injection magnitude under the declared proportional map. Signed alignment and real OP03 events remain open; the acquisition workflow is frozen.",
    "kind": "html",
    "file": "./content/releases/kappaBsDualLane.html",
    "source": "./releases/UD_KAPPA_BS_DUAL_LANE_OP03_PACKAGE_v0.1.zip"
  },
  "nonlinearHva1": {
    "title": "Nonlinear Cross-Block Boundary and HVA-1 Prospective Test",
    "label": "EXACT SCOPED BOUNDARY / PROSPECTIVE TEST · 17 files",
    "note": "Jacobi excludes the first burden-state-linear reversible cross block under the stated architecture. A frozen HVA-1 test checks 19 instantaneous stock jumps with independent covariance; only synthetic controls are supplied.",
    "kind": "html",
    "file": "./content/releases/nonlinearHva1.html",
    "source": "./releases/UD_NONLINEAR_CROSSBLOCK_AND_HVA1_PROSPECTIVE_TEST_v0.1_RELEASE.zip"
  },
  "c1FormationBench": {
    "title": "C1 Formation Receipt and Purpose-Built OP03/KBS Bench",
    "label": "EXACT CONDITIONAL RECEIPT / BENCH CONTRACT · 32 files",
    "note": "Source-complete six-edge before/after returns isolate the formation vector. Exact collinearity identifies signed event-scoped kappa; independent engine implementation and real acquisition remain pending.",
    "kind": "html",
    "file": "./content/releases/c1FormationBench.html",
    "source": "./releases/UD_C1_FORMATION_PURPOSE_BUILT_BENCH_PACKAGE_v0.1.zip"
  },
  "c4GluingRepair": {
    "title": "Unique-Simplex Gluing and C4 Harmonic Transfer",
    "label": "EXACT REPAIR / LATER C4 ADMISSION · 14 files",
    "note": "Repairs the universal 4q² gluing-cost interpretation, derives support-preserving top-cell exchange, and tracks H3 changes when top cells are added or removed. The later v0.2 amendment supersedes this package’s candidate C4 status.",
    "kind": "html",
    "file": "./content/releases/c4GluingRepair.html",
    "source": "./releases/UD_C4_H3_GLUING_REPAIR_v0.1.zip"
  },
  "c4GeneralTransfer": {
    "title": "C4 Address Admission and General Transfer",
    "label": "EXACT CONDITIONAL SELECTOR / SPECTRAL CLASSIFICATION · 13 files",
    "note": "Boundary-complete candidates are ranked by squared source overlap. The signed dual Gram matrix classifies top-cell transfer; the later non-return certificate strengthens the instantaneous removal gate.",
    "kind": "html",
    "file": "./content/releases/c4GeneralTransfer.html",
    "source": "./releases/UD_C4_ADDRESS_AND_GENERAL_TRANSFER_v0.1.zip"
  },
  "c4CanonRemoval": {
    "title": "Canonical C4 Channel and Certified Active-Set Removal",
    "label": "INTERNAL CANON / EXACT NON-RETURN / PHYSICAL PROMOTION 0 · 14 files",
    "note": "Admits the C4 Hodge channel as internal canon, scopes earlier harmonic conservation, and proves trajectory-preserving removal under a finite non-return certificate. Archive correspondence remains a candidate; absolute dissolution and physical identity remain open.",
    "kind": "html",
    "file": "./content/releases/c4CanonRemoval.html",
    "source": "./releases/UD_C4_CANON_AND_ARCHIVE_REMOVAL_v0.1.zip"
  },
  "boundaryPachnerC4": {
    "title": "Boundary Dissolution and C₄-Mediated Pachner Dynamics",
    "label": "EXACT CONDITIONAL DYNAMICS / OPERATIONAL DISSOLUTION CANDIDATE · 14 files",
    "note": "Derives safe coface-free boundary deletion and an exact conditional 2↔3 transition packet. The 2→3 launch requires q² of mediator support; selection among deletable faces and the first-history launch source remain open.",
    "kind": "html",
    "file": "./content/releases/boundaryPachnerC4.html",
    "source": "./releases/UD_BOUNDARY_DISSOLUTION_AND_PACHNER_C4_v0.1.zip"
  },
  "pachnerLaunchEconomy": {
    "title": "Pachner Launch Economy and Complete 3D Generator Family",
    "label": "EXACT PACKET FAMILY / CONDITIONAL LAUNCH SOURCES · 12 files",
    "note": "Unifies exact prepared 1↔4 and 2↔3 packets and their mediator-stock requirements. Existing network support or source-bound H3 occupancy can supply launch stock conditionally; a pure zero-reservoir expansion cannot self-start.",
    "kind": "html",
    "file": "./content/releases/pachnerLaunchEconomy.html",
    "source": "./releases/UD_PACHNER_LAUNCH_ECONOMY_AND_COMPLETE_GENERATOR_v0.1.zip"
  },
  "latentSeatScheduler": {
    "title": "Latent-Seat Activation and Global Pachner Scheduling",
    "label": "CONDITIONAL ACTIVATION / SCHEDULER METHOD · 14 files",
    "note": "A frozen fifth-seat descriptor determines the 1→4 endpoint closure. Signed mediator routing, reducing-block concurrency, and delayed reduction credits govern execution; symmetry-equivalent seats require a distinguishing source receipt.",
    "kind": "html",
    "file": "./content/releases/latentSeatScheduler.html",
    "source": "./releases/UD_LATENT_SEAT_AND_GLOBAL_PACHNER_SCHEDULER_v0.1.zip"
  },
  "contextRecursivePachner": {
    "title": "Context Selection and Recursive Pachner Method Simulation",
    "label": "EXACT SELECTOR / SYNTHETIC ENDPOINT SIMULATION · 11 files",
    "note": "Exact source-score factorization explains context selection and symmetry holds. The supplied 64-site endpoint protocol reproduces balanced period-two recurrence with zero rational ledger drift; it is not a fully geometric coupled-complex simulation.",
    "kind": "html",
    "file": "./content/releases/contextRecursivePachner.html",
    "source": "./releases/UD_CONTEXT_SELECTION_AND_RECURSIVE_PACHNER_SIM_v0.1.zip"
  },
  "geometricPachnerArrow": {
    "title": "Geometric Pachner Evolution and Topology-History Arrow",
    "label": "GEOMETRIC METHOD RESULT / EXACT HISTORY RULE · 12 files",
    "note": "Actual simplex mutation preserves the reported topology and normalized balance over 200 commits. Periodic active geometry is distinguished from the append-only dissolution history; physical time remains unbridged.",
    "kind": "html",
    "file": "./content/releases/geometricPachnerArrow.html",
    "source": "./releases/UD_GEOMETRIC_PACHNER_AND_TOPOLOGY_ARROW_v0.1.zip"
  },
  "openConnectedPachner": {
    "title": "Open Sources and Connected Pachner Dynamics",
    "label": "CARRIER TYPE REPAIR / CONNECTED METHOD FIXTURE / CONDITIONAL SOURCE · 12 files",
    "note": "Separates EVENT mediators from CELL homology, checks a connected overlapping-event fixture, and derives open support balance. Full launch-state integration and predictive vector-source closure remain open.",
    "kind": "html",
    "file": "./content/releases/openConnectedPachner.html",
    "source": "./releases/UD_OPEN_SOURCE_AND_CONNECTED_PACHNER_v0.1.zip"
  },
  "c5ContextLattice": {
    "title": "C₅ Context Sources and Multi-Frame Event Lattice",
    "label": "CONDITIONAL INTERNAL SOURCE / HISTORICAL ROUTING DIAGNOSTIC · 13 files",
    "note": "Derives a signed local source conditional on a larger context state and tests a 12-frame geometric batch. The later admission package supersedes the sampled routing-HOLD interpretation.",
    "kind": "html",
    "file": "./content/releases/c5ContextLattice.html",
    "source": "./releases/UD_C5_CONTEXT_AND_MULTIFRAME_LATTICE_v0.1.zip"
  },
  "c5AdmissionFirstHit": {
    "title": "C₅ Admission, Occupancy, and First-Hit Repair",
    "label": "INTERNAL CANDIDATE / EXACT ISOLATED BRANCH / SCHEDULER REPAIR · 12 files",
    "note": "Scopes C₅ as internal and not promoted; derives occupancy after admission and repairs next-snapshot inverse launch timing. Global descriptor provenance and full coupled execution remain gated.",
    "kind": "html",
    "file": "./content/releases/c5AdmissionFirstHit.html",
    "source": "./releases/UD_C5_ADMISSION_AND_26FRAME_FIRST_HIT_v0.1.zip"
  },
  "retainedTrigger": {
    "title": "Retained Terminal Triggers and Conditional Topology Change",
    "label": "CONDITIONAL INTERNAL CERTIFICATE / SOURCE FIXTURE / PHYSICAL PROMOTION 0 · 8 files",
    "note": "An exact terminal projection blocks the specified prepared inverse when the verdict, signed impulse, and balance receipt are frozen in time. Connected endpoint fixtures distinguish active counts, history, and support; the gate-to-source law remains open.",
    "kind": "html",
    "file": "./content/releases/retainedTrigger.html",
    "source": "./releases/UD_RETAINED_TRIGGER_AND_TOPOLOGY_ARROW_v0.1.zip"
  },
  "irreversibleReturn": {
    "title": "Terminal Projection and Prepared Return",
    "label": "EXACT INTERNAL / SOURCE-CONDITIONAL · 9 files",
    "note": "Exact local top-package removal under an explicit open intervention; closed skew exchange alone cannot produce this noninvertible projection.",
    "kind": "html",
    "file": "./content/releases/irreversibleReturn.html",
    "source": "./releases/UD_IRREVERSIBLE_PACHNER_RETURN_BLOCK_v0.1.zip"
  },
  "terminalPhases": {
    "title": "Terminal Classes and Geometric Impulses",
    "label": "CONDITIONAL LAW / INTERNAL FIXTURE · 11 files",
    "note": "Separates class selection from the geometry-fixed impulse; Fragment, Expel and Dissolve require different destination receipts.",
    "kind": "html",
    "file": "./content/releases/terminalPhases.html",
    "source": "./releases/UD_SELECTOR_FACTORIZED_TERMINAL_PHASES_v0.1.zip"
  },
  "thresholdDestinations": {
    "title": "Threshold Surfaces and Destination Maps",
    "label": "EXACT CONDITIONAL / THRESHOLDS OPEN · 11 files",
    "note": "Symbolic retention surfaces, fragment partitions and signed export maps; scalar equality never identifies the carrier or destination.",
    "kind": "html",
    "file": "./content/releases/thresholdDestinations.html",
    "source": "./releases/UD_THRESHOLD_DESTINATION_MAPS_v0.1.zip"
  },
  "hardTerminal": {
    "title": "Hard Gates and Terminal Selectors",
    "label": "EXACT INTERNAL / TIES HOLD · 11 files",
    "note": "Binary hard cuts and strict first-admissible export selection; interior soft thresholds are not fixed by order alone.",
    "kind": "html",
    "file": "./content/releases/hardTerminal.html",
    "source": "./releases/UD_HARD_THRESHOLDS_TERMINAL_SELECTORS_v0.1.zip"
  },
  "gateMetricSoft": {
    "title": "Gate Metric and Soft Selectors",
    "label": "CONDITIONAL / METRIC CANDIDATE · 11 files",
    "note": "Product conductance and unique minimum-cut selection under stated assumptions; the equal-step semantic metric remains a candidate.",
    "kind": "html",
    "file": "./content/releases/gateMetricSoft.html",
    "source": "./releases/UD_GATE_METRIC_SOFT_SELECTORS_v0.1.zip"
  },
  "hodgeSoft": {
    "title": "Hodge Margins and Pre-Hard Resolution",
    "label": "INTERNAL SIMULATION / CLASS SOURCE OPEN · 10 files",
    "note": "Operational Hodge margins drive cut and destination choices in a prescribed connected fixture; the terminal classes are source inputs.",
    "kind": "html",
    "file": "./content/releases/hodgeSoft.html",
    "source": "./releases/UD_HODGE_SOFT_PREHARD_SELECTOR_v0.1.zip"
  },
  "hodgeMetricReview": {
    "title": "Hodge Receipts and Metric Review Scope",
    "label": "OPERATIONAL BOUNDARY / REVIEW PENDING · 12 files",
    "note": "Hodge receipts are insufficient to select a full retained class. Historical metric preregistration v0.1 is followed by the v0.2 repair.",
    "kind": "html",
    "file": "./content/releases/hodgeMetricReview.html",
    "source": "./releases/UD_HODGE_INTERTWINER_METRIC_REVIEW_v0.1.zip"
  },
  "dfRedteam": {
    "title": "Distinction, Fidelity and Metric Red Team",
    "label": "INTERNAL RED TEAM / HISTORICAL PROTOCOL · 12 files",
    "note": "Operational identity monitors and synthetic separation of equal spacing from minimum passability; identifies the v0.1 protocol decision gap.",
    "kind": "html",
    "file": "./content/releases/dfRedteam.html",
    "source": "./releases/UD_DISTINCTION_FIDELITY_METRIC_REDTEAM_v0.1.zip"
  },
  "identityMetricV02": {
    "title": "Identity Contracts and Metric Protocol v0.2",
    "label": "SOURCE CANDIDATE / PREREGISTERED · 11 files",
    "note": "An explicit identity contract and repaired metric decision rules; synthetic protocol checks are not independent semantic review.",
    "kind": "html",
    "file": "./content/releases/identityMetricV02.html",
    "source": "./releases/UD_IDENTITY_CONTRACT_METRIC_V02_v0.1.zip"
  },
  "identityFormation": {
    "title": "Identity Formation and Ordinal Grading",
    "label": "HISTORICAL TIMING / LATER REPAIR · 9 files",
    "note": "Connected-component identity construction and binary-to-grade underdetermination; its original post-retention timing is superseded by v0.2.",
    "kind": "html",
    "file": "./content/releases/identityFormation.html",
    "source": "./releases/UD_IDENTITY_FORMATION_GRADING_v0.1.zip"
  },
  "identityStability": {
    "title": "Identity Timing, Stability and Robustness",
    "label": "CONDITIONAL / TIMING REPAIRED · 9 files",
    "note": "Moves the seed contract before admission; separates initial passability, temporal stability and robustness within a frozen perturbation class.",
    "kind": "html",
    "file": "./content/releases/identityStability.html",
    "source": "./releases/UD_IDENTITY_STABILITY_ROBUSTNESS_v0.1.zip"
  },
  "identityPerturbations": {
    "title": "Perturbation Families and Identity Grades",
    "label": "CONDITIONAL / RECOVERY RULE REPAIRED · 9 files",
    "note": "Symmetry-reduced operator families and scoped robustness; the original binary recovery rule is superseded by PASS/HOLD/FAIL.",
    "kind": "html",
    "file": "./content/releases/identityPerturbations.html",
    "source": "./releases/UD_CANONICAL_PERTURBATION_DF_LADDER_v0.1.zip"
  },
  "predictiveRecovery": {
    "title": "Predictive Source Packets and Recovery",
    "label": "RECEIPT-CONDITIONED / THREE-VALUED · 9 files",
    "note": "Frozen signed burden packets supply a prospective balance; recovery distinguishes constructive return, unresolved reachability and certified no-return.",
    "kind": "html",
    "file": "./content/releases/predictiveRecovery.html",
    "source": "./releases/UD_PREDICTIVE_SOURCE_RECOVERY_v0.1.zip"
  },
  "predictiveCompleteness": {
    "title": "Predictive Sources and Recovery Scope",
    "label": "SCOPE ADDENDUM / SHARED LINEAGE · 9 files",
    "note": "Clarifies the same source/recovery construction and its unresolved generator, carrier bridge and completeness conditions; shared payloads retained.",
    "kind": "html",
    "file": "./content/releases/predictiveCompleteness.html",
    "source": "./releases/UD_PREDICTIVE_SOURCE_RECOVERY_COMPLETENESS_v0.1.zip"
  },
  "q109Completeness": {
    "title": "Pathwise Information and Recovery Completeness",
    "label": "EXACT BOUNDARY / FINITE-DOMAIN THEOREM · 9 files",
    "note": "Different jump laws share the specified second moments; finite-domain recovery failure needs an exhaustive transition/source certificate.",
    "kind": "html",
    "file": "./content/releases/q109Completeness.html",
    "source": "./releases/UD_Q109_RECOVERY_COMPLETENESS_v0.1.zip"
  },
  "q109Compiler": {
    "title": "Microscopic Pushforward and Recovery Compiler",
    "label": "FIXTURE REPLAY / COVERAGE QUALIFICATION · 18 files",
    "note": "Names the missing microscopic response law and supplies four registry fixtures; the compiler trusts declared coverage and needs input qualification.",
    "kind": "html",
    "file": "./content/releases/q109Compiler.html",
    "source": "./releases/UD_Q109_PUSHFORWARD_REC_COMPILER_v0.1.zip"
  },
  "omega0RecPachner": {
    "title": "Ω₀ Source Audit and Recovery/Pachner Simulation",
    "label": "CONDITIONAL CONSTRUCTION / SOURCE OPEN · 10 files",
    "note": "Conditional recovery predicates are integrated into a finite simulation. The native pre-event micro-alphabet source remains open.",
    "kind": "html",
    "file": "./content/releases/omega0RecPachner.html",
    "source": "./releases/UD_OMEGA0_REC_PACHNER_v0.1.zip"
  },
  "omega0ReceiptAction": {
    "title": "Ω₀ Receipt Kernel and Pachner Action Admission",
    "label": "CONDITIONAL CONSTRUCTION / SOURCE OPEN · 11 files",
    "note": "A supplied-input receipt kernel and a conditional move-admission rule. Recovery alone does not imply a legal move or derive its pre-event source.",
    "kind": "html",
    "file": "./content/releases/omega0ReceiptAction.html",
    "source": "./releases/UD_OMEGA0_RECOVERY_PACHNER_ACTION_v0.1.zip"
  },
  "retainedBondParity": {
    "title": "Retained Relations and Odd-Event Parity",
    "label": "FINITE COUNTEREXAMPLES / CONDITIONAL REPAIR · 7 files",
    "note": "Selective retention separates one retained address from the number of precursor toggles. Odd gross toggle parity, rather than one-pair locality, is the exact binary-color condition.",
    "kind": "html",
    "file": "./content/releases/retainedBondParity.html",
    "source": "./releases/UD_RETAINED_BOND_ODD_EVENT_PACKAGE_v0.1.zip"
  },
  "hexacycleModels": {
    "title": "Honeycomb and Diamond Vector-Model Comparison",
    "label": "DECLARED GRAPH MODELS / MATERIAL HYPOTHESIS · 4 files",
    "note": "Girth-six calculations concern declared bond-vector models. The comparison does not derive a material network from the tetrahedral carrier.",
    "kind": "html",
    "file": "./content/releases/hexacycleModels.html",
    "source": "./releases/UD_GRAPHENE_DIAMOND_HEXACYCLE_PACKAGE_v0.1.zip"
  },
  "tetrahedralRingBoundary": {
    "title": "Tetrahedral Coordination and Ring-Length Conditions",
    "label": "STRUCTURAL LIMIT / CONDITIONAL GRAPH RESULT · 7 files",
    "note": "The K4 graph and unrestricted cell adjacency do not force six-cycles. A girth-six retained network needs additional alternation, square-exclusion and six-return assumptions.",
    "kind": "html",
    "file": "./content/releases/tetrahedralRingBoundary.html",
    "source": "./releases/UD_K4_C6_TETRAHEDRAL_MATERIALS_PACKAGE_v0.1.zip"
  },
  "retainedZ2Phases": {
    "title": "Binary Coloring and Conditional Ring Phases",
    "label": "EARLIER CONDITIONAL CONSTRUCTION · 8 files",
    "note": "Earlier one-pair construction preserved with the later odd-parity and address-atom refinements. Alternation alone excludes odd loops, not four-cycles.",
    "kind": "html",
    "file": "./content/releases/retainedZ2Phases.html",
    "source": "./releases/UD_RETAINED_Z2_TOPOLOGY_PHASES_PACKAGE_v0.1.zip"
  },
  "oddFormationBoundary": {
    "title": "Formation Rules Do Not Select Odd Events",
    "label": "FINITE IDENTIFIABILITY LIMIT · 6 files",
    "note": "Two-address transitions remain admissible under the stated finite rules; an odd-only formation law requires an additional premise.",
    "kind": "html",
    "file": "./content/releases/oddFormationBoundary.html",
    "source": "./releases/UD_ODD_EVENT_FORMATION_NO_GO_PACKAGE_v0.1.zip"
  },
  "addressAtomicCarrier": {
    "title": "Address-Level Events and Higher-Order Bundles",
    "label": "CONDITIONAL CARRIER REFINEMENT · 8 files",
    "note": "Individual nonzero address changes have odd index. Simultaneous multi-address events are retained as bundles without inventing a serial order or a material endpoint map.",
    "kind": "html",
    "file": "./content/releases/addressAtomicCarrier.html",
    "source": "./releases/UD_LINEAGE_ATOMIC_CARRIER_PACKAGE_v0.1.zip"
  },
  "faceReceiptBoundary": {
    "title": "Face-Resolved Data and Square-Exclusion Limits",
    "label": "CONDITIONAL RECONSTRUCTION / STRUCTURAL LIMIT · 8 files",
    "note": "A qualified singleton face event identifies its face and degree-two cell endpoints. Multiple-face events and a rule excluding legal four-cycles remain unresolved.",
    "kind": "html",
    "file": "./content/releases/faceReceiptBoundary.html",
    "source": "./releases/UD_FACE_RECEIPT_X4_PACKAGE_v0.2.zip"
  },
  "endpointFaceMap": {
    "title": "Endpoint Reconstruction from Shared-Face Incidence",
    "label": "FINITE IDENTIFIABILITY / CONDITIONAL MAP · 8 files",
    "note": "A matching label cannot equivariantly select one tetrahedral face. An independently supplied shared face with exactly two retained incident cells identifies an unordered endpoint pair.",
    "kind": "html",
    "file": "./content/releases/endpointFaceMap.html",
    "source": "./releases/UD_ENDPOINT_BETA_X4_PACKAGE_v0.1.zip"
  },
  "pairFaceLineage": {
    "title": "Pair–Face Matching and the Sixfold Return Candidate",
    "label": "CONDITIONAL LINEAGE / PROSPECTIVE SELECTOR · 8 files",
    "note": "Unique compatibility matching can identify atom lineage. Binary return plus coherent nonzero ternary steps constrains loop length to multiples of six; a six-cycle still requires an existence construction.",
    "kind": "html",
    "file": "./content/releases/pairFaceLineage.html",
    "source": "./releases/UD_PAIR_FACE_Z23_PACKAGE_v0.1.zip"
  },
  "faceChiralityBoundary": {
    "title": "Frame-Class and Chirality Conditions Remain Independent",
    "label": "EXACT COUNTEREXAMPLES / SOURCE CONDITIONS OPEN · 8 files",
    "note": "Oriented face compatibility does not enforce A4 minus V4. A mixed-chirality four-step loop returns exactly, keeping the proposed selector conditions separate.",
    "kind": "html",
    "file": "./content/releases/faceChiralityBoundary.html",
    "source": "./releases/UD_FACE_SELECTOR_CHIRALITY_PACKAGE_v0.1.zip"
  },
  "a4v4Acquisition": {
    "title": "Ternary Frame Classification and Acquisition Extension",
    "label": "FINITE GROUP CLASSIFICATION / ACQUISITION PROPOSAL · 8 files",
    "note": "The existing S4 receipt supports A4/V4 classification; universal edge-class selection and coherent loop chirality remain hypotheses for future source-complete tests.",
    "kind": "html",
    "file": "./content/releases/a4v4Acquisition.html",
    "source": "./releases/UD_A4V4_Z3_ACQUISITION_PACKAGE_v0.1.zip"
  },
  "retainedEdgeAcquisition": {
    "title": "First Retained-Edge Acquisition — Preparation Package",
    "label": "PREPARATION ONLY / ZERO REAL EVENTS · 57 files",
    "note": "The supplied session records zero real events. Intake templates, scorers and an empty-session check prepare future acquisition; no scientific PASS or FAIL is issued.",
    "kind": "html",
    "file": "./content/releases/retainedEdgeAcquisition.html",
    "source": "./releases/UD_FIRST_REAL_RETAINED_EDGE_ACQUISITION_v0.1.zip"
  },
  "retainedEdgeHandoff": {
    "title": "Retained-Edge Provider Handoff Materials",
    "label": "HANDOFF MATERIALS / NO ACQUISITION RESULT · 9 files",
    "note": "Blank source templates and provider instructions. This archive does not establish a provider submission, a completed measurement or an independently scored result.",
    "kind": "html",
    "file": "./content/releases/retainedEdgeHandoff.html",
    "source": "./releases/UD_FIRST_REAL_RETAINED_EDGE_PROVIDER_HANDOFF_v0.1.zip"
  },
  "seamCrossCoupling": {
    "title": "Shared-Face Support Coupling",
    "label": "FINITE INCIDENCE RESULT · 6 files",
    "note": "Exact unweighted two-cell Gram matrix and squared frequencies 3 and 5. Abstract incidence does not determine a continuous angular conductance.",
    "kind": "html",
    "file": "./content/releases/seamCrossCoupling.html",
    "source": "./releases/UD_SEAM_SUPPORT_CROSS_COUPLING_PACKAGE_v0.1 (1).zip"
  },
  "magicAngleComparison": {
    "title": "Small-Angle Comparison and Model Limits",
    "label": "MODEL COMPARISON / PHYSICAL BRIDGE OPEN · 4 files",
    "note": "Historical comparison motivating a conditional response model. Matching channel counts does not derive a material coupling law or predict a physical angle.",
    "kind": "html",
    "file": "./content/releases/magicAngleComparison.html",
    "source": "./releases/UD_MAGIC_ANGLE_1P1_PACKAGE_v0.1.zip"
  },
  "facePairingIntertwiner": {
    "title": "Quadratic Face-to-Pairing Map",
    "label": "FINITE ALGEBRA / SOURCE CHOICE OPEN · 8 files",
    "note": "Centered tetrahedral face data reconstruct a vector and a quadratic pairing tensor. Linear equivariant maps vanish; the quadratic map is unique up to scale.",
    "kind": "html",
    "file": "./content/releases/facePairingIntertwiner.html",
    "source": "./releases/UD_FACE_PAIRING_INTERTWINER_PACKAGE_v0.1.zip"
  },
  "continuousCoframe": {
    "title": "Continuous Coframes and Distinct Source Diagnostics",
    "label": "EXACT GEOMETRY / CONDITIONAL SOURCE ADAPTER · 7 files",
    "note": "Declared rotations preserve the face frame and transport pairing tensors. Face stock and incidence current provide different diagnostics; their constitutive roles remain proposals.",
    "kind": "html",
    "file": "./content/releases/continuousCoframe.html",
    "source": "./releases/UD_CONTINUOUS_COFRAME_SOURCE_ADAPTER_PACKAGE_v0.1.zip"
  },
  "dynamicPairingNull": {
    "title": "Conditional Angular Coupling and Response Cancellation",
    "label": "CONDITIONAL MATRIX MODELS / SCOPE QUALIFIED · 11 files",
    "note": "Weighted Gram spectra and Schur-complement cancellation are conditional matrix results. Normalized overlap and weighted-chain dynamics require the qualifications in the supporting review.",
    "kind": "html",
    "file": "./content/releases/dynamicPairingNull.html",
    "source": "./releases/UD_DYNAMIC_MAGIC_NULL_PACKAGE_v0.1.zip"
  },
  "observationKappaRepair": {
    "title": "Observation Maps and Corrected Dimensionless Ratios",
    "label": "LATEST OBSERVATION-MAP CORRECTION · 9 files",
    "note": "Under the mean-amplitude branch, correct each class signal before forming both ratios and second differences. A common scale cancels only after the observation map is specified.",
    "kind": "html",
    "file": "./content/releases/observationKappaRepair.html",
    "source": "./releases/UD_CRL2_OBSERVATION_KAPPA_NORMALIZATION_PACKAGE_v0.1.zip"
  },
  "signedHistorySufficiency": {
    "title": "Net-Winding Sufficiency and Readout Scope",
    "label": "EXACT STATE FUNCTION / READOUT SCOPE REPAIR · 7 files",
    "note": "Canonical harmonic history reduces to net winding. Retracts mandatory constellation readout for the frozen positive-transition family with independently known preparation labels.",
    "kind": "html",
    "file": "./content/releases/signedHistorySufficiency.html",
    "source": "./releases/UD_WINDING_SIGNED_HISTORY_SUFFICIENCY_PACKAGE_v0.1.zip"
  },
  "varianceChiralityHistory": {
    "title": "Variance Curvature and Sign Loss — Earlier Analysis",
    "label": "HISTORICAL ANALYSIS / LATER CORRECTIONS APPLY · 7 files",
    "note": "Quadratic observation loses sign and introduces second-moment terms. Later corrections narrow the readout-necessity claim and require branch-specific class correction before scoring.",
    "kind": "html",
    "file": "./content/releases/varianceChiralityHistory.html",
    "source": "./releases/UD_7_26_OBSERVATION_MAP_VARIANCE_CHIRALITY_PACKAGE_v0.1.zip"
  },
  "energySourceBranch": {
    "title": "Calorimetry Uses the Energy-Source Branch",
    "label": "OBSERVATION BRANCH SELECTED / EMPIRICAL TEST PENDING · 9 files",
    "note": "Selects measured event heat for the calorimetry proposal. Heat variance contributes to uncertainty; amplitude-variance subtraction is inactive without a separate observation law.",
    "kind": "html",
    "file": "./content/releases/energySourceBranch.html",
    "source": "./releases/UD_SECTION_7_26_ENERGY_SOURCE_PACKAGE_v0.1.zip"
  },
  "energyWindingScorer": {
    "title": "Energy-Space Winding Statistics and Reduced-Flux Matching",
    "label": "FINITE FORMULAS / SCORER REPAIR REQUIRED · 14 files",
    "note": "Scale cancellation and a conventional matched-device baseline are derived in scope. The supplied scorer has a unit-dependent denominator guard documented in the review.",
    "kind": "html",
    "file": "./content/releases/energyWindingScorer.html",
    "source": "./releases/UD_ENERGY_SCORER_RF_SQUID_PACKAGE_v0.1.zip"
  },
  "rfSquidBaselineStress": {
    "title": "Apparatus Baseline and Conditional Stress Tests",
    "label": "CONDITIONAL DEVICE MODEL / SYNTHETIC STRESS · 13 files",
    "note": "Event-energy predictions provide a conventional comparison and residual diagnostic. Synthetic drift envelopes are not empirical false-positive rates; residuals do not inherit the winding law.",
    "kind": "html",
    "file": "./content/releases/rfSquidBaselineStress.html",
    "source": "./releases/UD_RF_SQUID_BASELINE_STRESS_PACKAGE_v0.1.zip"
  },
  "totalHeatComparison": {
    "title": "Total-Heat Model Comparison and Calibration Covariance",
    "label": "SYNTHETIC REPLAY / VALIDATION LIMITS IDENTIFIED · 24 files",
    "note": "Retains the pre-fit family gate and a held-out fourth-class check. Supplied fixtures replay, while scale handling, covariance validation and source-order enforcement need repair before real scoring.",
    "kind": "html",
    "file": "./content/releases/totalHeatComparison.html",
    "source": "./releases/UD_MODEL_COMPARISON_COVARIANCE_PACKAGE_v0.1.zip"
  }
};
export const releaseOrder = ["signedSupport","edgeSource","edgeAmplitude","kappaBoundary","burdenTelemetry","independentBurden","intasetAdapter","intasetSourceLift","intasetM1M2","intasetAcquisition","intasetGenerator","intasetRouting","windingLift","packetExchange","c37Winding","breathingBurden","externalMassAudit","xiHbar","nativeAction","beIntertwiner","c37Nine","boundarySelector","c37Evolution","lehighSourceScorer","cordobaFreshScorer","lehighTankComparator","lehighLeakGate","lehighExecutionHarness","googleQecReplication","cmuHouseReplay","releaseAuthority","idleResponseLineage","tdglEngineeredC4","fourJunctionAction","qpb1BlindHardware","qpb1ClassASource","classAModal","symplecticNormalization","dynamicalIntertwiner","amplitudeMetric","actionLineage","asar1Source","asar1RawZenodo","asar1ClassicalResidue","genesisEventCount","gh1Poisson","gh2Local","boundaryManifold","boundaryReconstruction","a10Spectral","v03Distribution","gap5OrderStat","nonautonomousCovariance","sigma7Segmentation","phiTemporal","kappa4Joint","nonlocalKappa4","genesisActionClock","pairingAlignment","latentCrossing","bgFiniteHistory","bilinearBg","binaryTriadic","binaryDynamic","a2Replay","pairingBgGate","c3Custody","c2Contrast","primitiveC2","openC2","hardGateDryRun","faceGatePath","yaleFollowup","facetFrame","facetCurvature","localizedEvent","derivedLocality","sourceSelector","globalC3Harmonic","edgeAnisotropy","cycleAnisotropy","quadraticClassification","nrf1Refinement","anisotropyOrdering","kappaBsDualLane","nonlinearHva1","c1FormationBench","c4GluingRepair","c4GeneralTransfer","c4CanonRemoval","boundaryPachnerC4","pachnerLaunchEconomy","latentSeatScheduler","contextRecursivePachner","geometricPachnerArrow","openConnectedPachner","c5ContextLattice","c5AdmissionFirstHit","retainedTrigger","irreversibleReturn","terminalPhases","thresholdDestinations","hardTerminal","gateMetricSoft","hodgeSoft","hodgeMetricReview","dfRedteam","identityMetricV02","identityFormation","identityStability","identityPerturbations","predictiveRecovery","predictiveCompleteness","q109Completeness","q109Compiler","omega0RecPachner","omega0ReceiptAction","retainedBondParity","hexacycleModels","tetrahedralRingBoundary","retainedZ2Phases","oddFormationBoundary","addressAtomicCarrier","faceReceiptBoundary","endpointFaceMap","pairFaceLineage","faceChiralityBoundary","a4v4Acquisition","retainedEdgeAcquisition","retainedEdgeHandoff","seamCrossCoupling","magicAngleComparison","facePairingIntertwiner","continuousCoframe","dynamicPairingNull","observationKappaRepair","signedHistorySufficiency","varianceChiralityHistory","energySourceBranch","energyWindingScorer","rfSquidBaselineStress","totalHeatComparison"];

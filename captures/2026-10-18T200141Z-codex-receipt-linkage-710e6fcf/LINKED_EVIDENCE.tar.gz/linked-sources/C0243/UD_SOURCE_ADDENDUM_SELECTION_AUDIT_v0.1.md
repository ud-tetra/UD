# UD source addendum: incidence, metric, and source-selection audit

Date: 2026-09-23. Requested by Benjamin Walker Mayes; constructed by the assistant.

**Development — no registry entry. Physical promotion: 0. Independent review: not performed.**

Change type: structural scope clarification and exact selection obstruction. This addendum preserves the prior operator and source artifacts. It introduces no adopted coefficient, source distribution, or variational principle.

## Outcome

The audit separates three questions that cannot be answered by the same condition:

| Commitment | Exact consequence |
|---|---|
| Retain the original unit incidence entries in the declared basis, with the original Euclidean metric | Within the tested family, only h=1 reproduces the native operator |
| Treat h as a coordinate rescaling and transport the metric and source consistently | Every h>0 describes the original dynamics in different coordinates; no new exchange is generated |
| Change the incidence weights while keeping the Euclidean metric fixed | A genuinely different conditional operator family results; the weaker admissibility conditions do not select h |
| Require positivity, normalization, original stationarity, and carrier symmetry of the source | The source remains nonunique, including within strictly positive moments |

The original branch is therefore already identifiable as h=1 by source fidelity. This is not a newly derived dynamical coupling. No nontrivial h≠1 has been selected. The earlier statement that h remains unselected concerns the extended conditional family; this addendum makes the retained native branch explicit.

## 1. Native incidence gives an exact h=1 boundary

Retain the real Euclidean 23-chain of face-glued tetrahedra 0123 and 0124, the pinned orientation and simplex basis, and A=d−dᵀ. The degree-raising d has entries zero or ±1. The conditional family is

\[
d_h=S_h dS_h^{-1},\qquad A_h=d_h-d_h^T,
\]

where S_h scales the coordinates of edges 01,02,12 by h>0 and leaves the other coordinates unchanged.

The exact incidence audit finds 47 nonzero raising entries:

| Entry class | Count | Ratio to original entry |
|---|---:|---:|
| Shared-edge rows from vertex columns | 6 | h |
| Face rows from shared-edge columns | 9 | 1/h |
| Remaining incidences | 32 | 1 |

Thus retaining every original unit incidence magnitude forces h=1. Independently, the full operator defect satisfies

\[
\boxed{\|A_h-A\|_F^2=
12(h-1)^2+18(h^{-1}-1)^2
=\frac{6(h-1)^2(2h^2+3)}{h^2}.}
\]

For positive h this vanishes exactly at h=1. The result is a consistency condition within the declared family and basis, not a proof that all conceivable operator extensions are excluded.

By contrast, the exact chain identity d_h²=0, Euclidean skewness of A_h, all twelve carrier symmetries, harmonic preservation, and preservation of the original Laplacian sectors hold for every h>0 in this family. These weaker properties admit a continuum of h values. Passing them cannot select a nontrivial member.

## 2. A coordinate change transports the adjoint

Let a coordinate change be z_h=S_h z. The original inner product becomes

\[
G_h=S_h^{-T}S_h^{-1}.
\]

The adjoint must then be taken with this metric:

\[
d_h^{\dagger_{G_h}}=G_h^{-1}d_h^TG_h
=S_h d^T S_h^{-1}.
\]

Consequently the coordinate-transformed generator is

\[
\boxed{B_h=d_h-d_h^{\dagger_{G_h}}
=S_hAS_h^{-1}.}
\]

It satisfies B_hᵀG_h+G_hB_h=0 and is similar to the original A. Its spectrum and dynamics are unchanged under the coordinate correspondence. In particular, tr(−B_h²)=94 for every positive h.

This differs from keeping the metric equal to I while constructing A_h=d_h−d_hᵀ. The exact distinction is

\[
\|A_h-B_h\|_F^2=15(h-h^{-1})^2,
\qquad
\|B_h+B_h^T\|_F^2=30(h-h^{-1})^2.
\]

For h>0 these defects vanish only at h=1. Similarity of d_h and d alone does not imply that A_h and A represent the same fixed-metric dynamics. Reusing an ordinary transpose after a nonorthogonal coordinate change changes the adjoint being used.

The source and observation must also be transported:

\[
M_h=S_hMS_h^T,\qquad X_h=XS_h^{-1}.
\]

Then tr(G_hM_h)=tr(M), and

\[
X_he^{B_ht}M_he^{B_h^Tt}X_h^T
=Xe^{At}Me^{A^Tt}X^T.
\]

For this particular vertex-supported local map, XS_h⁻¹=X, so even its displayed matrix is unchanged. The replay verifies the intertwining identities, metric norm, transported stationarity, and local observation equality. The exponential identity follows for all t from B_h=S_hAS_h⁻¹; the executable also checks amplitude-derivative rows through order three.

These are two distinct, well-typed uses of the same diagonal scaling. The coordinate-only use cannot supply a new physical effect or an h selector. The fixed-metric modification remains a conditional extension requiring its own source justification.

## 3. Normalized, strictly positive prepared sources are not unique

Let the original preparation be the retained twelve-element group average followed by the original stationary average. Its real symmetric image has dimension thirteen. This audit checks the rank of the retained basis and the rank-one trace constraint; completeness of that basis remains a dependency of the prior source audit.

The trace-one prepared space therefore has affine dimension twelve. Since I₂₃/23 is positive definite, positivity leaves a relative open neighborhood in that affine space. Positivity and trace normalization do not collapse it to a point.

Two explicit prepared, trace-one sources are

\[
M_0=I_{23}/23,\qquad
M_1=\frac12M_0+\frac18Er,
\]

where Er is the original rank-four perpendicular projector. Both are invariant under all carrier symmetries, stationary under A, and bounded below by I₂₃/46. Their original receipts differ:

\[
(p,q,r)_0=\left(\frac3{184},\frac5{184},\frac1{23}\right),
\qquad
(p,q,r)_1=\left(\frac3{368},\frac5{368},\frac{27}{184}\right).
\]

Hence these source conditions do not even select a unique native h=1 local readout.

## 4. Equal stocks still leave dynamically relevant correlation freedom

There is a stronger ambiguity that retains the complete old stock receipt. Let

\[
v_\pm=e_{\{0\}}\pm e_{\{0,1\}},\quad
\widehat M_\pm=\mathcal P(v_\pm v_\pm^T/2),\quad
M_\pm=\frac12\left(I_{23}/23+\widehat M_\pm\right),
\]

where the basis vectors refer to the pinned vertex and oriented edge coordinates, and P is the original preparation map. These are explicit witnesses; their mixing weights are construction controls, not adopted source coefficients.

Both M± are prepared, have trace one, and satisfy M±≥I₂₃/46. They have identical ordered stocks

\[
(P0,Ep,H3,Eq,Er,H5)=
\left(\frac{33}{460},\frac1{23},\frac3{23},
\frac{53}{690},\frac{122}{345},\frac{149}{460}\right)
\]

and the same receipt

\[
(p,q,r)=\left(\frac3{368},\frac{53}{2208},\frac{61}{690}\right).
\]

Nevertheless, under the fixed-Euclidean-metric A_h family, their initial actual perpendicular variance rates are

\[
\boxed{a'_{\perp,\pm}(0)=\pm\frac{h-1}{20},}
\]

while their old occupancy rates are

\[
w'_\pm(0)=\pm\frac{(h-1)^2}{10h}.
\]

At the h=2 test control, the actual rates are +1/20 and −1/20. Thus source ambiguity is not an artifact of singular matrices, an unknown total, or differing old block stocks. Signed correlations remain unresolved. At h=1 these rates vanish, but the underlying source moments are still distinct.

Under the coordinate-only B_h construction, the transported moments S_hM±S_hᵀ remain stationary in the transported metric and reproduce the original readout. This also checks the distinction in Section 2 on concrete positive sources.

## 5. Parameter-free optimization still adds a law

A possible extra rule is to minimize the Euclidean operator norm. The native incidence counts give

\[
F(h)=\|A_h\|_F^2=12h^2+18h^{-2}+64.
\]

Its exact square decomposition is

\[
F(h)=64+12\sqrt6+
12\left(h-\frac{\sqrt{3/2}}h\right)^2.
\]

The unique positive minimizer would be h=(3/2)^(1/4), not h=1. In fact F′(1)=−12. This is an exact consequence **if** that objective is added. No retained source law in this audited chain supplies that objective, so the minimizer is not adopted or promoted as a UD coefficient.

Likewise, minimizing source purity would select M=I₂₃/23 because, for real symmetric trace-one M,

\[
\operatorname{tr}(M^2)-\frac1{23}
=\|M-I_{23}/23\|_F^2\ge0.
\]

The identity is obtained by expanding the square and using tr(M)=1. It proves uniqueness under the additional minimization rule; it does not derive that rule from the twelve carrier symmetries or stationary preparation. Replacing uncertainty with isotropy would add a source assumption.

Both examples are retained as unadopted selector controls. Having no adjustable numerical parameter is insufficient to establish that an objective or source law follows from the substrate.

## 6. Verification, custody, and remaining gate

The exact replay passes the incidence-count and defect identities; all-h chain, skew, sector, harmonic and symmetry checks; transported-adjoint and metric identities; readout intertwiners; four strictly positive source witnesses; the equal-stock opposite-rate pair; prepared-basis and trace ranks; and the two unadopted optimization identities.

Run with SymPy 1.14.0 from the unpacked archive:

```bash
python ud_selection_audit_replay_v0_1.py --output-dir replay-output
```

The archive includes the pinned matrices, replay, output receipts, typed provenance, selector contract, this report, governance records, prior end-to-end archive, and a checksum manifest. Hashes establish byte integrity, not proof or independent review.

The native-branch result is a scope clarification, not a retrospective selection of a nontrivial h in the earlier exploratory family. Prior artifacts are preserved. The publication anchor remains previously verified site version 86, commit `4cd4dc146f42350e75c8465598a35e9c14ee327b`; no new live-site check or publication is claimed. The unavailable `Gap2_FINAL_Finite_Genesis.png` supplies no evidence. The v0.39 ledger is treated as historical provenance, and the CRL proposal's safeguards are applied without changing its publication status.

The next justified development target is an explicit source-generation or selection law, with its action, boundary conditions, or forcing provenance stated before solving it. A proposed nontrivial h selector must also state why the original fixed-basis unit-incidence commitment is being extended. The supplied selector contract records these obligations without choosing their answers.

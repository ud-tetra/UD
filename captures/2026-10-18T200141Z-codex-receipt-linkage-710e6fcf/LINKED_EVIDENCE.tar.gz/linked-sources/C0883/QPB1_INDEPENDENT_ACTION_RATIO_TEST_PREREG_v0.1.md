# QPB-1 Independent Action-Ratio Test Preregistration v0.1

**Status:** `FROZEN PRETARGET TEST LOGIC / NO PHYSICAL A0 DATA YET`

Frozen prediction:

\[
\boxed{\eta_{\mathcal A}^{\rm QPB1}=\mathcal A_0/\hbar=2.}
\]

A lawful future test requires an independently constructed physical \(\mathcal A_0\) that did not use \(\hbar\), \(h\), Planck units, a known action target, or fitting to the value 2.

After the independent action anchor is frozen, compute

\[
\eta_{\mathcal A}^{\rm obs}=\mathcal A_0^{\rm indep}/\hbar.
\]

Use source-derived uncertainty only.

Verdicts:

- `QPB1_PASS_SCOPED`: the preregistered comparison admits the frozen value 2;
- `QPB1_FAIL`: a resolved independent interval excludes 2;
- `SOURCE_INDETERMINATE`: the action anchor is not sufficiently resolved;
- `SOURCE_INVALID`: the action anchor used forbidden action-target information.

A PASS would support only this action-phase unit correspondence on the tested bridge domain. Physical promotion remains 0.

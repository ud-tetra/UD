---
title: "Chain amplitudes, geometric support, and weighted receipts"
subtitle: "UD development note: an explicit interface contract"
date: "2026-09-30 (UTC)"
author: "Prepared with AI assistance for Benjamin Walker Mayes"
---

# 1. Result and status

The current finite-chain papers already specify what their amplitudes mean mathematically: real coefficients in an orthonormal oriented-simplex basis. They do not identify those coefficients with geometric densities, integrated fields, or electrical measurements. Shape alone does not supply that interpretation.

This note proves a compatibility constraint and gives a conditional extension of the observation contract. **Keeping the existing generator and a diagonal, additive, conserved support forces equal weights on each connected Hasse component.** A shape-sensitive diagonal support therefore requires a changed generator if it is to remain conserved. For a declared fixed positive diagonal weight matrix, the corresponding local current and positive-ray receipt can be written exactly.

Status: internal mathematical development; elementary algebra, no independent novelty claim, no independent human review. No canonical geometric weighting is selected. No physical promotion, spacetime metric, time unit, bench result, or retriangulation equivalence is asserted. The frozen LC acquisition and scoring contracts are unaffected.

# 2. Baseline and notation

Let \(K\) be a finite oriented simplicial complex, using nonaugmented real chains. Stack its simplex coordinates by degree into \(c\). Let \(B\) be the total degree-lowering boundary matrix, so \(B^2=0\). For a codimension-one incidence \(\sigma\subset\eta\), \(B_{\sigma\eta}=\pm1\). The existing source uses the dimensionless evolution parameter \(s\) and
\[
\dot c=A_0c,\qquad A_0=B^T-B,\qquad S_0=c^Tc.
\]
Its per-simplex stocks and signed incidence currents are
\[
q^0_\sigma=c_\sigma^2,\qquad
J^0_{\sigma\eta}=2B_{\sigma\eta}c_\sigma c_\eta.
\]
A positive current transfers stock from the lower-degree coordinate to the upper-degree coordinate. This is an algebraic convention, not a physical identification.

The Hasse graph has one vertex per simplex coordinate and an undirected edge per nonzero boundary entry. Connectedness below refers to this graph, not the graph of currently nonzero amplitudes. The latter can have more components when amplitudes vanish.

# 3. Fixed-source diagonal-support theorem

**Proposition 1.** Let \(H=\operatorname{diag}(h_\sigma)\) be fixed, with \(h_\sigma>0\). Then \(S_H=c^THc\) is conserved by \(\dot c=A_0c\) for every initial state if and only if \(h_\sigma=h_\eta\) on every Hasse incidence. Consequently, \(H\) is a positive scalar multiple of the identity on each connected Hasse component. Fixing a reference weight to one in each component gives \(H=I\).

*Proof.* Conservation for every initial state is equivalent to
\[
A_0^TH+HA_0=0.
\]
Indeed the derivative is the associated symmetric quadratic form, whose vanishing for all real vectors implies the symmetric matrix is zero. Since \(A_0^T=-A_0\), the matrix is \(HA_0-A_0H\). Its \((\sigma,\eta)\) entry is
\[
(h_\sigma-h_\eta)(A_0)_{\sigma\eta}.
\]
Every incidence has nonzero \((A_0)_{\sigma\eta}\); nonincidences impose no condition. Equality propagates along paths. Conversely, constant weights on components commute with \(A_0\). \(\square\)

This theorem does not force regular tetrahedra. It says that an unchanged incidence-only generator cannot conserve arbitrary relative geometric reweightings of its existing independent stocks. A common overall weight may still depend on externally fixed geometry; it contributes no relative shape weighting within a component.

**Scope check: non-diagonal metrics are not excluded.** Put \(\mathcal L=-A_0^2=A_0^TA_0\). Then \(H_\times=I+\mathcal L\) is positive definite and commutes with \(A_0\), hence is conserved by the same generator. For a filled tetrahedron it has nonzero off-diagonal entries. Such a quadratic form has cross terms and does not retain the original independent stocks \(h_\sigma c_\sigma^2\). Proposition 1 is not a uniqueness theorem for all conserved quadratic forms.

# 4. Declared weighted dynamics and local continuity

For a fixed positive diagonal \(H\), retain the same boundary matrix and define its weighted adjoint and a candidate generator:
\[
B^{\dagger_H}=H^{-1}B^TH,\qquad A_H=B^{\dagger_H}-B.
\]
Then \(A_H^TH+HA_H=0\). Set
\[
q_\sigma=h_\sigma c_\sigma^2,\qquad
S_H=\sum_\sigma q_\sigma,\qquad
\boxed{J^H_{\sigma\eta}=2B_{\sigma\eta}h_\sigma c_\sigma c_\eta.}
\]
The weight in this expression belongs to the **lower-degree simplex**.

**Proposition 2.** Under \(\dot c=A_Hc\),
\[
\dot q_\sigma=
\sum_{\xi:\,\xi\subset\sigma}J^H_{\xi\sigma}
-\sum_{\eta:\,\sigma\subset\eta}J^H_{\sigma\eta},
\]
where both sums are over codimension-one incidences.

*Proof.* An upper neighbor contributes \(-B_{\sigma\eta}c_\eta\) to \(\dot c_\sigma\); multiplication by \(2h_\sigma c_\sigma\) gives \(-J^H_{\sigma\eta}\). A lower neighbor contributes \(h_\sigma^{-1}B_{\xi\sigma}h_\xi c_\xi\), giving \(+J^H_{\xi\sigma}\). Summing over coordinates cancels every incidence pair. Summing over a subset cancels internal incidences and gives the corresponding cut balance. \(\square\)

In normalized coordinates \(y=H^{1/2}c\), this is
\[
J^H_{\sigma\eta}=2B_{\sigma\eta}
\sqrt{h_\sigma/h_\eta}\,y_\sigma y_\eta.
\]
The normalized generator \(H^{1/2}A_HH^{-1/2}\) is skew-symmetric, but its incidence coupling magnitudes are \(\sqrt{h_\sigma/h_\eta}\). It is generally not the old unit-coupling generator. Weighted normalization does not make the dynamics unchanged.

# 5. A compatible weighted receipt

Assume \(c\ne0\), the positive weights \(h_\sigma\) are known, and all data refer to the same state. Record
\[
p_\sigma=\frac{h_\sigma c_\sigma^2}{S_H},\qquad
\chi_{\sigma\eta}=\operatorname{sgn}(B_{\sigma\eta}J^H_{\sigma\eta})
\]
on a deterministic spanning forest of the nonzero support graph, plus one root sign per component. Include explicit zero stocks and the simplex, orientation, weight, forest, and normalization conventions.

**Proposition 3.** Propagate signs from the roots along the forest. If the resulting sign at \(\sigma\) is \(\epsilon_\sigma\), then
\[
\widehat y_\sigma=\epsilon_\sigma\sqrt{p_\sigma}
=\frac{\sqrt{h_\sigma}c_\sigma}{\sqrt{S_H}},\qquad
\boxed{\widehat c_\sigma=\epsilon_\sigma\sqrt{p_\sigma/h_\sigma}
=\frac{c_\sigma}{\sqrt{S_H}}.}
\]
Zeros reconstruct as zero. This recovers the positive ray; absolute amplitude additionally requires \(S_H\).

*Proof.* Positive weights do not change the relative sign: \(\chi_{\sigma\eta}=\operatorname{sgn}(c_\sigma c_\eta)\). Tree induction therefore recovers coefficient signs. The recorded stocks give the displayed squared magnitudes. \(\square\)

A root sign is required for each connected nonzero support component, including isolated nonzero coordinates. Neither a zero state nor an uncertain forest-current sign can be normalized into a valid exact receipt.

The exact current consistency test becomes
\[
\boxed{(J^H_{\sigma\eta})^2
=4\frac{h_\sigma}{h_\eta}q_\sigma q_\eta,}\qquad
\left(\frac{J^H_{\sigma\eta}}{S_H}\right)^2
=4\frac{h_\sigma}{h_\eta}p_\sigma p_\eta.
\]
Signs must still have product one around every cycle of the nonzero support graph. Given positive stocks, compatible signs, root signs, and known weights, reconstruction realizes currents with these magnitudes and signs. At zero endpoints the current must be zero. The legacy unit-weight test cannot be retained unchanged where endpoint weights differ and both stocks are nonzero.

These formulas are a conditional extension of the existing PSR contract, not evidence of a measured device. The weight matrix is supplied metadata; no inverse problem establishing its recovery from observations is solved here. One could instead report rescaled currents \(\widetilde J_{\sigma\eta}=\sqrt{h_\eta/h_\sigma}J^H_{\sigma\eta}\), which satisfy the legacy product identity for \(y\). Those rescaled quantities are not the currents in the local continuity law above.

# 6. Explicit nonregular counterexample

Use the previous disphenoid family
\[
p_0=(1,1,r),\quad p_1=(1,-1,-r),\quad
p_2=(-1,1,-r),\quad p_3=(-1,-1,r).
\]
At \(r=2\), the previous squared-volume-ratio candidate (Rule A) gives \(h_0=1\), \(h_{01}=5/2\). Set \(c_0=2\), \(c_{01}=-3\), all other coordinates zero, with \(B_{0,01}=-1\). Then
\[
q_0=4,\quad q_{01}=45/2,\quad S_H=53/2,\quad J^H_{0,01}=12.
\]
The correct squared current is \(144\), while the legacy expression \(4q_0q_{01}\) gives \(360\). Multiplication by \(h_0/h_{01}=2/5\) restores \(144\). Under the old generator \(A_0\), this same weighted support has instantaneous derivative \(18\); under \(A_H\), its derivative is zero.

This is an exact algebraic witness that geometry-dependent weights cannot simply be inserted into the old support and receipt formulas.

# 7. What an amplitude interpretation would add

The existing source definition is complete for its abstract algebra. A geometric interpretation is additional structure. Three distinct contracts should be distinguished:

| Interpretation of a coefficient | Declared norm | Geometric implication |
|---|---|---|
| Existing abstract chain amplitude | \(\sum c_\sigma^2\) | Unit weights; dihedral angles can accompany the state as geometry metadata |
| Constant scalar density on a cell of measure \(V\) | \(\int\rho^2\,dV=\rho^2V\) | Relative weight \(V/V_{\rm ref}\) after reference normalization |
| Integrated scalar quantity \(Q=\rho V\) on that cell | \(\int\rho^2\,dV=Q^2/V\) | Relative weight \(V_{\rm ref}/V\) after reference normalization |

The last two rows are conditional derivations for constant scalar densities, with separately chosen reference units for each interpretation. They do not establish a norm for all simplex degrees at once. Mixing dimensions requires explicit reference measures and amplitude units. In particular, the two squared-volume candidates in the previous interface note are not selected by either scalar-density calculation.

For differential forms, simplex integrals are cochain degrees of freedom. A Whitney reconstruction \(\omega=\sum_i a_iW_i\) has
\[
\|\omega\|_{L^2}^2=a^TMa,\qquad M_{ij}=\langle W_i,W_j\rangle_{L^2}.
\]
Overlapping basis forms generally produce off-diagonal terms. An inverse-volume diagonal rule is not automatically the Whitney mass matrix. This chain/cochain distinction is standard in finite element exterior calculus [3]; adopting that route requires a specified interpolation and inner product, beyond the present diagonal-stock contract.

# 8. Consequence for dihedral-angle research

The prior shape audit showed that the disphenoid's two interior-dihedral cosine classes determine its dimensionless shape parameter \(r^2\), but not its scale. That information is already a legitimate geometric observable. It does not by itself select a meaning for chain amplitudes or a transport law.

The next well-defined modelling decision is therefore an **amplitude-to-geometry contract**: state the represented quantity, its units or reference normalization, its interpolation if applicable, the conserved quadratic form, and the resulting observable currents. This note supplies the exact checks for a diagonal contract. Until such a contract is adopted, preserve the existing orthonormal-amplitude model and report shape observables separately.

If geometry varies with \(s\), the fixed-weight proof no longer suffices:
\[
\frac{d}{ds}(c^TH(s)c)=c^T\dot H(s)c
\]
when the instantaneous generator is \(A_{H(s)}\). An additional transport or exchange law would be needed to remove or interpret this term. No such law is chosen here. The parameter \(s\) remains dimensionless and is not identified with a sink-reversal count or an LC period.

# 9. Verification and provenance

`verify_receipts.py` uses only Python's standard library and rational arithmetic. It builds the oriented filled tetrahedron directly, checks the 28-incidence constraint matrix has rank 14, and verifies a non-diagonal conserved-form counterexample. It evaluates both previous geometric rules at \(r=1/2,1,3/2,2,3\), with dense, sparse incident-pair, and disconnected-support states. The script checks weighted skew-adjointness, per-coordinate continuity, global balance, reconstruction of squared magnitudes and signs, forest sizes, weighted current consistency, the explicit legacy-contract failure, and zero-state rejection.

Result: **218 exact constructor checks pass**, including ten shape/rule cases and three support patterns per case. Finite checks are regression evidence; the propositions above supply the general algebraic arguments. These checks are not exhaustive state-space verification, independent review, or physical data.

The source snapshots reproduce the local living-repository files consulted during this session, not newly verified publication editions. The previous shape and interface packages remain separate, unchanged development artifacts. The running LaTeX source accompanies this note; no compiled PDF is claimed.

# References

1. Current UD finite-chain source, local living repository `papers/sources/paper-1.md`, especially the finite-chain generator, support, and local-current definitions. Snapshot included as `dependencies/PAPER_I_SOURCE.md`.
2. Current UD positive-ray receipt source, local living repository `papers/sources/paper-2.md`, Sections 2--3. Snapshot included as `dependencies/PAPER_II_SOURCE.md`.
3. D. N. Arnold, R. S. Falk, R. Winther, *Finite element exterior calculus: from Hodge theory to numerical stability*, Bulletin of the American Mathematical Society 47 (2010), 281--354. DOI: 10.1090/S0273-0979-10-01278-4. Author preprint: <https://arxiv.org/abs/0906.4325>. Used for the established cochain/finite-element distinction, not as a novelty attribution for Propositions 1--3.
4. Session development packages `UD_TETRAHEDRAL_SHAPE_AUDIT_v0.1` and `UD_GEOMETRIC_INNER_PRODUCT_INTERFACE_v0.1`. Their archive hashes are recorded in this package's provenance file.

# Theorem — Viable-Lane Index Plus Idle-Response Index v0.1

**Status:** `EXACT DERIVED / CIRCULARITY FIREWALL`  
**Physical promotion:** `0`

For two ordered admissible source/response states, write

\[
q^\pm=\omega^\pm+h^\pm
\]

using the idle-mask decomposition. Because

\[
\theta=1-q,
\]

the Hamming event budget is

\[
\mu_\Theta
=
w_H(\theta^+)-w_H(\theta^-)
=
w_H(q^-)-w_H(q^+).
\]

The exact viable-lane continuation index is

\[
\mu_\omega
=
|\omega^-|-|\omega^+|
=
\operatorname{ind}F_\omega.
\]

Therefore

\[
\boxed{
\mu_\Theta
=
\mu_\omega
+
|h^-|-|h^+|.
}
\]

Define the residual idle-response index

\[
\boxed{
\nu_h=|h^-|-|h^+|.
}
\]

Then

\[
\boxed{
\mu_\Theta=\operatorname{ind}F_\omega+\nu_h.
}
\]

This identity was exhaustively checked over all

\[
125^2=15{,}625=5^6
\]

admissible ordered source/response pairs.

## Saturated-prior corollary

If the previous completed event satisfies the POC-1 saturation condition,

\[
h^-=0,
\]

then

\[
\boxed{
\mu_\Theta
=
\operatorname{ind}F_\omega-|h^+|.
}
\]

Consequently, on this domain,

\[
\mu_\Theta=\operatorname{ind}F_\omega
\]

holds iff

\[
h^+=0.
\]

Thus identifying the viable-lane index with the full \(\Theta\) Hamming budget **already selects the no-idle-open response on the new state**. It cannot be used as an independent proof of POC-1.

This is an append-only circularity firewall: the exact viable-lane index remains valid, but its promotion to the full constitutive event budget requires a separately sourced idle-response law or receipt.

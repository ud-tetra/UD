# Refinement exposes an observable-ordering choice

**Research update · 14 September 2026 · Physical promotion 0**

The two quadratic anisotropy channels now have an exact NRF-1 refinement calculation. Its result depends on when the nonlinear observable is formed. This narrows the unresolved coefficient-selection problem to an observable-ordering law; it does not yet select a unique channel ratio.

## Three orderings, three exact maps

For a parent cycle pseudovector \(z\), aligned child cycle pseudovectors satisfy

\[
\bar z=\frac14\sum_{i=1}^4 z_i=\frac12z.
\]

The equal child weights are fixed by normalized S4-invariance. Writing the quadratic family as \(\alpha\mathcal Q_{31}+\beta\mathcal Q_{22}\), the supplied calculation gives:

| Operation order | Channel map | Effect on a nonzero mixed ratio |
|---|---|---|
| Form each child tensor, then average | \(\operatorname{diag}(5/16,3/16)\) | \(\alpha/\beta\) is multiplied by \(5/3\). |
| Average pseudovectors, then form the tensor | \((1/4)I_2\) | The ratio is unchanged. |
| Apply exact chain retraction, then form the tensor | \(I_2\) | Both channels are unchanged because \(R_1I_1=I\). |

For synchronous self-similar NRF-1 with the first ordering,

\[
\frac{\alpha_n}{\beta_n}=\left(\frac53\right)^n\frac{\alpha_0}{\beta_0}.
\]

Only the two pure channels are fixed rays. This is a finite, ordering-dependent refinement calculation, not a physical renormalization-group law. Covariance across alternative refinement branches remains open.

[Read the NRF-1 theorem and supplied verification](#/doc/nrf1Refinement).

## What differs is retained child covariance

For the canonical traceless dyad \(\mathcal Q\),

\[
\frac14\sum_i\mathcal Q(z_i)-\mathcal Q(\bar z)
=\operatorname{TF}\!\left[\frac14\sum_i(z_i-\bar z)(z_i-\bar z)^{\mathsf T}\right].
\]

The local-first prescription retains the trace-free part of child-scale covariance. Averaging the pseudovector first removes that information before the nonlinear observable is evaluated. In the NRF-1 calculation, the difference is exactly \((\mathcal Q_{31}-\mathcal Q_{22})/16\).

This gives the ordering question concrete mathematical content. Identifying that retained covariance with a physical anisotropy observable still requires a constitutive or measurement bridge.

## What the source audit establishes

The supplied audit finds no existing governed law that forces local anisotropy formation before coarse averaging. Exact support-stock ownership additivity concerns a different object. A historical coarse burden-anisotropy tensor is a candidate construction whose weights and physical interpretation remain downstream; it cannot supply the missing axiom by implication.

**ALO-1 remains a candidate:** anisotropy is a cell-local additive observable formed before normalized top-cell averaging. Under that additional rule, the \(5/16\) and \(3/16\) channel factors apply. Selecting the pure three-dimensional channel would also require the additional nonzero cut–cycle coupling condition described in the theorem; that interaction law has not been derived.

[Read the observable-ordering source audit and governance record](#/doc/anisotropyOrdering).

## The next dependencies

- Derive or independently justify the observable/source/action law that decides local-first versus coarse-carrier-first observation.
- Test covariance across admissible alternative refinement branches.
- Supply any required cut–cycle interaction law and overall normalization separately.
- Keep physical/continuum interpretation gated; neither the ordering nor its coefficients may be chosen to recover a desired gravitational target.

The earlier [two-channel classification](#/doc/quadraticClassification) remains exact. This update refines its open coefficient question without closing it. The [harmonic-context occupancy problem](#/doc/globalC3Harmonic) and the pending real E2 laboratory inputs remain separate, unchanged dependencies.

## Preserved publication record

The two original archives contain **14 members**. All **12 manifest-listed payloads** match their supplied hashes; both manifest files are also retained. Reported mathematical checks and source-audit conclusions are preserved as supplied, rather than independently rerun or re-audited during this site intake.

Packaged manuscript variants **v2.40D** and **v2.40E** remain named branch snapshots alongside the main v2.40 manuscript. Their source locks, freezes, candidate status, and open conditions remain intact. The release collection now contains **84 packages and 1,097 package members**; the base ledger retains 738 objects.

[Download the intake receipt](./source/REFINEMENT_ORDERING_INTAKE_2026-09-14.json) · [Browse releases](#/releases)

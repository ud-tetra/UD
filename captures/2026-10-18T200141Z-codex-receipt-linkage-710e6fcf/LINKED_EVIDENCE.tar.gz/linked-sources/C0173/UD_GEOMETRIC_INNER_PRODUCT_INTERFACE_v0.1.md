---
title: 'A Geometry-Dependent Chain Inner Product: Compatibility and Nonuniqueness'
author: 'Benjamin Walker Mayes — assistant-assisted development note'
date: '29 September 2026 (America/Chicago); 30 September UTC'
---

## Disposition

Development — no registry entry. Two explicit candidate assignments are constructed to test sufficiency of geometric and algebraic requirements. Neither is selected as canonical UD dynamics. No coefficient, frozen benchmark, event-time convention, or physical claim is changed. Physical promotion 0. Proofs are elementary finite-dimensional algebra, with constructor verification and no claim of mathematical novelty or independent review.

**Main result.** Positive geometric weights, correct adjoints, boundary compatibility, relabeling covariance, conservation and recovery of the regular baseline do not uniquely select a shape-sensitive operator. Two assignments meet these requirements and give different dimensionless mode ratios at the same tetrahedron. This establishes underdetermination by those requirements, not impossibility of a further source-derived selection.

## 1. Fixed definitions and type discipline

Use the preceding audit's family

\[
p_0=(1,1,r),\ p_1=(1,-1,-r),\
p_2=(-1,1,-r),\ p_3=(-1,-1,r),\quad r>0,
\]

with q=r². The coordinate r describes an assigned, fixed shape. It is not an evolution parameter or a fitted theory coefficient. Increasing vertex order defines the simplex bases of the filled tetrahedron, with dimensions (4,6,4,1). B_k:C_k→C_(k-1) is the usual oriented boundary. These matrices are held fixed throughout.

A positive-definite matrix H_k defines an inner product on **chain-coordinate vectors**:

\[
\langle x,y\rangle_{H_k}=x^T H_k y.
\]

Its Riesz map sends a vector to the covector H_k x; H_k^{-1} reverses that map in the declared bases. This is a finite inner-product operation, not raising/lowering spacetime indices or a metric inferred from a pentachoron array. If dual cochain coordinates are used, the induced dual metric is H_k^{-1}; importing a cochain mass matrix as H_k without specifying that identification is not justified.

## 2. A compatible operator for any fixed positive H

The boundary adjoint is uniquely determined once H is given:

\[
B_k^{\dagger}=H_k^{-1}B_k^T H_{k-1}.
\]

Proof: x^T H_k B_k† y=(B_k x)^T H_(k-1)y for all x,y. Positivity makes H_k invertible. Importantly, uniqueness of the adjoint does not imply uniqueness of H.

Let B be the full degree-lowering boundary on the direct sum and H the block-diagonal matrix of the H_k. Define

\[
A_H=B^{\dagger}-B,\qquad D_H=B+B^{\dagger},\qquad
L_H=BB^{\dagger}+B^{\dagger}B.
\]

Since B²=0, (B†)²=0. Therefore

\[
-A_H^2=D_H^2=L_H,\qquad
A_H^T H+HA_H=0.
\]

For a fixed geometry and the declared dimensionless flow dc/ds=A_H c,

\[
\frac{d}{ds}(c^T Hc)=0.
\]

The conserved quantity is S_H=c^T Hc. It replaces the old coordinate quadratic form within this candidate branch; the claim is not that c^T c remains conserved at arbitrary H. Also

\[
\langle c,L_Hc\rangle_H=\|Bc\|_H^2+\|B^{\dagger}c\|_H^2\ge0.
\]

The k-th block is B_k†B_k+B_(k+1)B_(k+1)†, with absent endpoint terms omitted. The Euclidean-coordinate transform z=H^(1/2)c gives a real skew generator H^(1/2)A_H H^(-1/2); the Laplacian is similar to a symmetric positive-semidefinite matrix. Thus its eigenvalues are real and nonnegative. These properties hold for all fixed positive-definite choices, rather than selecting one.

## 3. Two exact geometric assignments

For a k-simplex sigma with k≥1, form its edge Gram matrix G_sigma using the k edges from any one vertex. Its determinant equals (k!)² times its squared Euclidean k-volume and is independent of the chosen base vertex. For the regular reference with squared edge length 8, these determinants are 8,48,256 for k=1,2,3. Define a dimensionless ratio

\[
R_\sigma=\frac{\det G_\sigma}{\det G_{\mathrm{regular},k}}.
\]

The assumed Euclidean coordinate geometry and reference scale are input. Neither is derived from incidence. On a nondegenerate simplex R_sigma>0; for rational coordinates it is rational. Both assignments below are invariant under rigid motions and transform covariantly under relabeling of the geometry and chain bases.

- **Rule A (Gram ratio):** H_0=I, with (H_k)_(sigma,sigma)=R_sigma.
- **Rule B (squared Gram ratio):** H_0=I, with (H_k)_(sigma,sigma)=R_sigma².

All off-diagonal entries are zero. These are candidate diagonal chain metrics justified as algebraically admissible, volume-derived assignments. Neither has been derived as the physically appropriate energy, norm, discrete L² product or continuum approximation. Rule B is a counterexample to uniqueness, not an adjustable exponent to fit data. No interpolation between the two is proposed.

For compact derivations write p=1 for Rule A and p=2 for Rule B only. Put

\[
a=\left(\frac{1+q}{2}\right)^p,\quad
b=\left(\frac{2q+1}{3}\right)^p,\quad c=q^p.
\]

In edge order (01,02,03,12,13,23),

\[
H_0=I_4,\quad H_1=\operatorname{diag}(a,a,1,1,a,a),\quad
H_2=bI_4,\quad H_3=(c).
\]

Both are positive for every r>0 and recover H_k=I at r=1. This is an exact regular-limit recovery of the existing chain generator, not merely recovery up to an unreported overall scale.

Global dilation is not eliminated by angles. With the reference held fixed, uniformly scaling the coordinates by t changes H_k by t^(2kp) and the Laplacian blocks by t^(-2p). Simultaneously rescaling both actual and reference coordinates leaves the ratios unchanged. These rules require explicit reference/scale discipline; dihedral angles alone cannot select an absolute frequency scale.

## 4. Complete spectra on this family

The vertex block is the weighted K4 graph Laplacian

\[
L_0=B_1 H_1^{-1}B_1^T.
\]

The two opposite edges 03,12 have weight 1; the other four have weight 1/a. Direct multiplication by the uniform vector and the three sign vectors of the tetrahedral coordinates gives

\[
\operatorname{spec}L_0=\{0,u,v,v\},\qquad
u=4/a,\quad v=2+2/a.
\]

For the higher blocks define

\[
x=4a/b,\qquad y=2(a+1)/b,\qquad z=4b/c.
\]

Then

\[
\begin{aligned}
\operatorname{spec}L_1&=\{u,v,v,x,y,y\},\\
\operatorname{spec}L_2&=\{x,y,y,z\},\\
\operatorname{spec}L_3&=\{z\}.
\end{aligned}
\]

Proof: B_2†B_2=(1/b)B_2^T H_1B_2 on the four face coordinates. Conjugating by the diagonal signs of B_3 turns B_2^T H_1B_2 into the dual K4 Laplacian with two opposite edge weights 1 and four weights a. Its three positive eigenvalues are 4a,2(a+1),2(a+1); its kernel is the B_3 direction. B_3B_3† contributes 4b/c on this kernel and vanishes on its orthogonal complement because H_2 is scalar. The exact and coexact edge subspaces im B_1† and im B_2 are H_1-orthogonal by B_1B_2=0; each has dimension three. Equality of nonzero spectra of the corresponding AB and BA products supplies the two edge triples. This proves the displayed spectra for all r>0, not only replayed samples.

The full 15-coordinate spectrum has one zero and two copies of each entry in {u,v,v,x,y,y,z}. Consequently the skew-generator characteristic polynomial is

\[
\lambda(\lambda^2+u)(\lambda^2+v)^2
(\lambda^2+x)(\lambda^2+y)^2(\lambda^2+z).
\]

At r=1, all seven positive factors equal 4, recovering lambda(lambda²+4)^7. For fixed H these eigenvalues give squared oscillation rates relative to the declared dimensionless s only; no SI seconds or SER ticks enter.

## 5. Exact counterexample to unique selection

At the same stretched tetrahedron r=2:

| Object | Rule A | Rule B |
|---|---|---|
| a | 5/2 | 25/4 |
| b | 3 | 9 |
| c | 4 | 16 |
| Positive vertex spectrum | 8/5,14/5,14/5 | 16/25,58/25,58/25 |
| v/u | 7/4 | 29/8 |
| Remaining positive factor x | 10/3 | 25/9 |
| Remaining double factor y | 7/3 | 29/18 |
| Remaining single factor z | 3 | 9/4 |

Since v/u differs, an overall scale cannot turn one vertex spectrum into the other. Both rules satisfy positive definiteness, geometry-derived rational entries, rigid-motion invariance, relabeling covariance, correct adjoints, chain compatibility, a conserved norm, and exact regular-baseline recovery. Those conditions therefore do not determine the operator uniquely.

There is also an important basis-change control. Given any degree-preserving invertible S, rewriting the original model with H=S^T S, B_new=S^(-1)B_old S and A_new=S^(-1)A_old S preserves its original spectrum. That is a coordinate change. In Rules A/B the standard incidence matrices B are held fixed while the adjoints change, so the new spectra describe different candidate operators, not a rediscovery caused solely by rescaling coordinates.

## 6. What remains unresolved

**Source selection:** specify what chain coefficients mean and what quadratic quantity the physical or mathematical model is intended to conserve. Derive a geometric norm or energy from that interpretation. Algebraic consistency alone is insufficient. Circumcentric DEC and Whitney-form constructions are distinct established approaches and require their own primal/dual, chain/cochain and normalization choices; these Gram-ratio candidates are not claimed to reproduce either construction.

**Gluing:** using one reference convention, a shared geometric simplex gives the same local determinant ratio from either incident tetrahedron if its edge geometry agrees. This is a local compatibility observation, not a proof of global geometric realization, invariance under subdivision, or Pachner equivalence. Independent cellwise choices of r cannot be glued arbitrarily.

**Changing shape:** the conservation proof assumes H is fixed. If r=r(s), then the unmodified equation gives

\[
\frac{d}{ds}(c^T H(s)c)=c^T\dot H(s)c,
\]

which is generally nonzero. Geometry evolution needs an additional source law and a corresponding work/transport account. Choosing r(s) or silently adding a connection term is not authorized by the fixed-shape proof. No shape dynamics has been constructed here.

**Time:** dimensionless oscillation rates of this candidate flow do not define laboratory duration, a spacetime metric, or a map from SER commits to seconds. The original frozen LC sqrt(5/3) ratio and Stage 0 protocol are unchanged.

## 7. Reproduction and provenance

The standard-library Python replay constructs determinant ratios directly from coordinates, boundary matrices directly from simplex lists, weighted adjoints, all four Laplacian blocks and the full generator. It checks positive weights, adjoint and chain identities, exact eigenspace nullities, conservation, regular-limit recovery and the non-rescalable counterexample. The report supplies the general proofs; finite tests do not establish an all-geometry theorem.

The preceding exact shape audit is retained as a dependency. The construction and self-checks here are assistant-performed, not independent review. Coefficient values, claim bins, the event-time manuscript, website and LC bench are not modified by this package. The unavailable Gap2_FINAL_Finite_Genesis.png was not used. Physical promotion remains 0.

Background literature: Desbrun, Hirani, Leok and Marsden, *Discrete Exterior Calculus*, arXiv:math/0508341, <https://arxiv.org/abs/math/0508341>; Hirani's research overview, <https://hirani.github.io/research.html>. Public abstract/search excerpts were inspected for positioning; no equation-level attribution to an unread body is made. The adjoint and compatibility statements above are proved directly. Neither reference is cited as the source of Rules A/B or as evidence selecting them.

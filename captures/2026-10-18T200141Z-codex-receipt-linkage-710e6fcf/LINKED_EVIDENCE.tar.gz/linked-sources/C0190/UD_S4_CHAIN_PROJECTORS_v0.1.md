---
title: "Exact S4 projectors on the filled tetrahedron"
subtitle: "Representation multiplicity versus the canonical unit-weight frequency"
date: "2026-09-29 (America/Chicago)"
author: "Prepared with AI assistance for Benjamin Walker Mayes"
---

# 1. Scope and objects

This note classifies the signed permutation action of \(S_4\) on the real nonaugmented chains of the filled tetrahedron \(\Delta^3\). It gives exact rational projectors and separates symmetry-enforced multiplicity from the equal frequencies of the canonical boundary generator. This is a finite mathematical classification, with no independent novelty claim, new dynamics selection, or physical interpretation. It neither changes the PSR freeze nor advances the LC queue.

Order the oriented simplex basis by degree, then lexicographically:
\[
(0,1,2,3;\ 01,02,03,12,13,23;\ 012,013,023,123;\ 0123).
\]
Orient every simplex by its increasing vertex order. The boundary is \(B_k:C_k\to C_{k-1}\); write \(D=B_1+B_2+B_3\) for its total block matrix, and
\[
A=D^T-D,\qquad L=-A^2=DD^T+D^TD.
\]
The inner product makes this simplex basis orthonormal. For \(g\in S_4\), the matrix \(R(g)\) permutes simplex labels and multiplies each column by the sign required to reorder its image increasingly. These orientation signs are essential. The matrices satisfy
\[
R(g)^TR(g)=I,\qquad DR(g)=R(g)D.
\]

# 2. Exact character decomposition

Let \(V\) be the standard three-dimensional representation and \(\varepsilon\) the sign representation. Denote \(V\otimes\varepsilon\) by \(V^\varepsilon\). The permutation representation on four vertices is \(\mathbf1\oplus V\); oriented \(k\)-simplices carry its \((k+1)\)-st exterior power. Therefore
\[
C_0=\mathbf1\oplus V,\quad C_1=V\oplus V^\varepsilon,
\quad C_2=V^\varepsilon\oplus\varepsilon,\quad C_3=\varepsilon.
\]
The following characters independently verify the decomposition. Class sizes are \(1,6,3,8,6\).

| Character | \(1\) | \((12)\) | \((12)(34)\) | \((123)\) | \((1234)\) |
|---|---:|---:|---:|---:|---:|
| \(\mathbf1\) | 1 | 1 | 1 | 1 | 1 |
| \(V\) | 3 | 1 | -1 | 0 | -1 |
| \(V^\varepsilon\) | 3 | -1 | -1 | 0 | 1 |
| \(\varepsilon\) | 1 | -1 | 1 | 1 | -1 |
| Unused two-dimensional irrep \(W\) | 2 | 0 | 2 | -1 | 0 |
| \(C_0\) | 4 | 2 | 0 | 1 | 0 |
| \(C_1\) | 6 | 0 | -2 | 0 | 0 |
| \(C_2\) | 4 | -2 | 0 | 1 | 0 |
| \(C_3\) | 1 | -1 | 1 | 1 | -1 |

The weighted class inner product, divided by \(24\), gives multiplicity one for each displayed constituent and zero for the others. On the full chain space,
\[
C_\bullet\cong\mathbf1\oplus2V\oplus2V^\varepsilon\oplus2\varepsilon.
\]
Here “2” counts copies; it is distinct from the irreducible dimension three or one.

# 3. Exact equivariant projectors

For an irreducible character \(\chi\) of dimension \(d_\chi\), the central projector is
\[
P_\chi=\frac{d_\chi}{24}\sum_{g\in S_4}\chi(g^{-1})R(g).
\]
All entries are rational. For this action the two-dimensional projector is zero. With \(J_4\) the all-ones matrix, the four nonzero projectors have the explicit degree-block formulas
\[
P_{\mathbf1}=\operatorname{diag}(J_4/4,0_6,0_4,0_1),
\]
\[
P_V=\operatorname{diag}(I_4-J_4/4,\ B_1^TB_1/4,\ 0_4,0_1),
\]
\[
P_{V^\varepsilon}=\operatorname{diag}(0_4,\ B_2B_2^T/4,\ B_2^TB_2/4,\ 0_1),
\]
\[
P_\varepsilon=\operatorname{diag}(0_4,0_6,\ B_3B_3^T/4,\ 1).
\]
They have ranks \(1,6,6,2\), respectively, and satisfy
\[
P_\chi^T=P_\chi,\quad P_\chi^2=P_\chi,\quad
P_\chi P_\psi=0\ (\chi\ne\psi),\quad
\sum P_\chi=I,\quad [P_\chi,R(g)]=[P_\chi,A]=0.
\]
The archive supplies each full \(15\times15\) matrix. These are isotypic projectors: \(P_V\), for example, selects both copies of \(V\). To select its copy in one chain degree, multiply by that degree's coordinate projector. Degree restriction alone need not commute with \(A\).

# 4. Multiplicity and unit-weight spectrum

| Chain degree | Representation | Copies in this degree | Dimension of each irrep | Canonical \(L\) eigenvalue |
|---|---|---:|---:|---:|
| \(C_0\) | \(\mathbf1\) | 1 | 1 | 0 |
| \(C_0\) | \(V\) | 1 | 3 | 4 |
| \(C_1\) | \(V\) | 1 | 3 | 4 |
| \(C_1\) | \(V^\varepsilon\) | 1 | 3 | 4 |
| \(C_2\) | \(V^\varepsilon\) | 1 | 3 | 4 |
| \(C_2\) | \(\varepsilon\) | 1 | 1 | 4 |
| \(C_3\) | \(\varepsilon\) | 1 | 1 | 4 |

For the specified generator,
\[
A^2=-4(I-P_{\mathbf1}),\quad
\operatorname{spec}L=\{0^{[1]},4^{[14]}\},\quad
\chi_A(\lambda)=\lambda(\lambda^2+4)^7.
\]
Each positive imaginary eigenvalue \(+2i\) has multiplicity seven: three contributions from the \(V\) pair, three from the \(V^\varepsilon\) pair, and one from the sign pair. Negative eigenvalues are their conjugates. The number seven is not a seven-dimensional irreducible representation of \(S_4\).

# 5. Which equalities are forced by symmetry?

Let \(A_k\) be the full \(15\times15\) skew matrix with blocks \(-B_k\) from degree \(k\) to \(k-1\) and \(B_k^T\) in the reverse direction, zero elsewhere. Then \(A=A_1+A_2+A_3\), and
\[
A_1^2=-4P_V,\quad A_2^2=-4P_{V^\varepsilon},\quad
A_3^2=-4P_\varepsilon,\qquad A_iA_j=0\quad(i\ne j).
\]

**Classification.** Every real skew-symmetric \(S_4\)-equivariant endomorphism of this full chain space has the form
\[
A(a,b,c)=aA_1+bA_2+cA_3,\qquad a,b,c\in\mathbb R.
\]

*Proof.* The four appearing irreducible types are absolutely irreducible real representations. Equivariant maps cannot mix inequivalent types. On the single trivial copy, a skew scalar is zero. On each of the other isotypic components there are two equivalent copies, so the equivariant commutant acts on a two-dimensional multiplicity space. Its skew part is one-dimensional. The three nonzero, mutually supported equivariant matrices \(A_k\) span those three skew lines. This gives the complete classification, not just a list of examples. \(\square\)

Consequently,
\[
A(a,b,c)^2=-4(a^2P_V+b^2P_{V^\varepsilon}+c^2P_\varepsilon),
\]
\[
\boxed{\chi_{A(a,b,c)}(\lambda)=
\lambda(\lambda^2+4a^2)^3(\lambda^2+4b^2)^3(\lambda^2+4c^2).}
\]
Zero coefficients give additional zero modes; the formula includes that case. Symmetry enforces the threefold multiplicity within each three-dimensional type. It does not force \(|a|=|b|=|c|\). The canonical choice \(a=b=c=1\) comes from the declared signed boundary and its unit-weight adjoint. **The unit inner product alone does not select that generator.**

As an exact counterexample to symmetry forcing a single active frequency, \((a,b,c)=(1,2,3)\) remains equivariant and skew under the same unit metric, but has positive squared frequencies \(4,16,36\). These are classification variables and a mathematical witness, not newly adopted UD couplings or fit parameters. No alternative generator is selected.

# 6. Verification and status

`verify_exact.py` constructs all 24 signed permutation matrices, checks boundary equivariance and orthogonality, evaluates the rational character sums, and verifies symmetry, idempotence, pairwise orthogonality, completeness, ranks, and equivariance of the projectors. It also checks the boundary-block formulas, cross-product zeros, and the unequal-frequency witness. Basis order is fixed above and in `MATRIX_CATALOG.json`.

This note is the second item in the requested mathematical order. It preserves the existing generator, PSR freeze, and experimental queue. The companion PSR addendum and Smith note address separate finite objects. No independent review or physical promotion is claimed.

# UD Constitutive Receipt-Index Event Operator v0.1

**Status:** `PASS_SCOPED / EXACT_CONDITIONAL CONSTITUTIVE OPERATOR DERIVED`  
**Physical promotion:** `0`

## 1. Source state

The current finite source chain already supplies:

1. exact frame alignment from a source-complete oriented \(C_1\) transport receipt;
2. a receipt-complete Hamming-budget law
   \[
   \mu_{\Theta,n}=\operatorname{ind}F_n;
   \]
3. pre-event pair-integrity receipts \(T_{p,n}^{\rm pair}\);
4. pre-event quadratic burden weights \(W_{p,n}^{B2}\);
5. an integrity-constrained target-shell optimizer.

The prior signed-support polarity lane remains conditional on one irreducible aligned-versus-anti-aligned sign axiom. It is therefore not used as the primary constitutive source when a receipt-index source packet is available.

## 2. Continuation-map cancellation theorem

Let

\[
F_n:\mathcal L_n^-\to\mathcal L_n^+
\]

be any finite-dimensional continuation map between the already-declared viable pre-event and receipt-constructed viable output-obligation spaces.

Write

\[
d_n^-:=\dim\mathcal L_n^-,
\qquad
d_n^+:=\dim\mathcal L_n^+,
\qquad
r_n:=\operatorname{rank}F_n.
\]

Rank-nullity gives

\[
\dim\ker F_n=d_n^--r_n,
\]

and

\[
\dim\operatorname{coker}F_n=d_n^+-r_n.
\]

Therefore

\[
\boxed{
\operatorname{ind}F_n
=
\dim\ker F_n-\dim\operatorname{coker}F_n
=
d_n^- - d_n^+.
}
\]

### Consequence

The **net Hamming budget** does not require predecessor matching or the explicit continuation map once the two finite obligation spaces are independently and target-blindly constructed:

\[
\boxed{
\mu_{\Theta,n}
=
d_n^- - d_n^+.
}
\]

The continuation map remains necessary for:

- separate \(N_{\rm sink}\) and \(N_{\rm add}\);
- gross lineage turnover;
- predecessor identity;
- source versus renewal provenance;
- overlap/merger provenance.

Thus:

\[
\boxed{
\text{net event polarity/multiplicity}
\neq
\text{full lineage provenance}.
}
\]

This is a source-gate reduction, not an endpoint reconstruction.

## 3. Minimal net-budget source packet

For net event polarity/multiplicity, the minimal admissible source packet is:

1. the frame-aligned current \(\Theta\) state
   \[
   \bar\theta_n^-;
   \]
2. a target-hidden, source-complete construction of the finite viable input-obligation space
   \[
   \mathcal L_n^-;
   \]
3. a target-hidden, source-complete construction of the finite viable output-obligation space
   \[
   \mathcal L_n^+;
   \]
4. pair-integrity receipts
   \[
   T_{p,n}^{\rm pair};
   \]
5. pre-event quadratic burden histories
   \[
   W_{p,n}^{B2}.
   \]

No observed endpoint \(\theta_n^+\) is admissible.

No terminal residual is admissible.

No signed-support alignment axiom is required in this receipt-complete lane.

## 4. Net polarity and multiplicity theorem

Define

\[
\boxed{
\mu_{\Theta,n}
=
d_n^- - d_n^+.
}
\]

Then the target Hamming count is

\[
\boxed{
k_n^+
=
w_H(\bar\theta_n^-)
+
\mu_{\Theta,n}.
}
\]

A source packet is carrier-admissible only when

\[
\boxed{
0\le k_n^+\le3.
}
\]

Since

\[
D_{\rm cl}(\theta)=6-2w_H(\theta),
\]

the predicted closure-capacity change is

\[
\boxed{
\Delta D_{{\rm cl},n}
=
-2\mu_{\Theta,n}.
}
\]

Hence:

- \(\mu_{\Theta,n}>0\): net closure;
- \(\mu_{\Theta,n}<0\): net reopening;
- \(\mu_{\Theta,n}=0\): fixed-Hamming exchange or hold.

This polarity follows from the receipt-index orientation already present in the source law; no signed-support polarity axiom is used.

## 5. Exact three-pair address selector

For pair-integrity receipts \(T_p\in\{0,1\}\), define

\[
\mathcal A_k(T)
=
\left\{
\theta\in\Theta:
w_H(\theta)=k,\ 
(1-\theta_p)(1-T_p)=0\ \forall p
\right\}.
\]

Let

\[
W=(W_A,W_B,W_C)
\]

be the source-derived quadratic burden weights.

Define

\[
\boxed{
\Theta_{\rm opt}
=
\operatorname*{arg\,min}_{\theta\in\mathcal A_k(T)}
\sum_p\theta_pW_p.
}
\]

For the three-pair carrier this has the following closed form.

### \(k=0\)

The only candidate is

\[
000.
\]

It is admissible iff

\[
T_A=T_B=T_C=1.
\]

### \(k=3\)

The only candidate is

\[
111.
\]

It is always integrity-admissible under the declared open-pair integrity rule.

### \(k=1\)

Exactly one pair is closed.

A candidate closed pair \(p\) is admissible iff the other two pairs pass integrity. Among admissible candidates choose the unique minimum \(W_p\).

### \(k=2\)

Exactly one pair is open.

The open pair must pass integrity. Since minimizing the closed burden sum is equivalent to maximizing the burden left open, choose the unique maximum \(W_p\) among integrity-passing open-pair candidates.

If the admissible set is empty, return `CONSTITUTIVE_INFEASIBLE`.

If the optimum is tied, return `HOLD_UNRESOLVED_SYMMETRY`.

No arbitrary tie-break is admitted.

## 6. Constitutive Receipt-Index Event Operator

When the exact relative-frame gate has supplied \(r_n\), define

\[
\bar\theta_n^-
=
P_{\pi_{\mathcal M}(r_n)}\theta_n^-.
\]

The source-complete constitutive operator is the partial map

\[
\boxed{
\mathcal E_n^{\rm RI}:
\left(
\bar\theta_n^-,
\mathcal L_n^-,
\mathcal L_n^+,
T_n,
W_n^{B2}
\right)
\longmapsto
\theta_n^+
}
\]

with the sequence

\[
d^- - d^+
\to
\mu_\Theta
\to
k^+
\to
\mathcal A_{k^+}(T)
\to
\Theta_{\rm opt}.
\]

If the optimizer is a singleton,

\[
\theta_n^+
\]

is predicted without endpoint access.

Then define

\[
c_{\Theta,n}
=
(1-\bar\theta_n^-)\odot\theta_n^+,
\]

\[
o_{\Theta,n}
=
\bar\theta_n^-\odot(1-\theta_n^+),
\]

and

\[
a_n
=
c_{\Theta,n}\oplus o_{\Theta,n}.
\]

These obey the exact identities

\[
\boxed{
|c_{\Theta,n}|-|o_{\Theta,n}|
=
\mu_{\Theta,n},
}
\]

and

\[
\boxed{
|c_{\Theta,n}|+|o_{\Theta,n}|
=
w_H(a_n).
}
\]

Therefore the operator predicts both:

- **net multiplicity** \( \mu_\Theta \);
- **gross pair-toggle multiplicity** \( w_H(a_n) \);

as well as the directed close/reopen addresses when the optimizer is unique.

Finally,

\[
\boxed{
U_n^\Theta
=
X(a_n)\Gamma_\Theta(\pi_{\mathcal M}(r_n))
}
\]

follows exactly from the already-locked affine receipt representation.

## 7. Source hierarchy repair

The source-completeness requirements split into two levels.

### NET-BUDGET SOURCE GATE

Required:

- independent viable input-obligation space;
- independent viable output-obligation space;
- target-hidden construction of both spaces.

Not required:

- predecessor bijection;
- explicit continuation matrix.

This gate is sufficient for

\[
\mu_\Theta.
\]

### LINEAGE-PROVENANCE SOURCE GATE

Additionally required:

- predecessor relations;
- continuation map;
- source/sink/renewal type;
- duplicate/merger equivalence;
- overlap provenance.

This stronger gate is required for gross lineage interpretation.

Therefore the earlier rule requiring the full continuation map before **any** Hamming-budget output was stricter than mathematically necessary.

## 8. Signed-support lane disposition

The one-seat sign candidate

\[
\mu_\Theta^{\rm sign}
=
-\operatorname{sgn}G_\Sigma^{S\pm}
\]

remains useful only as an independent consistency diagnostic when a receipt-index packet exists.

The equality

\[
\boxed{
\mu_\Theta^{\rm RI}
=
\mu_\Theta^{\rm sign}
}
\]

is a falsifiable comparison.

It is not imposed.

A disagreement does not permit the sign lane to overwrite the receipt-index source.

## 9. Remaining constitutive gap

This result closes the constitutive **operator** on the source-complete receipt domain.

It does not derive the source receipts themselves from the closed \(K_4\)/Hodge carrier.

The remaining upstream question is now:

\[
\boxed{
\text{What native pre-event mechanism constructs }
\mathcal L_n^-
\text{ and }
\mathcal L_n^+
\text{?}
}
\]

That is narrower than the previous statement that event polarity/multiplicity as a whole remained unspecified.

## 10. Claim status

- continuation-map cancellation: `EXACT_INTERNAL`;
- net receipt-index budget: `EXACT_CONDITIONAL SOURCE LAW`;
- polarity/capacity relation: `EXACT_CONDITIONAL`;
- three-pair address selector: `EXACT_CONDITIONAL`;
- full \(\mathcal E_n^{\rm RI}\): `EXACT_CONDITIONAL / COMPUTED CONSTITUTIVE OPERATOR`;
- signed-support lane: `SECONDARY CONDITIONAL DIAGNOSTIC`;
- primitive source of obligation-space receipts: `OPEN`;
- physical promotion: `0`.

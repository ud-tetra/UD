---
title: "Carrier symmetry and the full versus skew commutant"
date: "2026-09-29 (America/Chicago)"
author: "Prepared with AI assistance for Benjamin Walker Mayes"
---

# Accepted scope

This append-only clarification accompanies the existing [S4 projector note](#/doc/s29S4). It preserves the original package and selected operator. The useful shared method is: name the actual carrier and its group action, decompose the state space, classify equivariant operators, and separate enforced degeneracies from additional operator and inner-product choices. No Lie-group embedding or particle assignment is proposed.

# Full commutant and its adjoint decomposition

For the signed real action on the nonaugmented chains of the filled tetrahedron, with the simplex basis orthonormal,
\[
C_\bullet\cong\mathbf1\oplus V^{\oplus2}\oplus(V\otimes\varepsilon)^{\oplus2}\oplus\varepsilon^{\oplus2}.
\]
All four appearing irreducible types are of real type. Equivariant maps act on their multiplicity spaces, giving
\[
\operatorname{End}_{S_4}(C_\bullet)\cong\mathbb R\oplus M_2(\mathbb R)\oplus M_2(\mathbb R)\oplus M_2(\mathbb R).
\]
Consequently its real dimension is \(1+4+4+4=13\). With the unit inner product, the self-adjoint part has dimension \(1+3+3+3=10\), and the skew-adjoint part has dimension \(0+1+1+1=3\). The latter is exactly
\[
A(a,b,c)=aA_1+bA_2+cA_3.
\]
The skew-adjoint part is a vector subspace (and a Lie algebra under commutator), not the entire associative commutant algebra. The identity is a simple symmetric equivariant map outside it.

An explicit full basis follows from the existing matrices. Let \(Q_{k-1}\) project to chain degree \(k-1\), and let \(P_k\) be respectively \(P_V,P_{V\otimes\varepsilon},P_\varepsilon\). For each \(k=1,2,3\), take
\[
Q_{k-1}P_k,\quad (I-Q_{k-1})P_k,\quad Q_{k-1}A_k-A_kQ_{k-1},\quad A_k.
\]
The first three are symmetric and the fourth skew. Together with \(P_{\mathbf1}\), these thirteen independent equivariant matrices attain the full commutant dimension. Independently, the character formula gives \(24^{-1}\sum_{g\in S_4}\operatorname{tr}(R(g))^2=13\).

# What symmetry fixes

| Declared structure | Consequence |
|---|---|
| Signed S4 representation and equivariance | Maps respect the four isotypic components; action inside each irreducible factor repeats across its dimension |
| Unit-metric skew-adjointness | A(a,b,c); eigenvalue pairs at frequencies 2|a|, 2|b|, 2|c|, with multiplicities 3, 3, 1 when nonzero |
| Specified boundary D and generator A = D transpose minus D with H = I | a = b = c = 1 and the common active frequency 2 |

The unit inner product alone does not choose the boundary generator. Zero coefficients yield extra zero modes. The three classification variables are not fitted couplings and no alternative generator is selected. These statements concern the filled tetrahedron; they do not transfer unchanged to the K-minus carrier or the SER incidence star.

# GUT analogy: terminology only

The accepted comparison is to fifteen matter components arranged as \(\mathbf{10}\oplus\overline{\mathbf5}\) in SU(5). This is not a decomposition of the irreducible \(\mathbf{15}\), which is the symmetric rank-two representation. See the [grand-unification chapter](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/025B1D32C9D0584E8D2EC0D59C753B82/9781009290920c6_106-115.pdf/grand-unification.pdf) and the explicit symmetric-15 usage in [Awasthi, Choubey and Mitra, arXiv:1009.0509](https://arxiv.org/abs/1009.0509). Only the representation-theory discipline is shared; this note asserts no physical correspondence.

# Exact check and stopping point

[Verification script](./source/session-math-2026-09-29/verify_commutant.py) and [exact results](./source/session-math-2026-09-29/COMMUTANT_AUDIT_RESULTS.json) construct the thirteen matrices from the unchanged package, check their adjoint types and commutation with all 24 signed actions, and verify dimensions 13, 10 and 3 over the rationals. Run the script beside the original package directory with Python and SymPy. These are constructor checks, not independent peer review.

The symmetry clarification is complete at this scope. The LC ratio is unchanged. Stage 0 remains UNSCORED: the next physical input is the three labeled frequencies in hertz under the existing acquisition and estimator-provenance requirements. Physical promotion remains 0. No clock, metric, Lie embedding, particle assignment, Rule A/B selection, or jump law follows from this clarification.

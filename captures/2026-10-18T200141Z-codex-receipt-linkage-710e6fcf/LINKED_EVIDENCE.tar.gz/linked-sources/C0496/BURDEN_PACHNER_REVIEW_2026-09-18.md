# Tagged Load, Response Capacity and Pachner Spectral Change

Supporting mathematical review · 18 September 2026

The new developments make two parts of UD more explicit: how a recorded load redistributes on a finite graph, and how the support operator changes when a local triangulation is replaced. The strongest results are exact matrix identities, conservation and dissipation statements, and a demand-weighted response ratio. They do not yet select when a retriangulation occurs, how a state crosses that event, or how much load a physical carrier can store.

This review incorporates the completed 71-file batch and two earlier files referenced by its manifests. It distinguishes the current definitions from earlier proposals retained in the source record. Papers I and II remain frozen; this is a supporting development note.

**Reading route:** [Theorem paper](#/doc/manuscript) → [previous persistence review](#/doc/frontierPullbackReview) → the present note → [preserved sources and reproduction package](#/doc/burdenPachnerReview?section=sources-and-reproduction).

## 1. Two state spaces, two evolution laws

Let \(K\) be a finite oriented tetrahedral simplicial complex, with oriented boundary matrices \(B_k:C_k\to C_{k-1}\). Its real chain state is \(c\in\bigoplus_{k=0}^3 C_k\). The adjacent-degree skew matrix \(\mathcal A_K\) has upper blocks \(B_k\) and lower blocks \(-B_k^\top\). The standard identities

\[
B_1B_2=B_2B_3=0,\qquad \mathcal A_K^\top=-\mathcal A_K
\]

give conservation of the Euclidean chain norm under \(\dot c=\mathcal A_Kc\).

A separate vertex field \(b\), called *burden* in the source, records a transported load. With a declared diagonal gate matrix \(H\), \(0\preceq H\preceq I\), the Q162 model is

\[
j_B=-\tfrac14 HB_1^\top b,\qquad
\dot b=-R_Bb+s_B,\qquad R_B=\tfrac14 B_1HB_1^\top.
\]

Here \(R_B\) is symmetric positive semidefinite and \(\mathbf1^\top R_B=0\). Closed, source-free diffusion conserves total load. For a fixed connected open-edge graph it relaxes to the mean. Connectivity at isolated times alone is insufficient for that asymptotic conclusion under changing gates.

These are distinct models: the chain evolution is norm-preserving, while the load evolution is dissipative. Their parameters are internal evolution coordinates. Neither equation identifies a physical time or a measured energy.

## 2. Provenance resolves inherited load when tags are supplied

Write \(b=\sum_a b^{(a)}\), where each tag records a source event. For a fixed graph and the same prescribed gate history, every component satisfies

\[
\dot b^{(a)}=-R_Bb^{(a)}+s_B^{(a)}.
\]

Summing recovers the aggregate equation. For a cell \(D\) with birth event \(t_D\), one declared inherited-load convention is

\[
I_D=\sum_{a:t_a<t_D}\sum_{i\in D}b_i^{(a)}.
\]

This quantity is exactly computable from the tagged state. Tags add information; they cannot recover an unrecorded ancestry retrospectively from aggregate totals. The optional restriction to tags present at birth must be specified because it changes the observable.

On a fixed interval with constant \(R_B\), each component has the usual matrix-exponential solution with a source integral. Predicting it requires the initial tagged field, gates and source terms. Linearity applies with a shared prescribed operator; independently changing the gates for each component would not justify superposition.

A daughter sharing three old vertices inherits a *restriction* of the tagged field to those vertices, assuming a new apex initially carries no old tag. This local trace overlaps the parent's stock. Summing such traces over cells double-counts shared vertices unless an ownership partition is supplied.

## 3. Clock normalization is part of the model

On \(K_4\), \(B_1B_1^\top=4P_\perp\). The source's two fixed normalizations produce rates \(1\) and \(4/3\) on the zero-sum sector. For matched initial data, their trajectories coincide under

\[
s_{\mathrm{slot}}=\tfrac43s_{\mathrm{neighbor}}.
\]

This is an exact reparameterization on the matched model. It does not identify distinct observables solely because their rates can be rescaled.

For the two tetrahedra \(0123\) and \(0124\), Q162 has spectrum

\[
\{0,3/4,5/4,5/4,5/4\}.
\]

An irregular neighbor normalization requires an additional choice. Arithmetic, geometric and harmonic means of the endpoint inverse degrees all respect endpoint symmetry and agree on regular graphs. On a degree-4 to degree-3 edge they give \(7/24\), \(1/(2\sqrt3)\), and \(2/7\), respectively. Conservation does not select among them. Affine endpoint additivity would select the arithmetic mean, but that is an extra axiom.

For the two-cell graph, with weight \(1/4\) on the shared triangle and weight \(w\) on each apex edge, the exact Laplacian spectrum simplifies to

\[
\{0,3w,5w,3/4+2w,3/4+2w\}.
\]

This supplies a readable replacement for the unsimplified radical expression in the geometric-clock table. A single scalar time conversion exists exactly when the chosen edge weights are proportional on the active simple graph. Irregularity alone is not a universal obstruction: for example, a biregular graph can give the same endpoint-degree pair on every edge.

## 4. Memory measures retained contrast

The later source definition replaces the earlier autocorrelation proposal with normalized squared contrast:

\[
M^{(a)}(s)=\frac{\|x^{(a)}(s)\|^2}{\|x^{(a)}(s_0)\|^2},
\qquad x^{(a)}=P_\perp b^{(a)}.
\]

For a fixed vertex space, a fixed compatible projector and source-free evolution \(\dot x=-R_B(s)x\),

\[
\dot M=-\frac{2x^\top R_B(s)x}{\|x(s_0)\|^2}\le0.
\]

The generators need not commute. A nonzero eigenmode of rate \(\lambda\) gives \(M=e^{-2\lambda(s-s_0)}\). The earlier autocorrelation diagnostic gives \(e^{-\lambda(s-s_0)}\); these should not be interchanged. Setting \(M=0\) for zero reference contrast is a declared convention.

**The monotonicity statement needs its full domain.** A global mean-removing projector works for time-varying graph Laplacians on a fixed vertex set. A projector that changes as components split contributes additional terms. A sub-block exchanging load with its surroundings need not have decreasing contrast. On a three-vertex path with \(\dot b=-Lb\) and \(b=(4,1,0)^\top\), the squared contrast within the last two vertices has derivative \(+1\), although global squared contrast decreases.

Likewise, births, changing dimensions, sinks and a changing tag cohort require explicit interval and transfer rules. An old cohort with normalized power \(0.1\) gains aggregate value \(0.55\) if a new tag with equal reference power and value \(1\) is appended. That is consistent with the definition, but prevents a claim of monotone aggregate memory across births. Tagging new sources does not remove boundary forcing on old tags.

Inherited stock and retained contrast answer different questions. A uniform tagged field may have positive inherited stock and zero contrast memory.

## 5. Response capacity is a defined, testable scalar

For a fixed field and declared graph, let \(q_e=(B_1^\top b)_e^2\). The new response-capacity definition is

\[
V=\frac{\sum_e h_eq_e}{\sum_e q_e},\qquad \sum_e q_e>0.
\]

It compares the instantaneous relaxation quadratic form with the all-open form on the *same* graph and state. Thus \(0\le V\le1\); positive common clock scaling cancels; rescaling the field or adding a constant leaves the ratio unchanged. Opening a gate cannot decrease \(V\) **while the field and denominator remain fixed**. Comparing later trajectories does not satisfy that condition.

The convention \(V=1\) at zero demand is explicit, not a continuous-extension theorem. It means there is no redistribution requirement in this model; it does not establish storage tolerance, survival or physical viability.

For \(b=(3,1,-1,-3)^\top\) on \(K_4\), the six demands are \((4,16,36,4,16,4)\). Opening edges \(01,02,12,23\) gives \(V=28/80=7/20\), whereas the unweighted open-edge fraction is \(2/3\). The distinction is substantive. Equality with an unweighted fraction requires equal positive demands over the same edge set; a boundary-only gate count is not generally a whole-graph ratio.

The mathematical properties are exact consequences of the definition. Calling this particular ratio the historical UD coordinate \(V\) is a supplied semantic choice, not a proof that generic monotonicity conditions select a unique scalar. The earlier product-versus-minimum counterexample remains valid for that broader question.

## 6. Aggregation is exact; reduction of dynamics is a separate problem

Allocate each global edge's demand to its incident cells with nonnegative ownership weights summing to one. Equal shares \(w_{e,\tau}=1/n_3(e)\) are one such choice. Set

\[
D_\tau=\sum_{e\subset\tau}w_{e,\tau}q_e,\qquad
A_\tau=\sum_{e\subset\tau}w_{e,\tau}h_eq_e.
\]

For nonzero global demand,

\[
V_{\mathrm{global}}=
\frac{\sum_\tau D_\tau V_\tau}{\sum_\tau D_\tau}.
\]

The proof is the partition-of-unity identity on every edge. It establishes exact aggregation of a recorded observable, not a closed evolution equation for cell averages or invariance under changing the complex. It also requires every modeled edge to have an owner.

The supplied four-tetrahedron report contains 12 global and 30 cell summaries. Their ratios and owned-demand sums are consistent within rounding. The original initial tagged vectors and executable simulation are absent, so those summaries do not permit an independent replay of the reported trajectory or its stated maximum conservation error. The supplement includes a separate, fully specified four-cell control verifying conservation and aggregation; it is not represented as the original run or as experimental evidence.

## 7. Storage and obstruction remain separate constitutive questions

For nonnegative tagged load, \(B=\mathbf1^\top b\) and \(0\le I\le B\). The inherited fraction \(\iota=I/B\) is scale-free when \(B>0\), with a declared zero-stock convention. A unit-invariant quantity depending only on \((B,V,M,I)\) cannot distinguish absolute load magnitude under \((B,I)\mapsto(\alpha B,\alpha I)\) without another scale. An independently specified reference \(B_\star\) permits \(\beta=B/B_\star\).

That scale still does not select an obstruction function. On nonnegative normalized coordinates \(z=(\beta,1-V,M,\iota)\), the functions \(\sum_i z_i\), \(\sum_i\log(1+z_i)\), and \(\prod_i(1+z_i)-1\) satisfy null and monotonicity conditions while differing numerically. A unit multiplier on an already defined obstruction channel does not choose its internal formula.

Two further qualifications matter. Monotonicity in \(B\) at fixed \(I\) does not automatically become monotonicity in \(\beta\) at fixed \(\iota\); changing coordinates changes what is held constant. A positive-definite quadratic metric also need not yield a coordinatewise monotone obstruction on the positive orthant. For example, the matrix with diagonal entries \(1\) and off-diagonal entries \(-3/4\) is positive definite, but its quadratic form has a negative first partial derivative at \((0,1)\).

For fixed gates, the transformation \(b\mapsto b+k\mathbf1\) leaves currents and contrasts unchanged while increasing stock by \(kN\). If the admissible set permits these positive shifts, it has no universal finite stock ceiling. This is a statement across admissible initial states, not unbounded growth along a closed diffusion trajectory, whose total stock is conserved.

## 8. Quadratic storage provides a representation, not a capacity law

Choose the Euclidean storage functions

\[
H_S(c)=\tfrac12\|c\|^2,\qquad H_B(b)=\tfrac12\|b\|^2.
\]

Then \(\dot H_S=0\) under the skew support equation and

\[
\dot H_B=-b^\top R_Bb+b^\top s_B.
\]

These are standard conservative and dissipative storage identities. The load equation admits this gradient representation, but does not uniquely select the constant-mode storage. With \(P_0=\mathbf1\mathbf1^\top/N\), adding \(\alpha\|P_0b\|^2/2\) to \(H_B\) leaves \(-R_B\nabla H_B\) unchanged. Prescribing \(\nabla H_B=b\) and \(H_B(0)=0\) removes that ambiguity by assumption.

A proposed interconnection \(\left(\begin{smallmatrix}\mathcal A_K&T\\-T^\top&0\end{smallmatrix}\right)\) cancels cross-power in compatible Euclidean pairings. With other metrics, the adjoint and pairings must be changed consistently. This construction requires a specified map \(T\); it does not derive one, conserve each subsystem's norm separately, or identify their physical units.

If an independent law supplies \(H_B\le E_\star\), Cauchy–Schwarz gives

\[
|\mathbf1^\top b|\le\sqrt{2NE_\star}.
\]

The bound is attained by a nonnegative uniform field on the full Euclidean storage ball. Consequently it is the exact capacity of that declared feasible set. Additional constraints may make it an unattainable upper bound. The proposed comparison \(H_B\le H_S\) remains an additional storage-budget assumption; cross-power cancellation does not imply it.

## 9. The 2↔3 move has an exact isolated spectral response

The two triangulations are

\[
K_- =\{0123,0124\},\qquad
K_+ =\{0134,0234,1234\}.
\]

They share boundary triangles \(013,014,023,024,123,124\). The interior face \(012\) is replaced by the edge \(34\) and interior triangles \(034,134,234\). Both are triangulations of the same local ball.

| Exact quantity | Two tetrahedra | Three tetrahedra |
|---|---|---|
| Simplex counts by degree | \((5,9,7,2)\) | \((5,10,9,3)\) |
| Chain dimension | \(23\) | \(27\) |
| Euler characteristic | \(1\) | \(1\) |
| Skew characteristic polynomial | \(\lambda(\lambda^2+3)^4(\lambda^2+5)^7\) | \(\lambda(\lambda^2+2)^2(\lambda^2+5)^{11}\) |
| \(\operatorname{tr}(-\mathcal A^2)\) | \(94\) | \(118\) |
| \(\operatorname{tr}((-\mathcal A^2)^2)\) | \(422\) | \(566\) |

The independent verifier reconstructs all boundary matrices from the tetrahedra, checks each degree-resolved spectrum, and computes both characteristic polynomials exactly. In the 30-dimensional union basis, zero-extension gives update ranks \(18\) for \(\mathcal A_+^\cup-\mathcal A_-^\cup\) and \(19\) for the difference of squared operators. These are isolated-patch values. The 30-dimensional union is the boundary complex of a 4-simplex; including its 4-cell would add another chain coordinate.

Multiplying the three adjacent-degree blocks by positive controls \(a,b,c\) gives the source's weighted characteristic polynomials. Their factorization follows from singular-value pairs and \(B_kB_{k+1}=0\); the replay verifies it symbolically. This is a declared block-weighted control family. The source's inverse-product relation \(a=(g_0g_1)^{-1/2}\), and similarly for the other blocks, is realized by whitening \(G\dot c=\mathcal A c\) to \(G^{-1/2}\mathcal A G^{-1/2}\). It is not automatic from merely assigning chain inner products: the usual adjoint of an unchanged \(B_k\) is \(G_k^{-1}B_k^\top G_{k-1}\). The operator convention must therefore accompany any claim about Hodge metrics.

The spectral moments describe operator changes; they are not event energies. A common boundary does not specify a state-transfer map from 23 to 27 coordinates. Across a move, support conservation needs an explicit transfer rule and norm condition. On a larger mesh, external couplings enter the squared-operator update and the full spectrum must be reconsidered.

## 10. Topological admissibility does not select a dynamical event

Simplicial closure permits three or more tetrahedra on a face. A genuine 3-manifold with boundary has one incident tetrahedron at a boundary triangle and two at an interior triangle. Checking only these triangular links does not certify manifoldness: edge and vertex links also matter. Attaching a tetrahedron with a fresh apex solely along one boundary face exposes three new boundary faces; more general vertex identifications need additional checks.

The source's further inference from face degree two to identical transfer kernels is not established. The boundary-face sequence \(0123,0124,0135\) respects the face-degree cap but changes the old face-Laplacian block. This counterexample remains in the replay. Equal scalar kernels require a justified isolated or invariant dynamical reduction, matched initial conditions and a common event rule.

The next scientific task is therefore to specify the hybrid state \((K,c,b)\), admissible moves, state transfer across each move and a selection law. The exact spectral response supplies information for that task. It does not choose a scalar cost or a trigger. Storage saturation, support–load coupling and obstruction composition are separate missing laws.

## 11. Review claims and proof obligations

| ID | Statement | Status and evidence | Essential condition |
|---|---|---|---|
| BP1 | Chain boundary products vanish | Standard identity; integer replay | Declared orientations |
| BP2 | Skew flow conserves chain norm | Standard lemma | Fixed carrier |
| BP3 | Q162 lifts to \(B_1HB_1^\top/4\) | Exact substitution | Chosen Q162 model |
| BP4 | Tagged equations sum to aggregate flow | Exact linearity | Common operator and complete tags |
| BP5 | Inherited load is computable | Recorded-data definition | Birth convention and tags supplied |
| BP6 | K4 clocks differ by \(4/3\) | Exact reparameterization | Matched state and operator |
| BP7 | Irregular clock is not uniquely selected | Explicit distinct means | Symmetry and regular reduction alone |
| BP8 | Contrast-power memory decreases | Dissipation identity | Closed fixed space and compatible projection |
| BP9 | Open-block memory need not decrease | Exact path counterexample | Boundary exchange allowed |
| BP10 | Response ratio lies in \([0,1]\) | Exact inequality and gate replay | Positive denominator |
| BP11 | Zero-demand value is \(1\) | Definition | Explicit convention |
| BP12 | Owned-demand aggregation is exact | Partition-of-unity proof | All edges accounted for |
| BP13 | Recursive numerical summaries agree | 42 arithmetic checks | Original trajectory not replayable from summaries |
| BP14 | Uniform load is not bounded by gradients | Shift-family counterexample | No magnitude-sensitive admissibility bound |
| BP15 | Obstruction formula is not uniquely selected | Explicit candidate functions | Monotonicity and null alone |
| BP16 | Q162 has quadratic-storage representation | Standard gradient calculation | Euclidean choice |
| BP17 | Storage budget bounds total load | Cauchy–Schwarz; sharp on full ball | Independently supplied budget |
| BP18 | Pachner spectra and local ranks | Exact integer/symbolic replay | Isolated unit-weight patch |
| BP19 | Positive block controls factor spectrally | Singular-value decomposition | Specified weighting convention |
| BP20 | Face cap does not fix transfer dynamics | Exact growing-complex counterexample | Full operator retained |

## 12. Relation to established methods

Discrete exterior calculus already develops operators on simplicial complexes using discrete forms and dual structures; it is background, not a discovery claimed by this note. See Desbrun, Hirani, Leok and Marsden, [*Discrete Exterior Calculus*](https://arxiv.org/abs/math/0508341).

Simplicial Dirac structures and structure-preserving port-Hamiltonian discretizations also have an established literature. See Seslija, van der Schaft and Scherpen, [*Discrete Exterior Geometry Approach to Structure-Preserving Discretization of Distributed-Parameter Port-Hamiltonian Systems*](https://arxiv.org/abs/1111.6403). The correspondence here is a finite storage representation; it does not import that paper's physical model or supply a missing UD interconnection.

The reviewable contribution of this batch is the explicit operator comparison on the declared Pachner pair, together with precise definitions and limits for the transported-load observables. It makes no priority claim for standard Laplacian, semigroup, Rayleigh-quotient or storage arguments. It supplies no continuum-limit theorem or empirical coupling.

## Sources and reproduction

All 71 current files are preserved byte-for-byte, along with two earlier dependencies. All 59 file entries in the 14 supplied manifests match the preserved bytes. Hash agreement establishes file identity, not mathematical correctness.

The independent reproduction package includes exact matrices reconstructed from simplex lists, symbolic spectra, explicit counterexamples, reported-table consistency checks and a separately specified numerical control. It requires Python with NumPy, SciPy and SymPy. Original status labels remain historical source statements; the claim table above states this review's conclusions.

- [Download the complete review supplement](./releases/UD_BURDEN_PACHNER_REVIEW_SUPPLEMENT_2026-09-18.zip)
- [Source inventory and filename mapping](./source/BURDEN_PACHNER_SOURCE_INVENTORY_2026-09-18.json)
- [Independent verification results](./source/BURDEN_PACHNER_VERIFICATION_2026-09-18.json)
- [Independent verification script](./source/burden-pachner/verify-burden-pachner.py)

### Source reading order

<!-- SOURCE_INDEX -->

<details>
<summary>Transport, provenance and clocks</summary>

- [Burden Ancestry Tagging](#/doc/burdenPachnerSource1)
- [Burden Breathing Receipt State](#/doc/burdenPachnerSource8)
- [Burden Breathing State Rebase](#/doc/burdenPachnerSource9)
- [Burden Clock Normalization Reconciliation](#/doc/burdenPachnerSource13)
- [Global Glued Burden Operator Q162](#/doc/burdenPachnerSource33)
- [Irregular Graph Neighbor Clock Audit](#/doc/burdenPachnerSource34)
- [Port Hamiltonian Burden Support Audit](#/doc/burdenPachnerSource57)
- [Reciprocal Neighbor Proposal Clock Adversarial Audit](#/doc/burdenPachnerSource59)
- [Recursive K₄ Inherited Burden Derivation](#/doc/burdenPachnerSource61)

</details>

<details>
<summary>Memory and response capacity</summary>

- [Burden Memory As Semigroup Retention](#/doc/burdenPachnerSource2)
- [Burden Viability As Response Capacity](#/doc/burdenPachnerSource3)
- [Burden Memory Semigroup Adversarial Audit](#/doc/burdenPachnerSource14)
- [Burden Memory Semigroup Retention](#/doc/burdenPachnerSource15)
- [Burden Temporal Memory And Inherited Load Audit](#/doc/burdenPachnerSource22)
- [Burden Variational Viability Audit](#/doc/burdenPachnerSource23)
- [Burden Viability Coordinate Audit](#/doc/burdenPachnerSource25)
- [Burden Viability Scalar Closure Audit](#/doc/burdenPachnerSource26)
- [Recursive Tagged Multik4 Viability Simulation](#/doc/burdenPachnerSource63)
- [Variational Viability Coarse Graining Theorem](#/doc/burdenPachnerSource70)

</details>

<details>
<summary>Storage and composition</summary>

- [Burden Obstruction Functional Uniqueness Audit](#/doc/burdenPachnerSource16)
- [Burden Obstruction Map And Stock Normalization Audit](#/doc/burdenPachnerSource17)
- [Burden State After Viability Closure](#/doc/burdenPachnerSource19)
- [Burden Stock Reference Scale Audit](#/doc/burdenPachnerSource20)
- [Burden Storage Capacity Identifiability Limit And Source Requirement](#/doc/burdenPachnerSource21)
- [Obstruction Composition Principle Audit](#/doc/burdenPachnerSource50)

</details>

<details>
<summary>Topology and Pachner response</summary>

- [Frontier Pseudomanifold Derivation Audit](#/doc/burdenPachnerSource30)
- [Local 3Manifold Link Adversarial Compatibility Audit](#/doc/burdenPachnerSource35)
- [Pachner 2↔3 Hodge Dirac Move Response](#/doc/burdenPachnerSource51)
- [Partner Math Roadmap Analysis](#/doc/burdenPachnerSource54)
- [Recursive Frontier Homogenization Audit](#/doc/burdenPachnerSource60) — earlier dependency

</details>

<details>
<summary>Earlier manuscript addenda</summary>

- [Ancestry Resolved Inherited Burden](#/doc/burdenPachnerSource36)
- [Reference Scale And Obstruction Uniqueness](#/doc/burdenPachnerSource37)
- [Burden Clock And Memory](#/doc/burdenPachnerSource38)
- [Burden Receipt And Homogenization](#/doc/burdenPachnerSource39)
- [Capacity And Composition Frontier](#/doc/burdenPachnerSource40)
- [Obstruction Normalization And Viability Coarse Stability](#/doc/burdenPachnerSource41)
- [Global Burden Operator And State Rebase](#/doc/burdenPachnerSource42)
- [Memory And Irregular Clock](#/doc/burdenPachnerSource43)
- [Pachner Response And Port Hamiltonian Burden](#/doc/burdenPachnerSource44)
- [Temporal Burden And Spatial Manifold Scope](#/doc/burdenPachnerSource45)
- [Variational Burden Viability](#/doc/burdenPachnerSource46)
- [Viability And Clock Admission](#/doc/burdenPachnerSource47)
- [Viability And Manifold Frontier](#/doc/burdenPachnerSource48)

</details>

<details>
<summary>Tables and manifests</summary>

- [Reference Scale And Obstruction Candidate Audit](#/doc/burdenPachnerSource4)
- [Reference Scale And Obstruction Uniqueness](#/doc/burdenPachnerSource5)
- [Burden Ancestry Tagging And Recursive Inherited Load](#/doc/burdenPachnerSource6)
- [Burden Ancestry Tagging Schema](#/doc/burdenPachnerSource7)
- [Burden Capacity And Composition Frontier](#/doc/burdenPachnerSource10)
- [Burden Clock And Memory Comparison](#/doc/burdenPachnerSource11)
- [Burden Clock And Memory](#/doc/burdenPachnerSource12)
- [Burden Receipt And Frontier Homogenization](#/doc/burdenPachnerSource18)
- [Burden Variational Viability Examples](#/doc/burdenPachnerSource24)
- [Capacity And Composition Frontier](#/doc/burdenPachnerSource27)
- [Obstruction Normalization And Viability Coarse Stability](#/doc/burdenPachnerSource28)
- [Frontier Admissibility Comparison](#/doc/burdenPachnerSource29)
- [Geometry Homogenization Rate Examples](#/doc/burdenPachnerSource31) — earlier dependency
- [Global Burden Operator And State Rebase](#/doc/burdenPachnerSource32)
- [Memory And Irregular Clock](#/doc/burdenPachnerSource49)
- [Pachner 2↔3 Move Spectral Telemetry](#/doc/burdenPachnerSource52)
- [Pachner And Port Hamiltonian Frontier](#/doc/burdenPachnerSource53)
- [Partner Math Roadmap Analysis](#/doc/burdenPachnerSource55)
- [Partner Math Roadmap Priority Matrix](#/doc/burdenPachnerSource56)
- [Port Hamiltonian Burden Support Status](#/doc/burdenPachnerSource58)
- [Recursive Tagged Multik4 Cell Viability](#/doc/burdenPachnerSource62)
- [Recursive Tagged Multik4 Viability Sim](#/doc/burdenPachnerSource64)
- [Spatial Manifold Branch Compatibility](#/doc/burdenPachnerSource65)
- [Temporal Burden And Spatial Manifold Scope](#/doc/burdenPachnerSource66)
- [Two K₄ Global Burden Operator Q162](#/doc/burdenPachnerSource67)
- [Two K₄ Irregular Clock Comparison](#/doc/burdenPachnerSource68)
- [Variational Burden Viability](#/doc/burdenPachnerSource69)
- [Viability And Clock Admission](#/doc/burdenPachnerSource71)
- [Viability And Clock Nonuniqueness Examples](#/doc/burdenPachnerSource72)
- [Viability And Manifold Frontier](#/doc/burdenPachnerSource73)

</details>


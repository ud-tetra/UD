# UD_PACHNER_23_HODGE_DIRAC_MOVE_RESPONSE_v0.1

**Date:** 2026-09-18  
**Status:** EXACT INTERNAL MOVE-RESPONSE THEOREM + WEIGHTED-HODGE CONTROL FAMILY  
**Physical promotion:** 0

## 1. Local 2→3 move

Use the common five-vertex ball.

### Two-tetrahedron side \(K_-\)

\[
K_-=\{0123,0124\}.
\]

Its f-vector is

\[
\boxed{f(K_-)=(5,9,7,2)}.
\]

Total chain dimension:

\[
5+9+7+2=23.
\]

The unique internal triangular face is

\[
(012).
\]

### Three-tetrahedron side \(K_+\)

\[
K_+=\{0134,0234,1234\}.
\]

Its f-vector is

\[
\boxed{f(K_+)=(5,10,9,3)}.
\]

Total chain dimension:

\[
5+10+9+3=27.
\]

The new internal edge is

\[
(34),
\]

with internal triangles

\[
(034),(134),(234).
\]

## 2. Common boundary

Both triangulations have exactly the same boundary triangles:

\[
\boxed{(013),(014),(023),(024),(123),(124)}.
\]

Thus the move changes only the interior triangulation.

Euler characteristic is preserved:

\[
5-9+7-2=1,
\]

\[
5-10+9-3=1.
\]

## 3. Skew Hodge–Dirac operator

With oriented boundary matrices

\[
B_1:C_1\to C_0,\quad
B_2:C_2\to C_1,\quad
B_3:C_3\to C_2,
\]

define

\[
\mathcal A_K=
\begin{pmatrix}
0&B_1&0&0\\
-B_1^\top&0&B_2&0\\
0&-B_2^\top&0&B_3\\
0&0&-B_3^\top&0
\end{pmatrix}.
\]

## 4. Exact unit-weight spectra

For \(K_-\),

\[
\boxed{
\chi_-(\lambda)
=
\lambda(\lambda^2+3)^4(\lambda^2+5)^7
}.
\]

Hence

\[
\boxed{
\operatorname{spec}(\mathcal A_-)
=
\left\{
0,
(\pm i\sqrt3)^4,
(\pm i\sqrt5)^7
\right\}.
}
\]

For \(K_+\),

\[
\boxed{
\chi_+(\lambda)
=
\lambda(\lambda^2+2)^2(\lambda^2+5)^{11}
}.
\]

Hence

\[
\boxed{
\operatorname{spec}(\mathcal A_+)
=
\left\{
0,
(\pm i\sqrt2)^2,
(\pm i\sqrt5)^{11}
\right\}.
}
\]

### AUTO_LOCK

`PACHNER_23_UNIT_HODGE_DIRAC_SPECTRAL_RESPONSE_THEOREM_v0.1`

This identifies the previously separate \(23\)- and \(27\)-dimensional support spectra as the two sides of one 2↔3 Pachner move.

## 5. Degree-resolved Hodge Laplacians

With

\[
\Delta_k=(-\mathcal A_K^2)|_{C_k},
\]

the exact spectra are:

### \(K_-\)

\[
\operatorname{spec}\Delta_0=\{0,3,5,5,5\},
\]

\[
\operatorname{spec}\Delta_1=\{3^{\times3},5^{\times6}\},
\]

\[
\operatorname{spec}\Delta_2=\{3^{\times3},5^{\times4}\},
\]

\[
\operatorname{spec}\Delta_3=\{3,5\}.
\]

### \(K_+\)

\[
\operatorname{spec}\Delta_0=\{0,5^{\times4}\},
\]

\[
\operatorname{spec}\Delta_1=\{2,5^{\times9}\},
\]

\[
\operatorname{spec}\Delta_2=\{2^{\times2},5^{\times7}\},
\]

\[
\operatorname{spec}\Delta_3=\{2,5^{\times2}\}.
\]

Thus the move reallocates the nonzero Hodge spectrum across chain degree.

## 6. Exact spectral response

The move removes the unit-weight \(\sqrt3\) family and introduces a \(\sqrt2\) family while increasing the \(\sqrt5\) multiplicity:

\[
(\pm i\sqrt3)^4
\longrightarrow
(\pm i\sqrt2)^2,
\]

\[
(\pm i\sqrt5)^7
\longrightarrow
(\pm i\sqrt5)^{11}.
\]

The quadratic spectral moment changes by

\[
118-94
=
\boxed{24}
=
2^3\cdot3.
\]

The quartic moment changes by

\[
566-422
=
\boxed{144}
=
2^4\cdot3^2.
\]

These are structural diagnostics, not action costs.

### AUTO_FREEZE

`DELTA_TRACE_A2_IS_PHYSICAL_EVENT_ENERGY`.

## 7. Common ambient embedding

The union simplex basis has f-vector

\[
\boxed{(5,10,10,5)}
\]

and total dimension \(30\).

Embedding both local operators into this common basis gives

\[
\Delta\mathcal A
=
\mathcal A_+^\cup-\mathcal A_-^\cup.
\]

Exact isolated-patch rank:

\[
\boxed{
\operatorname{rank}(\Delta\mathcal A)=18.
}
\]

For the squared Hodge operator on the same isolated ambient patch,

\[
\boxed{
\operatorname{rank}
\left[
(-(\mathcal A_+^\cup)^2)-(-(\mathcal A_-^\cup)^2)
\right]
=19.
}
\]

This is a finite-rank local move update on a common chain basis.

## 8. Positive weighted-Hodge control family

Assign positive block weights

\[
a,b,c>0
\]

to the three adjacent-degree incidence blocks:

\[
B_1\mapsto aB_1,\qquad
B_2\mapsto bB_2,\qquad
B_3\mapsto cB_3.
\]

For degree-block Hodge metrics

\[
G_k=g_kI,
\]

the whitened skew operator has

\[
a=(g_0g_1)^{-1/2},
\quad
b=(g_1g_2)^{-1/2},
\quad
c=(g_2g_3)^{-1/2}.
\]

These are **control variables**, not promoted UD coefficients.

For \(K_-\),

\[
\boxed{
\chi_-^{(a,b,c)}(\lambda)
=
\lambda
(\lambda^2+3a^2)
(\lambda^2+5a^2)^3
(\lambda^2+3b^2)^2
(\lambda^2+5b^2)^3
(\lambda^2+3c^2)
(\lambda^2+5c^2)
}.
\]

For \(K_+\),

\[
\boxed{
\chi_+^{(a,b,c)}(\lambda)
=
\lambda
(\lambda^2+5a^2)^4
(\lambda^2+2b^2)
(\lambda^2+5b^2)^5
(\lambda^2+2c^2)
(\lambda^2+5c^2)^2
}.
\]

### AUTO_LOCK

`PACHNER_23_WEIGHTED_HODGE_DIRAC_RESPONSE_THEOREM_v0.1`

The unit case is \(a=b=c=1\).

### AUTO_FREEZE

- interpreting \(a,b,c\) as free UD theory constants;
- fitting \(a,b,c\) to a desired physical spectrum;
- calling the control family a physical metric without a bridge.

## 9. Move-response packet

A source-clean event-response object is now

\[
\boxed{
\mathcal R_{2\to3}
=
\left(
\Delta f,
\Delta\mathcal A,
\Delta\operatorname{spec}_k,
\Delta\operatorname{Tr}(-\mathcal A^2),
\Delta\operatorname{Tr}((-\mathcal A^2)^2)
\right).
}
\]

No scalar move cost is selected here.

That is the correct input for a later launch/selection law.

## 10. Governance

### AUTO_LOCK
- common-boundary 2↔3 identification;
- exact unit spectral response;
- exact degree-resolved Laplacian response;
- isolated common-basis update ranks;
- positive weighted-Hodge response family.

### OPEN
- source-derived scalar move cost;
- launch/event selector;
- physical interpretation of move rates;
- general external-mesh response theorem beyond the local patch.

**Physical promotion:** 0.

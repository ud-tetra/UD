# UD Native Hodge Action–Phase Specific Scale Theorem v0.1

**Status:** `EXACT INTERNAL / AUTO_LOCK`  
**Carrier:** single filled \(K_4\) active Hodge sector  
**Depends on POC-1 response selector:** `NO`  
**Physical promotion:** `0`

## 1. Exact carrier

The current single-cell Hodge carrier supplies

\[
P_2=I-P_{H_0}=-\frac{\mathcal A^2}{4},
\qquad
\Omega=(-\mathcal A^2)^{1/2}=2P_2,
\]

and on the active sector

\[
J=\mathcal A\Omega^+=\frac{\mathcal A}{2},
\qquad
J^2=-I.
\]

For active state \(x=P_2x\), define

\[
a:=\|x\|^2.
\]

The exact lifted Hodge action is

\[
\boxed{\mathcal I_{\rm Hodge}=\frac12a\,\Delta\widetilde\phi.}
\]

The native action-dimensional unit is

\[
\boxed{\mathcal A_0=\frac{B_0a_0^2}{\tau_0}.}
\]

Define

\[
\mathcal S_{\rm native}:=\mathcal A_0\mathcal I_{\rm Hodge}.
\]

No physical \(\hbar\) enters these definitions.

## 2. Specific native action–phase scale

For \(a>0\) and \(\Delta\widetilde\phi\neq0\), define

\[
\alpha_{\mathcal A}:=
\frac{\mathcal S_{\rm native}}{a\,\Delta\widetilde\phi}.
\]

Then

\[
\alpha_{\mathcal A}
=
\frac{\mathcal A_0(\frac12a\Delta\widetilde\phi)}{a\Delta\widetilde\phi}
=
\boxed{\frac{\mathcal A_0}{2}}.
\]

Hence

\[
\boxed{\alpha_{\mathcal A}=\frac12\frac{B_0a_0^2}{\tau_0}.}
\]

This is exact, amplitude-independent, and action-dimensional. It is not yet physical \(\hbar\).

## 3. Closed-cycle cross-check

The single-cell active frequency is \(2\) in native parameter \(s\). One recurrence has

\[
s=\pi,
\qquad
\Delta\widetilde\phi=2\pi.
\]

For winding \(n\in\mathbb Z\),

\[
\Delta\widetilde\phi_n=2\pi n,
\qquad
\mathcal I_n=\pi na,
\qquad
\mathcal S_{{\rm native},n}=\pi na\mathcal A_0.
\]

Therefore for every \(n\neq0\),

\[
\boxed{
\frac{\mathcal S_{{\rm native},n}}{a\Delta\widetilde\phi_n}
=
\frac{\mathcal A_0}{2}.
}
\]

Clock arithmetic is important here:

\[
2\pi n\equiv0\pmod{2\pi}
\]

while \(\mathcal S_{{\rm native},n}\) is generally nonzero. Endpoint phase alone therefore cannot recover accumulated action.

## 4. Independent energy/frequency cross-check

The canonical spectral Hamiltonian is

\[
H_{\rm Hodge}(x)=\frac12\langle x,\Omega x\rangle.
\]

On \(E_2\), \(\Omega x=2x\), so

\[
\boxed{H_{\rm Hodge}=a.}
\]

With native dimensional energy

\[
E_{\rm native}:=\frac{\mathcal A_0}{\tau_0}a
\]

and native dimensional time \(t=\tau_0s\), the Hodge phase rate is

\[
\dot{\widetilde\phi}=\frac2{\tau_0}.
\]

Thus

\[
\boxed{
\frac{E_{\rm native}}{a\dot{\widetilde\phi}}
=
\frac{\mathcal A_0}{2}.
}
\]

The action-integral and energy/frequency derivations therefore agree exactly.

## 5. Normalized-ray corollary

For

\[
\widehat x=\frac{x}{\sqrt a},
\qquad
\|\widehat x\|^2=1,
\]

\[
\boxed{
\mathcal S_{\rm native}[\widehat x]
=
\frac{\mathcal A_0}{2}\Delta\widetilde\phi.
}
\]

One recurrence gives

\[
\boxed{\mathcal S_{\rm spinor,rec}^{\rm native}=\pi\mathcal A_0,}
\]

matching the existing native recurrence anchor.

This is an explicit normalized representative of a projective ray; it does not prove physical support quantization.

## 6. Earlier amplitude no-go preserved

The prior source result

\[
\text{discrete receipts}\not\Rightarrow a=1
\]

remains valid.

The repair is not to assert \(a=1\), but to derive the intensive invariant

\[
\boxed{
\frac{\mathcal S_{\rm native}}{a\Delta\widetilde\phi}=\frac{\mathcal A_0}{2}.
}
\]

Therefore:

- `EXACT INTERNAL`: \(\alpha_{\mathcal A}=\mathcal A_0/2\);
- `OPEN PHYSICAL BRIDGE`: whether a normalized physical quantum-state correspondence identifies this scale with \(\hbar\).

## 7. Scope

This theorem is exact on the single-cell \(K_4\) active sector. It does not automatically universalize to glued carriers with multiple frequencies, and it does not establish quantum identity, Born probabilities, physical time/energy, a continuum limit, or physical \(\hbar\).

\[
\boxed{\text{Physical promotion}=0.}
\]

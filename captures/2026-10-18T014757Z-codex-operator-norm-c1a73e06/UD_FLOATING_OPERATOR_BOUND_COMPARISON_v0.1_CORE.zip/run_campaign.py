from pathlib import Path
import subprocess,json,sys,time,hashlib
P=Path(__file__).resolve().parent;f=json.loads((P/'CAMPAIGN_FREEZE.json').read_text());runs=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in f['code_sha256'].items():assert sha(P/n)==h
for c in f['cases']:
 n=c['case'];assert sha(P/c['record_path'])==c['record_sha256']
 for stage,args in [('original_proposer',['propose_complementary.py',str(P/c['record_path']),str(P/'inputs/FROZEN_CONTRACT.json'),str((P/c['original_proposal_path']).parent)]),('captured_floating_proposer',['instrumented_proposer.py',str(P/c['record_path']),str(P/'inputs/FROZEN_CONTRACT.json'),str(P/f'results/{n}')]),('exact_operator_and_frobenius_verifier',['certify_operator.py',n])]:
  t=time.monotonic()
  with (P/f'{stage}-{n}.log').open('x') as log:r=subprocess.run([sys.executable,*args],stdout=log,stderr=subprocess.STDOUT,cwd=P)
  runs.append({'case':n,'stage':stage,'returncode':r.returncode,'seconds':time.monotonic()-t});(P/'RUN_EXECUTIONS.json').write_text(json.dumps(runs,indent=2));assert r.returncode==0
print(json.dumps(runs,indent=2))

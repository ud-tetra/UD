# Gauge coupling constants from tetrahedral combinatorics

## Authors
Benjamin Walker Mayes (corresponding), Arthur Eugene Mayes,
Dustin Huff, Brayden Ross Sanders, Jonathan Engle,
Jeffrey A. Dewey, Brandon Bevin, A. Christopher Beckingham

## Files
- `UD_AIP_GaugeCouplings.tex` — Main manuscript (RevTeX 4.1, AIP substyle)
- `aiptemplate.tex` — AIP template reference
- `Makefile` — Build script
- `README.md` — This file

## Build
```
make
```
Requires `pdflatex` and the `revtex4-1` package (typically from `texlive-publishers`).

## Abstract
We derive α_s(m_Z) = 129/(112π²), sin²θ_W(m_Z) = 3/13, and
α_EM⁻¹(m_Z) = 13π² from the combinatorial geometry of the
complete graph K₄ with zero free parameters.

## Key Results
| Observable | Formula | Prediction | Measured | Error |
|-----------|---------|-----------|---------|-------|
| α_s(m_Z) | 129/(112π²) | 0.1167 | 0.1180(9) | 1.1% |
| sin²θ_W(m_Z) | 3/13 | 0.2308 | 0.23121(4) | 0.19% |
| α_EM⁻¹(m_Z) | 13π² | 128.3 | 127.951(9) | 0.28% |

## DOI
Zenodo: 10.5281/zenodo.19582493

#!/usr/bin/env python3
"""Independent arithmetic-form verification of v0.9 conditional reservoir dynamics.
Only fractions and Python stdlib; no SymPy/NumPy, no empirical calibration.
"""
from fractions import Fraction as Q
from itertools import combinations, product

edges=list(combinations(range(4),2))
faces=list(combinations(range(4),3))

def step(rho,res,beta=(1,)*4,tau=(1,)*6):
    open_bit=[int(v>0) for v in res]
    gate=[open_bit[u]*open_bit[v]*beta[u]*beta[v]*tau[k] for k,(u,v) in enumerate(edges)]
    j=[Q(-gate[k],4)*(rho[v]-rho[u]) for k,(u,v) in enumerate(edges)]
    p=list(rho)
    for k,(u,v) in enumerate(edges):
        p[u]-=j[k];p[v]+=j[k]
    s=[(res[k]-p[k])/4 for k in range(4)]
    nxt=[p[k]+s[k] for k in range(4)]
    rs=[res[k]-s[k] for k in range(4)]
    f=[]
    for a,b,c in faces:
        f.append(j[edges.index((b,c))]-j[edges.index((a,c))]+j[edges.index((a,b))])
    return nxt,rs,p,s,j,f,gate

def sumsq(x):return sum((t*t for t in x),Q(0))
count=0;nonflat=0
for pat in product((0,1),repeat=4):
  for v in range(4):
    x=[Q(int(k==v)) for k in range(4)]
    r=list(map(Q,pat))
    a,b,p,s,j,f,g=step(x,r)
    mass=sum(x)+sum(r)
    assert mass==sum(a)+sum(b)
    assert min(a+b)>=0
    mu=mass/8
    Eold=sumsq([q-mu for q in x+r]);Enew=sumsq([q-mu for q in a+b])
    assert Eold-Enew>=sumsq(f)+Q(3,8)*sumsq([p[k]-r[k] for k in range(4)])
    # The boundary-of-boundary orientation remains exact: -f012+f013-f023+f123=0.
    assert -f[0]+f[1]-f[2]+f[3]==0
    nonflat+=int(any(f))
    count+=1
assert count==64
x=[Q(1),Q(0),Q(0),Q(0)];r=[Q(1),Q(1),Q(1),Q(0)]
a,b,p,s,j,f,g=step(x,r)
assert tuple(g)==(1,1,0,1,0,0)
assert a==[Q(5,8),Q(7,16),Q(7,16),Q(0)]
assert b==[Q(7,8),Q(13,16),Q(13,16),Q(0)]
assert f==[Q(0),Q(1,4),Q(1,4),Q(0)]
print('PASS pure stdlib Fraction: 64 independent stock/gate controls; nonzero face',nonflat)
print('PASS exact first receipt and oriented face closure')
print('PASS exact 8-bin Lyapunov inequality all controls')

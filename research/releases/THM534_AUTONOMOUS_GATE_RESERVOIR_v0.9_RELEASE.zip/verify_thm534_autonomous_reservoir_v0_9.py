#!/usr/bin/env python3
"""THM-534 v0.9 autonomous positive-stock gate candidate: exact + numeric controls.

Development ONLY; chi is a STOCK AVAILABILITY proxy, not derived UD closure.
No physical time, stress energy, Born readout, original THM-534 recovery.
"""
import itertools, json
import sympy as sp
import numpy as np

V=range(4)
E=list(itertools.combinations(V,2))
F=list(itertools.combinations(V,3))
B=sp.zeros(4,6); D=sp.zeros(6,4)
for ei,(u,v) in enumerate(E): B[u,ei]=-1; B[v,ei]=1
for fi,f in enumerate(F):
    for k in range(3): D[E.index(f[:k]+f[k+1:]),fi]=(-1)**k
assert B*D==sp.zeros(4,4)

def update_exact(rho,reserve,beta=None,tau=None):
    beta=tuple([1]*4) if beta is None else tuple(beta)
    tau=tuple([1]*6) if tau is None else tuple(tau)
    chi=tuple(int(bool(reserve[i]>0)) for i in V)
    mask=tuple(chi[u]*chi[v]*beta[u]*beta[v]*tau[ei] for ei,(u,v) in enumerate(E))
    H=sp.diag(*mask)
    j=-H*B.T*rho/4
    p=rho+B*j
    # autonomous source from paired reservoir AFTER diffusion, not imposed s.
    s=(reserve-p)/4
    return (p+s, reserve-s, j, D.T*j, p, s, mask)

rho=sp.Matrix([1,0,0,0])
r=sp.Matrix([1,1,1,0])
rn,rr,j,circ,p,s,mask=update_exact(rho,r)
assert mask==(1,1,0,1,0,0),mask
assert list(j)==[sp.Rational(1,4),sp.Rational(1,4),0,0,0,0], j
assert list(circ)==[0,sp.Rational(1,4),sp.Rational(1,4),0], circ
assert list(p)==[sp.Rational(1,2),sp.Rational(1,4),sp.Rational(1,4),0]
assert list(s)==[sp.Rational(1,8),sp.Rational(3,16),sp.Rational(3,16),0]
assert list(rn)==[sp.Rational(5,8),sp.Rational(7,16),sp.Rational(7,16),0]
assert list(rr)==[sp.Rational(7,8),sp.Rational(13,16),sp.Rational(13,16),0]
assert sum(rho)+sum(r)==sum(rn)+sum(rr)==4
assert D.T*j!=sp.zeros(4,1)
assert all(x>=0 for x in rn) and all(x>=0 for x in rr)
assert mask==tuple(int(bool(rr[u]>0))*int(bool(rr[v]>0)) for u,v in E)

# The all-connected triangle K3 spectrum and the 2-layer exchange eigenvalues
H=sp.diag(*mask); P=sp.eye(4)-B*H*B.T/4
assert P.eigenvals()=={sp.Integer(1):2,sp.Rational(1,4):2}
lam=sp.Rational(1,4)
Mmode=sp.Matrix([[3*lam/4,sp.Rational(1,4)],[lam/4,sp.Rational(3,4)]])
expected={ (15+sp.sqrt(97))/32 : 1,(15-sp.sqrt(97))/32 : 1 }
assert Mmode.eigenvals()==expected, Mmode.eigenvals()

# exact finite-step continuity and Lyapunov budget for a deterministic dynamics
mean=sp.Rational(1,2) # eight total slots contain 4 units
energy=lambda x,y:sum((a-mean)**2 for a in tuple(x)+tuple(y))
for t in range(12):
    nxt,rs,j,F0,p,s,mask=update_exact(rho,r)
    Eold=energy(rho,r); Enew=energy(nxt,rs)
    Eafter_diff=energy(p,r)
    assert sp.simplify(Eold-Eafter_diff-(sum((rho[i]-mean)**2 for i in V)-sum((p[i]-mean)**2 for i in V)))==0
    assert sp.simplify(Eafter_diff-Enew-sp.Rational(3,8)*sum((p[i]-r[i])**2 for i in V))==0
    assert sp.simplify((Eold-Enew)-sum(x*x for x in F0)-sp.Rational(3,8)*sum((p[i]-r[i])**2 for i in V))>=0
    assert mask==(1,1,0,1,0,0)
    assert sum(nxt)+sum(rs)==4
    rho,r=nxt,rs

# Check all 16 support patterns x 4 single-node burdens x 16 boundary
# patterns x 64 edge integrity patterns. 65536 exact state instances, but
# gate and maps can be precomputed from bitmasks. Restrict to 4096 to be fast.
count=0
for chi_bits in itertools.product((0,1),repeat=4):
    reservoir=sp.Matrix(list(chi_bits))
    for bv in itertools.product((0,1),repeat=4):
        for k in range(4):
            rho=sp.eye(4)[:,k]
            for tau_bits in ((1,1,1,1,1,1),(0,0,0,0,0,0),(1,0,1,0,1,0),(0,1,0,1,0,1)):
                a,b,j,F0,p,s,h=update_exact(rho,reservoir,bv,tau_bits)
                assert all(z>=0 for z in a) and all(z>=0 for z in b)
                assert sum(rho)+sum(reservoir)==sum(a)+sum(b)
                assert (D.T*j)==F0
                count+=1
assert count==4096

# Equivariance of complete update under all S4 relabelings (on first witness)
rho=sp.Matrix([1,0,0,0]); r=sp.Matrix([1,1,1,0]); original=update_exact(rho,r)
for perm in itertools.permutations(V):
    pr=sp.zeros(4,1);pp=sp.zeros(4,1)
    for i in V: pr[perm[i]]=r[i];pp[perm[i]]=rho[i]
    output=update_exact(pp,pr)
    for i in V:
        assert output[0][perm[i]]==original[0][i]
        assert output[1][perm[i]]==original[1][i]
    for e,(u,v) in enumerate(E):
        jdx=E.index(tuple(sorted((perm[u],perm[v]))))
        assert output[-1][jdx]==original[-1][e]


# Exact contrast dynamics: F_n = (a_n/4)*(0,1,1,0) on the held active triangle.
lp=(15+sp.sqrt(97))/32
lm=(15-sp.sqrt(97))/32
cp=(sp.sqrt(97)-9)/(2*sp.sqrt(97))
cm=(sp.sqrt(97)+9)/(2*sp.sqrt(97))
rho=sp.Matrix([1,0,0,0]);r=sp.Matrix([1,1,1,0])
for n in range(12):
    a=sp.simplify(cp*lp**n+cm*lm**n)
    assert sp.simplify(rho[0]-rho[1]-a)==0
    nxt,rr,j,ff,p,s,hh=update_exact(rho,r)
    assert ff==sp.Matrix([0,a/4,a/4,0])
    rho,r=nxt,rr

# Reversible oriented rotor candidate: an extra ordered-cycle register (0,1,2).
# It is NOT the Q162 passive gradient law. Positive directed edge transfers
# implement the permutation rho0->rho1->rho2->rho0 with no sources/reservoir.
Rho=sp.Matrix([1,0,0,0])
rotor_faces=[]
for t in range(9):
    k=sp.Matrix([Rho[0],-Rho[2],0,Rho[1],0,0])
    rot_next=Rho+B*k
    assert rot_next==sp.Matrix([Rho[2],Rho[0],Rho[1],Rho[3]])
    assert sum(rot_next)==sum(Rho)
    assert all(v>=0 for v in rot_next)
    rot_face=D.T*k
    assert rot_face[0]==1 and (sp.Matrix([1,-1,1,-1]).T*rot_face)[0]==0
    rotor_faces.append(str(rot_face[0]))
    Rho=rot_next
assert Rho==sp.Matrix([1,0,0,0])

rng=np.random.default_rng(534090)
BF=np.array(B,dtype=float);DF=np.array(D,dtype=float)
maxstock=0.; maxlyapunov=0.; maxfaceclosure=0.; nonuniform=0; nonzero=0
for run in range(32):
    rho=rng.random(4);res=rng.random(4)
    if run%2==0:res[3]=0;rho[3]=0
    total=rho.sum()+res.sum(); mu=total/8
    for t in range(256):
        chi=(res>0).astype(int)
        h=np.array([chi[u]*chi[v] for u,v in E]);nonuniform+=int(0<h.sum()<6)
        j=-(h*(BF.T@rho))/4
        p=rho+BF@j
        s=(res-p)/4
        rho_new=p+s;res_new=res-s
        f=DF.T@j
        Ebefore=((rho-mu)**2).sum()+((res-mu)**2).sum()
        Eafter=((rho_new-mu)**2).sum()+((res_new-mu)**2).sum()
        waste=float((Ebefore-Eafter)-(f@f+3/8*((p-res)@(p-res))))
        maxlyapunov=max(maxlyapunov,max(0,-waste))
        maxstock=max(maxstock,abs(rho_new.sum()+res_new.sum()-total))
        maxfaceclosure=max(maxfaceclosure,abs(np.array([(-1)**k for k in range(4)])@f))
        if np.linalg.norm(f)>1e-12: nonzero+=1
        assert min(rho_new.min(),res_new.min())>=-1e-12
        rho,res=rho_new,res_new
assert maxstock<1e-11 and maxlyapunov<1e-11 and maxfaceclosure<1e-12
record={"status":"PASS_SCOPED","exact_control_states":count,"S4_permutations":24,
"numerical_steps":32*256,"nonuniform_mask_steps":nonuniform,"nonzero_face_steps":nonzero,
"max_total_stock_drift":maxstock,"max_lyapunov_budget_violation":maxlyapunov,
"max_oriented_face_closure_error":maxfaceclosure,"first_mask":[1,1,0,1,0,0],
"first_vertex_next":["5/8","7/16","7/16","0"],
"first_reservoir_next":["7/8","13/16","13/16","0"],
"first_face_circulation":["0","1/4","1/4","0"],
"closure_status":"candidate stock-availability only; not frozen UD χ admissibility",
"rotor_9_steps_face012":rotor_faces,
"exact_contrast_eigenvalues":["(15+sqrt(97))/32","(15-sqrt(97))/32"],
"physical_promotion":0}
print(json.dumps(record,indent=2))

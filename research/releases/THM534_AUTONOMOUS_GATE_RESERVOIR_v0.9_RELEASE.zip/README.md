# THM-534 v0.9 — finite autonomous gate and positive-stock reservoir candidate

**Date:** 2026-10-21. **Classification:** EXACT CONDITIONAL/CANDIDATE; source-complete *finite model*, NOT derivation of a canonical UD microscopic law. Physical promotion 0.

GitHub manuscript: https://github.com/ud-tetra/UD/blob/research/thm-534-theorem-session-audit-20261021/research/theorems/THM534_AUTONOMOUS_GATE_RESERVOIR_v0.9.md
Claim ledger: https://github.com/ud-tetra/UD/blob/research/thm-534-theorem-session-audit-20261021/research/theorems/THM534_AUTONOMOUS_GATE_CLAIM_LEDGER_DELTA_v0.9.md
PR: https://github.com/ud-tetra/UD/pull/346
Issue: https://github.com/ud-tetra/UD/issues/347

## State and model
Nonnegative vertex burden rho_v and a **different** nonnegative local vertex stock reservoir r_v; binary boundary and transport-integrity controls. Candidate availability chi_v=1[r_v>0] and locally factored gate h_uv=chi_u chi_v beta_u beta_v tau_uv. The latter is a **provisional selection law**, not the UD closure predicate.

With signed B1 and B2 on filled Delta^3, Q162 source-bound normalized flux j=-H B1^T rho/4. Let p=rho+B1j and F=B2^Tj. Candidate reciprocal reservoir exchange s=(r-p)/4 sets rho'=p+s, r'=r-s. This conserves total rho+r and remains nonnegative. The use of a second 1/4 for reservoir exchange is a declared modeling choice, **not derived** from the historical Q161 attempt constant.

The exact passive model satisfies E-E' >= ||F||^2+(3/8)||p-r||^2, so the full reservoir cannot sustain asymptotically nonzero F. A distinct oriented permutation rotor can, but is not Q162 and needs an additional native mechanism to select orientation/scheduling.

## Reproduction
`python verify_thm534_autonomous_reservoir_v0_9.py`: exact witness, 4,096 exact controls, 24 relabelings, geometric decay, 9 rotor controls and 8,192 finite numerical steps.

`python verify_thm534_reservoir_independent_v0_9.py`: independently coded Fraction arithmetic checks of 64 additional initial/boundary controls, exact Lyapunov and signed face closure. Distinct code implementation but same constructor, so not independent outside review.

Outputs and file hashes recorded in `RESULTS_v0.9.json`, `INDEPENDENT_ARITHMETIC_RECEIPT.txt` and `MANIFEST_v0.9.json`. The full executed script here is longer than the compact GitHub adaptation; no byte identity is asserted.

## Open gates
Actual UD cell-closure/boundary update and admissibility of an open-faced packet state, physical burden reservoir identification, native source/route action, reversible orientation, physical time and energy, historical THM-534 hopping probabilities, Born bridge, and independent reviewer. No physical promotion.

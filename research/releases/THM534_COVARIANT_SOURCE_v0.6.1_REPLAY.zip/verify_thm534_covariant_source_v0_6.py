#!/usr/bin/env python3
"""THM534 v0.6: exact relative U1 seam forcing and finite Cayley continuity.
Requires sympy, numpy; selected j=4 is a declared diagnostic, not a calibration.
"""
from itertools import combinations
from fractions import Fraction
import sympy as sp
import numpy as np

V=list(range(4)); E=list(combinations(V,2)); F=list(combinations(V,3))
B1=sp.zeros(4,6); B2=sp.zeros(6,4); B3=sp.zeros(4,1)
for k,(a,b) in enumerate(E): B1[a,k]=-1; B1[b,k]=1
for k,f in enumerate(F):
    for i in range(3): B2[E.index(f[:i]+f[i+1:]),k]=(-1)**i
for i in range(4): B3[F.index(tuple(V[:i]+V[i+1:])),0]=(-1)**i
assert B1*B2==sp.zeros(4,4) and B2*B3==sp.zeros(6,1)
assert B1.T*B1+B2*B2.T==4*sp.eye(6)
e=E.index((1,2)); f=F.index((0,1,2)); q=B2[e,f]
phi,j=sp.symbols('phi j',real=True)
z=(sp.Integer(3)+sp.I*j)/sp.sqrt(9+j*j)
assert sp.simplify(z*sp.conjugate(z))==1
N=B2.copy(); N[e,f]=q*z
L=B1*N; U=N*B3
assert sp.simplify(L.norm()**2-2*(z-1)*sp.conjugate(z-1))==0
assert sp.simplify(U.norm()**2-(z-1)*sp.conjugate(z-1))==0
assert sp.simplify((L.norm()**2+U.norm()**2)/2-3*(1-3/sp.sqrt(9+j*j)))==0
# Candidate source functional V_j=3(1-cos(phi))-j sin(phi).
# Its global minimum is 3-sqrt(9+j^2) and is unique for all real j.
assert sp.simplify(3*(1-3/sp.sqrt(9+j*j))-j*j/sp.sqrt(9+j*j)-(3-sp.sqrt(9+j*j)))==0
zs=sp.simplify(z.subs(j,4)); assert zs==(3+4*sp.I)/5
Ns=N.subs(j,4)
Ls=B1*Ns; Us=Ns*B3
assert sp.simplify(Ls.norm()**2-sp.Rational(8,5))==0
assert sp.simplify(Us.norm()**2-sp.Rational(4,5))==0
assert sp.simplify((Ls.norm()**2+Us.norm()**2)-sp.Rational(12,5))==0
# Full 15D skew-Hermitian transport with N as distinct covariant coupling;
# original B2 is retained in the independent topological chain complex.
A=sp.zeros(15)
for off1,off2,B in ((0,4,B1),(4,10,Ns),(10,14,B3)):
    A[off1:off1+B.rows,off2:off2+B.cols]=B
    A[off2:off2+B.cols,off1:off1+B.rows]=-B.conjugate().T
assert A+A.conjugate().T==sp.zeros(15)
assert Ls!=sp.zeros(4,4) and Us!=sp.zeros(6,1)
assert B1*Us == Ls*B3
# Cayley transform exact rational+complex finite-event step.
h=sp.Rational(1,2)
Ucy=(sp.eye(15)-h*A/2).inv()*(sp.eye(15)+h*A/2)
assert sp.simplify(Ucy.conjugate().T*Ucy-sp.eye(15))==sp.zeros(15)
psi0=sp.zeros(15,1);psi0[4+e,0]=1
psi1=Ucy*psi0; midpoint=(psi0+psi1)/2
assert sp.simplify(sum(sp.conjugate(v)*v for v in psi1)-1)==0
# Exact local signed flux receipt at every degree cell.
for a in range(15):
    d=sp.simplify(sp.conjugate(psi1[a])*psi1[a]-sp.conjugate(psi0[a])*psi0[a])
    current=sp.simplify(sum(h*(sp.conjugate(midpoint[a])*A[a,b]*midpoint[b]+midpoint[a]*sp.conjugate(A[a,b])*sp.conjugate(midpoint[b])) for b in range(15)))
    assert sp.simplify(d-current)==0
# Check edge current redistribution equals negative complement current.
edge_delta=sp.simplify(sum(sp.conjugate(psi1[k])*psi1[k]-sp.conjugate(psi0[k])*psi0[k] for k in range(4,10)))
other_delta=sp.simplify(sum(sp.conjugate(psi1[k])*psi1[k]-sp.conjugate(psi0[k])*psi0[k] for k in list(range(0,4))+list(range(10,15))))
assert sp.simplify(edge_delta+other_delta)==0
print('PASS: chain topology fixed, covariant curvature and upper source distinct')
print('PASS: candidate variational source exact minimizer z=(3+ij)/sqrt(9+j^2)')
print('PASS: diagnostic j=4: z=(3+4i)/5, ||lower||^2=8/5, ||upper||^2=4/5')
print('PASS: finite-step Cayley evolution unitary and 15 local continuity receipts EXACT')
print('PASS: edge loss receipted by nonedge sectors; edge_delta =',edge_delta)
print('NOTE: no native derivation of j; no identification of amplitude norm with physical burden')

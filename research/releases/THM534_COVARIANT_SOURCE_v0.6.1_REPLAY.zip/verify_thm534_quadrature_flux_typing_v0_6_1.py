#!/usr/bin/env python3
"""THM-534 v0.6.1 exact quadrature/continuity-current provenance audit."""
import sympy as s
q=s.Integer(-1)
# real-normalized edge and imaginary face state
x=s.sqrt(2)/2; y=s.I*q*s.sqrt(2)/2
phase=s.simplify(2*s.im(s.conjugate(x)*q*y))
flow=s.simplify(2*s.re(s.conjugate(x)*q*y))
assert phase==1 and flow==0
# conjugate state leaves magnitudes fixed, reverses phase quadrature
yp=s.conjugate(y)
assert s.simplify(abs(y)**2-abs(yp)**2)==0
assert s.simplify(2*s.im(s.conjugate(x)*q*yp))==-1
# real state has zero phase quadrature but nonzero norm-flow bilinear
xr=s.sqrt(2)/2;yr=q*s.sqrt(2)/2
assert s.simplify(2*s.im(s.conjugate(xr)*q*yr))==0
assert s.simplify(2*s.re(s.conjugate(xr)*q*yr))==1
print('PASS exact phase-quadrature not equal continuity flux (q=1, flow=0)')
print('PASS equal amplitude moduli give opposite signed phase quadrature')
print('PASS real state phase quadrature=0 but continuity flow=1')
print('CONCLUSION: phase-source rule remains proposed; packet-burden/current bridge OPEN')

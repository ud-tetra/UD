"""Numerical reproducible endogenous phase-current trial for THM-534 v0.6.
This is a constitutive candidate, not a UD-primitive derivation.
"""
import numpy as np
from itertools import combinations
from scipy.linalg import solve
V=range(4); E=list(combinations(V,2)); F=list(combinations(V,3))
B1=np.zeros((4,6),complex);B2=np.zeros((6,4),complex);B3=np.zeros((4,1),complex)
for k,(a,b) in enumerate(E):B1[a,k]=-1;B1[b,k]=1
for k,ff in enumerate(F):
    for i in range(3):B2[E.index(ff[:i]+ff[i+1:]),k]=(-1)**i
for i in range(4):B3[F.index(tuple(list(V)[:i]+list(V)[i+1:])),0]=(-1)**i
e=E.index((1,2));f=F.index((0,1,2));q=B2[e,f]

def generator(z):
    N=B2.copy(); N[e,f]=q*z
    A=np.zeros((15,15),complex)
    for i,j,B in ((0,4,B1),(4,10,N),(10,14,B3)):
        A[i:i+B.shape[0],j:j+B.shape[1]]=B
        A[j:j+B.shape[1],i:i+B.shape[0]]=-B.conj().T
    return A,N

def current(psi):
    return float(2*np.imag(np.conj(psi[4+e])*q*psi[10+f]))

h=0.1
psi=np.zeros(15,complex);psi[4+e]=1/np.sqrt(2);psi[10+f]=1j*q/np.sqrt(2)
initialnorm=float(np.vdot(psi,psi).real)
assert np.isclose(current(psi),1)
maxerr=0.0;js=[];otheredge=[]
for n in range(30):
    j=current(psi)
    js.append(j)
    z=(3+1j*j)/np.sqrt(9+j*j)
    A,N=generator(z)
    nxt=solve(np.eye(15)-h*A/2, (np.eye(15)+h*A/2)@psi)
    mid=(psi+nxt)/2
    delta=np.abs(nxt)**2-np.abs(psi)**2
    flux=np.zeros(15)
    for a in range(15):
        for b in range(15):
            flux[a]+=2*h*np.real(np.conj(mid[a])*A[a,b]*mid[b])
    maxerr=max(maxerr,float(np.max(np.abs(delta-flux))))
    if n==0:
        otheredge=[float(np.abs(nxt[4+k])**2) for k in range(6) if k!=e]
    psi=nxt
assert maxerr<2e-14
assert abs(float(np.vdot(psi,psi).real)-initialnorm)<1e-13
assert max(js)>0.01
# control: all-real initial amplitudes must remain real if j=0 and source map flat
c=np.zeros(15,complex);c[4+e]=1
for n in range(10):
    j=current(c);assert j==0
    A,N=generator(1)
    c=solve(np.eye(15)-h*A/2, (np.eye(15)+h*A/2)@c)
    assert np.max(np.abs(c.imag))<1e-14
print('PASS: state-dependent signed phase-current j_n=2 Im(conj(edge) B2_{ef} face)')
print('PASS: j0=1, z0=(3+i)/sqrt(10), 30 Cayley updates norm-preserving')
print('PASS: max local flux residual',maxerr)
print('PASS: all-real initial subspace remains j=0 and flat after 10 updates')
print('diagnostics: j range',min(js),max(js),'non-source-edge populations after step1',otheredge)

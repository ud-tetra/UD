# THM-534 v0.8 — hard-gate selection and circulation-budget proof

Status: EXACT CONDITIONAL / NO-GO / candidate inputs only. Physical promotion 0.
Date: 2026-10-21.

This release reproduces the source-facing v0.8 finite proofs and constructor controls.
It is not the source-complete THM-534 micro-event derivation and does not predict physical observables.

## Main results
S23: The Q156 hard-gate factorization does not uniquely select a state-to-mask map; local versus whole-cell closure are explicit equivariant countermodels.
S24: Deterministic equivariance cannot break a perfectly S4-symmetric state into a nonuniform edge mask.
S25: With closed normalized Q162 relaxation and arbitrary time-dependent 0<=H_n<=I, sum_{n<N} ||B2^T j_n||^2 <= D_0-D_N <= D_0; hence F_n -> 0.
S26: A replenishing signed zero-sum burden-source vector requires its own positive variance compensation budget; an explicit reset shows this is possible but NOT a derived UD source law.
S27: Vertex continuity B1 k=s does not uniquely determine edge route k, because k+B2 y has the same vertex receipt but modified face circulation.
S28: Fixed nonuniform mask can persist while curvature decays exactly F_n=4^{-n} F_0.

## Source provenance
- UD_COEFFICIENT_PROVENANCE_LEDGER_v0.39(2).md Q153, Q156, Q162, Q167.
- THM534_BURDEN_GATE_CURVATURE_CONTINUITY_v0.7.md.

## Reproduction
Install SymPy and NumPy, then run:

    python verify_thm534_gate_selection_v0_8.py

Input seed 534080 for 16x256 numerical controls; all symbolic checks use exact rationals.
The printed output is recorded in THM534_GATE_SELECTION_v0.8_VERIFICATION.txt.

## Recorded correction
A preliminary extra assertion that the *unweighted* sum of four face-circulation components vanishes failed. It is not the correct topological closure test. Correct signed test is B3^T F=0. Preliminary assertion removed before the released successful run.

## Limits
The binary vertex chi/beta and edge-integrity tau selectors are constructed countermodels, not recovered canonical packet closure/transport laws. A local failure chi_3=0 may not be an admitted retained filled tetrahedron. No physical time, energy, electromagnetic field, Born normalization or original THM-534 transition probabilities are established. Independent review pending.

GitHub manuscript and proof ledger: branch research/thm-534-theorem-session-audit-20261021, draft PR #346, issue #347.

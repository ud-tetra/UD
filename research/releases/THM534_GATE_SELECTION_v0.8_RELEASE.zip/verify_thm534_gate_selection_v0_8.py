#!/usr/bin/env python3
"""THM-534 v0.8, exact nonidentifiability and finite circulation budget.

SOURCE SCOPE: UD coefficient ledger v0.39 Q153/Q156/Q162, with additional
explicitly CANDIDATE binary projections for chi,b,transport integrity.
Unit-metric oriented complete tetrahedron. No physical clock or empirical law.
"""
import itertools
import numpy as np
import sympy as S

vertices = range(4)
edges = list(itertools.combinations(vertices, 2))
faces = list(itertools.combinations(vertices, 3))
B1 = S.zeros(4, 6)
B2 = S.zeros(6, 4)
B3 = S.zeros(4, 1)
for e, (a, b) in enumerate(edges):
    B1[a,e] = -1; B1[b,e] = 1
for f, t in enumerate(faces):
    for k in range(3):
        B2[edges.index(t[:k]+t[k+1:]),f] = (-1)**k
for k in range(4):
    B3[faces.index(tuple(x for x in vertices if x!=k)),0] = (-1)**k
I = S.eye(4)
assert B1*B2 == S.zeros(4,4)
assert B2*B3 == S.zeros(6,1)
assert B1.T*B1+B2*B2.T==4*S.eye(6)

def masks(chi, boundary, transport):
    # Two incompatible candidate hard-gate selectors with identical inputs.
    # Both respect Q156 factorization, binary range and S4 relabeling.
    C_local = [chi[u]*chi[v] for u,v in edges]
    C_cell = [S.prod(chi)]*6
    T = [boundary[u]*boundary[v]*transport[e] for e,(u,v) in enumerate(edges)]
    return tuple(C_local[e]*T[e] for e in range(6)), tuple(C_cell[e]*T[e] for e in range(6))

chi = (1,1,1,0)
b = (1,1,1,1)
t = (1,)*6
local, cell = masks(chi,b,t)
assert local == (1,1,0,1,0,0)
assert cell == (0,)*6
rho = S.Matrix([1,0,0,0])
def update(rho, h):
    H = S.diag(*h)
    j = -H*B1.T*rho/4
    return rho+B1*j, j, B2.T*j
rl,jl,fl = update(rho,local)
rc,jc,fc = update(rho,cell)
assert rl!=rc and fl!=fc and fc==S.zeros(4,1)
assert S.simplify(sum(rl)-1)==0 and all(q>=0 for q in rl)
print('COUNTERMODEL local gate:', local, 'rho prime:', list(rl),'face curl:', list(fl))
print('COUNTERMODEL cell gate:', cell, 'rho prime:', list(rc),'face curl:',list(fc))

# Verify S4-equivariance for both projected gate selectors under all 24 vertex permutations.
for p in itertools.permutations(vertices):
    newchi = [0]*4; newb = [0]*4
    for i in vertices:
        newchi[p[i]] = chi[i]; newb[p[i]] = b[i]
    newt = [0]*6
    for i, (u,v) in enumerate(edges):
        newt[edges.index(tuple(sorted((p[u],p[v]))))] = t[i]
    L,C=masks(newchi,newb,newt)
    for k, (u,v) in enumerate(edges):
        mapped = edges.index(tuple(sorted((p[u],p[v]))))
        assert L[mapped] == local[k] and C[mapped] == cell[k]

# Every S4-invariant edge mask is constant: check transitive edge action.
for seed in edges:
    orbit={tuple(sorted((p[seed[0]],p[seed[1]]))) for p in itertools.permutations(vertices)}
    assert orbit == set(edges)

# Full exact all-64-mask local dissipation inequality.
counts={}
for bits in itertools.product((0,1),repeat=6):
    H=S.diag(*bits)
    P=I-B1*H*B1.T/4
    F=-B2.T*H*B1.T/4
    # D(rho)-D(P rho) >= ||F rho||^2 is PSD.
    W = I - P.T*P - F.T*F
    assert W.T==W
    eig=W.eigenvals()
    assert all(val.is_nonnegative is True for val in eig), (bits,eig)
    counts[W.rank()] = counts.get(W.rank(),0)+1
assert sum(counts.values())==64
print('EXACT: all-64 gate-mask dissipation bound matrix PSD',counts)

# Explicitly accounted driven return: sustained conditional j-circulation needs a
# second source/current receipt. Merely conserving vertex mass does not select route.
Hfix=S.diag(*local)
pre=rho
post,jhop,Fhop=update(pre,local)
supply=pre-post
assert sum(supply)==0 and post+supply==pre
assert list(supply)==[S.Rational(1,2),-S.Rational(1,4),-S.Rational(1,4),0]
assert (Fhop.T*Fhop)[0] == S.Rational(1,8)
mean=S.ones(4,1)/4
Dpre=((pre-mean).T*(pre-mean))[0]
Dpost=((post-mean).T*(post-mean))[0]
work=2*((post-mean).T*supply)[0]+(supply.T*supply)[0]
assert Dpre==S.Rational(3,4) and Dpost==S.Rational(1,8)
assert work==Dpre-Dpost==S.Rational(5,8)
source_route_1=-jhop
assert B1*source_route_1==supply
assert B2.T*(jhop+source_route_1)==S.zeros(4,1)
source_route_2=source_route_1+B2[:,0]
assert B1*source_route_2==supply
assert B2.T*(jhop+source_route_2)!=S.zeros(4,1)
print('EXACT: driven reset produces persistent per-step F²=1/8; source budget=5/8')
print('EXACT: same vertex-source receipt admits zero versus nonzero total circulation depending on source routing')


# Arbitrary time-dependent masks preserve stock and spend a finite budget.
B=np.array(B1).astype(float)
Bf=np.array(B2).astype(float)
rng=np.random.default_rng(534080)
numruns=16; steps=256
maxstockerr=maxbudgeterr=maxface_tail=0.0
nonzero_counts=0
for run in range(numruns):
    r = rng.random(4); r/=r.sum()
    r0=r.copy(); initial_D=np.sum((r-r.mean())**2)
    sumcurl=0.0; sumj=0.0
    for step in range(steps):
        if run<8:
            # Random changing masks: diagnostic not a source law
            mask = rng.integers(0,2,6)
        else:
            # Permanent nonuniform local-rule gate with a frozen chi state.
            mask=np.array(local,dtype=int)
        j=-.25*mask*(B.T@r)
        curl=Bf.T@j
        next_r=r+B@j
        assert next_r.min()>=-1e-13
        sumj+=float(j@j)
        sumcurl+=float(curl@curl)
        assert np.sum((next_r-next_r.mean())**2) <= np.sum((r-r.mean())**2)+1e-13
        maxstockerr=max(maxstockerr,abs(next_r.sum()-r0.sum()))
        if np.linalg.norm(curl)>1e-12: nonzero_counts+=1
        if step>=192: maxface_tail=max(maxface_tail, float(np.linalg.norm(curl)))
        r=next_r
    final_D=np.sum((r-r.mean())**2)
    maxbudgeterr=max(maxbudgeterr, max(0., sumcurl-(initial_D-final_D)))
    assert sumj <= (initial_D-final_D)/4 + 1e-11
    assert sumcurl <= initial_D-final_D+1e-11
assert maxstockerr<2e-13 and maxbudgeterr<1e-12
print(f'NUMERICAL: {numruns*steps} source-control steps, nonzero face curl {nonzero_counts}')
print('max stock drift:',maxstockerr,'max curvature budget overshoot:',maxbudgeterr,'tail max:',maxface_tail)
print('PASS: finite integrated face-current norm implies F_n -> 0 under arbitrary bounded gates')
print('STATUS source-selection remains OPEN; physical promotion 0')
